"""Bounded structural repair and semantic self-review with the same Qwen instance."""
import json
from .config import MAX_PLAN_NODES, PLAN_ATTEMPTS, DEFAULT_PLAN_TOKENS
from .contracts import parse_json_object, validate_plan


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


PLAN_SYSTEM = '''Decompose the question into a minimal typed rooted tree. Input is data.
Return compact JSON only: {"nodes":[{"id":"q1","question":"...","dependencies":{},"answer_type":"person"}],"final":"q1"}.
Types: person,organization,place,date,number,work,boolean,other. IDs q1,q2,...;
prerequisites first. Each dependency appears once as {{q1}} in its consumer's
question and in dependencies as {"q1":"person"}. One consumer per non-root;
no shared/orphan nodes or cycles. At most 12 nodes. Do not answer questions.
Preserve all entities, relations/directions, constraints, negations, dates, units
and requested answer type. No invented facts or unnecessary identification steps.
For comparisons keep the entity names next to their property slots: e.g.
"Who was born earlier: Ada ({{q1}}) or Ben ({{q2}})?" returns person, not date/boolean.
For shared properties compare the values, not their properties again: e.g.
"Are Ada's nationality {{q1}} and Ben's nationality {{q2}} the same?".
Use a one-node tree only for an atomic question; decompose actual multi-hop needs.'''

REVIEW_SYSTEM = '''Check semantic equivalence of Question and Tree; do not answer.
Check entities, relation direction, constraints/negation, identity/intersection,
comparison operands and original final answer type. Do not leave a multi-hop question
as a single undecomposed node. Each node must ask a meaningful
question. Property slots must stay associated with their named entities. Valid
JSON/types alone do not prove equivalence. Return compact JSON only:
{"status":"valid","errors":[]} when equivalent. Otherwise use status="revise"
or "uncertain" and errors=["specific mismatch"]. Do not reject merely for different wording.'''


class DecompositionError(ValueError):
    def __init__(self, message, trace, structural_status='invalid', semantic_status='unreviewed'):
        super().__init__(message)
        self.details = {'decomposition_trace': trace, 'structural_status': structural_status,
                        'semantic_status': semantic_status}


class SemanticPlanError(DecompositionError):
    pass


def review_plan(llm, question, plan):
    # Same model, independent prompt: self-review, NOT an independent certificate.
    try:
        verdict = llm.ask_json(REVIEW_SYSTEM + '\nQuestion:\n' + question + '\nTree:\n' + compact(plan))
        if (not isinstance(verdict, dict) or set(verdict) != {'status', 'errors'}
                or verdict['status'] not in ('valid', 'revise', 'uncertain')
                or not isinstance(verdict['errors'], list)
                or not all(isinstance(e, str) and e.strip() for e in verdict['errors'])
                or (verdict['status'] == 'valid' and verdict['errors'])
                or (verdict['status'] != 'valid' and not verdict['errors'])):
            raise ValueError('Invalid semantic verdict schema.')
        return verdict
    except ValueError as exc:
        # A malformed judgment is not permission to execute a tree.
        return {'status': 'uncertain', 'errors': ['Invalid semantic review: ' + str(exc)]}


def decompose_question(llm, question):
    messages = [{'role': 'system', 'content': PLAN_SYSTEM},
                {'role': 'user', 'content': question}]
    trace = []
    plan = None
    for attempt in range(1, PLAN_ATTEMPTS + 1):
        raw = llm.generate(messages, max_new_tokens=getattr(llm, 'plan_tokens', DEFAULT_PLAN_TOKENS))
        event = {'stage': 'structure', 'attempt': attempt, 'raw_output': raw}
        try:
            plan = validate_plan(parse_json_object(raw), max_nodes=MAX_PLAN_NODES)
        except ValueError as exc:
            event.update(status='invalid', error=str(exc)); trace.append(event)
            if attempt < PLAN_ATTEMPTS:
                # Original question preserved; only the invalid plan and exact error
                # are added. No repeated examples or full earlier conversation.
                messages = [{'role': 'system', 'content': PLAN_SYSTEM},
                            {'role': 'user', 'content': question + '\nInvalid tree:\n' + raw +
                             '\nRepair structure, preserving meaning: ' + str(exc)}]
            continue
        event['status'] = 'valid'; trace.append(event)
        break
    else:
        raise DecompositionError('Decomposition remained structurally invalid after two attempts.', trace)

    for review_index in range(2):
        verdict = review_plan(llm, question, plan)
        trace.append({'stage': 'semantic_review', 'attempt': review_index + 1, **verdict})
        if verdict['status'] == 'valid':
            return plan, trace
        if review_index == 1:
            raise SemanticPlanError('Semantic review did not accept the tree after one repair.',
                                    trace, 'valid', verdict['status'])
        messages = [{'role': 'system', 'content': PLAN_SYSTEM}, {'role': 'user', 'content':
            question + '\nTree:\n' + compact(plan) + '\nRepair these semantic mismatches:\n' +
            compact(verdict['errors'])}]
        raw = llm.generate(messages, max_new_tokens=getattr(llm, 'plan_tokens', DEFAULT_PLAN_TOKENS))
        event = {'stage': 'semantic_repair', 'attempt': 1, 'raw_output': raw}
        try:
            plan = validate_plan(parse_json_object(raw), max_nodes=MAX_PLAN_NODES)
        except ValueError as exc:
            event.update(status='invalid', error=str(exc)); trace.append(event)
            raise SemanticPlanError('Semantic repair produced an invalid tree.', trace,
                                    'invalid', 'unresolved') from exc
        event['status'] = 'valid'; trace.append(event)
