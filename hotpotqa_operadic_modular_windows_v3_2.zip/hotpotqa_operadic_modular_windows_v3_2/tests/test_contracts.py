"""No real model calls: contract checks alone do not assess model quality."""
import unittest

from hotpotqa_operadic_rag.contracts import expand_plan, parse_json_object, validate_plan
from hotpotqa_operadic_rag import contracts


def chain():
    return {"nodes": [
        {"id": "q1", "question": "Who wrote Hamlet?", "dependencies": {}, "answer_type": "person"},
        {"id": "q2", "question": "Where was {{q1}} born?", "dependencies": {"q1": "person"}, "answer_type": "place"},
    ], "final": "q2"}


class ParseTests(unittest.TestCase):
    def test_json_and_whole_fence(self):
        self.assertEqual(parse_json_object('```json\n{"nodes": []}\n```'), {"nodes": []})
        self.assertEqual(parse_json_object('```json\r\n{"nodes": []}\r\n```'), {"nodes": []})
        self.assertEqual(parse_json_object('{"text": "سلام"}'), {"text": "سلام"})

    def test_reject_duplicates_nonfinite_and_nonobjects(self):
        for raw in ['{"a":1,"a":2}', '{"a":{"b":1,"b":2}}', '{"a":NaN}',
                    '{"a":Infinity}', '{"a":1e999}', 'null', '[]', '3',
                    '{"a":1} trailing', '```json\n{}', None]:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                parse_json_object(raw)


class PlanTests(unittest.TestCase):
    def test_default_accepts_twelve_nodes_but_rejects_thirteen(self):
        nodes = [{"id": "q1", "question": "Which entity?", "dependencies": {}, "answer_type": "other"}]
        for n in range(2, 14):
            nodes.append({"id": f"q{n}", "question": "Which relation of {{q" + str(n-1) + "}}?",
                          "dependencies": {f"q{n-1}": "other"}, "answer_type": "other"})
        self.assertEqual(len(validate_plan({"nodes": nodes[:12], "final": "q12"})['nodes']), 12)
        with self.assertRaisesRegex(ValueError, '1..12'):
            validate_plan({"nodes": nodes, "final": "q13"})

    def test_decomposition_contracts_do_not_execute_answers(self):
        self.assertFalse(hasattr(contracts, "instantiate_question"))
        self.assertFalse(hasattr(contracts, "validate_answer"))

    def test_single_and_chain(self):
        self.assertEqual(validate_plan(chain()), chain())
        leaf = chain()["nodes"][0]
        self.assertEqual(validate_plan({"nodes": [leaf], "final": "q1"})["final"], "q1")

    def test_topologically_sort_without_renumbering(self):
        plan = chain()
        plan["nodes"].reverse()
        self.assertEqual(validate_plan(plan), chain())

    def test_bad_field_types_raise_value_error_not_type_error(self):
        for key, value in [("id", []), ("answer_type", []), ("question", None),
                           ("dependencies", []), ("dependencies", {"q2": []})]:
            plan = chain()
            plan["nodes"][0][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_plan(plan)
        for final in [[], {}, None, "q999"]:
            plan = chain()
            plan["final"] = final
            with self.subTest(final=final), self.assertRaises(ValueError):
                validate_plan(plan)

    def test_exact_fields(self):
        plan = chain()
        plan["extra"] = "unexpected"
        with self.assertRaises(ValueError):
            validate_plan(plan)
        plan = chain()
        plan["nodes"][0]["answer"] = "not allowed in a plan"
        with self.assertRaises(ValueError):
            validate_plan(plan)

    def test_malformed_and_repeated_slots(self):
        for question in ["Where was {{person}} born?", "Where was {{q1} born?",
                         "Where was {q1} born?", "Where was {{q1000}} born?",
                         "Compare {{q1}} with {{q1}}."]:
            plan = chain()
            plan["nodes"][1]["question"] = question
            with self.subTest(question=question), self.assertRaises(ValueError):
                validate_plan(plan)

    def test_missing_slots_types_and_self_reference(self):
        mutations = [
            {"dependencies": {}},
            {"dependencies": {"q1": "place"}},
            {"question": "Who is {{q2}}?", "dependencies": {"q2": "place"}},
            {"question": "Who is {{q9}}?", "dependencies": {"q9": "person"}},
        ]
        for change in mutations:
            plan = chain()
            plan["nodes"][1].update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_plan(plan)

    def test_orphan_and_shared_prerequisite_rejected(self):
        plan = chain()
        plan["nodes"].append({"id": "q3", "question": "Unrelated?", "dependencies": {}, "answer_type": "other"})
        with self.assertRaises(ValueError):
            validate_plan(plan)
        plan["nodes"][2] = {"id": "q3", "question": "When was {{q1}} born?", "dependencies": {"q1": "person"}, "answer_type": "date"}
        plan["nodes"].append({"id": "q4", "question": "Combine {{q2}} and {{q3}}.", "dependencies": {"q2": "place", "q3": "date"}, "answer_type": "other"})
        plan["final"] = "q4"
        with self.assertRaisesRegex(ValueError, "one consumer"):
            validate_plan(plan)

    def test_cycle_rejected(self):
        plan = {"nodes": [
            {"id": "q1", "question": "What is {{q2}}?", "dependencies": {"q2": "other"}, "answer_type": "other"},
            {"id": "q2", "question": "What is {{q1}}?", "dependencies": {"q1": "other"}, "answer_type": "other"},
            {"id": "q3", "question": "An unrelated root?", "dependencies": {}, "answer_type": "other"},
        ], "final": "q3"}
        with self.assertRaisesRegex(ValueError, "Cyclic"):
            validate_plan(plan)

    def test_size_and_null(self):
        for data in [None, {}, {"nodes": [], "final": "q1"}]:
            with self.subTest(data=data), self.assertRaises(ValueError):
                validate_plan(data)
        with self.assertRaises(ValueError):
            validate_plan(chain(), max_nodes=1)
        with self.assertRaises(ValueError):
            validate_plan(chain(), max_nodes=True)

    def test_formal_expansion_without_answers(self):
        self.assertEqual(expand_plan(chain()), "Where was [q1: Who wrote Hamlet?] born?")
        with self.assertRaises(ValueError):
            expand_plan(chain(), max_chars=10)

    def test_no_semantic_claim(self):
        # The schema alone cannot reject a question unrelated to a user's input.
        plan = {"nodes": [chain()["nodes"][0]], "final": "q1"}
        result = validate_plan(plan)
        self.assertNotIn("semantic_valid", result)


if __name__ == "__main__":
    unittest.main()
