@echo off
call "%~dp0run_decomposition_test.bat" %*
exit /b %ERRORLEVEL%
