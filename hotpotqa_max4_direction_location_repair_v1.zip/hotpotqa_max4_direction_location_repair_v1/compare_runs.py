"""Compare actual results for the same cohort; standard-library only, no LLM calls."""
import argparse
import csv
import json
from pathlib import Path
from hotpotqa_operadic_rag.cost_comparison import paired_token_report


def read_rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    by_id = {row['question_id']: row for row in rows}
    if not rows or len(by_id) != len(rows):
        raise ValueError('Empty run or duplicate question IDs.')
    return by_id


def summary(rows, prefix, answer_key):
    completed = [r for r in rows if r[prefix + '_status'] == 'completed']
    correct = sum(float(r[prefix + '_f1'] or 0) >= .5 for r in completed)
    return {'requested': len(rows), 'completed': len(completed), 'correct_f1_ge_0_5': correct,
            'accuracy_all_requested': correct / len(rows),
            'mean_f1_completed': sum(float(r[prefix + '_f1']) for r in completed) / len(completed) if completed else None,
            'abstained_completed': sum(not r[answer_key].strip() for r in completed),
            'failed': sum(r[prefix + '_status'] in ('failed', 'interrupted') for r in rows),
            'pending': sum(r[prefix + '_status'] == 'pending' for r in rows),
            'input_tokens_including_retries': sum(int(r[prefix + '_cumulative_prompt_tokens']) for r in rows),
            'output_tokens_including_retries': sum(int(r[prefix + '_cumulative_completion_tokens']) for r in rows),
            'llm_calls_including_retries': sum(int(r[prefix + '_cumulative_llm_calls']) for r in rows),
            'retrieval_calls_including_retries': sum(int(r[prefix + '_cumulative_retrieval_steps']) for r in rows),
            'time_seconds_including_retries': sum(float(r[prefix + '_cumulative_execution_time_sec']) for r in rows)}


def compare(baseline_path, current_path):
    old, new = read_rows(baseline_path), read_rows(current_path)
    if set(old) != set(new):
        raise ValueError('Runs do not contain exactly the same question IDs.')
    for qid in old:
        for field in ('question', 'question_type', 'ground_truth_answer', 'dataset_split'):
            if old[qid][field] != new[qid][field]:
                raise ValueError('Cohort content changed: ' + qid + ' / ' + field)
    result = {'note': 'Only observed outputs. Empty answers/failures count as unsuccessful in the all-requested denominator. No semantic accuracy or independence of the self-judge is assumed.',
              'baseline': {}, 'current': {}}
    for label, mapping in [('baseline', old), ('current', new)]:
        rows = list(mapping.values())
        result[label]['whole_method_token_condition'] = paired_token_report(rows)
        for scope in ('all', 'bridge', 'comparison'):
            subset = rows if scope == 'all' else [r for r in rows if r['question_type'] == scope]
            if not subset:
                continue
            result[label][scope] = {p: summary(subset, p, key) for p, key in
                                   [('std', 'answer_std'), ('operadic', 'answer_decomposed')]}
        result[label]['oc_extra_input_tokens'] = sum(int(r['oc_cumulative_prompt_tokens']) for r in rows)
        result[label]['oc_extra_output_tokens'] = sum(int(r['oc_cumulative_completion_tokens']) for r in rows)
        result[label]['oc_extra_llm_calls'] = sum(int(r['oc_cumulative_llm_calls']) for r in rows)
        result[label]['oc_completed'] = sum(r['oc_status'] == 'completed' for r in rows)
        result[label]['oc_failed'] = sum(r['oc_status'] in ('failed', 'interrupted') for r in rows)
        result[label]['oc_pending'] = sum(r['oc_status'] == 'pending' for r in rows)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True)
    parser.add_argument('--current', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(compare(args.baseline, args.current), ensure_ascii=False, indent=2))
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    main()
