@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=%~dp0.venv\Scripts\python.exe"
if defined VIRTUAL_ENV set "PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PYTHON=%HOTPOT_PYTHON%"
if not exist "%PYTHON%" (
  echo ERROR: Project virtual environment was not found.
  echo Activate the existing CUDA environment or set HOTPOT_PYTHON to its python.exe.
  pause
  exit /b 1
)
"%PYTHON%" preload_models.py %*
if errorlevel 1 (
  echo.
  echo Model download or verification failed. Read the error above.
  pause
  exit /b 1
)
echo.
echo Model preparation completed.
pause
