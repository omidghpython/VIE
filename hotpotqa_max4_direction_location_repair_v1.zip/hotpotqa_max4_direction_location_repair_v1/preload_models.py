#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pre-download the exact Hugging Face models used by this project.

Downloads to the standard Hugging Face cache, which is the same cache used by
Transformers.from_pretrained() and SentenceTransformer(). No model is loaded
into GPU memory by this script.
"""

import argparse
import os
import shutil
import sys
from pathlib import Path

# More tolerant timeouts for slower / unstable connections.
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "120")
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "60")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

from huggingface_hub import snapshot_download
from hotpotqa_operadic_rag.config import MODEL_NAME, MODEL_REVISION, EMBEDDING_MODEL, EMBEDDING_REVISION

MODELS = [
    ("Qwen LLM", MODEL_NAME, MODEL_REVISION),
    ("BGE embedding model", EMBEDDING_MODEL, EMBEDDING_REVISION),
]


def main() -> int:
    parser = argparse.ArgumentParser(description="Download project models into the Hugging Face cache.")
    parser.add_argument(
        "--qwen-only",
        action="store_true",
        help="Download only Qwen2.5-7B-Instruct.",
    )
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Verify that the required model snapshots are already cached; do not download.",
    )
    args = parser.parse_args()

    selected = MODELS[:1] if args.qwen_only else MODELS
    hf_home = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface"))
    hf_home.mkdir(parents=True, exist_ok=True)
    disk = shutil.disk_usage(hf_home)

    print("=" * 72)
    print("HotpotQA Operadic RAG - model preparation")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Hugging Face cache: {hf_home}")
    print(f"Free disk space: {disk.free / (1024 ** 3):.2f} GiB")
    print("=" * 72)
    if disk.free < 20 * (1024 ** 3):
        print("WARNING: Less than 20 GiB is free. Qwen's repository is about 15.2 GB;")
        print("the dataset, temporary files and other project files need extra space.")

    errors = []
    for label, repo_id, revision in selected:
        print(f"\n[{label}] {repo_id}")
        try:
            path = snapshot_download(
                repo_id=repo_id,
                repo_type="model",
                revision=revision,
                local_files_only=args.verify_only,
            )
            print(f"READY: {path}")
        except Exception as exc:
            errors.append((repo_id, exc))
            print(f"FAILED: {repo_id}")
            print(f"Reason: {type(exc).__name__}: {exc}")

    print("\n" + "=" * 72)
    if errors:
        print("Model preparation did not complete.")
        print("Check internet access, free disk space and the Hugging Face Hub connection.")
        return 1

    print("All selected model snapshots are available in the Hugging Face cache.")
    print("The project will reuse these cached files when it loads the models.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
