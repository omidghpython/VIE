"""Project entry point. Run: python main.py --help"""
from hotpotqa_operadic_rag.cli import main

if __name__ == "__main__":
    main()
