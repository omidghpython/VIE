"""Offline reporting and per-file provenance; never included in model prompts."""
from pathlib import Path
import hashlib
import json
from collections import Counter
from .relation_repair import diagnose

ROOT=Path(__file__).resolve().parent.parent


def code_files():
    paths=[ROOT/'decomposition_pilot.py',*sorted((ROOT/'hotpotqa_operadic_rag').rglob('*.py'))]
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def export_experiment(store):
    rows=[]
    for order,sample in enumerate(store.samples,1):
        st=store.read(sample['question_id'])['phases'].get('structure',{})
        result=st.get('result',{})
        plan=result.get('plan')
        meta=result.get('relation_repair',{})
        rows.append(dict(order=order,question_id=sample['question_id'],question=sample['question'],
                         structure_status=st.get('status','pending'),
                         repair_status=meta.get('status','not_enabled_or_no_valid_plan'),
                         attempted=meta.get('attempted',False),changed=meta.get('changed',False),
                         before=meta.get('before'),after=diagnose(sample['question'],plan) if plan else None,
                         reason=meta.get('reason','')))
    report=dict(role='limited_relation_checks_not_semantic_accuracy',questions=rows,
                repair_status_counts=dict(Counter(r['repair_status'] for r in rows)),
                note='A compatible result covers supported direction/location/binding/target patterns only. Unknown is not success. Rejected proposals leave the original plan and error visible.')
    lines=['# Direction/location repair audit','',report['note'],'']
    for row in rows:
        lines += [f"## {row['order']}. {row['question_id']} — {row['repair_status']}",'',row['question'],'',
                  '```json',json.dumps(row,ensure_ascii=False,indent=2),'```','']
    return report,'\n'.join(lines)


def source_report(store):
    expected_path=ROOT/'RELEASE_IDENTITY.json'
    expected=json.loads(expected_path.read_text(encoding='utf-8')) if expected_path.exists() else {}
    recorded=store.manifest['settings'].get('source_files_sha256',{})
    expected_files=expected.get('files_sha256',{})
    mismatches=[name for name in sorted(set(recorded)|set(expected_files)) if recorded.get(name)!=expected_files.get(name)]
    return dict(experiment='max4_direction_location_repair_v1',
                recorded_code_sha256=store.manifest['settings']['code_sha256'],recorded_files_sha256=recorded,
                expected_release=expected,release_file_differences=mismatches if expected else None,
                release_matches_recorded=bool(expected) and not mismatches and expected.get('code_sha256')==store.manifest['settings']['code_sha256'],
                note='File-byte hashes at run initialization; not a claim of independent GPU observation. No local absolute paths or secrets are stored.')
