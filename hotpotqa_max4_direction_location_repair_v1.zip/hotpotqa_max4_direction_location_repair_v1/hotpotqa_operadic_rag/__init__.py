"""Modular Standard RAG vs Operadic-Guided RAG experiment."""
__version__ = "3.2.0"
