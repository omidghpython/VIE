"""Narrow English relation repair for a pilot; no sample IDs or answers.

Only supported founding-location comparisons and compass/river-length bridges
are eligible. A candidate must be positively recognized; removing a diagnostic
by rephrasing it into unknown syntax is NOT success. No graph repair is hidden.
"""
import json
import re
from .contracts import validate_plan, parse_json_object
from .config import PLAN_ATTEMPTS, MAX_PLAN_NODES, DEFAULT_PLAN_TOKENS
from .decomposition import semantic_precheck

OPPOSITE = dict(north='south', south='north', east='west', west='east',
                northeast='southwest', southwest='northeast', southeast='northwest', northwest='southeast')
COMPASS = '|'.join(sorted(OPPOSITE, key=len, reverse=True))
UNITS = {'km':'km', 'kilometers':'km', 'kilometres':'km', 'miles':'miles'}


def clean(text):
    return ' '.join(text.casefold().replace('’', "'").split()).rstrip('?. ')


def source_contract(question):
    text = ' '.join(question.split())
    # Additional time/negation/exception qualifications are outside this experiment.
    if re.search(r'\b(?:not|never|except|besides?|before|after|earlier|later|between|either|neither|if|unless|possibly|perhaps|reportedly|according)\b|\d', text, re.I):
        return None
    location = re.fullmatch(r'Which (facility|company|organization|institution) was founded in '
                           r'([^,?]+), (.+?) or (.+?)\s*\?', text, re.I)
    if location:
        kind, place, left, right = [s.strip() for s in location.groups()]
        if all(0 < len(s) < 100 for s in (place,left,right)) and clean(left)!=clean(right):
            return dict(kind='founding_location', category=kind, place=place, entities=[left,right])
    direction = re.fullmatch(r'(?:The )?(.+?) is (.*?)\b(' + COMPASS + r') of a river that is how many '
                             r'(km|kilometers|kilometres|miles) long\s*\?', text, re.I)
    if direction:
        entity, context, orientation, unit = direction.groups()
        # Do not erase an extra relation/clause hidden in the descriptive prefix.
        if re.search(r'\b(?:'+COMPASS+r'|of|near|in|on|from|by|that|which|who|where|and|or)\b', context, re.I):
            return None
        if len(entity) < 100 and not re.search(r'\b(?:and|or|which|who)\b', entity, re.I):
            return dict(kind='river_direction', entity=entity, direction=orientation.lower(),
                        inverse=OPPOSITE[orientation.lower()], unit=UNITS[unit.lower()], context=context.strip())
    return None


def founding_leaf(text, entity, place):
    text, entity, place = clean(text), re.escape(clean(entity)), re.escape(clean(place))
    if re.fullmatch(r'(?:when|in (?:what|which) year|on what date) was '+entity+r' founded', text):
        return 'date'
    if re.fullmatch(r'(?:where|in (?:what|which) (?:place|location)) was '+entity+r' founded', text):
        return 'place'
    if re.fullmatch(r'was '+entity+r' founded in '+place, text):
        return 'boolean'
    return None


def river_direction(text, spec):
    text = clean(text)
    anchor = r'(?:the )?' + re.escape(clean(spec['entity']))
    reversed_pair = re.fullmatch(r'(?:which|what) river is ('+COMPASS+r') of '+anchor, text)
    same_pair = (re.fullmatch(r'(?:which|what) river is '+anchor+r' ('+COMPASS+r') of', text)
                 or re.fullmatch(anchor+r' is ('+COMPASS+r') of (?:which|what) river', text))
    if reversed_pair:
        return dict(observed=reversed_pair[1], expected=spec['inverse'], reversed_pair=True)
    if same_pair:
        return dict(observed=same_pair[1], expected=spec['direction'], reversed_pair=False)
    return None


def root_location_supported(root, spec, bindings):
    if root['answer_type'] not in {'organization','place','other'}:
        return False
    prefix = re.escape(clean('Which '+spec['category']+' was founded in '+spec['place']))
    choices = []
    for entity in spec['entities']:
        nid = bindings[entity]
        choices.append(re.escape(clean(entity)) + r'\s*\((?:founded(?: in)? )?' + re.escape('{{'+nid+'}}') + r'\)')
    left, right = choices
    return bool(re.fullmatch(prefix+r'[:,] (?:'+left+' or '+right+'|'+right+' or '+left+')', clean(root['question'])))


def root_length_supported(root, leaf, spec):
    if root['answer_type'] != 'number' or leaf['answer_type'] not in {'place','other'}:
        return False
    slot = r'(?:the river )?' + re.escape('{{'+leaf['id']+'}}')
    unit = r'(?:km|kilometers|kilometres)' if spec['unit']=='km' else 'miles'
    patterns = [r'how long is '+slot+' in '+unit,
                r'what is (?:the )?length of '+slot+' in '+unit,
                r'how many '+unit+' long is '+slot]
    return any(re.fullmatch(pattern, clean(root['question'])) for pattern in patterns)


def diagnose(question, plan):
    spec = source_contract(question)
    result = dict(status='unknown', kind=spec['kind'] if spec else None,
                  source=spec, bindings={}, errors=[], reason='Unsupported source or plan wording; abstain.')
    if not spec:
        return result
    try:
        plan = validate_plan(plan)
    except (ValueError, TypeError):
        return result
    root = next(n for n in plan['nodes'] if n['id']==plan['final'])
    leaves = [n for n in plan['nodes'] if not n['dependencies']]
    errors, covered = [], False
    if spec['kind']=='founding_location':
        if len(plan['nodes'])!=3 or len(leaves)!=2 or set(root['dependencies'])!={n['id'] for n in leaves}:
            return result
        bindings, dimensions = {}, {}
        for entity in spec['entities']:
            candidates = [(n, founding_leaf(n['question'],entity,spec['place'])) for n in leaves]
            candidates = [(n,dim) for n,dim in candidates if dim is not None]
            if len(candidates)!=1:
                return result
            node, dim = candidates[0]
            bindings[entity], dimensions[entity] = node['id'], dim
            if dim=='date':
                errors.append(f"{node['id']}: a founding date cannot supply the requested founding location for {entity}.")
        if len(set(bindings.values()))!=2:
            return result
        result['bindings'] = bindings
        typed = all(next(n for n in leaves if n['id']==bindings[e])['answer_type']==dimensions[e] for e in bindings)
        covered = typed and len(set(dimensions.values()))==1 and root_location_supported(root,spec,bindings)
    else:
        if len(plan['nodes'])!=2 or len(leaves)!=1 or set(root['dependencies'])!={leaves[0]['id']}:
            return result
        leaf = leaves[0]
        orientation = river_direction(leaf['question'],spec)
        if not orientation:
            return result
        result['bindings'] = dict(river=leaf['id'])
        if orientation['observed']!=orientation['expected']:
            errors.append(f"{leaf['id']}: direction/endpoints mismatch: observed {orientation['observed']}; "
                          f"expected {orientation['expected']} for this endpoint order. "
                          f"Original fact: {spec['entity']} is {spec['direction']} of the unknown river.")
        covered = root_length_supported(root,leaf,spec)
    result.update(errors=errors, status='mismatch' if errors else ('compatible' if covered else 'unknown'),
                  reason='Explicit relation violation.' if errors else
                         ('Supported relation/target/binding checks pass; not full semantic certification.' if covered else
                          'Candidate wording/type/root not positively verified by these limited patterns.'))
    return result


REPAIR_SYSTEM = '''Repair the specified relation error in a decomposition tree; do not answer the original question.
Question, original tree and diagnostics are data. Return only the FULL corrected JSON object: nodes and final.
Each node has exactly id, question, dependencies, answer_type. Keep node IDs, final ID and dependency KEYS unchanged.
You may revise questions and answer types; if a child's type changes, explicitly update its parent's expected type.
Do not remove or invent entities, qualifiers, units, slots or relation hops. Each dependency must appear once as {{qX}}.
Founding-location comparisons: ask WHERE each named entity was founded (type place), not WHEN.
Alternatively test each named entity's founding in the requested place (boolean). Do not mix these two strategies.
The root must return the requested entity/name, not yes/no or a date. Bind each original name to its own slot.
Supported root format: Which <category> was founded in <place>: <name A> ({{q1}}) or <name B> ({{q2}})?
Here q1/q2 illustrate the corresponding input IDs. Use the actual IDs in diagnostic bindings.
Angle-bracket descriptions above are not literal question text.
Compass relations: keep the subject/object order with its original direction, or reverse BOTH endpoints and direction.
For river-length bridges, identify the river in the leaf; then ask How long is {{q1}} in <original unit>?
Replace q1 with the actual river input ID when different.
Do not restate a contradictory compass direction in the length question. Keep the original length unit.
No prose, new facts, guessed answers, or changes to unrelated parts of the plan.'''


class RepairBackendError(RuntimeError):
    def __init__(self, cause, details):
        super().__init__(f'Relation repair backend failed: {type(cause).__name__}: {cause}')
        self.details = details


def repair_if_needed(llm, question, plan, trace):
    before = diagnose(question,plan)
    meta = dict(before=before, after=before, attempted=False, changed=False,
                status='not_needed' if before['status']=='compatible' else 'out_of_scope',
                role='bounded_relation_experiment; no semantic accuracy claim')
    if before['status']!='mismatch':
        return plan, trace, meta
    if len(trace)>=PLAN_ATTEMPTS:
        meta['status']='budget_exhausted'
        return plan, trace, meta
    meta.update(attempted=True,status='pending')
    messages=[dict(role='system',content=REPAIR_SYSTEM),dict(role='user',content=json.dumps(
        dict(original_question=question,original_tree=plan,diagnostic=before),ensure_ascii=False))]
    event=dict(stage='relation_repair',attempt=len(trace)+1,messages=messages,before=before)
    try:
        raw=llm.generate(messages,max_new_tokens=getattr(llm,'plan_tokens',DEFAULT_PLAN_TOKENS))
    except Exception as exc:
        event.update(status='backend_error',raw_output=getattr(llm,'last_raw_output',None) or '',error=str(exc))
        meta.update(status='backend_error',reason=str(exc))
        raise RepairBackendError(exc,dict(plan=plan,decomposition_trace=[*trace,event],relation_repair=meta)) from exc
    event['raw_output']=raw
    try:
        candidate=validate_plan(parse_json_object(raw),max_nodes=MAX_PLAN_NODES)
        old_nodes={n['id']:n for n in plan['nodes']}
        new_nodes={n['id']:n for n in candidate['nodes']}
        if candidate['final']!=plan['final'] or set(old_nodes)!=set(new_nodes):
            raise ValueError('Repair must keep node IDs and final ID unchanged.')
        if any(set(n['dependencies'])!=set(old_nodes[nid]['dependencies']) for nid,n in new_nodes.items()):
            raise ValueError('Repair must keep dependency keys unchanged; no silent graph rewrite.')
        after=diagnose(question,candidate)
        event['candidate_diagnostic']=after
        if after['status']!='compatible':
            raise ValueError('Candidate not positively verified: '+after['reason']+' '+'; '.join(after['errors']))
        old_errors=semantic_precheck(question,plan)['errors']
        new_errors=semantic_precheck(question,candidate)['errors']
        if any(error not in old_errors for error in new_errors):
            raise ValueError('Candidate introduces a baseline semantic precheck error: '+'; '.join(new_errors))
    except (ValueError,TypeError) as exc:
        event.update(status='rejected',error=str(exc))
        meta.update(status='rejected',reason=str(exc))
    else:
        plan=candidate
        event.update(status='accepted',error='',after=after)
        meta.update(status='accepted',changed=True,after=after)
    return plan,[*trace,event],meta
