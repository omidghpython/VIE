"""Report comparison with the recorded original max4; never used in prompts."""
import hashlib
import json
from pathlib import Path

REFERENCE = Path(__file__).resolve().parent.parent / 'evaluation/max4_reference.json'


def reference_digest():
    return hashlib.sha256(REFERENCE.read_bytes()).hexdigest()


def compare(store, summary):
    baseline = json.loads(REFERENCE.read_text(encoding='utf-8'))
    lookup = {row['question_id']: row for row in baseline['questions']}
    rows = []
    for order, sample in enumerate(store.samples, 1):
        old = lookup.get(sample['question_id'])
        phases = store.read(sample['question_id'])['phases']
        structure = phases.get('structure', {})
        plan = structure.get('result', {}).get('plan')
        matched = bool(old and old['question'] == sample['question'])
        cost = {key: sum(h['telemetry'].get(key, 0) for p in phases.values() for h in p.get('history', []))
                for key in ('llm_calls', 'total_tokens')}
        rows.append(dict(order=order, question_id=sample['question_id'], baseline_matched=matched,
                         baseline_status=old['status'] if matched else None,
                         current_status=structure.get('status', 'pending'),
                         plan_identical_to_max4=(plan == old['plan']) if matched and structure.get('status') in ('valid','invalid') else None,
                         baseline_cost=old['cost'] if matched else None, current_cost=cost))
    same_cohort = len(rows) == len(baseline['questions']) and all(r['baseline_matched'] for r in rows)
    complete = not summary['incomplete_questions']
    report = dict(baseline='v3.2.4-max4', source_result_sha256=baseline['source_result_sha256'],
                  reference_sha256=reference_digest(), same_cohort=same_cohort, current_run_complete=complete,
                  metrics_comparable=same_cohort and complete,
                  baseline_metrics=baseline['metrics'],
                  current_metrics={k:summary[k] for k in ('structure_status','total_cost','valid_on_first_attempt','root_contract_status')},
                  questions=rows,
                  note='Saved original max4 output comparison only. Structural counts and model verdicts are not semantic accuracy. No gold data enters generation.')
    lines=['# Comparison with original max4', '', report['note'], '',
           f'Same complete cohort: {report["metrics_comparable"]}', '',
           '| Case | Baseline structure | Current structure | Identical plan | Baseline tokens | Current tokens |',
           '|---|---|---|---|---|---|']
    for row in rows:
        lines.append(f"| {row['order']} | {row['baseline_status']} | {row['current_status']} | {row['plan_identical_to_max4']} | "
                     f"{(row['baseline_cost'] or {}).get('total_tokens')} | {row['current_cost']['total_tokens']} |")
    return report, '\n'.join(lines)
