"""New checks exercised on independent fixtures and recorded outputs, not live inference."""
import copy
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
import unittest

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.contracts import expand_typed_plan, SLOT_PATTERN, validate_plan
from hotpotqa_operadic_rag.decomposition import review_plan, root_answer_check, semantic_precheck, decompose_question
from hotpotqa_operadic_rag.semantic_checks import answer_target, binding_errors, geographic_precision_errors
from hotpotqa_operadic_rag.cost_comparison import paired_token_report, pilot_token_report
from test_decomposition_pilot import ScriptedModel
from test_grounded_revision import Scripted

ROOT = Path(__file__).resolve().parents[1]


def chain(first, first_type, second, second_type):
    return validate_plan({'nodes': [
        {'id': 'q1', 'question': first, 'answer_type': first_type, 'dependencies': {}},
        {'id': 'q2', 'question': second, 'answer_type': second_type, 'dependencies': {'q1': first_type}}],
        'final': 'q2'})


class SemanticChecksTests(unittest.TestCase):
    def test_root_wording_cannot_be_hidden_by_changing_only_type_label(self):
        bad = chain('Which novel features Mara?', 'work', 'Which character in {{q1}} sings?', 'work')
        check = root_answer_check('Mara sings in which novel?', bad)
        self.assertEqual(check['status'], 'mismatch')
        self.assertIn('question target=person', check['errors'][0])
        details = {}
        self.assertEqual(review_plan(Scripted(), 'Mara sings in which novel?', bad, details=details)['status'], 'revise')
        self.assertEqual(details['source'], 'root_rule')

    def test_correct_entity_then_property_is_not_rejected(self):
        good = chain('Who is the spouse of Nima?', 'person', 'What nationality is {{q1}}?', 'other')
        self.assertFalse(semantic_precheck('What nationality is Nima\'s spouse?', good)['errors'])
        bad = chain('What nationality is Nima?', 'other', 'Who is the spouse of {{q1}}?', 'person')
        self.assertTrue(binding_errors(bad))

    def test_person_is_not_reused_as_band(self):
        wrong = chain('Who is the lead singer of Silver Leaves?', 'person', 'Who is the lead singer of {{q1}}?', 'person')
        self.assertTrue(binding_errors(wrong))
        right = chain('Which band released Blue Moon?', 'organization', 'Who is the lead singer of {{q1}}?', 'person')
        self.assertFalse(binding_errors(right))

    def test_description_is_not_passed_as_actor(self):
        bad = chain('What is Ira Bloom known for?', 'other', 'In which game did {{q1}} appear?', 'work')
        good = chain('Who portrayed Captain Stone?', 'person', 'In which game did {{q1}} appear?', 'work')
        self.assertTrue(binding_errors(bad))
        self.assertFalse(binding_errors(good))

    def test_coordinates_not_required_for_qualitative_comparison(self):
        plan = chain('What is the longitude of Westhaven?', 'number', 'Is Eastbank west of {{q1}}?', 'boolean')
        question = 'Which city is further west, Westhaven or Eastbank?'
        self.assertTrue(geographic_precision_errors(question, plan))
        for text in ('Compare their longitudes: ' + question, 'What is the longitude of Westhaven?'):
            self.assertFalse(geographic_precision_errors(text, plan))
        plan['nodes'][0].update(question='Where is Westhaven?', answer_type='place')
        plan['nodes'][1]['dependencies']['q1'] = 'place'
        self.assertFalse(geographic_precision_errors(question, plan))

    def test_ambiguous_targets_do_not_trigger_specific_type_claims(self):
        for text in ('Could you tell me which city?', 'What is the answer to "Which film?"?',
                     "Which chain's headquarters is further north?", 'Who published The Lantern?'):
            self.assertIsNone(answer_target(text), text)
        self.assertEqual(answer_target('In which year was the novelist born?')['type'], 'date')

    def test_existing_one_semantic_repair_budget_handles_binding_error(self):
        bad = chain('What nationality is Nima?', 'other', 'Who is the spouse of {{q1}}?', 'person')
        good = chain('Who is the spouse of Nima?', 'person', 'What nationality is {{q1}}?', 'other')
        model = Scripted([bad, good], [{'status': 'valid', 'errors': []}])
        plan, trace = decompose_question(model, 'What nationality is the spouse of Nima?')
        self.assertEqual(plan, good)
        self.assertEqual((len(model.messages), len(model.prompts)), (2, 1))
        self.assertEqual(trace[1]['details']['source'], 'binding_rule')

    def test_recorded_v322_checks_are_separate_from_judgments(self):
        samples, baselines = pilot.load_cohort(ROOT / 'evaluation/samples.json')
        rows = baselines['runs']['v3.2.2']['questions']
        expected = {15: 'binding_rule', 19: 'root_rule', 21: 'geography_rule',
                    30: 'root_rule', 31: 'geography_rule', 34: 'binding_rule', 40: 'binding_rule'}
        plans = [e['raw_output'] for row in rows for e in row['trace']]
        replies = [row['judge']['raw_output'] for i, row in enumerate(rows, 1)
                   if row['status'] == 'valid' and i not in expected]
        for i, row in enumerate(rows, 1):
            if row['status'] == 'valid':
                self.assertEqual(bool(semantic_precheck(row['question'], row['plan'])['errors']), i in expected)
        model = ScriptedModel(plans, replies)
        with tempfile.TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()):
            summary = pilot.run_pilot(samples, baselines, Path(tmp) / 'pilot',
                                      model_factory=lambda settings: (model, {'backend': 'scripted'}))
            self.assertEqual(summary['structure_status'], {'valid': 35, 'invalid': 5})
            self.assertEqual(summary['review_source'], {'model': 28, 'not_reviewed': 5,
                                                       'binding_rule': 3, 'root_rule': 2, 'geography_rule': 2})
            self.assertEqual(summary['judge_calls_avoided_by_all_rules'], 7)
            self.assertEqual(summary['total_cost']['llm_calls'], 47 + 28)
            self.assertEqual(summary['whole_method_token_condition']['status'], 'not_measured_scripted_backend')
            self.assertIsNone(summary['whole_method_token_condition']['full_token_condition_met'])
        self.assertFalse(model.plans)
        self.assertFalse(model.verdicts)


class TypedExpansionTests(unittest.TestCase):
    def test_full_nested_text_no_duplicate_json_and_original_question_intact(self):
        plan = chain('Who wrote Čas, in 1994, but not its sequel?', 'person', 'In which city was {{q1}} born?', 'place')
        expanded = expand_typed_plan(plan)
        self.assertEqual(expanded, '[answer q2:place | In which city was [answer q1:person | Who wrote Čas, in 1994, but not its sequel?] born?]')
        question = '  Where was the author of Čas (1994), not its sequel, born?  '
        model = Scripted(replies=[{'status': 'valid', 'errors': []}])
        review_plan(model, question, plan)
        self.assertIn(question, model.prompts[0])
        self.assertIn(expanded, model.prompts[0])
        self.assertNotIn('"nodes":', model.prompts[0])
        self.assertNotIn('{{q1}}', model.prompts[0])

    def test_all_recorded_trees_retain_every_fragment_and_type_once(self):
        rows = json.loads((ROOT / 'evaluation/decomposition_baselines.json').read_text())['runs']['v3.2.2']['questions']
        for row in rows:
            if row['status'] != 'valid':
                continue
            expanded = expand_typed_plan(row['plan'])
            for node in row['plan']['nodes']:
                self.assertEqual(expanded.count(f"[answer {node['id']}:{node['answer_type']} | "), 1)
                for part in SLOT_PATTERN.split(node['question'])[::2]:
                    self.assertIn(part, expanded)
            self.assertNotRegex(expanded, SLOT_PATTERN)

    def test_expansion_size_error_does_not_truncate(self):
        plan = chain('Who wrote A?', 'person', 'Where was {{q1}} born?', 'place')
        with self.assertRaisesRegex(ValueError, 'nothing was truncated'):
            expand_typed_plan(plan, max_chars=10)


def cost_row(qid, direct, decomposed, status='completed', answer='x'):
    row = {'question_id': qid, 'std_status': 'completed', 'operadic_status': status,
           'answer_std': 'x', 'answer_decomposed': answer}
    for prefix, count in (('std', direct), ('operadic', decomposed), ('oc', 900)):
        row[prefix + '_cumulative_prompt_tokens'] = count - 1
        row[prefix + '_cumulative_completion_tokens'] = 1
        # Lower latest-attempt counters MUST NOT replace cumulative counters.
        row[prefix + '_total_tokens'] = 1
    return row


class CostTests(unittest.TestCase):
    def test_full_paired_cost_includes_every_row_and_retries_not_oc_baseline(self):
        report = paired_token_report([cost_row('a', 100, 80), cost_row('b', 150, 160)])
        self.assertEqual((report['standard_tokens'], report['decomposed_tokens']), (250, 240))
        self.assertEqual(report['oc_diagnostic_extra_tokens'], 1800)
        self.assertEqual(report['per_question_cost'], {'less': 1, 'more': 1})
        self.assertEqual(report['status'], 'meets_token_condition_quality_requires_review')

    def test_equal_is_not_less_and_failed_or_empty_answers_do_not_certify_savings(self):
        self.assertEqual(paired_token_report([cost_row('a', 100, 100)])['status'], 'fails_strict_token_condition')
        self.assertEqual(paired_token_report([cost_row('a', 100, 30, 'failed')])['status'], 'not_established_incomplete_run')
        self.assertEqual(paired_token_report([cost_row('a', 100, 30, answer='')])['status'], 'not_established_reduced_answer_coverage')

    def test_historical_standard_reference_is_full_same_40_not_oc_eight(self):
        samples, _ = pilot.load_cohort(ROOT / 'evaluation/samples.json')
        ref = pilot.direct_reference()
        settings = {**ref['settings'], 'backend': 'LocalQwen'}
        for tokens, status in ((54908, 'pilot_already_exceeds_or_equals_historical_standard'),
                               (54222, 'pilot_already_exceeds_or_equals_historical_standard'),
                               (40000, 'pilot_below_reference_full_savings_not_established')):
            report = pilot_token_report(samples, settings, tokens, ref, 0)
            self.assertEqual(report['standard_reference_tokens'], 54222)
            self.assertEqual(report['standard_reference_status'], {'completed': 39, 'failed': 1})
            self.assertEqual(report['status'], status)
            self.assertIsNone(report['full_token_condition_met'])
        self.assertEqual(pilot_token_report(samples[:8], settings, 10, ref, 0)['status'], 'not_comparable')

    def test_different_model_or_scripted_results_cannot_claim_live_savings(self):
        samples, _ = pilot.load_cohort(ROOT / 'evaluation/samples.json')
        ref = pilot.direct_reference()
        settings = {**ref['settings'], 'backend': 'injected_test'}
        self.assertEqual(pilot_token_report(samples, settings, 10, ref, 0)['status'], 'not_measured_scripted_backend')
        settings.update(backend='LocalQwen', model_revision='different')
        self.assertEqual(pilot_token_report(samples, settings, 10, ref, 0)['status'], 'not_comparable')


if __name__ == '__main__':
    unittest.main()
