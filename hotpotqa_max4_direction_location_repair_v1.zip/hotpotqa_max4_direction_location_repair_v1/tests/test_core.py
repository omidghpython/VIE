import unittest

from hotpotqa_operadic_rag.utils import parse_json_object, safe_minmax, to_bool
from hotpotqa_operadic_rag.metrics import squad_em, squad_f1
from hotpotqa_operadic_rag.telemetry import TelemetryTracker


class CoreTests(unittest.TestCase):
    def test_json_markdown(self):
        parsed = parse_json_object(
            '```json\n{"is_sufficient": true}\n```',
            {"is_sufficient": False},
        )
        self.assertTrue(parsed["is_sufficient"])

    def test_json_embedded_in_text(self):
        parsed = parse_json_object('Result: {"answer": "Paris"}.', {"answer": ""})
        self.assertEqual(parsed["answer"], "Paris")

    def test_squad_normalization(self):
        self.assertEqual(squad_em("The Eiffel Tower", "Eiffel Tower"), 1.0)
        self.assertEqual(squad_f1("The Eiffel Tower", "Eiffel Tower"), 1.0)
        self.assertEqual(squad_f1("Paris", "London"), 0.0)

    def test_minmax_constant_values(self):
        self.assertEqual(safe_minmax([5, 5, 5]).tolist(), [0.0, 0.0, 0.0])

    def test_telemetry_budget(self):
        tracker = TelemetryTracker("test")
        tracker.add_retrieval()
        tracker.add_retrieval()
        with self.assertRaises(RuntimeError):
            tracker.add_retrieval()

    def test_boolean_parser(self):
        self.assertTrue(to_bool("true"))
        self.assertFalse(to_bool("false"))


if __name__ == "__main__":
    unittest.main()
