import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch
import zipfile

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.relation_repair import diagnose, source_contract, repair_if_needed, RepairBackendError, OPPOSITE
from hotpotqa_operadic_rag.contracts import parse_json_object
from hotpotqa_operadic_rag import telemetry


def node(nid,text,kind,deps=None):
    return dict(id=nid,question=text,answer_type=kind,dependencies=deps or {})


def tree(*nodes):
    return dict(nodes=list(nodes),final=nodes[-1]['id'])


LOCATION='Which facility was founded in Ontario, Alpha or Beta?'
DIRECTION='The Vale is a traditional region southeast of a river that is how many km long?'
BAD_LOCATION=tree(node('q1','When was Alpha founded?','date'),node('q2','When was Beta founded?','date'),
                  node('q3','Which facility was founded in Ontario: Alpha (founded {{q1}}) or Beta (founded {{q2}})?','work',{'q1':'date','q2':'date'}))
GOOD_LOCATION=tree(node('q1','Where was Alpha founded?','place'),node('q2','Where was Beta founded?','place'),
                   node('q3','Which facility was founded in Ontario: Alpha ({{q1}}) or Beta ({{q2}})?','other',{'q1':'place','q2':'place'}))
BAD_DIRECTION=tree(node('q1','Which river is southeast of the Vale?','other'),
                   node('q2','How long is the river southeast of the Vale? ({{q1}}) in kilometers?','number',{'q1':'other'}))
GOOD_DIRECTION=tree(node('q1','Which river is northwest of the Vale?','place'),
                    node('q2','How long is {{q1}} in kilometers?','number',{'q1':'place'}))


class Model:
    plan_tokens=3072
    last_raw_output=None
    def __init__(self,replies): self.replies,self.messages=list(replies),[]
    def generate(self,messages,**kwargs):
        self.messages.append(copy.deepcopy(messages))
        if telemetry._ACTIVE_TRACKER:
            telemetry._ACTIVE_TRACKER.add_generate_invocation(10)
        reply=self.replies.pop(0)
        if isinstance(reply,BaseException):
            self.last_raw_output=None
            raise reply
        if telemetry._ACTIVE_TRACKER: telemetry._ACTIVE_TRACKER.add_completion(5)
        self.last_raw_output=reply if isinstance(reply,str) else json.dumps(reply)
        return self.last_raw_output
    def ask_json(self,prompt): return parse_json_object(self.generate([{'role':'user','content':prompt}]))


class DiagnosisTests(unittest.TestCase):
    def test_known_bad_and_good_location(self):
        self.assertEqual(diagnose(LOCATION,BAD_LOCATION)['status'],'mismatch')
        self.assertEqual(diagnose(LOCATION,GOOD_LOCATION)['status'],'compatible')

    def test_known_bad_and_good_direction(self):
        self.assertEqual(diagnose(DIRECTION,BAD_DIRECTION)['status'],'mismatch')
        self.assertEqual(diagnose(DIRECTION,GOOD_DIRECTION)['status'],'compatible')

    def test_each_compass_inverse_and_original_endpoint_order(self):
        for direction,inverse in OPPOSITE.items():
            q=DIRECTION.replace('southeast',direction)
            for wording in [f'Which river is {inverse} of the Vale?',f'Which river is the Vale {direction} of?',
                            f'The Vale is {direction} of which river?']:
                with self.subTest(direction=direction,wording=wording):
                    t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][0]['question']=wording
                    self.assertEqual(diagnose(q,t)['status'],'compatible')
            t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][0]['question']=f'Which river is {direction} of the Vale?'
            self.assertEqual(diagnose(q,t)['status'],'mismatch')

    def test_explicit_boolean_location_leaves(self):
        t=copy.deepcopy(GOOD_LOCATION)
        for n,entity in zip(t['nodes'][:2],['Alpha','Beta']):
            n.update(question=f'Was {entity} founded in Ontario?',answer_type='boolean')
        t['nodes'][-1]['dependencies']={'q1':'boolean','q2':'boolean'}
        self.assertEqual(diagnose(LOCATION,t)['status'],'compatible')

    def test_source_temporal_negation_exception_and_unknown_abstain(self):
        for q in ['Which facility was founded in Ontario before 1900, Alpha or Beta?',
                  'Which facility was not founded in Ontario, Alpha or Beta?',
                  'Where was Alpha founded?', 'The Vale lies southeast of a river.',
                  'What type of product is the sponsor of Cup?',
                  DIRECTION.replace('is a traditional','is not a traditional')]:
            with self.subTest(question=q):self.assertIsNone(source_contract(q))

    def test_unknown_plan_does_not_get_certified(self):
        t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][0]['question']='Which river borders the Vale?'
        self.assertEqual(diagnose(DIRECTION,t)['status'],'unknown')
        self.assertEqual(diagnose(LOCATION,None)['status'],'unknown')

    def test_extra_source_relation_and_hedging_abstain(self):
        for q in [DIRECTION.replace('a traditional region', 'a region northeast of a town'),
                  DIRECTION.replace('is a traditional', 'is possibly a traditional'),
                  DIRECTION.replace('a traditional region', 'a region near the capital')]:
            with self.subTest(question=q): self.assertIsNone(source_contract(q))

    def test_entity_mapping_not_global_word_coverage(self):
        t=copy.deepcopy(GOOD_LOCATION)
        t['nodes'][-1]['question']='Which facility was founded in Ontario: Alpha ({{q2}}) or Beta ({{q1}})?'
        self.assertEqual(diagnose(LOCATION,t)['status'],'unknown')

    def test_correct_entity_order_can_be_reversed_with_its_own_slots(self):
        t=copy.deepcopy(GOOD_LOCATION)
        t['nodes'][-1]['question']='Which facility was founded in Ontario: Beta ({{q2}}) or Alpha ({{q1}})?'
        self.assertEqual(diagnose(LOCATION,t)['status'],'compatible')

    def test_mixed_date_location_and_type_relabel_only_not_success(self):
        t=copy.deepcopy(BAD_LOCATION)
        t['nodes'][0].update(question='Where was Alpha founded?',answer_type='place')
        t['nodes'][-1]['dependencies']['q1']='place'
        self.assertEqual(diagnose(LOCATION,t)['status'],'mismatch')
        t=copy.deepcopy(BAD_LOCATION)
        for n in t['nodes'][:2]:n['answer_type']='place'
        t['nodes'][-1]['dependencies']={'q1':'place','q2':'place'}
        self.assertEqual(diagnose(LOCATION,t)['status'],'mismatch')

    def test_names_apostrophe_units_and_whitespace(self):
        q=LOCATION.replace('Alpha',"Valentino's").replace('Ontario','New York')
        t=json.loads(json.dumps(GOOD_LOCATION).replace('Alpha',"Valentino's").replace('Ontario','New York'))
        self.assertEqual(diagnose(q,t)['status'],'compatible')
        for unit in ['km','kilometres','kilometers']:
            t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][-1]['question']='How many '+unit+' long is {{q1}}?'
            self.assertEqual(diagnose(DIRECTION,t)['status'],'compatible')


class RepairTests(unittest.TestCase):
    def run_case(self,q,original,proposal):
        model=Model([original,proposal]);before=copy.deepcopy(original)
        result=pilot.generate_result(model,q,relation_repair=True)
        self.assertEqual(original,before)
        self.assertEqual(len(model.messages),2)
        self.assertEqual(result['decomposition_trace'][1]['messages'],model.messages[1])
        return result

    def test_accept_both_supported_repairs_and_preserve_raw(self):
        for q,bad,good in [(LOCATION,BAD_LOCATION,GOOD_LOCATION),(DIRECTION,BAD_DIRECTION,GOOD_DIRECTION)]:
            with self.subTest(q=q):
                r=self.run_case(q,bad,good)
                self.assertEqual(r['plan'],good)
                self.assertEqual(r['relation_repair']['status'],'accepted')
                self.assertEqual(json.loads(r['decomposition_trace'][0]['raw_output']),bad)
                self.assertEqual(json.loads(r['decomposition_trace'][1]['raw_output']),good)

    def test_no_extra_call_on_compatible_unknown_or_disabled(self):
        for q,p,enabled in [(LOCATION,GOOD_LOCATION,True),('Who wrote Alpha?',GOOD_LOCATION,True),(LOCATION,BAD_LOCATION,False)]:
            m=Model([p]);r=pilot.generate_result(m,q,relation_repair=enabled)
            self.assertEqual(len(m.messages),1)
            self.assertEqual(r['plan'],p)

    def test_structural_retry_exhausts_shared_budget(self):
        m=Model([{'nodes':[],'final':'q1'},BAD_LOCATION])
        r=pilot.generate_result(m,LOCATION,relation_repair=True)
        self.assertEqual(len(m.messages),2)
        self.assertEqual(r['relation_repair']['status'],'budget_exhausted')
        self.assertEqual(r['plan'],BAD_LOCATION)

    def test_drop_placeholder_or_change_graph_is_rejected(self):
        invalid=copy.deepcopy(GOOD_DIRECTION);invalid['nodes'][-1]['question']='How long is the river in km?'
        single=tree(node('q1','How long is the river northwest of the Vale in km?','number'))
        for proposed in [invalid,single]:
            r=self.run_case(DIRECTION,BAD_DIRECTION,proposed)
            self.assertEqual(r['relation_repair']['status'],'rejected')
            self.assertEqual(r['plan'],BAD_DIRECTION)

    def test_failed_repair_does_not_hide_original_error(self):
        r=self.run_case(DIRECTION,BAD_DIRECTION,BAD_DIRECTION)
        self.assertEqual(r['relation_repair']['status'],'rejected')
        self.assertEqual(r['relation_repair']['after']['status'],'mismatch')

    def test_reject_paraphrase_that_evades_detector(self):
        t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][0]['question']='Which river borders the Vale?'
        r=self.run_case(DIRECTION,BAD_DIRECTION,t)
        self.assertEqual(r['relation_repair']['status'],'rejected')
        self.assertEqual(r['decomposition_trace'][1]['candidate_diagnostic']['status'],'unknown')

    def test_preserve_length_units_target_and_direct_slot_use(self):
        for wording,kind in [('How long is {{q1}} in miles?','number'),('How long is {{q1}}?','number'),
                             ('Is {{q1}} long in kilometers?','boolean'),
                             ('How long is the river southeast of the Vale? ({{q1}}) in kilometers?','number')]:
            with self.subTest(wording=wording):
                t=copy.deepcopy(GOOD_DIRECTION);t['nodes'][-1].update(question=wording,answer_type=kind)
                self.assertEqual(self.run_case(DIRECTION,BAD_DIRECTION,t)['relation_repair']['status'],'rejected')

    def test_location_qualifier_entity_mapping_and_final_name_retained(self):
        for wording,kind in [('Which facility was founded in Quebec: Alpha ({{q1}}) or Beta ({{q2}})?','other'),
                             ('Which facility was founded in Ontario: Alpha ({{q2}}) or Beta ({{q1}})?','other'),
                             (GOOD_LOCATION['nodes'][-1]['question'],'work'),
                             ('Were Alpha and Beta founded in Ontario? ({{q1}} and {{q2}})','boolean')]:
            t=copy.deepcopy(GOOD_LOCATION);t['nodes'][-1].update(question=wording,answer_type=kind)
            self.assertEqual(self.run_case(LOCATION,BAD_LOCATION,t)['relation_repair']['status'],'rejected')

    def test_dependency_type_must_be_proposed_consistently(self):
        t=copy.deepcopy(GOOD_LOCATION);t['nodes'][-1]['dependencies']={'q1':'date','q2':'date'}
        r=self.run_case(LOCATION,BAD_LOCATION,t)
        self.assertEqual(r['relation_repair']['status'],'rejected')

    def test_malformed_payload_and_schema_rejected(self):
        for proposed in ['not JSON',{'question':'Where?','answer_type':'place'},'null']:
            self.assertEqual(self.run_case(LOCATION,BAD_LOCATION,proposed)['relation_repair']['status'],'rejected')

    def test_backend_error_preserves_original_and_raw_trace(self):
        m=Model([BAD_LOCATION,RuntimeError('synthetic offline failure')])
        with self.assertRaises(RepairBackendError) as c:
            pilot.generate_result(m,LOCATION,relation_repair=True)
        self.assertEqual(c.exception.details['plan'],BAD_LOCATION)
        self.assertEqual(len(c.exception.details['decomposition_trace']),2)


class IntegrationTests(unittest.TestCase):
    def test_cost_reporting_resume_mode_isolation_and_gold_exclusion(self):
        samples=[dict(question_id='synthetic',question=LOCATION,type='comparison',answer='GOLD_NEVER_SEND',context='EVIDENCE_NEVER_SEND')]
        m=Model([BAD_LOCATION,GOOD_LOCATION,{'status':'valid','errors':[]}])
        with tempfile.TemporaryDirectory() as tmp,redirect_stdout(io.StringIO()):
            dest=Path(tmp)/'pilot';factory=lambda settings:(m,{'backend':'synthetic'})
            s=pilot.run_pilot(samples,{},dest,model_factory=factory,relation_repair=True)
            self.assertEqual(s['total_cost']['llm_calls'],3)
            self.assertEqual(s['valid_on_first_attempt'],1)
            self.assertEqual(s['relation_repair_status'],{'accepted':1})
            self.assertNotIn('GOLD_NEVER_SEND',json.dumps(m.messages))
            self.assertNotIn('EVIDENCE_NEVER_SEND',json.dumps(m.messages))
            with zipfile.ZipFile(Path(tmp)/'pilot_results.zip') as z:
                for name in ['source_identity.json','relation_repair.json','relation_repair.md','max4_comparison.json']:
                    self.assertIn('pilot/'+name,z.namelist())
                identity=json.loads(z.read('pilot/source_identity.json'))
                self.assertIn('hotpotqa_operadic_rag/relation_repair.py',identity['recorded_files_sha256'])
            pilot.run_pilot(samples,{},dest,model_factory=factory,relation_repair=True)
            self.assertEqual(len(m.messages),3)
            with self.assertRaisesRegex(ValueError,'settings/code differ'):
                pilot.run_pilot(samples,{},dest,model_factory=factory,relation_repair=False)

    def test_backend_failure_checkpoint_keeps_plan_and_marks_incomplete(self):
        samples=[dict(question_id='synthetic',question=LOCATION,type='comparison')]
        m=Model([BAD_LOCATION,RuntimeError('synthetic failure')])
        with tempfile.TemporaryDirectory() as tmp,redirect_stdout(io.StringIO()):
            dest=Path(tmp)/'pilot';factory=lambda settings:(m,{'backend':'synthetic'})
            with self.assertRaises(RepairBackendError):
                pilot.run_pilot(samples,{},dest,model_factory=factory,relation_repair=True)
            record=json.loads((dest/'trees.csv.state/questions/synthetic.json').read_text())
            self.assertEqual(record['phases']['structure']['status'],'error')
            self.assertEqual(record['phases']['structure']['result']['plan'],BAD_LOCATION)
            summary=json.loads((dest/'summary.json').read_text())
            self.assertEqual(summary['backend_errors'],1)
            self.assertEqual(summary['incomplete_questions'],1)
            self.assertEqual(summary['total_cost']['llm_calls'],2)
