@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=python"
if exist ".venv\Scripts\python.exe" set "PYTHON=%~dp0.venv\Scripts\python.exe"
if defined VIRTUAL_ENV set "PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PYTHON=%HOTPOT_PYTHON%"
"%PYTHON%" -m unittest discover -s tests -v
set "TEST_EXIT=%errorlevel%"
pause
exit /b %TEST_EXIT%
