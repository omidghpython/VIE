"""Check Windows VM CUDA, PyTorch and bitsandbytes visibility."""
import sys

try:
    import torch
except Exception as exc:
    print(f"PyTorch import failed: {exc}")
    raise SystemExit(1)

print("Python:", sys.version.split()[0])
print("PyTorch:", torch.__version__)
print("PyTorch CUDA build:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
if not torch.cuda.is_available():
    raise SystemExit("CUDA GPU is not visible to this Python environment.")
for i in range(torch.cuda.device_count()):
    p = torch.cuda.get_device_properties(i)
    print(f"GPU {i}: {p.name} | VRAM: {p.total_memory / 1024**3:.2f} GiB")
try:
    import bitsandbytes as bnb
    print("bitsandbytes:", getattr(bnb, "__version__", "installed"))
except Exception as exc:
    print("bitsandbytes import error:", repr(exc))
    print("Install/repair bitsandbytes before running with --use-4bit.")
