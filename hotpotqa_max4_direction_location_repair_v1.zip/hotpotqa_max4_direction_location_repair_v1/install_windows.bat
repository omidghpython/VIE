@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=%~dp0.venv\Scripts\python.exe"
if not exist "%PYTHON%" (
  echo Creating project virtual environment with Python 3.13...
  py -3.13 -m venv .venv
  if errorlevel 1 exit /b 1
)
echo ======================================================
echo Installing project dependencies (preserving PyTorch)
echo ======================================================
"%PYTHON%" --version
if errorlevel 1 exit /b 1
"%PYTHON%" -m pip install --upgrade pip
if errorlevel 1 exit /b 1
"%PYTHON%" -m pip install -r requirements_windows.txt
if errorlevel 1 (
  echo Dependency installation failed. Review the error above.
  pause
  exit /b 1
)
echo.
echo Checking CUDA and bitsandbytes...
"%PYTHON%" check_gpu.py
if errorlevel 1 (
  echo GPU check failed. Do not start the experiment until CUDA works.
  pause
  exit /b 1
)
echo.
echo Libraries installed. Model weights have NOT been downloaded yet.
echo Run download_models.bat to download Qwen and BGE model weights.
pause
