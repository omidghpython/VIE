import copy
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from hotpotqa_operadic_rag.experiment_diagnostics import analyze, EXPERIMENT
import decomposition_pilot as pilot
from hotpotqa_operadic_rag.checkpoint import RunStore


def node(nid, question, kind='other', deps=None):
    return dict(id=nid, question=question, answer_type=kind, dependencies=deps or {})


def plan(*nodes):
    return dict(nodes=list(nodes), final=nodes[-1]['id'])


class DiagnosticsTests(unittest.TestCase):
    def check(self, question, tree, status, code=None):
        old = copy.deepcopy(tree)
        result = analyze(question, tree)
        self.assertEqual(result['status'], status, result)
        if code:
            self.assertIn(code, [f['code'] for f in result['findings']])
        self.assertEqual(tree, old)
        return result

    def test_invalid_and_missing_plan_abstain(self):
        self.check('Which river?', None, 'unknown')
        self.check('Who?', {'nodes': [], 'final': 'q1'}, 'unknown')

    def test_unknown_wording_abstains(self):
        self.check('Explain the phenomenon.', plan(node('q1', 'Explain the phenomenon.')), 'unknown')

    def test_reports_are_in_archive_and_no_model_load(self):
        samples = [dict(question_id='synthetic', question='Who wrote Alpha?', type='bridge')]
        with tempfile.TemporaryDirectory() as tmp:
            store = RunStore(Path(tmp)/'run/trees.csv', dict(backend='injected_test', n_samples=1), lambda: samples)
            summary = pilot.export_reports(store, {})
            self.assertEqual(summary['total_cost']['llm_calls'], 0)
            with zipfile.ZipFile(Path(tmp)/'run_results.zip') as z:
                self.assertIn('run/diagnostics.json', z.namelist())
                self.assertIn('run/diagnostics.md', z.namelist())
                report = json.loads(z.read('run/diagnostics.json'))
                self.assertEqual(report['status_counts'], {'unknown': 1})
                self.assertEqual(report['role'], 'advisory_only')

    def test_same_direction_swapped_endpoints(self):
        self.check('The Vale is a region southeast of a river that is how many km long?',
                   plan(node('q1', 'Which river is southeast of the Vale?')), 'suspicious', 'direction_role_mismatch')

    def test_inverse_direction_with_swapped_endpoints_is_supported(self):
        self.check('The Vale is southeast of a river.', plan(node('q1', 'Which river is northwest of the Vale?')), 'no_violation_found')

    def test_original_direction_with_original_endpoints(self):
        for text in ['Which river is the Vale southeast of?', 'The Vale is southeast of which river?']:
            with self.subTest(text=text):
                self.check('The Vale is southeast of a river.', plan(node('q1', text)), 'no_violation_found')

    def test_direction_unknown_syntax_abstains(self):
        self.check('The Vale lies beyond a river.', plan(node('q1', 'Which river borders Vale?')), 'unknown')

    def test_compass_hyphen_unsupported_abstains(self):
        self.check('Vale is south-east of a river.', plan(node('q1', 'Which river is south-east of Vale?')), 'unknown')

    def test_location_replaced_by_time(self):
        self.check('Which facility was founded in Ontario, Alpha or Beta?',
                   plan(node('q1', 'When was Alpha founded?', 'date')), 'suspicious', 'location_replaced_by_time')

    def test_location_positive(self):
        self.check('Which facility was founded in Ontario, Alpha or Beta?',
                   plan(node('q1', 'Where was Alpha founded?', 'place')), 'no_violation_found')

    def test_original_time_request_not_flagged(self):
        self.check('Which facility was founded in Ontario earlier, Alpha or Beta?',
                   plan(node('q1', 'When was Alpha founded?', 'date')), 'unknown')

    def product(self, root):
        return plan(node('q1', 'Who sponsors Cup?', 'organization'), node('q2', root, 'other', {'q1':'organization'}))

    def test_identity_replaced_by_production(self):
        self.check('What type of product is the sponsor of Cup?', self.product('What does {{q1}} produce?'),
                   'suspicious', 'identity_replaced_by_production')

    def test_identity_preserved(self):
        self.check('What type of product is the sponsor of Cup?', self.product('What type of product is {{q1}}?'), 'no_violation_found')

    def test_original_production_request_abstains(self):
        self.check('What type of product does the sponsor of Cup produce?', self.product('What does {{q1}} produce?'), 'unknown')

