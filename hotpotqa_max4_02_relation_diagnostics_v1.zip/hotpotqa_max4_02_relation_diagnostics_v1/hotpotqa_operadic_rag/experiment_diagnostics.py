"""Advisory diagnostics only: never called by generation, validation or judging.

no_violation_found means only that supported patterns passed these narrow checks.
unknown is an abstention, and suspicious is not a semantic verdict or a rejection.
"""
import re
from collections import Counter
from .contracts import validate_plan


def norm(text):
    return ' '.join(re.findall(r"[a-z0-9]+", text.casefold()))


def finding(code, nodes, reason, **evidence):
    return dict(code=code, nodes=nodes, reason=reason, evidence=evidence)


def analyze(question, plan):
    try:
        clean = validate_plan(plan)
    except (ValueError, TypeError, KeyError) as exc:
        return dict(status='unknown', supported_checks=[], findings=[], reason='No structurally valid plan: ' + str(exc))
    supported, findings = inspect(question, clean)
    return dict(status='suspicious' if findings else ('no_violation_found' if supported else 'unknown'),
                supported_checks=supported, findings=findings,
                reason='Advisory pattern checks only; no assertion of complete semantic correctness.')


def build_report(store):
    rows = []
    for order, sample in enumerate(store.samples, 1):
        result = store.read(sample['question_id'])['phases'].get('structure', {}).get('result', {})
        rows.append(dict(order=order, question_id=sample['question_id'], question=sample['question'],
                         diagnostic=analyze(sample['question'], result.get('plan'))))
    report = dict(experiment=EXPERIMENT, role='advisory_only', calls=0,
                  status_counts=dict(Counter(row['diagnostic']['status'] for row in rows)), questions=rows,
                  limitation='No automatic rejection, repair, gold answers, or model calls. Unknown patterns abstain.')
    lines = ['# Advisory diagnostics', '', report['limitation'], '',
             'no_violation_found covers supported checks only; it is not semantic validity.', '']
    for row in rows:
        lines += [f"## {row['order']}. {row['question_id']}: {row['diagnostic']['status']}", '', row['question'], '']
        lines += [f"- {item['code']} ({', '.join(item['nodes'])}): {item['reason']} Evidence: {item['evidence']}"
                  for item in row['diagnostic']['findings']]
        if not row['diagnostic']['findings']:
            lines += [row['diagnostic']['reason']]
        lines += ['']
    return report, '\n'.join(lines)


EXPERIMENT = 'max4_02_relation_diagnostics_v1'
OPPOSITE = dict(north='south', south='north', east='west', west='east',
                northeast='southwest', southwest='northeast', southeast='northwest', northwest='southeast')
DIRECTION = '|'.join(sorted(OPPOSITE, key=len, reverse=True))


def inspect(question, plan):
    supported, findings = [], []
    # Explicit source subject and an indefinite target after a compass relation.
    source = re.search(r'^(?:the )?(.+?) is\b[^?]*?\b(' + DIRECTION + r') of (?:a|an|the) (river|city|town|region|country)\b',
                       question, re.I)
    if source:
        entity, direction, target = source.groups()
        entity, direction, target = norm(entity), direction.lower(), target.lower()
        for node in plan['nodes']:
            if node['dependencies']:
                continue
            text = norm(node['question'])
            # Known A appears after 'of'; WH B is the subject. Its direction must invert.
            reverse = re.fullmatch(r'(?:which|what) ' + target + r' is (' + DIRECTION + r') of (?:the )?' + re.escape(entity), text)
            direct = re.fullmatch(r'(?:which|what) ' + target + r' is (?:the )?' + re.escape(entity) + r' (' + DIRECTION + r') of', text)
            direct2 = re.fullmatch(r'(?:the )?' + re.escape(entity) + r' is (' + DIRECTION + r') of (?:which|what) ' + target, text)
            match = reverse or direct or direct2
            if not match:
                continue
            supported.append('direction:' + node['id'])
            expected = OPPOSITE[direction] if reverse else direction
            if match[1] != expected:
                findings.append(finding('direction_role_mismatch', [node['id']],
                    'Compass direction does not match the ordered entity pair.', known_entity=entity,
                    original_direction=direction, observed_direction=match[1], expected_direction=expected,
                    endpoints_reversed=bool(reverse)))
    # Only the narrow founded-in-place comparison; explicit time in the source abstains.
    location = re.search(r'\bfounded in ([A-Z][A-Za-z -]*?)[,?]', question)
    time = re.search(r'\b(?:when|year|date|earlier|later|before|after|\d{4})\b', question, re.I)
    if location and not time and re.search(r'\bor\b', question, re.I):
        for node in plan['nodes']:
            if node['dependencies'] or not re.search(r'\bfound(?:ed|ing)\b', node['question'], re.I):
                continue
            text = node['question'].casefold()
            if re.search(r'\b(?:when|date|year)\b', text):
                supported.append('founding_dimension:' + node['id'])
                findings.append(finding('location_replaced_by_time', [node['id']],
                    'A founding date alone does not supply the requested founding location.', place=location[1]))
            elif re.search(r'\b(?:where|place|city|state|location)\b', text) or norm(location[1]) in norm(text):
                supported.append('founding_dimension:' + node['id'])
    identity = re.search(r'\b(?:what|which) (?:type|kind|sort) of product is\b', question, re.I)
    production = r'\b(?:produce[sd]?|make[sd]?|manufacture[sd]?)\b'
    if identity and not re.search(production, question, re.I):
        for node in plan['nodes']:
            if 'organization' not in node['dependencies'].values():
                continue
            if re.search(production, node['question'], re.I):
                supported.append('identity_relation:' + node['id'])
                findings.append(finding('identity_replaced_by_production', [node['id']],
                    'An organizational input is asked what it produces instead of what type of product it is.',
                    original_relation='is', observed=node['question']))
            elif re.search(r'\b(?:type|kind|sort) of product (?:is|was)\b', node['question'], re.I):
                supported.append('identity_relation:' + node['id'])
    return supported, findings
