# Review of the decompositions

Mark each item: (a) is the TREE well-formed? (b) is the DECOMPOSITION correct, i.e. do the sub-questions capture exactly the reasoning the question needs? Use review.csv for the marks.

## 5ac2cdaa554299657fa29070 | gold type: comparison | auto verdict: TREE_INVALID

- Question: Where are Neoregelia and Aloysia known to grow
- Gold answer: temperate climates,
- Gold paragraphs: Neoregelia, Aloysia

```
[comparison] Where are Neoregelia and Aloysia known to grow
  ROOT: Where are Neorelia (known to grow [A1]) and Aloysia (known to grow [A2]) known to grow?
   `-- [A1] <- Where is Neorelia known to grow?   => 'South American rainforests'
   `-- [A2] <- Where is Aloysia known to grow?   => 'Americas, temperate climates, subtropical and desert climates'
  filled root : Where are Neorelia (known to grow South American rainforests) and Aloysia (known to grow Americas, temperate climates, subtropical and desert climates) known to grow?
  final answer: 'South American rainforests, Americas, temperate climates, subtropical and desert climates'   (gold: 'temperate climates,') -> MISMATCH
  control     : 'South American rainforests, Americas' -> MISMATCH
```
- Failed checks: leaves_cover_distinct_entities, root_restates_entities, entities_ok, structure_ok
- Warning: tree drops tokens of the question: neoregelia

## 5a793bc95542994bb9456fc3 | gold type: bridge | auto verdict: TREE_INVALID

- Question: Who was born first, Brooklyn Decker or Andy Roddick?
- Gold answer: Andrew Stephen Roddick
- Gold paragraphs: Brooklyn Decker, Andy Roddick

```
[comparison] Who was born first, Brooklyn Decker or Andy Roddick?
  ROOT: Who was born first: Brooklyn Decker (born [A1]) or Andy Roddick (born [A2])?
   `-- [A1] <- When was Brooklyn Decker born?   => 'April 12, 1987'
   `-- [A2] <- When was Andy Roddick born?   => 'August 30, 1982'
  filled root : Who was born first: Brooklyn Decker (born April 12, 1987) or Andy Roddick (born August 30, 1982)?
  final answer: 'no'   (gold: 'Andrew Stephen Roddick') -> MISMATCH
  control     : 'Andy Roddick' -> MISMATCH
```
- Failed checks: type_ok, structure_ok

## 5a72d7b35542991f9a20c5be | gold type: bridge | auto verdict: OK

- Question: What is the name of the pop artist that belongs on the Pledis Entertainment label and has 13 members?
- Gold answer: Seventeen
- Gold paragraphs: Pledis Entertainment, Seventeen (band)

```
[bridge] What is the name of the pop artist that belongs on the Pledis Entertainment label and has 13 members?
  ROOT: What is the name of [A1]?
   `-- [A1] <- Which pop artist belongs on the Pledis Entertainment label and has 13 members?   => 'Seventeen'
  filled root : What is the name of Seventeen?
  final answer: 'Seventeen'   (gold: 'Seventeen') -> MATCH
  control     : 'Seventeen' -> MATCH
```

## 5adf62d05542992d7e9f932d | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Which number-one single is Michael Steele responsible for?
- Gold answer: "Walk Like an Egyptian"
- Gold paragraphs: Ezo (band), The Bangles

```
[bridge] Which number-one single is Michael Steele responsible for?
  ROOT: Which number-one single is [A1] responsible for?
   `-- [A1] <- Which number-one single did Michael Steele produce?   => 'UNKNOWN'
  filled root : Which number-one single is UNKNOWN responsible for?
  final answer: 'UNKNOWN'   (gold: '"Walk Like an Egyptian"') -> MISMATCH
  control     : 'UNKNOWN' -> MISMATCH
```
- Failed checks: anchor_in_q1

## 5a85a3005542991dd0999e72 | gold type: bridge | auto verdict: OK

- Question: The Azad Hind Dal was created by an Indian nationalist whose defiant patriotism made him a hero in India, but whose attempt to rid India of British rule during what war left a troubled legacy?
- Gold answer: World War II
- Gold paragraphs: Azad Hind Dal, Subhas Chandra Bose

```
[bridge] The Azad Hind Dal was created by an Indian nationalist whose defiant patriotism made him a hero in India, but whose attempt to rid India of British rule during what war left a troubled legacy?
  ROOT: [A1] (whose defiant patriotism made him a hero in India) attempted to rid India of British rule during what war (which left a troubled legacy)?
   `-- [A1] <- Whose defiant patriotism made him a hero in India and whose attempt to rid India of British rule during what war left a troubled legacy?   => "Subhas Chandra Bose's"
  filled root : Subhas Chandra Bose's (whose defiant patriotism made him a hero in India) attempted to rid India of British rule during what war (which left a troubled legacy)?
  final answer: 'World War II'   (gold: 'World War II') -> MATCH
  control     : 'World War II' -> MATCH
```
- Failed checks: anchor_in_q1
- Warning: sub-question 1 may not be self-contained (contains him)
- Warning: tree drops tokens of the question: azad, dal, hind, indian
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each

## 5a831fc955429954d2e2ec28 | gold type: bridge | auto verdict: OK

- Question: What city is the most populous city in Australia and Oceania and the birthplace of a silver and bronze medalist from the 1992 Barcelona Paralympics?
- Gold answer: Sydney
- Gold paragraphs: Marsha Green, Sydney

```
[bridge] What city is the most populous city in Australia and Oceania and the birthplace of a silver and bronze medalist from the 1992 Barcelona Paralympics?
  ROOT: What city is the most populous city in Australia and Oceania (where the silver and bronze medalist from the 1992 Barcelona Paralympics was born in [A1])?
   `-- [A1] <- What city is the birthplace of a silver and bronze medalist from the 1992 Barcelona Paralympics?   => 'Sydney'
  filled root : What city is the most populous city in Australia and Oceania (where the silver and bronze medalist from the 1992 Barcelona Paralympics was born in Sydney)?
  final answer: 'Sydney'   (gold: 'Sydney') -> MATCH
  control     : 'Sydney' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2

## 5a812d0555429938b61422e1 | gold type: comparison | auto verdict: OK

- Question: Which breed of dog came first, the Norrbottenspets or the Blue Lacy?
- Gold answer: Norrbottenspets
- Gold paragraphs: Norrbottenspets, Blue Lacy

```
[comparison] Which breed of dog came first, the Norrbottenspets or the Blue Lacy?
  ROOT: Which breed of dog came first, the Norrbottenspets (recognized in [A1]) or the Blue Lacy (recognized in [A2])?
   `-- [A1] <- When was the Norrbottenspets breed recognized?   => 'UNKNOWN'
   `-- [A2] <- When was the Blue Lacy breed recognized?   => '2001'
  filled root : Which breed of dog came first, the Norrbottenspets (recognized in UNKNOWN) or the Blue Lacy (recognized in 2001)?
  final answer: 'Norrbottenspets'   (gold: 'Norrbottenspets') -> MATCH
  control     : 'Norrbottenspets' -> MATCH
```

## 5a7b443c5542992d025e67ce | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Who was the director behind the Cirque du Soleil show in Las Vegas that was first performed on December 25, 1993?
- Gold answer: Franco Dragone
- Gold paragraphs: Le Rêve (show), Mystère (Cirque du Soleil)

```
[bridge] Who was the director behind the Cirque du Soleil show in Las Vegas that was first performed on December 25, 1993?
  ROOT: Who was the director of the Cirque du Soleil show [A1]?
   `-- [A1] <- Which Cirque du Soleil show was first performed on December 25, 1993 in Las Vegas?   => 'Mystère'
  filled root : Who was the director of the Cirque du Soleil show Mystère?
  final answer: 'UNKNOWN'   (gold: 'Franco Dragone') -> MISMATCH
  control     : 'Franco Dragone' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: root just repeats the original question

## 5adf34d35542993a75d26425 | gold type: bridge | auto verdict: OK

- Question: Who was the president of the Sinn Fein political party during the Hume-Adams Dialogue?
- Gold answer: Gerard "Gerry" Adams
- Gold paragraphs: Hume–Adams dialogue, Gerry Adams

```
[bridge] Who was the president of the Sinn Fein political party during the Hume-Adams Dialogue?
  ROOT: Who was the president of the Sinn Fein political party [A1]?
   `-- [A1] <- During the Hume-Adams Dialogue, who was the president of the Sinn Fein political party?   => 'Gerry Adams'
  filled root : Who was the president of the Sinn Fein political party Gerry Adams?
  final answer: 'Gerry Adams'   (gold: 'Gerard "Gerry" Adams') -> MATCH
  control     : 'Gerry Adams' -> MATCH
```
- Failed checks: anchor_in_q1

## 5a78bd515542990784727749 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: The show featuring a young boy named Gerald Bald Z premiered on what TV channel? 
- Gold answer: Cartoon Network
- Gold paragraphs: Anime Talk Show, Perfect Hair Forever

```
[bridge] The show featuring a young boy named Gerald Bald Z premiered on what TV channel? 
  ROOT: The show featuring a young boy named Gerald Bald Z premiered on [A1].
   `-- [A1] <- What is the name of the TV channel where the show featuring a young boy named Gerald Bald Z premiered?   => 'Cartoon Network'
  filled root : The show featuring a young boy named Gerald Bald Z premiered on Cartoon Network.
  final answer: 'UNKNOWN'   (gold: 'Cartoon Network') -> MISMATCH
  control     : 'Cartoon Network' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: root must contain the placeholders [A1] exactly once each; root just repeats the original question

## 5adbf69c55429947ff173871 | gold type: bridge | auto verdict: NO_TREE

- Question: Tolex and General Tire manufacture very different products, but both make accessories for what type of transportation vehicle?
- Gold answer: automobiles
- Gold paragraphs: Tolex, General Tire
- No valid tree. Problems per attempt: a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each | root must contain the placeholders [A1] exactly once each | root must contain the placeholders [A1] exactly once each

```
last raw output: {"type": "bridge", "sub_questions": ["What type of transportation vehicle do Tolex accessories fit?"], "root": "Tolex and General Tire both make accessories for the same type of transportation vehicle (Tolex [A1], General Tire [A1])."}
```

## 5adf53dc5542995534e8c791 | gold type: comparison | auto verdict: EXEC_MISMATCH

- Question: Who has more productions under their belt Ridley Scott or Elmer Clifton?
- Gold answer: Ridley Scott
- Gold paragraphs: Ridley Scott, Elmer Clifton

```
[comparison] Who has more productions under their belt Ridley Scott or Elmer Clifton?
  ROOT: Who has more productions under their belt: Ridley Scott (with [A1] productions) or Elmer Clifton (with [A2] productions)?
   `-- [A1] <- How many productions does Ridley Scott have under their belt?   => 'UNKNOWN'
   `-- [A2] <- How many productions does Elmer Clifton have under their belt?   => 'UNKNOWN'
  filled root : Who has more productions under their belt: Ridley Scott (with UNKNOWN productions) or Elmer Clifton (with UNKNOWN productions)?
  final answer: 'unknown'   (gold: 'Ridley Scott') -> MISMATCH
  control     : 'Ridley Scott' -> MATCH
```
- Warning: sub-question 1 may not be self-contained (contains their)
- Warning: sub-question 2 may not be self-contained (contains their)

## 5ae788fa55429952e35ea964 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: The On Tour Forever album gave Blues Traveler the opportunity to display what musical trademark?
- Gold answer: extensive use of segues
- Gold paragraphs: On Tour Forever, Blues Traveler

```
[bridge] The On Tour Forever album gave Blues Traveler the opportunity to display what musical trademark?
  ROOT: What musical trademark did the On Tour Forever album give Blues Traveler (opportunity to display [A1]) the chance to show?
   `-- [A1] <- What musical trademark did the On Tour Forever album give Blues Traveler the opportunity to display?   => 'extensive use of segues'
  filled root : What musical trademark did the On Tour Forever album give Blues Traveler (opportunity to display extensive use of segues) the chance to show?
  final answer: 'UNKNOWN'   (gold: 'extensive use of segues') -> MISMATCH
  control     : 'segues' -> MISMATCH
```
- Needed 3 attempts; problems seen: root just repeats the original question | root must contain the placeholders [A1] exactly once each

## 5abb342055429966062416e8 | gold type: bridge | auto verdict: OK

- Question: The world's greatest Super-Heroes anthology showcased one of four superheroes known for speaking the phrase "SHAZAM", what was their name?
- Gold answer: Captain Marvel
- Gold paragraphs: The World's Greatest Super-Heroes, Captain Marvel (DC Comics)

```
[bridge] The world's greatest Super-Heroes anthology showcased one of four superheroes known for speaking the phrase "SHAZAM", what was their name?
  ROOT: The world's greatest Super-Heroes anthology showcased one of [A1], what was their name?
   `-- [A1] <- Which four superheroes are known for speaking the phrase 'SHAZAM'?   => 'UNKNOWN'
  filled root : The world's greatest Super-Heroes anthology showcased one of UNKNOWN, what was their name?
  final answer: 'Captain Marvel'   (gold: 'Captain Marvel') -> MATCH
  control     : 'Billy Batson' -> MISMATCH
```
- Failed checks: anchor_in_q1

## 5a776b82554299373536026f | gold type: bridge | auto verdict: OK

- Question: What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?
- Gold answer: yen
- Gold paragraphs: Asahi-Ryokuken Yomiuri Memorial, Japanese yen

```
[bridge] What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?
  ROOT: What is the official currency in [A1]?
   `-- [A1] <- In which country is the Asahi-Ryokuken Yomiuri Memorial tournament hosted?   => 'Japan'
  filled root : What is the official currency in Japan?
  final answer: 'Japanese yen'   (gold: 'yen') -> MATCH
  control     : 'Japanese yen' -> MATCH
```

## 5abe87cb5542993f32c2a156 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Millennium Greens were funded in part by a what type of lottery?
- Gold answer: state-franchised
- Gold paragraphs: Millennium Green, National Lottery (United Kingdom)

```
[bridge] Millennium Greens were funded in part by a what type of lottery?
  ROOT: Millennium Greens were funded in part by a [A1] lottery.
   `-- [A1] <- What type of lottery funded Millennium Greens in part?   => 'National Lottery'
  filled root : Millennium Greens were funded in part by a National Lottery lottery.
  final answer: 'yes'   (gold: 'state-franchised') -> MISMATCH
  control     : 'National Lottery' -> MISMATCH
```
- Failed checks: anchor_in_q1

## 5ab236645542993be8fa98c9 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: August R. Lindt served as chairman of a UN program from 1956 to 1960 that won how many noble prizes ?
- Gold answer: two Nobel Peace Prizes
- Gold paragraphs: August R. Lindt, United Nations High Commissioner for Refugees

```
[bridge] August R. Lindt served as chairman of a UN program from 1956 to 1960 that won how many noble prizes ?
  ROOT: August R. Lindt served as chairman of [A1] from 1956 to 1960 that won how many noble prizes?
   `-- [A1] <- Which UN program did August R. Lindt serve as chairman from 1956 to 1960?   => 'UNKNOWN'
  filled root : August R. Lindt served as chairman of UNKNOWN from 1956 to 1960 that won how many noble prizes?
  final answer: 'UNKNOWN 2'   (gold: 'two Nobel Peace Prizes') -> MISMATCH
  control     : 'UNKNOWN' -> MISMATCH
```

## 5a733b835542991f9a20c6b2 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Which movie is loosley based off the Brother Grimm's "Iron Henry"?
- Gold answer: The Frog Prince
- Gold paragraphs: The Princess and the Frog, The Frog Prince

```
[bridge] Which movie is loosley based off the Brother Grimm's "Iron Henry"?
  ROOT: Which movie is loosely based off the Brothers Grimm's 'Iron Henry' ([A1])?
   `-- [A1] <- Which movie is loosely based off the Brothers Grimm's 'Iron Henry'?   => 'The Princess and the Frog'
  filled root : Which movie is loosely based off the Brothers Grimm's 'Iron Henry' (The Princess and the Frog)?
  final answer: 'The Princess and the Frog'   (gold: 'The Frog Prince') -> MISMATCH
  control     : 'The Princess and the Frog' -> MISMATCH
```
- Failed checks: anchor_in_q1
- Warning: tree drops tokens of the question: brother
- Needed 2 attempts; problems seen: root must contain the placeholders [A1] exactly once each

## 5a7326cd5542991f29ee2d11 | gold type: bridge | auto verdict: OK

- Question: In the television series Green Hornet, which actor played the role of Kato?
- Gold answer: Bruce Lee
- Gold paragraphs: The Green Hornet (TV series), Kato (The Green Hornet)

```
[bridge] In the television series Green Hornet, which actor played the role of Kato?
  ROOT: Which actor played the role of Kato in the television series Green Hornet ([A1])?
   `-- [A1] <- In the television series Green Hornet, who played the role of Kato?   => 'Bruce Lee'
  filled root : Which actor played the role of Kato in the television series Green Hornet (Bruce Lee)?
  final answer: 'Bruce Lee'   (gold: 'Bruce Lee') -> MATCH
  control     : 'Bruce Lee' -> MATCH
```
- Needed 2 attempts; problems seen: root just repeats the original question

## 5a77a65b5542992a6e59df57 | gold type: bridge | auto verdict: OK

- Question: when was the album that includes the song by Dustin Lynch released to country radio on February 17, 2017?
- Gold answer: September 8, 2017
- Gold paragraphs: Current Mood, Small Town Boy (song)

```
[bridge] when was the album that includes the song by Dustin Lynch released to country radio on February 17, 2017?
  ROOT: When was the album that includes the song by Dustin Lynch (released on February 17, 2017) released to country radio ([A1])?
   `-- [A1] <- When was the album that includes the song by Dustin Lynch released to country radio?   => 'February 17, 2017'
  filled root : When was the album that includes the song by Dustin Lynch (released on February 17, 2017) released to country radio (February 17, 2017)?
  final answer: 'September 8, 2017'   (gold: 'September 8, 2017') -> MATCH
  control     : 'September 8, 2017' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 3 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each | a bridge question needs exactly 1 sub-question(s), got 2

## 5a80c79155429938b61421da | gold type: bridge | auto verdict: OK

- Question: How many seasons has a popular tv show had, in which one of the episodes is called Moho House?
- Gold answer: 28
- Gold paragraphs: Moho House, The Simpsons (season 28)

```
[bridge] How many seasons has a popular tv show had, in which one of the episodes is called Moho House?
  ROOT: How many seasons has [A1] had?
   `-- [A1] <- Which popular TV show has an episode called Moho House?   => 'The Simpsons'
  filled root : How many seasons has The Simpsons had?
  final answer: '28'   (gold: '28') -> MATCH
  control     : '28' -> MATCH
```

## 5a81e8ea5542995ce29dcc73 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Who played the role of Nettie Harris in the 1985 film directed by Steven Spielberg?
- Gold answer: Akosua Gyamama Busia
- Gold paragraphs: Akosua Busia, The Color Purple (film)

```
[bridge] Who played the role of Nettie Harris in the 1985 film directed by Steven Spielberg?
  ROOT: Who played the role of Nettie Harris in the 1985 film directed by [A1]?
   `-- [A1] <- In the 1985 film directed by Steven Spielberg, who played the role of Nettie Harris?   => 'Akosua Busia'
  filled root : Who played the role of Nettie Harris in the 1985 film directed by Akosua Busia?
  final answer: 'UNKNOWN'   (gold: 'Akosua Gyamama Busia') -> MISMATCH
  control     : 'Akosua Busia' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: root must contain the placeholders [A1] exactly once each; root just repeats the original question

## 5ab84f2c55429934fafe6d54 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: The Red Queen's Race is a science fiction short story that uses the Red Queen's race from a novel by Lewis Carroll that is the sequel to what?
- Gold answer: Alice's Adventures in Wonderland
- Gold paragraphs: The Red Queen's Race, Through the Looking-Glass

```
[bridge] The Red Queen's Race is a science fiction short story that uses the Red Queen's race from a novel by Lewis Carroll that is the sequel to what?
  ROOT: The Red Queen's Race is a science fiction short story that uses the Red Queen's race from a novel by Lewis Carroll that is the sequel to [A1].
   `-- [A1] <- What is the title of the novel by Lewis Carroll that is the sequel to Alice's Adventures in Wonderland?   => 'Through the Looking-Glass'
  filled root : The Red Queen's Race is a science fiction short story that uses the Red Queen's race from a novel by Lewis Carroll that is the sequel to Through the Looking-Glass.
  final answer: 'UNKNOWN'   (gold: "Alice's Adventures in Wonderland") -> MISMATCH
  control     : "Alice's Adventures in Wonderland" -> MATCH
```
- Failed checks: anchor_in_q1

## 5abfd5c45542994516f4550e | gold type: bridge | auto verdict: OK

- Question: When "Good Night" was aired on "The Simpsons 138th Epsiode Spectacular," which actress did the voice of the character named after Matt Groening's mother?
- Gold answer: Julie Kavner
- Gold paragraphs: Marge Simpson, Good Night (The Simpsons short)

```
[bridge] When "Good Night" was aired on "The Simpsons 138th Epsiode Spectacular," which actress did the voice of the character named after Matt Groening's mother?
  ROOT: When 'Good Night' was aired on 'The Simpsons 138th Epsiode Spectacular' (aired in [A1]), which actress did the voice of the character named after Matt Groening's mother?
   `-- [A1] <- When was 'Good Night' aired on 'The Simpsons 138th Epsiode Spectacular'?   => 'In its entirety'
  filled root : When 'Good Night' was aired on 'The Simpsons 138th Epsiode Spectacular' (aired in In its entirety), which actress did the voice of the character named after Matt Groening's mother?
  final answer: 'Julie Kavner'   (gold: 'Julie Kavner') -> MATCH
  control     : 'Julie Kavner' -> MATCH
```
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each

## 5a7300b85542994cef4bc41a | gold type: comparison | auto verdict: TREE_INVALID

- Question: Gaia is a space observatory of the European Space Agency, what is Astrosat?
- Gold answer: India's first dedicated multi-wavelength space observatory.
- Gold paragraphs: Gaia (spacecraft), Astrosat

```
[bridge] Gaia is a space observatory of the European Space Agency, what is Astrosat?
  ROOT: Astrosat is a space observatory of the European Space Agency ([A1]). What is Astrosat?
   `-- [A1] <- What is Astrosat?   => "India's first dedicated multi-wavelength space observatory"
  filled root : Astrosat is a space observatory of the European Space Agency (India's first dedicated multi-wavelength space observatory). What is Astrosat?
  final answer: "Astrosat is India's first dedicated multi-wavelength space observatory"   (gold: "India's first dedicated multi-wavelength space observatory.") -> MATCH
  control     : "Astrosat is India's first dedicated multi-wavelength space observatory" -> MATCH
```
- Failed checks: type_ok, structure_ok

## 5abc5951554299114383a116 | gold type: bridge | auto verdict: NO_TREE

- Question: Which Argentine telenovela broadcast by Telefe from March 12 to December 19, 2012 starred Isabel Macedo as Jimena Benitez?
- Gold answer: Graduados
- Gold paragraphs: Patricia Longo, Graduados
- No valid tree. Problems per attempt: sub-question 1 just repeats the original question; root must contain the placeholders [A1] exactly once each; root just repeats the original question | sub-question 1 just repeats the original question; root must contain the placeholders [A1] exactly once each | sub-question 1 just repeats the original question; root must contain the placeholders [A1] exactly once each

```
last raw output: {"type": "bridge", "sub_questions": ["Which Argentine telenovela broadcast by Telefe from March 12 to December 19, 2012 starred Isabel Macedo as Jimena Benitez?"], "root": "What was the name of the telenovela that starred Isabel Macedo as Jimena Benitez?"}
```

## 5a7f79155542995d8a8dde86 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: A man known as one of the most brutal pro-Confederate guerrilla leaders in the American Civil War had a following that included a bank and train robber from western Missouri raised in what area?
- Gold answer: Little Dixie
- Gold paragraphs: Jesse James, William T. Anderson

```
[bridge] A man known as one of the most brutal pro-Confederate guerrilla leaders in the American Civil War had a following that included a bank and train robber from western Missouri raised in what area?
  ROOT: A man known as one of the most brutal pro-Confederate guerrilla leaders in the American Civil War had a following that included a bank and train robber from western Missouri raised in [A1].
   `-- [A1] <- What area was the bank and train robber from western Missouri raised in?   => 'Little Dixie'
  filled root : A man known as one of the most brutal pro-Confederate guerrilla leaders in the American Civil War had a following that included a bank and train robber from western Missouri raised in Little Dixie.
  final answer: 'yes'   (gold: 'Little Dixie') -> MISMATCH
  control     : 'Little Dixie' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 3 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each | root must contain the placeholders [A1] exactly once each

## 5ade0bc55542997545bbbe30 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: What role did Kim Dong-wook play in the 2012 South Korean historical film directed by Kim Dae-seung?
- Gold answer: an obsessed and tormented king
- Gold paragraphs: Kim Dong-wook, The Concubine (film)

```
[bridge] What role did Kim Dong-wook play in the 2012 South Korean historical film directed by Kim Dae-seung?
  ROOT: Kim Dong-wook played [A1] in the 2012 South Korean historical film directed by Kim Dae-seung.
   `-- [A1] <- In the 2012 South Korean historical film directed by Kim Dae-seung, what role did Kim Dong-wook play?   => 'Prince Sung-won'
  filled root : Kim Dong-wook played Prince Sung-won in the 2012 South Korean historical film directed by Kim Dae-seung.
  final answer: 'yes'   (gold: 'an obsessed and tormented king') -> MISMATCH
  control     : 'Prince Sung-won' -> MISMATCH
```
- Needed 3 attempts; problems seen: root must contain the placeholders [A1] exactly once each; root just repeats the original question | root must contain the placeholders [A1] exactly once each; root just repeats the original question

## 5ac3a76e554299741d48a2be | gold type: bridge | auto verdict: TREE_INVALID

- Question: Who released the song "With or Without You" first, Jai McDowall or U2?
- Gold answer: U2
- Gold paragraphs: Believe (Jai McDowall album), With or Without You

```
[comparison] Who released the song "With or Without You" first, Jai McDowall or U2?
  ROOT: Who released the song 'With or Without You' first: Jai McDowall (released [A1]) or U2 (released [A2])?
   `-- [A1] <- When did Jai McDowall release the song 'With or Without You'?   => 'UNKNOWN'
   `-- [A2] <- When did U2 release the song 'With or Without You'?   => '16 March 1987'
  filled root : Who released the song 'With or Without You' first: Jai McDowall (released UNKNOWN) or U2 (released 16 March 1987)?
  final answer: 'U2'   (gold: 'U2') -> MATCH
  control     : 'U2' -> MATCH
```
- Failed checks: type_ok, leaves_cover_distinct_entities, root_restates_entities, entities_ok, structure_ok

## 5add3fe05542992c1e3a2580 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: What 1997 song was on the Garth Brooks album that debuted at #1 on the "Billboard" 200?
- Gold answer: Two Piña Coladas
- Gold paragraphs: Two Piña Coladas, Sevens (album)

```
[bridge] What 1997 song was on the Garth Brooks album that debuted at #1 on the "Billboard" 200?
  ROOT: What 1997 song was on the [A1]?
   `-- [A1] <- Which Garth Brooks album debuted at #1 on the 'Billboard' 200 in 1997?   => 'Sevens'
  filled root : What 1997 song was on the Sevens?
  final answer: 'UNKNOWN'   (gold: 'Two Piña Coladas') -> MISMATCH
  control     : 'Sevens' -> MISMATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: root just repeats the original question

## 5abb2f2f554299232ef4a3d7 | gold type: bridge | auto verdict: OK

- Question: Harry Emerson Fosdick was called to serve as pastor at a church that opened its doors on what date?
- Gold answer: October 5, 1930
- Gold paragraphs: Harry Emerson Fosdick, Riverside Church

```
[bridge] Harry Emerson Fosdick was called to serve as pastor at a church that opened its doors on what date?
  ROOT: The church where Harry Emerson Fosdick was called to serve as pastor opened its doors on what date ([A1]).
   `-- [A1] <- When did the church where Harry Emerson Fosdick was called to serve as pastor open its doors?   => 'October 5, 1930'
  filled root : The church where Harry Emerson Fosdick was called to serve as pastor opened its doors on what date (October 5, 1930).
  final answer: 'October 5, 1930'   (gold: 'October 5, 1930') -> MATCH
  control     : 'October 5, 1930' -> MATCH
```
- Warning: sub-question 1 may not be self-contained (contains its)
- Needed 2 attempts; problems seen: root just repeats the original question

## 5ab1e984554299340b525428 | gold type: comparison | auto verdict: OK

- Question: which is larger Asante Traditional Buildings or Gulangyu?
- Gold answer: Gulangyu
- Gold paragraphs: Gulangyu, Asante Traditional Buildings

```
[comparison] which is larger Asante Traditional Buildings or Gulangyu?
  ROOT: Which is larger: the Asante Traditional Buildings (size [A1]) or Gulangyu (size [A2])?
   `-- [A1] <- How large is the Asante Traditional Buildings?   => 'UNKNOWN'
   `-- [A2] <- How large is Gulangyu?   => 'about 2 km2'
  filled root : Which is larger: the Asante Traditional Buildings (size UNKNOWN) or Gulangyu (size about 2 km2)?
  final answer: 'Gulangyu'   (gold: 'Gulangyu') -> MATCH
  control     : 'UNKNOWN' -> MISMATCH
```

## 5a80e5f5554299260e20a1ae | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: How many of the 12 million immigrants to the United States through Ellis Island were Italian immigrants?
- Gold answer: 5.3 million
- Gold paragraphs: History of Italian Americans in Boston, Ellis Island

```
[bridge] How many of the 12 million immigrants to the United States through Ellis Island were Italian immigrants?
  ROOT: How many of the 12 million immigrants to the United States through Ellis Island were Italian immigrants ([A1] million)?
   `-- [A1] <- What percentage of the 12 million immigrants to the United States through Ellis Island were Italian immigrants?   => 'UNKNOWN'
  filled root : How many of the 12 million immigrants to the United States through Ellis Island were Italian immigrants (UNKNOWN million)?
  final answer: 'UNKNOWN'   (gold: '5.3 million') -> MISMATCH
  control     : 'UNKNOWN' -> MISMATCH
```
- Needed 2 attempts; problems seen: root just repeats the original question

## 5ab4304a55429942dd415ec5 | gold type: bridge | auto verdict: OK

- Question: To where did the war criminal who is the fictional defendant in the film After the Truth flee in real life ?
- Gold answer: South America
- Gold paragraphs: After the Truth, Josef Mengele

```
[bridge] To where did the war criminal who is the fictional defendant in the film After the Truth flee in real life ?
  ROOT: To where did the war criminal [A1] flee in real life?
   `-- [A1] <- Who is the fictional defendant in the film After the Truth?   => 'Dr. Josef Mengele'
  filled root : To where did the war criminal Dr. Josef Mengele flee in real life?
  final answer: 'South America'   (gold: 'South America') -> MATCH
  control     : 'South America' -> MATCH
```
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; sub-question 2 must not contain a placeholder

## 5abe79c755429976d4830b2a | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Mesih Pasha's uncle became emperor in what year?
- Gold answer: 1449
- Gold paragraphs: Mesih Pasha, Constantine XI Palaiologos

```
[bridge] Mesih Pasha's uncle became emperor in what year?
  ROOT: Mesih Pasha's uncle became emperor in [A1].
   `-- [A1] <- In what year did Mesih Pasha's uncle become emperor?   => '1449'
  filled root : Mesih Pasha's uncle became emperor in 1449.
  final answer: 'yes'   (gold: '1449') -> MISMATCH
  control     : '1449' -> MATCH
```
- Failed checks: anchor_in_q1

## 5a85e5345542991dd0999ebb | gold type: bridge | auto verdict: NO_TREE

- Question: Which mechanical device which engages and disengages power transmission  uses brake fluid?
- Gold answer: hydraulic clutch
- Gold paragraphs: Brake fluid, Clutch
- No valid tree. Problems per attempt: root just repeats the original question | sub-question 1 just repeats the original question | sub-question 1 just repeats the original question

```
last raw output: {"type": "bridge", "sub_questions": ["Which mechanical device which engages and disengages power transmission uses brake fluid?"], "root": "Which mechanical device uses brake fluid [A1]?"}
```

## 5ae2d59755429928c42394ec | gold type: comparison | auto verdict: OK

- Question: Who has a wider scope of profession, Hrag Vartanian or Hovsep Pushman?
- Gold answer: Hrag Vartanian
- Gold paragraphs: Hrag Vartanian, Hovsep Pushman

```
[comparison] Who has a wider scope of profession, Hrag Vartanian or Hovsep Pushman?
  ROOT: Who has a wider scope of profession: Hrag Vartanian (scope [A1]) or Hovsep Pushman (scope [A2])?
   `-- [A1] <- What is the scope of profession of Hrag Vartanian?   => 'editor, writer, critic, curator'
   `-- [A2] <- What is the scope of profession of Hovsep Pushman?   => 'artist'
  filled root : Who has a wider scope of profession: Hrag Vartanian (scope editor, writer, critic, curator) or Hovsep Pushman (scope artist)?
  final answer: 'Hrag Vartanian'   (gold: 'Hrag Vartanian') -> MATCH
  control     : 'Hrag Vartanian' -> MATCH
```

## 5ae628fd5542995703ce8b33 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Cinnamon sugar is a spice used to flavor this traditional Spanish and Portugese fried pastry.
- Gold answer: Churros
- Gold paragraphs: Cinnamon sugar, Churro

```
[bridge] Cinnamon sugar is a spice used to flavor this traditional Spanish and Portugese fried pastry.
  ROOT: Cinnamon sugar is a spice used to flavor this traditional Spanish and Portuguese fried pastry ([A1]).
   `-- [A1] <- What is the name of the traditional Spanish and Portuguese fried pastry flavored with cinnamon sugar?   => 'Churro'
  filled root : Cinnamon sugar is a spice used to flavor this traditional Spanish and Portuguese fried pastry (Churro).
  final answer: 'yes'   (gold: 'Churros') -> MISMATCH
  control     : 'yes' -> MISMATCH
```
- Warning: tree drops tokens of the question: portugese

## 5a713ea95542994082a3e6e4 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Alvaro Mexia had a diplomatic mission with which tribe of indigenous people?
- Gold answer: Apalachees
- Gold paragraphs: Alvaro Mexia, Indigenous peoples of Florida

```
[bridge] Alvaro Mexia had a diplomatic mission with which tribe of indigenous people?
  ROOT: Which tribe of indigenous people had a diplomatic mission with Alvaro Mexia ([A1])?
   `-- [A1] <- With which tribe did Alvaro Mexia have a diplomatic mission?   => 'Ais'
  filled root : Which tribe of indigenous people had a diplomatic mission with Alvaro Mexia (Ais)?
  final answer: 'Ais'   (gold: 'Apalachees') -> MISMATCH
  control     : 'Ais' -> MISMATCH
```
- Needed 2 attempts; problems seen: root just repeats the original question

## 5ae022ab554299025d62a428 | gold type: comparison | auto verdict: OK

- Question: Which genus is native to arid or semi-desert areas, Alopecurus or Echeveria?
- Gold answer: Echeveria
- Gold paragraphs: Alopecurus, Echeveria

```
[comparison] Which genus is native to arid or semi-desert areas, Alopecurus or Echeveria?
  ROOT: Which genus is native to arid or semi-desert areas, the genus Alopecurus (native to [A1]) or the genus Echeveria (native to [A2])?
   `-- [A1] <- In which genus is the plant Alopecurus native?   => 'Alopecurus'
   `-- [A2] <- In which genus is the plant Echeveria native?   => 'Echeveria'
  filled root : Which genus is native to arid or semi-desert areas, the genus Alopecurus (native to Alopecurus) or the genus Echeveria (native to Echeveria)?
  final answer: 'Echeveria'   (gold: 'Echeveria') -> MATCH
  control     : 'Echeveria' -> MATCH
```
- Needed 2 attempts; problems seen: the sub-questions are identical

## 5ae28b76554299495565daa8 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: What three categories does income get levied under the Parliament of Australia's tax code?
- Gold answer: "personal earnings" (such as salary and wages), "business income" and "capital gains"
- Gold paragraphs: Income Tax Assessment Act 1936, Income tax in Australia

```
[bridge] What three categories does income get levied under the Parliament of Australia's tax code?
  ROOT: What three categories does income get levied under the Parliament of Australia's tax code (answer [A1])?
   `-- [A1] <- Under the Parliament of Australia's tax code, what are the three categories that income gets levied under?   => 'personal earnings, business income, capital gains'
  filled root : What three categories does income get levied under the Parliament of Australia's tax code (answer personal earnings, business income, capital gains)?
  final answer: 'personal earnings, business income, capital gains'   (gold: '"personal earnings" (such as salary and wages), "business income" and "capital gains"') -> MISMATCH
  control     : 'personal earnings, business income, capital gains' -> MISMATCH
```
- Failed checks: anchor_in_q1
- Needed 3 attempts; problems seen: sub-question 1 just repeats the original question; root must contain the placeholders [A1] exactly once each; root just repeats the original question | sub-question 1 just repeats the original question

## 5a7c9ead5542990527d554e4 | gold type: bridge | auto verdict: OK

- Question: As of 2010, what was the population of the county that was named after the 13th Speaker of the House of Representatives?
- Gold answer: 16,825
- Gold paragraphs: Polk County, Tennessee, James K. Polk

```
[bridge] As of 2010, what was the population of the county that was named after the 13th Speaker of the House of Representatives?
  ROOT: As of 2010, what was the population of the county [A1] (named after the 13th Speaker of the House of Representatives)?
   `-- [A1] <- What was the population of the county named after the 13th Speaker of the House of Representatives as of 2010?   => 'UNKNOWN'
  filled root : As of 2010, what was the population of the county UNKNOWN (named after the 13th Speaker of the House of Representatives)?
  final answer: '16,825'   (gold: '16,825') -> MATCH
  control     : '16,825' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2

## 5add21555542992ae4cec496 | gold type: bridge | auto verdict: OK

- Question: What is the start date of this tour that was the third concert tour by an American singer-songwriter and was completed in support of the album Red?
- Gold answer: March 13, 2013
- Gold paragraphs: Red (Taylor Swift album), The Red Tour

```
[bridge] What is the start date of this tour that was the third concert tour by an American singer-songwriter and was completed in support of the album Red?
  ROOT: What is the start date of this tour that was [A1]?
   `-- [A1] <- What is the start date of the third concert tour by an American singer-songwriter that was completed in support of the album Red?   => 'March 13, 2013'
  filled root : What is the start date of this tour that was March 13, 2013?
  final answer: 'March 13, 2013'   (gold: 'March 13, 2013') -> MATCH
  control     : 'March 13, 2013' -> MATCH
```
- Needed 3 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2 | root must contain the placeholders [A1] exactly once each; root just repeats the original question

## 5ab259b25542993be8fa98de | gold type: bridge | auto verdict: NO_TREE

- Question: What word or phrase is found in both the history of Belgium and cockfighting?
- Gold answer: cockpit
- Gold paragraphs: History of Belgium, Cockfight
- No valid tree. Problems per attempt: "root" must be a string | a bridge question needs exactly 1 sub-question(s), got 2; root must contain the placeholders [A1] exactly once each; root just repeats the original question | root just repeats the original question

```
last raw output: {
  "type": "bridge",
  "sub_questions": ["What word or phrase is found in the history of Belgium?"],
  "root": "What word or phrase is found in both the history of Belgium ([A1]) and cockfighting?"
}
```

## 5a8aed1555429970aeb70334 | gold type: bridge | auto verdict: TREE_INVALID

- Question: What vehicle, made by UROVESA, is most like the four-wheel drive military light truck produced by AM General?
- Gold answer: URO VAMTAC
- Gold paragraphs: UROVESA, Humvee

```
[comparison] What vehicle, made by UROVESA, is most like the four-wheel drive military light truck produced by AM General?
  ROOT: What vehicle made by UROVESA (similar [A1]) is most like the four-wheel drive military light truck produced by AM General (characteristics [A2])?
   `-- [A1] <- What vehicle made by UROVESA is similar to the four-wheel drive military light truck produced by AM General?   => 'URO VAMTAC'
   `-- [A2] <- What are the characteristics of the four-wheel drive military light truck produced by AM General?   => 'High Mobility Multipurpose Wheeled Vehicle (HMMWV), commonly known as the Humvee'
  filled root : What vehicle made by UROVESA (similar URO VAMTAC) is most like the four-wheel drive military light truck produced by AM General (characteristics High Mobility Multipurpose Wheeled Vehicle (HMMWV), commonly known as the Humvee)?
  final answer: 'URO VAMTAC'   (gold: 'URO VAMTAC') -> MATCH
  control     : 'URO VAMTAC' -> MATCH
```
- Failed checks: type_ok, leaves_cover_distinct_entities, root_restates_entities, entities_ok, structure_ok

## 5a85e24a5542994775f6067f | gold type: comparison | auto verdict: OK

- Question: Are Hoodoo Gurus and Pierre Bouvier of the same nationality?
- Gold answer: no
- Gold paragraphs: Hoodoo Gurus, Pierre Bouvier

```
[comparison] Are Hoodoo Gurus and Pierre Bouvier of the same nationality?
  ROOT: Are Hoodoo Gurus (nationality [A1]) and Pierre Bouvier (nationality [A2]) of the same nationality?
   `-- [A1] <- What is the nationality of Hoodoo Gurus?   => 'Australian'
   `-- [A2] <- What is the nationality of Pierre Bouvier?   => 'Canadian'
  filled root : Are Hoodoo Gurus (nationality Australian) and Pierre Bouvier (nationality Canadian) of the same nationality?
  final answer: 'No'   (gold: 'no') -> MATCH
  control     : 'UNKNOWN' -> MISMATCH
```

## 5a7c68575542996dd594b91c | gold type: bridge | auto verdict: OK

- Question: What was the sequel of the game that e was published by U.S. Gold in 1992?
- Gold answer: Fade to Black
- Gold paragraphs: Fade to Black (video game), Flashback (1992 video game)

```
[bridge] What was the sequel of the game that e was published by U.S. Gold in 1992?
  ROOT: What was the sequel of the game [A1] (published by U.S. Gold in 1992)?
   `-- [A1] <- What game was published by U.S. Gold in 1992?   => 'Flashback'
  filled root : What was the sequel of the game Flashback (published by U.S. Gold in 1992)?
  final answer: 'Fade to Black'   (gold: 'Fade to Black') -> MATCH
  control     : 'Fade to Black' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; sub-question 2 must not contain a placeholder

## 5a80a25d5542995d8a8ddfb7 | gold type: bridge | auto verdict: OK

- Question: What is the name of the vocalist who collaborated with the rap duo who won the 2002 Grammy Award for Best Rap Performance by a Duo or Group?
- Gold answer: Sleepy Brown
- Gold paragraphs: So Fresh, So Clean, Ms. Jackson

```
[bridge] What is the name of the vocalist who collaborated with the rap duo who won the 2002 Grammy Award for Best Rap Performance by a Duo or Group?
  ROOT: What is the name of the vocalist who collaborated with the rap duo [A1]?
   `-- [A1] <- Who won the 2002 Grammy Award for Best Rap Performance by a Duo or Group?   => 'OutKast'
  filled root : What is the name of the vocalist who collaborated with the rap duo OutKast?
  final answer: 'Sleepy Brown'   (gold: 'Sleepy Brown') -> MATCH
  control     : 'Sleepy Brown' -> MATCH
```
- Failed checks: anchor_in_q1
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; sub-question 2 must not contain a placeholder

## 5ae07e5b55429945ae959381 | gold type: bridge | auto verdict: EXEC_MISMATCH

- Question: Drachen Fire was a roller coaster located behind which suspended coaster at Busch Gardens Williamsburg?
- Gold answer: Big Bad Wolf
- Gold paragraphs: Drachen Fire, Big Bad Wolf (roller coaster)

```
[bridge] Drachen Fire was a roller coaster located behind which suspended coaster at Busch Gardens Williamsburg?
  ROOT: Drachen Fire is located behind which suspended coaster at Busch Gardens Williamsburg ([A1]).
   `-- [A1] <- Behind which roller coaster is Drachen Fire located at Busch Gardens Williamsburg?   => 'Big Bad Wolf'
  filled root : Drachen Fire is located behind which suspended coaster at Busch Gardens Williamsburg (Big Bad Wolf).
  final answer: 'UNKNOWN'   (gold: 'Big Bad Wolf') -> MISMATCH
  control     : 'Big Bad Wolf' -> MATCH
```

## 5a8aa1685542992d82986f32 | gold type: bridge | auto verdict: OK

- Question: What dance academy did the starring actress from The Glory of Tang Dynasty graduate from?
- Gold answer: Beijing Dance Academy
- Gold paragraphs: The Glory of Tang Dynasty, Jing Tian

```
[bridge] What dance academy did the starring actress from The Glory of Tang Dynasty graduate from?
  ROOT: What dance academy did [A1] graduate from?
   `-- [A1] <- Who is the starring actress of the film The Glory of Tang Dynasty?   => 'Jing Tian'
  filled root : What dance academy did Jing Tian graduate from?
  final answer: 'Beijing Dance Academy'   (gold: 'Beijing Dance Academy') -> MATCH
  control     : 'Beijing Dance Academy' -> MATCH
```
- Needed 2 attempts; problems seen: a bridge question needs exactly 1 sub-question(s), got 2; sub-question 2 must not contain a placeholder
