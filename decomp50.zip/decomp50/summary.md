# Decomposition report

Questions: 50 (gold types: bridge 42, comparison 8)

## 1. Is the tree valid?

- Valid tree produced at all (after up to the allowed repair attempts): 46/50 = 0.92 (95% CI 0.81-0.97)
- Valid on the first attempt (no repair needed): 22/50 = 0.44 (95% CI 0.31-0.58)
- Predicted type = gold type: 42/46 = 0.91 (95% CI 0.80-0.97) of built trees
- **tree_valid** (structure ok + type ok + comparison entities covered): 41/50 = 0.82 (95% CI 0.69-0.90)
- Trees with heuristic warnings (pronouns / dropped question tokens): 6

| Gold type | n | tree_valid | type correct | decomposition ok (auto) |
|---|---|---|---|---|
| bridge | 42 | 35 | 35 | 17 |
| comparison | 8 | 6 | 7 | 5 |

## 2. Is the decomposition correct? (oracle execution with the gold paragraphs)

- Execution reproduces the gold answer: 25/46 = 0.54 (95% CI 0.40-0.68)
- Control (original question + same paragraphs): 30/46 = 0.65 (95% CI 0.51-0.77)
- Failures where the control succeeded (decomposition is the likely culprit): 8; where the control failed too (answerer limit, ambiguous): 13
- Leaf answers found verbatim in the gold paragraphs: 40/56 = 0.71 (95% CI 0.59-0.82)
- **decomposition_ok (auto)** = tree_valid AND execution correct: 22/50 = 0.44 (95% CI 0.31-0.58)

## 3. Cost (per question, averages)

| | LLM calls | Prompt tok | Completion tok | Total tok | Time (s) | Total tok (all) | Total time (s) |
|---|---|---|---|---|---|---|---|
| Decomposition | 1.76 | 1254 | 116 | 1370 | 14.64 | 68516 | 731.8 |
| Evaluation only | 2.96 | 893 | 15 | 908 | 2.18 | 45405 | 109.0 |

The automatic verdict is a proxy: confirm it with the human columns in review.csv / review.md.
