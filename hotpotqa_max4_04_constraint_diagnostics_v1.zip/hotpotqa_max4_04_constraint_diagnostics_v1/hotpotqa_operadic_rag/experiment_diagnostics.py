"""Advisory diagnostics only: never called by generation, validation or judging.

no_violation_found means only that supported patterns passed these narrow checks.
unknown is an abstention, and suspicious is not a semantic verdict or a rejection.
"""
import re
from collections import Counter
from .contracts import validate_plan


def norm(text):
    return ' '.join(re.findall(r"[a-z0-9]+", text.casefold()))


def finding(code, nodes, reason, **evidence):
    return dict(code=code, nodes=nodes, reason=reason, evidence=evidence)


def analyze(question, plan):
    try:
        clean = validate_plan(plan)
    except (ValueError, TypeError, KeyError) as exc:
        return dict(status='unknown', supported_checks=[], findings=[], reason='No structurally valid plan: ' + str(exc))
    supported, findings = inspect(question, clean)
    return dict(status='suspicious' if findings else ('no_violation_found' if supported else 'unknown'),
                supported_checks=supported, findings=findings,
                reason='Advisory pattern checks only; no assertion of complete semantic correctness.')


def build_report(store):
    rows = []
    for order, sample in enumerate(store.samples, 1):
        result = store.read(sample['question_id'])['phases'].get('structure', {}).get('result', {})
        rows.append(dict(order=order, question_id=sample['question_id'], question=sample['question'],
                         diagnostic=analyze(sample['question'], result.get('plan'))))
    report = dict(experiment=EXPERIMENT, role='advisory_only', calls=0,
                  status_counts=dict(Counter(row['diagnostic']['status'] for row in rows)), questions=rows,
                  limitation='No automatic rejection, repair, gold answers, or model calls. Unknown patterns abstain.')
    lines = ['# Advisory diagnostics', '', report['limitation'], '',
             'no_violation_found covers supported checks only; it is not semantic validity.', '']
    for row in rows:
        lines += [f"## {row['order']}. {row['question_id']}: {row['diagnostic']['status']}", '', row['question'], '']
        lines += [f"- {item['code']} ({', '.join(item['nodes'])}): {item['reason']} Evidence: {item['evidence']}"
                  for item in row['diagnostic']['findings']]
        if not row['diagnostic']['findings']:
            lines += [row['diagnostic']['reason']]
        lines += ['']
    return report, '\n'.join(lines)


EXPERIMENT = 'max4_04_constraint_diagnostics_v1'


def inspect(question, plan):
    supported, findings = [], []
    nodes = plan['nodes']
    titles = re.findall(r'"([^"\n]+)"', question)
    attribution = re.match(r'^(.+?) is by (?:what|which)\b', question, re.I)
    if attribution:
        titles.append(attribution[1])
    for title in titles:
        supported.append('literal_title_coverage')
        if not any(norm(title) in norm(n['question']) for n in nodes):
            findings.append(finding('title_not_found_literally', [],
                'The source title has no literal normalized occurrence in any node; aliases need manual review.', title=title))
    # Track each named subject separately; union of unrelated branch words is insufficient.
    pair = re.fullmatch(r'Are (.+?) and (.+?) ([A-Z][a-z]+) (cinematographers|actors|photographers|directors)\s*\?', question)
    if pair:
        left, right, qualifier, role = pair.groups()
        singular = role[:-1]
        by_id = {n['id']: n for n in nodes}
        for entity in (left, right):
            leaves = [n for n in nodes if not n['dependencies'] and norm(entity) in norm(n['question'])]
            if not leaves:
                # Indirect reference / pronoun resolution not supported.
                continue
            supported.append('entity_qualifiers:' + entity)
            # Follow the single-consumer chain while retaining the named subject's binding.
            linked, frontier = list(leaves), {n['id'] for n in leaves}
            while frontier:
                next_nodes = [n for n in nodes if n not in linked and frontier.intersection(n['dependencies'])
                              and len(n['dependencies']) == 1]
                linked.extend(next_nodes)
                frontier = {n['id'] for n in next_nodes}
            text = ' '.join(norm(n['question']) for n in linked)
            missing = [word for word in (qualifier.lower(), singular)
                       if not re.search(r'\b' + re.escape(word) + r's?\b', text)]
            if missing:
                findings.append(finding('entity_qualifier_not_established', [n['id'] for n in linked],
                    'This subject-specific branch omits part of the joint property. A negative conjunct may still suffice for no; inspect evidence.',
                    entity=entity, required=[qualifier, singular], missing=missing))
    exclusion = re.match(r'^Who else (?:besides?|other than|except) (?:the|an?|this) (.+?) (?:was|is)\b', question, re.I)
    if exclusion:
        descriptor = norm(exclusion[1])
        key_roles = re.findall(r'\b(administrator|politician|actor|photographer|singer|author)\b', descriptor)
        candidates = [n for n in nodes if not n['dependencies'] and key_roles and
                      all(re.search(r'\b' + r + r's?\b', norm(n['question'])) for r in key_roles)]
        for node in candidates:
            text = norm(node['question'])
            supported.append('excluded_person:' + node['id'])
            if re.search(r'\b(?:else|besides?|except|other than)\b', text):
                findings.append(finding('exclusion_applied_during_identity_lookup', [node['id']],
                    'The branch identifying the excluded person already asks for someone else.', descriptor=descriptor))
            if re.match(r'^who (?:are|were)\b', text) or any(re.search(r'\b' + r + r's\b', text) for r in key_roles):
                findings.append(finding('excluded_single_person_became_group', [node['id']],
                    'A singular excluded-person description became a plural lookup.', descriptor=descriptor))
            # Presence is insufficient: root must explicitly exclude that branch's value.
            consumers = [n for n in nodes if node['id'] in n['dependencies']]
            if consumers and not any(re.search(r'(?:besides?|except|other than|apart from)\s+(?:the\s+)?' +
                                               re.escape('{{' + node['id'] + '}}'), n['question'], re.I)
                                     for n in consumers):
                findings.append(finding('excluded_person_binding_unconfirmed', [node['id']] + [n['id'] for n in consumers],
                    'No supported explicit exclusion of this slot was found; paraphrases require manual review.'))
    return supported, findings
