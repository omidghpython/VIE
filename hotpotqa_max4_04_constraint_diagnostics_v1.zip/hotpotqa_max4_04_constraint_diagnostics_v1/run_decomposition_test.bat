@echo off
setlocal
cd /d "%~dp0"
set "PILOT_PYTHON=%~dp0.venv\Scripts\python.exe"
if defined CONDA_PREFIX set "PILOT_PYTHON=%CONDA_PREFIX%\python.exe"
if defined VIRTUAL_ENV set "PILOT_PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PILOT_PYTHON=%HOTPOT_PYTHON%"
if not exist "%PILOT_PYTHON%" (
  echo ERROR: Activate the Python environment used for v3.2 or set HOTPOT_PYTHON to its python.exe.
  echo See README_WINDOWS_FA.txt. No new environment or model download is needed.
  pause
  exit /b 1
)
set "HF_HUB_OFFLINE=1"
set "TRANSFORMERS_OFFLINE=1"
"%PILOT_PYTHON%" decomposition_pilot.py --use-4bit --max-input-tokens 8500 --intermediate-tokens 512 --plan-tokens 3072 %*
set "PILOT_EXIT=%ERRORLEVEL%"
echo.
if "%PILOT_EXIT%"=="0" (
  echo Pilot processed all questions. Structural/semantic correctness still needs inspection.
  echo Send results\max4_04_constraint_diagnostics_v1_results.zip for review.
) else (
  echo Pilot incomplete. Read the error above. Saved phases are preserved.
  echo Rerun to resume an interruption. Use --retry-errors only after fixing a saved backend error.
)
pause
exit /b %PILOT_EXIT%
