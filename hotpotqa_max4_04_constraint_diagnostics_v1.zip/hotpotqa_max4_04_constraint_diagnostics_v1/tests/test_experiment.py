import copy
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from hotpotqa_operadic_rag.experiment_diagnostics import analyze, EXPERIMENT
import decomposition_pilot as pilot
from hotpotqa_operadic_rag.checkpoint import RunStore


def node(nid, question, kind='other', deps=None):
    return dict(id=nid, question=question, answer_type=kind, dependencies=deps or {})


def plan(*nodes):
    return dict(nodes=list(nodes), final=nodes[-1]['id'])


class DiagnosticsTests(unittest.TestCase):
    def check(self, question, tree, status, code=None):
        old = copy.deepcopy(tree)
        result = analyze(question, tree)
        self.assertEqual(result['status'], status, result)
        if code:
            self.assertIn(code, [f['code'] for f in result['findings']])
        self.assertEqual(tree, old)
        return result

    def test_invalid_and_missing_plan_abstain(self):
        self.check('Which river?', None, 'unknown')
        self.check('Who?', {'nodes': [], 'final': 'q1'}, 'unknown')

    def test_unknown_wording_abstains(self):
        self.check('Explain the phenomenon.', plan(node('q1', 'Explain the phenomenon.')), 'unknown')

    def test_reports_are_in_archive_and_no_model_load(self):
        samples = [dict(question_id='synthetic', question='Who wrote Alpha?', type='bridge')]
        with tempfile.TemporaryDirectory() as tmp:
            store = RunStore(Path(tmp)/'run/trees.csv', dict(backend='injected_test', n_samples=1), lambda: samples)
            summary = pilot.export_reports(store, {})
            self.assertEqual(summary['total_cost']['llm_calls'], 0)
            with zipfile.ZipFile(Path(tmp)/'run_results.zip') as z:
                self.assertIn('run/diagnostics.json', z.namelist())
                self.assertIn('run/diagnostics.md', z.namelist())
                report = json.loads(z.read('run/diagnostics.json'))
                self.assertEqual(report['status_counts'], {'unknown': 1})
                self.assertEqual(report['role'], 'advisory_only')

    def test_attributed_title_missing(self):
        self.check('Lantern Days is by what Mexican actress?', plan(node('q1', 'Who is a Mexican actress?', 'person')),
                   'suspicious', 'title_not_found_literally')

    def test_attributed_title_present(self):
        self.check('Lantern Days is by what Mexican actress?', plan(node('q1', 'Who wrote Lantern Days?', 'person')), 'no_violation_found')

    def test_quoted_title_punctuation_normalizes(self):
        self.check('Who wrote "Lantern... Days"?', plan(node('q1', 'Who wrote Lantern Days?', 'person')), 'no_violation_found')

    def comparison(self, a, b):
        return plan(node('q1', a, 'boolean'), node('q2', b, 'boolean'),
                    node('q3', 'Are {{q1}} and {{q2}} both true?', 'boolean', {'q1':'boolean', 'q2':'boolean'}))

    def test_missing_role_each_subject(self):
        r = self.check('Are Alex One and Blair Two American cinematographers?',
                       self.comparison('Is Alex One American?', 'Is Blair Two American?'),
                       'suspicious', 'entity_qualifier_not_established')
        self.assertEqual(len(r['findings']), 2)

    def test_qualifiers_on_wrong_subject_do_not_count(self):
        r = self.check('Are Alex One and Blair Two American cinematographers?',
                       self.comparison('Is Alex One an American cinematographer?', 'Is Blair Two American?'), 'suspicious')
        self.assertEqual(r['findings'][0]['evidence']['entity'], 'Blair Two')

    def test_qualifiers_preserved(self):
        self.check('Are Alex One and Blair Two American cinematographers?',
                   self.comparison('Is Alex One an American cinematographer?', 'Is Blair Two an American cinematographer?'),
                   'no_violation_found')

    def excluded(self, leaf, root='Who else besides {{q1}} joined Alpha?'):
        return plan(node('q1', leaf, 'person'), node('q2', root, 'person', {'q1':'person'}))

    def test_plural_excluded_person(self):
        self.check('Who else beside the American administrator and politician from Ohio was part of Alpha?',
                   self.excluded('Who were the American administrators and politicians from Ohio?'),
                   'suspicious', 'excluded_single_person_became_group')

    def test_excluded_person_singular(self):
        self.check('Who else beside the American administrator and politician from Ohio was part of Alpha?',
                   self.excluded('Who is the American administrator and politician from Ohio?'), 'no_violation_found')

    def test_premature_exclusion(self):
        self.check('Who else beside the American politician was part of Alpha?',
                   self.excluded('Who else is the American politician?'), 'suspicious', 'exclusion_applied_during_identity_lookup')

    def test_unbound_exclusion(self):
        self.check('Who else beside the American politician was part of Alpha?',
                   self.excluded('Who is the American politician?', 'Who joined Alpha with {{q1}}?'),
                   'suspicious', 'excluded_person_binding_unconfirmed')

    def test_unsupported_pronoun_abstains(self):
        self.check('Who else besides him joined?', plan(node('q1', 'Who joined?', 'person')), 'unknown')

