"""Offline diagnostic-runner tests; these do not measure real Qwen accuracy."""
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from contextlib import redirect_stdout

import decomposition_pilot as pilot
from hotpotqa_operadic_rag import telemetry
from hotpotqa_operadic_rag.contracts import parse_json_object, validate_plan
from hotpotqa_operadic_rag.decomposition import PLAN_SYSTEM


CHAIN = {'nodes': [
    {'id': 'q1', 'question': 'Who wrote The Lantern?', 'dependencies': {}, 'answer_type': 'person'},
    {'id': 'q2', 'question': 'Where was {{q1}} born?', 'dependencies': {'q1': 'person'}, 'answer_type': 'place'}],
    'final': 'q2'}
SINGLE = {'nodes': [{'id': 'q1', 'question': 'Where was the writer of The Lantern born?',
                    'dependencies': {}, 'answer_type': 'place'}], 'final': 'q1'}
SAMPLES = [{'question_id': 'example1', 'question': 'Where was the writer of The Lantern born?',
            'type': 'bridge', 'answer': 'GOLD_MUST_NOT_BE_SENT', 'context': 'CONTEXT_MUST_NOT_BE_SENT'}]


class ScriptedModel:
    plan_tokens = 3072

    def __init__(self, plans=(), verdicts=()):
        self.plans, self.verdicts = list(plans), list(verdicts)
        self.messages, self.prompts = [], []
        self.last_raw_output = None

    def count(self):
        tracker = telemetry._ACTIVE_TRACKER
        tracker.add_generate_invocation(10)
        tracker.add_completion(5)

    def generate(self, messages, max_new_tokens=None):
        self.count()
        self.messages.append(copy.deepcopy(messages))
        reply = self.plans.pop(0)
        if isinstance(reply, BaseException):
            raise reply
        return reply if isinstance(reply, str) else json.dumps(reply)

    def ask_json(self, prompt):
        self.count()
        self.prompts.append(prompt)
        reply = self.verdicts.pop(0)
        if isinstance(reply, BaseException):
            raise reply
        self.last_raw_output = reply if isinstance(reply, str) else json.dumps(reply)
        return parse_json_object(self.last_raw_output)


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name) / 'pilot'
        self.loaded = 0
        self.model = ScriptedModel()

    def factory(self, settings):
        self.loaded += 1
        return self.model, {'backend': 'scripted-test'}

    def run_pilot(self, **kwargs):
        with redirect_stdout(io.StringIO()):
            return pilot.run_pilot(SAMPLES, {}, self.output, model_factory=self.factory, **kwargs)

    def record(self):
        return json.loads((self.output / 'trees.csv.state/questions/example1.json').read_text())

    def test_restored_complete_example_satisfies_real_tree_contract(self):
        example = next(line for line in PLAN_SYSTEM.splitlines() if line.startswith('{"nodes":'))
        plan = validate_plan(parse_json_object(example))
        self.assertGreater(len(plan['nodes']), 1)
        self.assertEqual(plan['nodes'][-1]['dependencies'], {'q1': 'person'})

    def test_uncertain_is_observed_not_repaired_and_original_question_is_preserved(self):
        self.model = ScriptedModel([CHAIN], [{'status': 'uncertain', 'errors': ['uncertain']}])
        summary = self.run_pilot()
        self.assertEqual(summary['structure_status'], {'valid': 1})
        self.assertEqual(summary['judge_status'], {'uncertain': 1})
        self.assertEqual(summary['total_cost']['llm_calls'], 2)
        self.assertEqual(summary['total_cost']['retrieval_steps'], 0)
        self.assertEqual(self.record()['phases']['structure']['result']['plan'], CHAIN)
        self.assertEqual(self.model.messages[0][-1]['content'], SAMPLES[0]['question'])
        prompts = json.dumps([self.model.messages, self.model.prompts])
        self.assertNotIn('GOLD_MUST_NOT_BE_SENT', prompts)
        self.assertNotIn('CONTEXT_MUST_NOT_BE_SENT', prompts)
        self.assertFalse(summary['semantic_correctness_measured'])
        self.assertEqual(summary['inference_backend'], 'injected_test')

    def test_actual_v32_self_dependency_shape_is_rejected_without_judge(self):
        invalid = copy.deepcopy(SINGLE)
        invalid['nodes'][0]['dependencies'] = {'q1': 'place'}
        self.model = ScriptedModel([invalid, invalid])
        summary = self.run_pilot()
        self.assertEqual(summary['structure_status'], {'invalid': 1})
        self.assertEqual(summary['total_cost']['llm_calls'], 2)
        self.assertEqual(self.model.prompts, [])
        self.assertEqual(len(self.record()['phases']['structure']['result']['decomposition_trace']), 2)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.run_pilot()
        self.assertEqual(self.loaded, 1, 'Terminal invalid plans must not consume tokens on ordinary resume.')

    def test_single_node_accepted_by_judge_is_visible_not_claimed_success(self):
        self.model = ScriptedModel([SINGLE], [{'status': 'valid', 'errors': []}])
        summary = self.run_pilot()
        self.assertEqual(summary['single_node_accepted_by_judge'], 1)
        self.assertEqual(summary['multiple_nodes'], 0)
        self.assertFalse(summary['answer_accuracy_measured'])

    def test_malformed_judgment_raw_text_survives(self):
        raw = '{"status":"valid","errors":[]} TRAILING DATA'
        self.model = ScriptedModel([CHAIN], [raw])
        summary = self.run_pilot()
        review = self.record()['phases']['review']['result']
        self.assertEqual(review['raw_output'], raw)
        self.assertEqual(summary['judge_status'], {'format_error': 1})
        self.assertEqual(summary['review_status'], {'invalid_response': 1})
        self.assertEqual(summary['review_response_status'], {'format_error': 1})
        self.assertEqual(summary['total_cost']['llm_calls'], 2)

    def test_successful_resume_and_report_only_never_load_model(self):
        self.model = ScriptedModel([CHAIN], [{'status': 'valid', 'errors': []}])
        first = self.run_pilot()
        resumed = self.run_pilot()
        report = self.run_pilot(report_only=True)
        self.assertEqual(first, resumed)
        self.assertEqual(resumed, report)
        self.assertEqual(self.loaded, 1)
        self.assertTrue(self.output.with_name('pilot_results.zip').exists())

    def test_interrupt_during_judge_resumes_without_regenerating_tree_and_counts_cost(self):
        self.model = ScriptedModel([CHAIN], [KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt):
            self.run_pilot()
        self.assertEqual(self.record()['phases']['structure']['status'], 'valid')
        self.model = ScriptedModel([], [{'status': 'valid', 'errors': []}])
        summary = self.run_pilot()
        self.assertEqual(self.model.messages, [])
        self.assertEqual(summary['total_cost']['llm_calls'], 3)
        self.assertEqual(summary['total_cost']['total_tokens'], 45)

    def test_backend_error_is_preserved_and_retried_only_explicitly(self):
        self.model = ScriptedModel([RuntimeError('device failure')])
        with self.assertRaisesRegex(RuntimeError, 'device failure'):
            self.run_pilot()
        summary = self.run_pilot()
        self.assertEqual(self.loaded, 1)
        self.assertEqual(summary['backend_errors'], 1)
        self.model = ScriptedModel([CHAIN], [{'status': 'valid', 'errors': []}])
        summary = self.run_pilot(retry_errors=True)
        self.assertEqual(summary['total_cost']['llm_calls'], 3)
        self.assertEqual(summary['backend_errors'], 0)

    def test_resume_refuses_different_budget_and_preserves_results(self):
        self.model = ScriptedModel([CHAIN], [{'status': 'valid', 'errors': []}])
        self.run_pilot()
        old = self.record()
        with self.assertRaisesRegex(ValueError, 'settings/code differ'):
            self.run_pilot(plan_tokens=2048)
        self.assertEqual(self.record(), old)

    def test_exact_cohort_and_recorded_baseline_gaps_are_preserved(self):
        samples, baselines = pilot.load_cohort(pilot.ROOT / 'evaluation/samples.json')
        self.assertEqual(len(samples), 40)
        summaries = pilot.summarize_baselines(baselines)
        self.assertEqual(summaries['v3.1']['structure_status'], {'valid': 32, 'invalid': 7, 'unknown': 1})
        self.assertEqual(summaries['v3.2']['structure_status'], {'valid': 20, 'invalid': 20})
        self.assertEqual(summaries['v3.2']['multiple_nodes'], 0)
        self.assertEqual(summaries['v3.2.1']['structure_status'], {'valid': 28, 'invalid': 12})
        self.assertEqual(summaries['v3.2.1']['multiple_nodes'], 26)
        altered = copy.deepcopy(samples)
        altered[0]['question'] += ' CHANGED'
        path = Path(self.temp.name) / 'changed.json'
        path.write_text(json.dumps(altered))
        with self.assertRaisesRegex(ValueError, 'unchanged'):
            pilot.load_cohort(path)

    def test_recorded_v32_structural_outputs_replay_for_all_40_without_changing_counts(self):
        import zipfile
        samples, baselines = pilot.load_cohort(pilot.ROOT / 'evaluation/samples.json')
        recorded = baselines['runs']['v3.2']['questions']
        outputs = [e['raw_output'] for row in recorded for e in row['trace']]
        # Only replay recorded generation. These synthetic judgments make no claim
        # about the actual historical judge or the new prompt's model performance.
        self.model = ScriptedModel(outputs, [{'status': 'uncertain', 'errors': ['synthetic test judge']}] * 20)
        with redirect_stdout(io.StringIO()):
            summary = pilot.run_pilot(samples, baselines, self.output, model_factory=self.factory)
        self.assertEqual(summary['requested'], 40)
        self.assertEqual(summary['structure_status'], {'invalid': 20, 'valid': 20})
        self.assertEqual(summary['single_node'], 20)
        self.assertEqual(summary['multiple_nodes'], 0)
        self.assertEqual(summary['total_cost']['llm_calls'], len(outputs) + 20)
        self.assertEqual(summary['total_cost']['retrieval_steps'], 0)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.assertFalse(self.model.plans)
        with zipfile.ZipFile(self.output.with_name('pilot_results.zip')) as archive:
            self.assertIsNone(archive.testzip())
            self.assertEqual(len([n for n in archive.namelist() if '/questions/' in n]), 40)

    def test_rule_source_is_not_reported_as_a_model_judgment(self):
        bad = copy.deepcopy(CHAIN)
        bad['nodes'][-1].update(question='Is {{q1}} from Paris?', answer_type='boolean')
        self.model = ScriptedModel([bad])
        summary = self.run_pilot()
        self.assertEqual(summary['structure_status'], {'valid': 1})
        self.assertEqual(summary['review_source'], {'root_rule': 1})
        self.assertEqual(summary['judge_status'], {'not_called': 1})
        self.assertEqual(summary['review_status'], {'revise': 1})
        self.assertEqual(summary['judge_calls_avoided_by_root_rule'], 1)
        self.assertEqual(summary['total_cost']['llm_calls'], 1)
        self.assertIsNone(self.record()['phases']['review']['result']['raw_output'])
        self.assertEqual(self.model.prompts, [])
        self.run_pilot()
        self.assertEqual(self.loaded, 1)

    def test_vague_reason_retains_actual_model_status_but_reports_uncertainty(self):
        self.model = ScriptedModel([CHAIN], ['{"status":"revise","errors":["different wording"]}```'])
        summary = self.run_pilot()
        self.assertEqual(summary['judge_status'], {'revise': 1})
        self.assertEqual(summary['review_status'], {'uncertain': 1})
        self.assertEqual(summary['review_response_status'], {'vague_reason': 1})
        self.assertEqual(summary['closing_fence_responses_recovered'], 1)
        self.assertEqual(summary['total_cost']['llm_calls'], 2)

    def test_legacy_12_node_replay_keeps_structure_and_separates_rules_from_model(self):
        samples, baselines = pilot.load_cohort(pilot.ROOT / 'evaluation/samples.json')
        rows = baselines['runs']['v3.2.1']['questions']
        mismatches = {4, 10, 11, 12, 16, 21, 22, 27, 30, 31, 36}
        plans = [e['raw_output'] for row in rows for e in row['trace']]
        replies = [row['judge']['raw_output'] for order, row in enumerate(rows, 1)
                   if row['status'] == 'valid' and order not in mismatches]
        self.model = ScriptedModel(plans, replies)
        # Recorded responses assume the former 12-node cap and cannot supply
        # new repairs. Current three-node behavior is exercised in test_max3.py.
        with patch('hotpotqa_operadic_rag.decomposition.MAX_PLAN_NODES', 12), \
                patch.object(pilot, 'MAX_PLAN_NODES', 12), redirect_stdout(io.StringIO()):
            summary = pilot.run_pilot(samples, baselines, self.output, model_factory=self.factory)
        self.assertEqual(summary['structure_status'], {'invalid': 12, 'valid': 28})
        self.assertEqual(summary['multiple_nodes'], 26)
        self.assertEqual(summary['review_source'], {'not_reviewed': 12, 'model': 17, 'root_rule': 11})
        self.assertEqual(summary['judge_calls_avoided_by_root_rule'], 11)
        self.assertEqual(summary['judge_status']['valid'], 2)
        self.assertEqual(summary['closing_fence_responses_recovered'], 6)  # Seventh case skips the judge entirely.
        self.assertNotIn('format_error', summary['review_response_status'])
        self.assertEqual(summary['total_cost']['llm_calls'], 55 + 17)
        self.assertEqual(summary['total_cost']['retrieval_steps'], 0)
        self.assertFalse(self.model.plans)
        self.assertFalse(self.model.verdicts)
        self.assertFalse(summary['semantic_correctness_measured'])


if __name__ == '__main__':
    unittest.main()
