"""Three-node boundary and bounded repair checks; no new Qwen inference."""
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
import unittest

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.decomposition import (
    DecompositionError, SemanticPlanError, decompose_question, generate_plan,
)
from test_grounded_revision import Scripted
from test_decomposition_pilot import ScriptedModel


def chain(size):
    nodes = [{'id': 'q1', 'question': 'Which entity starts the chain?',
              'dependencies': {}, 'answer_type': 'other'}]
    for i in range(2, size + 1):
        nodes.append({'id': f'q{i}', 'question': 'Which entity follows {{q' + str(i-1) + '}}?',
                      'dependencies': {f'q{i-1}': 'other'}, 'answer_type': 'other'})
    return {'nodes': nodes, 'final': f'q{size}'}


class ThreeNodeTests(unittest.TestCase):
    def test_oversized_tree_is_repaired_without_truncating_or_changing_question(self):
        question = 'Which entity completes the chain, retaining every qualifier?'
        model = Scripted([chain(4), chain(3)])
        plan, trace = generate_plan(model, question)
        self.assertEqual(plan, chain(3))
        self.assertEqual(len(trace), 2)
        self.assertEqual(json.loads(trace[0]['raw_output']), chain(4))
        self.assertEqual(trace[0]['error'], 'Plan must contain 1..3 nodes.')
        self.assertEqual(model.messages[0][-1]['content'], question)
        self.assertTrue(model.messages[1][-1]['content'].startswith(question + '\n'))
        self.assertIn('Plan must contain 1..3 nodes.', model.messages[1][-1]['content'])

    def test_two_oversized_outputs_stop_without_judging(self):
        model = Scripted([chain(4), chain(4)])
        with self.assertRaises(DecompositionError) as caught:
            generate_plan(model, 'Which entity completes the chain?')
        self.assertEqual(len(caught.exception.details['decomposition_trace']), 2)
        self.assertEqual((len(model.messages), len(model.prompts)), (2, 0))

    def test_existing_single_semantic_repair_cannot_bypass_three_node_limit(self):
        model = Scripted([chain(3), chain(4)], [
            {'status': 'revise', 'errors': ['q3: drops the original location qualifier.']}])
        with self.assertRaises(SemanticPlanError) as caught:
            decompose_question(model, 'Which entity completes the chain?')
        trace = caught.exception.details['decomposition_trace']
        self.assertEqual(trace[-1]['stage'], 'semantic_repair')
        self.assertEqual(trace[-1]['error'], 'Plan must contain 1..3 nodes.')
        self.assertEqual((len(model.messages), len(model.prompts)), (2, 1))

    def test_v324_replay_preserves_cohort_and_only_changes_oversize_errors(self):
        samples, baselines = pilot.load_cohort(pilot.ROOT / 'evaluation/samples.json')
        rows = baselines['runs']['v3.2.4']['questions']
        model = ScriptedModel(
            [event['raw_output'] for row in rows for event in row['trace']],
            [row['judge']['raw_output'] for row in rows if row['judge'].get('details', {}).get('source') == 'model'])
        with tempfile.TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()):
            output = Path(tmp) / 'pilot'
            summary = pilot.run_pilot(samples, baselines, output,
                                      model_factory=lambda settings: (model, {'backend': 'scripted'}))
            self.assertEqual(summary['structure_status'], {'valid': 35, 'invalid': 5})
            self.assertEqual(summary['review_status'], {'revise': 24, 'not_reviewed': 5, 'valid': 11})
            self.assertEqual(summary['total_cost']['llm_calls'], 81)
            self.assertEqual(summary['whole_method_token_condition']['status'], 'not_measured_scripted_backend')
            for index in (18, 32):
                record = json.loads((output / 'trees.csv.state/questions' /
                                    (samples[index-1]['question_id'] + '.json')).read_text())
                trace = record['phases']['structure']['result']['decomposition_trace']
                self.assertEqual([event['error'] for event in trace], ['Plan must contain 1..3 nodes.'] * 2)
            self.assertFalse(model.plans)
            self.assertFalse(model.verdicts)


if __name__ == '__main__':
    unittest.main()
