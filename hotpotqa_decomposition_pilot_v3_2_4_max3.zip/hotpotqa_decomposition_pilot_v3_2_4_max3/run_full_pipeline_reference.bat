@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=%~dp0.venv\Scripts\python.exe"
if defined VIRTUAL_ENV set "PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PYTHON=%HOTPOT_PYTHON%"
if not exist "%PYTHON%" (
  echo ERROR: Python environment not found. Activate the existing CUDA environment or set HOTPOT_PYTHON to its python.exe.
  pause
  exit /b 1
)
if not exist logs mkdir logs
if not exist results mkdir results
"%PYTHON%" preload_models.py --verify-only
if errorlevel 1 (
  echo A required model revision is not cached. Run download_models.bat first.
  pause
  exit /b 1
)
"%PYTHON%" main.py --n-samples 40 --use-4bit --max-input-tokens 8500 --max-new-tokens 150 --samples-json evaluation\samples.json --output-csv results\hotpotqa_qwen25_operadic_rag_results_v3_2_4_max3.csv
if errorlevel 1 (
  echo.
  echo Experiment has failed or incomplete phases; checkpoints are saved.
  "%PYTHON%" compare_runs.py --baseline evaluation\baseline.csv --current results\hotpotqa_qwen25_operadic_rag_results_v3_2_4_max3.csv
  pause
  exit /b 1
)
echo.
"%PYTHON%" compare_runs.py --baseline evaluation\baseline.csv --current results\hotpotqa_qwen25_operadic_rag_results_v3_2_4_max3.csv
if errorlevel 1 exit /b 1
echo Experiment completed.
pause
