"""Regression tests use recorded contexts and scripted responses, not real Qwen accuracy."""
import copy
import csv
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from hotpotqa_operadic_rag.contracts import validate_plan
from hotpotqa_operadic_rag.data import load_sample_snapshot, make_passage_corpus
from hotpotqa_operadic_rag.decomposition import (
    decompose_question, SemanticPlanError, review_plan, root_answer_check, question_answer_mode, PLAN_SYSTEM,
)
from hotpotqa_operadic_rag.methods.common import assess_node, citation_map
from hotpotqa_operadic_rag.methods.operadic import evaluate_tree, run_operadic_rag
from hotpotqa_operadic_rag.retriever import format_evidence
from hotpotqa_operadic_rag.telemetry import TelemetryTracker, activate_tracker
from hotpotqa_operadic_rag import telemetry, experiment
from hotpotqa_operadic_rag.llm import LocalQwen
from test_revision import FakeRetriever, FakeLLM, sample, PLAN
from compare_runs import compare

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / 'evaluation' / 'samples.json'


class Scripted:
    plan_tokens = 3072
    def __init__(self, plans=(), replies=()):
        self.plans = list(plans)
        self.replies = list(replies)
        self.messages = []
        self.prompts = []
    def count(self):
        if telemetry._ACTIVE_TRACKER:
            telemetry._ACTIVE_TRACKER.add_generate_invocation(1)
            telemetry._ACTIVE_TRACKER.add_completion(1)
    def generate(self, messages, max_new_tokens=None):
        self.count(); self.messages.append(copy.deepcopy(messages))
        return json.dumps(self.plans.pop(0))
    def ask_json(self, prompt):
        self.count(); self.prompts.append(prompt)
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return copy.deepcopy(reply)
    def answer(self, *args, **kwargs):
        raise AssertionError('Short cited root should not generate another answer.')


def supported(answer, refs):
    return {'answer': answer, 'refs': refs, 'need': ''}


def unresolved(need='missing fact'):
    return {'answer': '', 'refs': [], 'need': need}


def chain():
    return {'nodes': [
        {'id':'q1', 'question':'Who wrote Ingenious?', 'dependencies':{}, 'answer_type':'person'},
        {'id':'q2', 'question':'In what year was {{q1}} born?',
         'dependencies':{'q1':'person'}, 'answer_type':'date'}], 'final':'q2'}


class EvidenceTests(unittest.TestCase):
    def test_all_original_sentences_and_titles_survive_formatting_for_all_40(self):
        samples = load_sample_snapshot(SNAPSHOT, 40)
        for s in samples:
            ev = make_passage_corpus(s); formatted = format_evidence(ev)
            for p in ev:
                self.assertIn(f"[Evidence {p['index']} | Title: {p['title']}]", formatted)
                for sid, sentence in zip(p['sentence_ids'], p['sentences']):
                    self.assertIn(f"[{p['index']}:{sid}] {sentence}", formatted)
            self.assertEqual(len(citation_map(ev)), sum(len(p['sentences']) for p in ev))
            self.assertEqual(formatted.count('[Evidence '), 10)
    def test_source_ids_stable_after_second_retrieval(self):
        ev = make_passage_corpus(sample())
        self.assertIn('[4:1]', format_evidence([ev[4], ev[0]]))
        self.assertEqual(citation_map([ev[4]])['4:1'], citation_map(ev)['4:1'])
    def test_formatter_rejects_missing_ids_instead_of_dropping_sentences(self):
        ev = make_passage_corpus(sample())[:3]
        ev[0]['sentence_ids'].pop()
        with self.assertRaisesRegex(ValueError, 'no sentence was truncated'):
            format_evidence(ev)
    def test_invalid_citation_does_not_authorize_answer(self):
        ev = make_passage_corpus(sample())[:3]
        for refs in (['9:0'], ['0:99'], [], [None]):
            result = assess_node(Scripted(replies=[supported('Ada', refs)]), 'Who?', 'person', ev)
            self.assertFalse(result['sufficient']); self.assertEqual(result['answer'], '')
            self.assertTrue(result['error'])
    def test_negative_answer_is_supported_not_insufficient(self):
        result = assess_node(Scripted(replies=[supported('no', ['0:0'])]), 'Are both American?',
                             'boolean', make_passage_corpus(sample())[:3])
        self.assertTrue(result['sufficient']); self.assertEqual(result['answer'], 'no')
    def test_parse_error_is_logged_for_targeted_review(self):
        result = assess_node(Scripted(replies=[ValueError('bad JSON')]), 'Who?', 'person',
                             make_passage_corpus(sample())[:3])
        self.assertFalse(result['sufficient']); self.assertIn('bad JSON', result['error'])


class SemanticTests(unittest.TestCase):
    def test_comparison_example_returns_a_named_person_with_bound_dates(self):
        from hotpotqa_operadic_rag.contracts import parse_json_object
        plans = [validate_plan(parse_json_object(line)) for line in PLAN_SYSTEM.splitlines()
                 if line.startswith('{"nodes":')]
        self.assertEqual(len(plans), 2)
        final = plans[1]['nodes'][-1]
        self.assertEqual(final['answer_type'], 'person')
        self.assertEqual(final['dependencies'], {'q1': 'date', 'q2': 'date'})
        self.assertIn('Lena (born {{q1}})', final['question'])
        self.assertIn('Omar (born {{q2}})', final['question'])

    def test_only_final_type_is_checked_not_intermediate_person_for_date_question(self):
        question = 'In what year was the writer of the drama "Ingenious" born?'
        model = Scripted(replies=[{'status': 'valid', 'errors': []}])
        details = {}
        verdict = review_plan(model, question, chain(), details=details)
        self.assertEqual(verdict['status'], 'valid')
        self.assertEqual(details['root_contract']['status'], 'compatible')
        self.assertEqual(details['source'], 'model')
        self.assertEqual(len(model.prompts), 1)
        self.assertIn(question, model.prompts[0])
        self.assertIn('Final node ID: q2', model.prompts[0])

    def test_limited_root_check_handles_new_entities_and_abstains_on_ambiguous_forms(self):
        bad = chain()
        bad['nodes'][-1].update(question='Is {{q1}} older?', answer_type='boolean')
        for question in ('Which harbour is busier, Westhaven or Northport?',
                         'Who was born first, Nia or Pavel?',
                         'What country are Riverdale and Silverton in?'):
            with self.subTest(question=question):
                self.assertEqual(root_answer_check(question, bad)['status'], 'mismatch')
        for question in ('Could you tell me which harbour is busier?',
                         'What is the truth value of this statement?',
                         'What is the answer to "Is there a river?"?', 'Choose the best option.'):
            with self.subTest(question=question):
                self.assertIsNone(question_answer_mode(question))
                self.assertEqual(root_answer_check(question, bad)['status'], 'not_checked')
        self.assertEqual(root_answer_check('Is Nia older than Pavel?', bad)['status'], 'compatible')

    def test_changing_only_root_type_does_not_hide_yes_no_question(self):
        wrong = chain()
        wrong['nodes'][-1].update(question='Is {{q1}} older?', answer_type='person')
        self.assertEqual(root_answer_check('Who was born first, Nia or Pavel?', wrong)['status'], 'mismatch')

    def test_clear_root_error_uses_existing_single_repair_and_only_one_model_judgment(self):
        wrong = chain()
        wrong['nodes'][-1].update(question='Was {{q1}} born in 1959?', answer_type='boolean')
        right = chain()
        model = Scripted([wrong, right], [{'status': 'valid', 'errors': []}])
        plan, trace = decompose_question(model, 'In what year was the writer of Ingenious born?')
        self.assertEqual(plan, right)
        self.assertEqual(len(model.messages), 2)
        self.assertEqual(len(model.prompts), 1)
        self.assertEqual(trace[1]['details']['source'], 'root_rule')
        self.assertEqual(trace[-1]['details']['source'], 'model')
        self.assertIn('Rewrite its question and type', model.messages[1][-1]['content'])

    def test_all_ten_recorded_root_errors_block_false_acceptance_without_a_model_call(self):
        rows = json.loads((ROOT / 'evaluation/decomposition_baselines.json').read_text())['runs']['v3.2.1']['questions']
        expected = {4, 10, 11, 12, 16, 21, 22, 27, 31, 36}
        detected = set()
        for order, row in enumerate(rows, 1):
            if row['status'] != 'valid':
                continue
            check = root_answer_check(row['question'], row['plan'])
            if check['errors']:
                detected.add(order)
                model = Scripted()  # Any model call is an error in this test.
                details = {}
                verdict = review_plan(model, row['question'], row['plan'], details=details)
                self.assertEqual(verdict['status'], 'revise')
                self.assertEqual(details['source'], 'root_rule')
                self.assertEqual(model.prompts, [])
        self.assertEqual(detected, expected)
        for order in (8, 15, 28, 35, 38):
            row = rows[order - 1]
            self.assertEqual(root_answer_check(row['question'], row['plan'])['status'], 'compatible')

    def test_relation_reversal_repaired_then_reviewed_using_original_question(self):
        question = 'The Innviertel is southeast of a river that is how many km long?'
        wrong = chain()
        wrong['nodes'][0]['question'] = 'Which river is southeast of the Innviertel?'
        wrong['nodes'][0]['answer_type'] = 'place'
        wrong['nodes'][1].update(question='How many km long is {{q1}}?', dependencies={'q1':'place'}, answer_type='number')
        right = copy.deepcopy(wrong)
        right['nodes'][0]['question'] = 'The Innviertel is southeast of which river?'
        model = Scripted([wrong, right], [{'status':'revise','errors':['q1 reverses southeast direction']},
                                         {'status':'valid','errors':[]}])
        plan, trace = decompose_question(model, question)
        self.assertEqual(plan, right)
        self.assertEqual(len(model.messages), 2); self.assertEqual(len(model.prompts), 2)
        self.assertTrue(all(question in m[-1]['content'] for m in model.messages))
        self.assertIn('reverses southeast', model.messages[1][-1]['content'])
        self.assertEqual([e['stage'] for e in trace], ['structure','semantic_review','semantic_repair','semantic_review'])
    def test_same_bad_semantics_after_repair_stops_before_retrieval(self):
        retriever = FakeRetriever(sample())
        model = Scripted([PLAN, PLAN], [{'status':'revise','errors':['wrong final type']},
                                      {'status':'revise','errors':['still wrong final type']}])
        with self.assertRaises(SemanticPlanError) as caught:
            run_operadic_rag('Which person?', retriever, model, TelemetryTracker('b'))
        self.assertEqual(retriever.calls, [])
        self.assertEqual(caught.exception.details['semantic_status'], 'revise')
        self.assertEqual(len(model.messages), 2)
    def test_unreadable_judgment_is_not_acceptance(self):
        model = Scripted([PLAN, PLAN], [{'status':'valid','errors':['actually wrong']}, {}])
        with self.assertRaises(SemanticPlanError):
            decompose_question(model, 'Which person?')
    def test_invalid_repair_cannot_bypass_structure(self):
        model = Scripted([PLAN, {}], [{'status':'revise','errors':['wrong relation']}])
        with self.assertRaises(SemanticPlanError) as caught:
            decompose_question(model, 'Which person?')
        self.assertEqual(caught.exception.details['structural_status'], 'invalid')


class BindingTests(unittest.TestCase):
    def test_shared_nationality_retains_each_person_and_property(self):
        s = next(s for s in load_sample_snapshot(SNAPSHOT, 40) if s['question_id']=='5a89bf18554299669944a591')
        ev = make_passage_corpus(s)
        ref_a = str(next(p['index'] for p in ev if p['title']=="John O'Hara"))+':0'
        ref_b = str(next(p['index'] for p in ev if p['title']=='Bobbie Ann Mason'))+':0'
        plan = {'nodes':[
            {'id':'q1','question':"What is John O'Hara's nationality?",'dependencies':{},'answer_type':'other'},
            {'id':'q2','question':"What is Bobbie Ann Mason's nationality?",'dependencies':{},'answer_type':'other'},
            {'id':'q3','question':"Are John O'Hara's nationality {{q1}} and Bobbie Ann Mason's nationality {{q2}} the same?",
             'dependencies':{'q1':'other','q2':'other'},'answer_type':'boolean'}], 'final':'q3'}
        model = Scripted(replies=[supported('American',[ref_a]),supported('American',[ref_b]),supported('yes',[ref_a,ref_b])])
        result = evaluate_tree(model, plan, ev, original_question=s['question'])
        root_prompt = model.prompts[-1]
        supplied = json.loads(root_prompt.split('Bindings:\n')[1].split('\nEvidence:')[0])
        self.assertIn("John O'Hara", supplied['q1']['source_question'])
        self.assertIn('Bobbie Ann Mason', supplied['q2']['source_question'])
        self.assertEqual(supplied['q1']['value'], supplied['q2']['value'])
        self.assertIn('{{q1}}', root_prompt)
        self.assertNotIn('Do American and American share', root_prompt)
        self.assertEqual(result['answers']['q3'], 'yes')
        self.assertIn(s['question'], root_prompt)
        self.assertNotIn('supporting_facts', root_prompt)
    def test_cache_conflict_invalidates_dependent_answer(self):
        ev = make_passage_corpus(sample())
        model1 = Scripted(replies=[supported('Alice',['0:0']), supported('1900',['1:0'])])
        first = evaluate_tree(model1, chain(), ev[:3], original_question='Q?')
        model2 = Scripted(replies=[{'invalid':[{'id':'q1','refs':['3:0'],'reason':'New source contradicts writer'}]},
                                  supported('Bob',['3:0']),supported('1920',['4:0'])])
        second = evaluate_tree(model2, chain(), ev[:6], original_question='Q?',
                               previous=first, previous_evidence=ev[:3])
        self.assertEqual(second['answers'], {'q1':'Bob','q2':'1920'})
        self.assertTrue(all(not node['reused'] for node in second['nodes']))
        self.assertEqual(len(model2.prompts), 3)
    def test_same_evidence_reuses_answers_without_another_call(self):
        ev = make_passage_corpus(sample())[:3]
        first = evaluate_tree(Scripted(replies=[supported('Alice',['0:0']), supported('1900',['1:0'])]), chain(), ev)
        model = Scripted()
        second = evaluate_tree(model, chain(), ev, previous=first, previous_evidence=ev, review=True)
        self.assertEqual(model.prompts, [])
        self.assertTrue(all(s['reused'] for s in second['nodes']))
    def test_malformed_cache_audit_conservatively_reassesses(self):
        ev = make_passage_corpus(sample())
        first = evaluate_tree(Scripted(replies=[supported('Alice',['0:0']), unresolved()]), chain(), ev[:3])
        model = Scripted(replies=[{}, supported('Bob',['3:0']), supported('1920',['4:0'])])
        second = evaluate_tree(model, chain(), ev[:6], previous=first, previous_evidence=ev[:3])
        self.assertEqual(second['cache_audit']['status'], 'invalid')
        self.assertFalse(second['nodes'][0]['reused'])
    def test_all_ancestors_kept_for_long_chain(self):
        plan = chain()
        plan['nodes'].append({'id':'q3','question':'What happened in {{q2}}?', 'dependencies':{'q2':'date'},'answer_type':'other'})
        plan['final']='q3'
        model = Scripted(replies=[supported('Alice',['0:0']), supported('1900',['1:0']),supported('event',['2:0'])])
        evaluate_tree(model, plan, make_passage_corpus(sample())[:3])
        supplied = json.loads(model.prompts[-1].split('Bindings:\n')[1].split('\nEvidence:')[0])
        self.assertEqual(set(supplied), {'q1','q2'})


class TargetedReviewTests(unittest.TestCase):
    def test_ingenious_explicit_birth_date_review_without_reasking_writer(self):
        s = next(s for s in load_sample_snapshot(SNAPSHOT, 40) if s['question_id']=='5ae254565542992decbdccbb')
        ev = make_passage_corpus(s)
        writer = next(p['index'] for p in ev if p['title']=='Ingenious (2009 British film)')
        birth = next(p['index'] for p in ev if p['title']=='Jeanette Winterson')
        others = [p['index'] for p in ev if p['index'] not in (writer,birth)]
        order = [writer]+others[:2]+[birth]+others[2:]
        retriever = FakeRetriever(s)
        def search(query, top_k=3, exclude_indices=()):
            retriever.calls.append((query,top_k,tuple(exclude_indices)))
            return [ev[i] for i in order if i not in exclude_indices][:top_k]
        retriever.search = search
        model = Scripted([chain()], [
            {'status':'valid','errors':[]}, supported('Jeanette Winterson',[f'{writer}:0']),
            unresolved('When was Jeanette Winterson born?'), {'invalid':[]},
            unresolved('When was Jeanette Winterson born?'), supported('1959',[f'{birth}:0'])])
        tracker = TelemetryTracker('b')
        with activate_tracker(tracker):
            result = run_operadic_rag(s['question'], retriever, model, tracker)
        self.assertEqual(result['answer_decomposed'], '1959')
        self.assertEqual(result['answer_source'], 'cited_root')
        self.assertEqual(tracker.retrieval_steps, 2)
        self.assertEqual(tracker.llm_calls, 7)
        self.assertEqual(result['targeted_review_calls'], 1)
        self.assertEqual(result['reused_nodes'], 2)
        self.assertEqual(sum('\nNode:\nWho wrote Ingenious?\n' in p for p in model.prompts), 1)
        self.assertIn('TARGETED RECHECK', model.prompts[-1])
        for p in result['evidence_final']:
            for sentence in p['sentences']:
                self.assertIn(sentence, model.prompts[-1])
    def test_unresolved_tree_gets_one_pass_not_infinite_retry(self):
        r = FakeRetriever(sample())
        model = Scripted([chain()], [{'status':'valid','errors':[]}, unresolved(),unresolved(),unresolved()])
        result = run_operadic_rag('Q?', r, model, TelemetryTracker('b'))
        self.assertEqual(result['answer_status'],'abstained')
        self.assertEqual(len(r.calls),2)
        self.assertEqual(result['targeted_review_calls'],1)
        self.assertEqual(len(model.prompts),4)
    def test_short_root_saves_final_generation(self):
        r = FakeRetriever(sample())
        model = Scripted([chain()], [{'status':'valid','errors':[]},supported('Alice',['0:0']),supported('1900',['1:0'])])
        result = run_operadic_rag('Q?',r,model,TelemetryTracker('b'))
        self.assertEqual(result['answer_decomposed'],'1900')
        self.assertEqual(len(model.prompts),3)
        self.assertEqual(result['targeted_review_calls'],0)
    def test_long_root_uses_formatting_only_with_full_evidence(self):
        r = FakeRetriever(sample())
        model = Scripted([chain()], [{'status':'valid','errors':[]},supported('Alice',['0:0']),
                                    supported('The correct year of birth is 1900',['1:0'])])
        captured = []
        def shorten(question, evidence, bindings, final):
            captured.append((question,evidence,bindings,final))
            return '1900'
        model.shorten_answer = shorten
        result = run_operadic_rag('Full original question?',r,model,TelemetryTracker('b'))
        self.assertEqual(result['answer_source'], 'shortened_root')
        self.assertEqual(captured[0][0], 'Full original question?')
        self.assertEqual(captured[0][1], result['evidence_final'])
        self.assertEqual(captured[0][3], 'q2')
        self.assertEqual(captured[0][2]['q2']['value'], 'The correct year of birth is 1900')
    def test_shortening_prompt_keeps_question_bindings_and_full_text(self):
        llm = LocalQwen.__new__(LocalQwen)
        captured = []
        llm.generate = lambda messages: captured.append(messages) or '1900'
        ev = make_passage_corpus(sample())[:3]
        result = llm.shorten_answer('Exact question?', ev,
            {'q2':{'source_question':'When was Alice born?','value':'The year was 1900','refs':['0:0']}}, 'q2')
        self.assertEqual(result,'1900')
        self.assertIn('Do not solve the question anew', captured[0][0]['content'])
        self.assertIn('Exact question?', captured[0][1]['content'])
        self.assertIn('Root ID: q2', captured[0][1]['content'])
        for p in ev:
            for sentence in p['sentences']:
                self.assertIn(sentence,captured[0][1]['content'])


class SnapshotComparisonTests(unittest.TestCase):
    def test_exact_cohort_and_baseline_counts(self):
        samples = load_sample_snapshot(SNAPSHOT,40)
        baseline = compare(ROOT/'evaluation/baseline.csv', ROOT/'evaluation/baseline.csv')
        self.assertEqual(len(samples),40)
        self.assertEqual(baseline['baseline']['all']['operadic']['correct_f1_ge_0_5'],5)
        self.assertEqual(baseline['baseline']['all']['operadic']['abstained_completed'],23)
        self.assertEqual(baseline['baseline']['all']['operadic']['failed'],8)
    def test_snapshot_mismatch_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'samples.json'
            values=json.loads(SNAPSHOT.read_text()); values[0]['question']+=' altered'
            p.write_text(json.dumps(values))
            (p.parent/'manifest.json').write_text((SNAPSHOT.parent/'manifest.json').read_text())
            with self.assertRaisesRegex(ValueError,'checksum'):
                load_sample_snapshot(p,40)
    def test_comparison_refuses_different_question(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'other.csv'
            with (ROOT/'evaluation/baseline.csv').open(encoding='utf-8-sig',newline='') as h:
                rows=list(csv.DictReader(h))
            rows[0]['question']+=' changed'
            with p.open('w',encoding='utf-8',newline='') as h:
                w=csv.DictWriter(h,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
            with self.assertRaisesRegex(ValueError,'content changed'):
                compare(ROOT/'evaluation/baseline.csv',p)
    def test_experiment_uses_snapshot_not_network_dataset(self):
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(experiment,'load_hotpotqa',side_effect=AssertionError('dataset reloaded')), \
             patch.object(experiment,'check_runtime'), patch.object(experiment,'set_seed'), \
             patch.object(experiment,'print_summary'), patch.object(experiment,'LocalQwen',side_effect=lambda **kw:FakeLLM()), \
             patch.object(experiment,'build_question_retrievers',side_effect=lambda rows:{s['question_id']:FakeRetriever(s) for s in rows}):
            output=Path(tmp)/'results.csv'
            frame=experiment.run_experiment(n_samples=40,output_csv=output,samples_json=SNAPSHOT)
            self.assertEqual(frame['question_id'].tolist(),[s['question_id'] for s in load_sample_snapshot(SNAPSHOT,40)])
            self.assertTrue(frame.attrs['run_complete'])
            self.assertTrue((frame['operadic_llm_calls']>=5).all())  # Includes semantic self-judge.
            self.assertTrue((frame['semantic_status']=='model_reviewed').all())


if __name__ == '__main__':
    unittest.main()
