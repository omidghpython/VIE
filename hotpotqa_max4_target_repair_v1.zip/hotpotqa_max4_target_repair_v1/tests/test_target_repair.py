"""Target-detector and shared-budget tests; no claim about live model accuracy."""
import copy
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.decomposition import (
    PLAN_SYSTEM, TargetPlanError, DecompositionError, generate_plan,
    decompose_question, value_target_check, plan_instructions,
)
from test_decomposition_pilot import ScriptedModel


def single(question, kind):
    return {'nodes': [{'id': 'q1', 'question': question,
                      'dependencies': {}, 'answer_type': kind}], 'final': 'q1'}


QUESTION = 'Which botanist discovered the fern, Talia or Ivo?'
BAD = single('Did Talia discover the fern?', 'boolean')
GOOD = {'nodes': [
    {'id': 'q1', 'question': 'Did Talia discover the fern?', 'dependencies': {}, 'answer_type': 'boolean'},
    {'id': 'q2', 'question': 'Did Ivo discover the fern?', 'dependencies': {}, 'answer_type': 'boolean'},
    {'id': 'q3', 'question': 'Which botanist discovered the fern: Talia ({{q1}}) or Ivo ({{q2}})?',
     'dependencies': {'q1': 'boolean', 'q2': 'boolean'}, 'answer_type': 'person'}], 'final': 'q3'}


class Model:
    plan_tokens = 3072
    def __init__(self, *outputs):
        self.outputs = list(outputs)
        self.messages = []
    def generate(self, messages, max_new_tokens=None):
        self.messages.append(copy.deepcopy(messages))
        reply = self.outputs.pop(0)
        return reply if isinstance(reply, str) else json.dumps(reply)
    def ask_json(self, prompt):
        raise AssertionError('Unresolved target must not reach the judge.')


class TargetDetectorTests(unittest.TestCase):
    def test_synthetic_positive_cases_outside_evaluation_set(self):
        questions = [QUESTION, 'Who designed the Zephyr monument?',
                     'Where was the inventor of the Vela engine born?',
                     'When was the Cobalt bridge opened?', 'What year did Selene graduate?',
                     'How many towers does the Arin fortress have?',
                     'The narrator of Vela appeared in what novel?',
                     'Which statement is true about the new bridge?']
        for question in questions:
            with self.subTest(question=question):
                self.assertEqual(value_target_check(question, BAD)['status'], 'mismatch')

    def test_legitimate_boolean_and_uncertain_requests_are_not_rejected(self):
        questions = ['Did Talia discover the fern?', 'Are the two rivers equally long?',
                     'What is the truth value of the statement?',
                     'What is the truth-value of the statement?',
                     'What is the Boolean result of this expression?',
                     'Which answer applies: yes/no?', 'What is the answer: true/false?',
                     'What is the result of the test?',
                     'Could you tell me which botanist discovered the fern?',
                     'How can we tell whether the botanist discovered the fern?',
                     'Explain the finding.', 'Choose the best option.']
        for question in questions:
            with self.subTest(question=question):
                self.assertEqual(value_target_check(question, BAD)['status'], 'not_checked')

    def test_boolean_intermediates_are_allowed_and_tree_not_mutated(self):
        before = copy.deepcopy(GOOD)
        self.assertEqual(value_target_check(QUESTION, GOOD)['status'], 'compatible')
        self.assertEqual(GOOD, before)

    def test_root_wording_and_type_are_checked_independently(self):
        for plan in [single('Did Talia discover the fern?', 'person'),
                     single('Which botanist discovered the fern?', 'boolean')]:
            self.assertEqual(value_target_check(QUESTION, plan)['status'], 'mismatch')

    def test_wrong_nonboolean_types_and_missing_question_mark_are_out_of_scope(self):
        plan = single('Name the botanist who discovered the fern', 'work')
        self.assertEqual(value_target_check(QUESTION, plan)['status'], 'compatible')
        self.assertEqual(value_target_check('Did Talia discover it?', plan)['status'], 'not_checked')

    def test_saved_outputs_match_narrow_assistant_labels_not_general_accuracy(self):
        path = Path(__file__).resolve().parents[1] / 'evaluation/target_detector_saved_audit.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        checked = positive = 0
        for row in data['rows']:
            if 'plan' not in row:
                continue
            actual = value_target_check(row['question'], row['plan'])['status'] == 'mismatch'
            self.assertEqual(actual, row['expected_value_to_boolean_mismatch'], (row['run'], row['index']))
            checked += 1
            positive += actual
        self.assertEqual((checked, positive), (75, 5))


class SharedBudgetTests(unittest.TestCase):
    def test_valid_first_output_has_no_extra_generation(self):
        model = Model(GOOD)
        plan, trace = generate_plan(model, QUESTION)
        self.assertEqual(plan, GOOD)
        self.assertEqual(len(model.messages), 1)
        self.assertEqual(trace[0]['target_check']['status'], 'compatible')

    def test_target_repair_keeps_exact_question_system_and_raw_plan(self):
        raw = json.dumps(BAD, indent=2)
        model = Model(raw, GOOD)
        plan, trace = generate_plan(model, QUESTION)
        self.assertEqual(plan, GOOD)
        self.assertEqual([e['status'] for e in trace], ['valid', 'valid'])
        self.assertEqual(trace[0]['generation_status'], 'target_mismatch')
        self.assertEqual(trace[0]['raw_output'], raw)
        for messages in model.messages:
            self.assertEqual(messages[0]['content'], plan_instructions(QUESTION))
            self.assertTrue(messages[1]['content'].startswith(QUESTION))
        self.assertIn(raw, model.messages[1][1]['content'])
        self.assertIn('preserving meaning and all constraints', model.messages[1][1]['content'])
        self.assertIn('Rewrite its question and type', model.messages[1][1]['content'])

    def test_repeated_target_failure_retains_plan_and_never_calls_judge(self):
        model = Model(BAD, BAD)
        with self.assertRaises(TargetPlanError) as cm:
            decompose_question(model, QUESTION)
        self.assertEqual(len(model.messages), 2)
        self.assertEqual(cm.exception.details['structural_status'], 'valid')
        self.assertEqual(cm.exception.details['semantic_status'], 'target_mismatch')
        self.assertEqual(cm.exception.details['plan'], BAD)

    def test_structure_then_target_failure_has_no_third_attempt(self):
        model = Model('not json', BAD)
        with self.assertRaises(TargetPlanError) as cm:
            generate_plan(model, QUESTION)
        self.assertEqual(len(model.messages), 2)
        self.assertEqual([e['status'] for e in cm.exception.details['decomposition_trace']], ['invalid', 'valid'])

    def test_target_then_structure_failure_is_reported_as_final_structure_failure(self):
        model = Model(BAD, 'not json')
        with self.assertRaises(DecompositionError) as cm:
            generate_plan(model, QUESTION)
        self.assertNotIsInstance(cm.exception, TargetPlanError)
        self.assertEqual(cm.exception.details['structural_status'], 'invalid')
        self.assertEqual(cm.exception.details['decomposition_trace'][0]['target_check']['status'], 'mismatch')
        self.assertEqual(len(model.messages), 2)

    def test_unknown_request_does_not_trigger_repair(self):
        model = Model(BAD)
        _, trace = generate_plan(model, 'What is the truth value of the finding?')
        self.assertEqual(trace[0]['target_check']['status'], 'not_checked')
        self.assertEqual(len(model.messages), 1)


class TargetPilotTests(unittest.TestCase):
    def run_case(self, plans, verdicts=()):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / 'pilot'
        model = ScriptedModel(plans, verdicts)
        samples = [{'question_id': 'new_synthetic_case', 'question': QUESTION, 'type': 'comparison',
                    'answer': 'DO_NOT_SEND_GOLD', 'context': 'DO_NOT_SEND_CONTEXT'}]
        loads = []
        def factory(settings):
            loads.append(True)
            return model, {'backend': 'scripted-test'}
        def run(**kwargs):
            with redirect_stdout(io.StringIO()):
                return pilot.run_pilot(samples, {}, path, model_factory=factory, **kwargs)
        summary = run()
        self.assertNotIn('DO_NOT_SEND', json.dumps([model.messages, model.prompts]))
        return path, model, summary, run, loads

    def test_unresolved_target_counts_structure_valid_generation_blocked_and_resumes_without_calls(self):
        path, model, summary, run, loads = self.run_case([BAD, BAD])
        self.assertEqual(summary['structure_status'], {'valid': 1})
        self.assertEqual(summary['generation_status'], {'target_mismatch': 1})
        self.assertEqual(summary['valid_on_first_attempt'], 1)
        self.assertEqual(summary['generation_accepted_on_first_attempt'], 0)
        self.assertEqual(summary['target_mismatch_unresolved_questions'], 1)
        self.assertEqual(summary['review_source'], {'target_gate': 1})
        self.assertEqual(summary['total_cost']['llm_calls'], 2)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.assertEqual(model.prompts, [])
        for options in ({}, {'retry_errors': True}, {'report_only': True}):
            self.assertEqual(run(**options), summary)
        self.assertEqual(len(loads), 1)
        report = (path / 'review.md').read_text(encoding='utf-8')
        self.assertIn('Answer-target check: mismatch', report)
        with (path / 'trees.csv').open(encoding='utf-8-sig') as stream:
            row = next(csv.DictReader(stream))
        self.assertEqual(row['structure_error'], '')
        self.assertTrue(row['generation_error'])

    def test_resolved_target_runs_existing_judge_once_and_counts_all_costs(self):
        _, model, summary, _, _ = self.run_case([BAD, GOOD], [{'status': 'valid', 'errors': []}])
        self.assertEqual(summary['generation_status'], {'valid': 1})
        self.assertEqual(summary['target_repair_resolved_questions'], 1)
        self.assertEqual(summary['total_cost']['llm_calls'], 3)
        self.assertEqual(summary['total_cost']['total_tokens'], 45)
        self.assertEqual(len(model.prompts), 1)

    def test_second_attempt_structure_failure_keeps_target_diagnosis_in_trace(self):
        _, _, summary, _, _ = self.run_case([BAD, 'not json'])
        self.assertEqual(summary['structure_status'], {'invalid': 1})
        self.assertEqual(summary['target_mismatch_detected_questions'], 1)
        self.assertEqual(summary['target_repair_attempted_questions'], 1)
        self.assertEqual(summary['target_repair_resolved_questions'], 0)
        self.assertEqual(summary['total_cost']['llm_calls'], 2)


if __name__ == '__main__':
    unittest.main()
