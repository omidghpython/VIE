@echo off
call "%~dp0run_bridge_first_probe.bat" %*
exit /b %ERRORLEVEL%
