@echo off
call "%~dp0run_comparison_test.bat" %*
exit /b %ERRORLEVEL%
