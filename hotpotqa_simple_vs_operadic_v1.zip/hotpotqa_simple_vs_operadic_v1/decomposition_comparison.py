"""Paired simple-prompt vs max4 operadic generation; no model judge or RAG."""
import argparse
from collections import Counter
import copy
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.checkpoint import RunStore, atomic_json, digest
from hotpotqa_operadic_rag.config import (
    MODEL_NAME, MODEL_REVISION, RANDOM_SEED, MAX_PLAN_NODES, PLAN_ATTEMPTS,
    DEFAULT_MAX_INPUT_TOKENS, DEFAULT_PLAN_TOKENS, DEFAULT_INTERMEDIATE_TOKENS,
)
from hotpotqa_operadic_rag.decomposition import PLAN_SYSTEM, generate_plan, DecompositionError
from hotpotqa_operadic_rag.telemetry import TelemetryTracker, activate_tracker

ROOT = Path(__file__).resolve().parent
METHODS = ('simple', 'operadic')
TERMINAL = {'observed', 'empty_output', 'valid', 'invalid'}
SIMPLE_SYSTEM = (
    'Break the question into at most four ordered subquestions needed to answer it. '
    'Refer to earlier answers when needed. '
    'Return only the numbered subquestions, not their answers.'
)


def code_digest():
    checksum = hashlib.sha256()
    paths = [Path(__file__).resolve(), ROOT / 'decomposition_pilot.py',
             *sorted((ROOT / 'hotpotqa_operadic_rag').rglob('*.py'))]
    for path in paths:
        checksum.update(path.relative_to(ROOT).as_posix().encode())
        checksum.update(path.read_bytes())
    return checksum.hexdigest()


def inspect_numbering(raw):
    """Report presentation only. Never reject prose or infer semantic correctness."""
    matches = list(re.finditer(r'^\s*(\d+)[.)]\s+\S', raw, re.MULTILINE))
    ids = [int(m.group(1)) for m in matches]
    return {'numbered_items_detected': len(ids),
            'sequential_numbering': bool(ids) and ids == list(range(1, len(ids) + 1)),
            'above_requested_four_flag': len(ids) > 4,
            'scope': 'Heuristic formatting observations only; inspect full raw output.'}


class CallRecorder:
    """Keep each exact input/output and cost, including failed recorded calls."""
    def __init__(self, model, tracker):
        self.model, self.tracker = model, tracker
        self.plan_tokens = model.plan_tokens
        self.calls = []

    def generate(self, messages, max_new_tokens=None):
        before = self.tracker.as_dict()
        event = {'messages': copy.deepcopy(messages), 'max_new_tokens': max_new_tokens,
                 'raw_output': None, 'error': ''}
        try:
            raw = self.model.generate(messages, max_new_tokens=max_new_tokens)
            if not isinstance(raw, str):
                raise TypeError('Model output must be text.')
            event['raw_output'] = raw
            return raw
        except BaseException as exc:
            event['error'] = f'{type(exc).__name__}: {exc}'
            raise
        finally:
            after = self.tracker.as_dict()
            event['telemetry'] = {k: after[k] - before[k] for k in
                                  ('llm_calls', 'prompt_tokens', 'completion_tokens', 'total_tokens')}
            self.calls.append(event)


def run_phase(store, record, method, model, question):
    previous = record['phases'].get(method, {})
    tracker = TelemetryTracker(method)
    recorder = CallRecorder(model, tracker)
    outcome = {'status': 'error', 'error': '', 'result': {}}
    try:
        with activate_tracker(tracker):
            if method == 'simple':
                raw = recorder.generate([{'role': 'system', 'content': SIMPLE_SYSTEM},
                                          {'role': 'user', 'content': question}],
                                         max_new_tokens=model.plan_tokens)
                outcome['result'] = {'raw_output': raw, 'format_observations': inspect_numbering(raw)}
                outcome['status'] = 'observed' if raw.strip() else 'empty_output'
            else:
                plan, trace = generate_plan(recorder, question)
                outcome['result'] = {'plan': plan, 'decomposition_trace': trace}
                outcome['status'] = 'valid'
    except DecompositionError as exc:
        outcome.update(status='invalid', error=str(exc), result=exc.details)
    except KeyboardInterrupt:
        outcome.update(status='interrupted', error='Interrupted; recorded costs retained on resume.')
        raise
    except Exception as exc:
        outcome['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        outcome['calls'] = recorder.calls
        outcome['telemetry'] = tracker.as_dict()
        outcome['history'] = previous.get('history', []) + [{
            'status': outcome['status'], 'error': outcome['error'],
            'telemetry': tracker.as_dict(), 'calls': recorder.calls,
            'result': copy.deepcopy(outcome['result'])}]
        record['phases'][method] = outcome
        store.write(record)


def write_csv(path, rows):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def export_reports(store):
    rows, manual_rows = [], []
    statuses = {m: Counter() for m in METHODS}
    costs = {m: Counter() for m in METHODS}
    first_costs = {m: Counter() for m in METHODS}
    review = ['# Simple vs operadic decomposition', '',
              'Compare FIRST outputs on equal calls, then inspect operadic structural repair separately.',
              'No model judge, retrieval or final answering was run. No automatic semantic winner.',
              'Both prompts request at most four items; simple output has no typed/tree validation or repair.',
              'Inspect target, relations, constraints, necessary decomposition and redundant steps.',
              'Formatting, item count and structural validity are not semantic accuracy.', '']
    incomplete = 0
    for index, sample in enumerate(store.samples, 1):
        record = store.read(sample['question_id'])
        row = {'index': index, 'question_id': sample['question_id'],
               'question': sample['question'], 'type': sample['type']}
        review.extend([f'## {index}. {sample["question_id"]}', '', sample['question'], ''])
        for method in METHODS:
            phase = record['phases'].get(method, {})
            status = phase.get('status', 'pending')
            statuses[method][status] += 1
            incomplete += int(status not in TERMINAL)
            history = phase.get('history', [])
            all_calls = [c for h in history for c in h.get('calls', [])]
            first = all_calls[0] if all_calls else {}
            latest = phase.get('calls', [])
            result = phase.get('result', {})
            row[method + '_status'] = status
            row[method + '_first_raw'] = first.get('raw_output')
            row[method + '_first_error'] = first.get('error', '')
            row[method + '_latest_raw'] = latest[-1].get('raw_output') if latest else None
            row[method + '_error'] = phase.get('error', '')
            row[method + '_recorded_calls'] = len(all_calls)
            row[method + '_semantic_correctness'] = 'not_evaluated'
            for key in pilot.COST_KEYS:
                value = sum(h.get('telemetry', {}).get(key, 0) for h in history)
                costs[method][key] += value
                row[method + '_' + key] = value
            for key in ('llm_calls', 'prompt_tokens', 'completion_tokens', 'total_tokens'):
                value = first.get('telemetry', {}).get(key, 0)
                first_costs[method][key] += value
                row[method + '_first_' + key] = value
            if method == 'simple':
                row['simple_format_observations'] = json.dumps(result.get('format_observations', {}))
            else:
                row['operadic_final_plan'] = json.dumps(result.get('plan'), ensure_ascii=False)
                row['operadic_structure_trace'] = json.dumps(result.get('decomposition_trace', []), ensure_ascii=False)
            review.extend([f'### {method}: {status}', '', 'FIRST output (original call):',
                           pilot.markdown_code_block(first.get('raw_output') if first.get('raw_output') is not None
                                                     else '(no complete returned output)'),
                           'First error: ' + first.get('error', ''), ''])
            for hindex, h in enumerate(history, 1):
                for cindex, call in enumerate(h.get('calls', []), 1):
                    if hindex == 1 and cindex == 1:
                        continue
                    review.extend([f'Additional call: phase attempt {hindex}, call {cindex}',
                                   pilot.markdown_code_block(call.get('raw_output') if call.get('raw_output') is not None
                                                             else '(no complete returned output)'),
                                   'Error: ' + call.get('error', ''), ''])
            if method == 'operadic':
                review.extend(pilot.structure_trace_markdown(result.get('decomposition_trace', [])))
            review.extend(['Manual semantic assessment: pending.', ''])
        rows.append(row)
        manual = {'question_id': sample['question_id'], 'question': sample['question']}
        for version in ('simple_first', 'operadic_first', 'operadic_after_structural_repair'):
            for criterion in ('target', 'relations', 'constraints', 'required_hops', 'no_redundancy', 'overall'):
                manual[version + '_' + criterion] = ''
        manual.update(winner_first_call='', winner_with_operadic_repair='', reviewer='', notes='')
        manual_rows.append(manual)
    summary = {'requested': len(rows), 'status_counts': {m: dict(v) for m, v in statuses.items()},
               'total_cost_including_recorded_retries': {m: dict(v) for m, v in costs.items()},
               'first_call_cost': {m: dict(v) for m, v in first_costs.items()},
               'incomplete_phases': incomplete, 'semantic_correctness_measured': False,
               'answer_accuracy_measured': False, 'automatic_winner': None,
               'backend': store.manifest['settings']['backend'],
               'comparison_scope': 'Simple one-call prompt vs unchanged operadic max4 generation (up to two structural calls). '
                                   'Judge, retrieval, node answering and semantic repair excluded from BOTH arms. '
                                   'Compare first calls separately from operadic repaired output; not a full RAG cost or accuracy claim.',
               'evaluation_priority': 'Correct, complete decomposition; tokens are diagnostic.',
               'manual_review': 'Fill manual_review.csv with pass/fail/uncertain and reasons; blank means pending. '
                                'It is preserved on report regeneration, not automatically counted as independent ground truth.'}
    write_csv(store.output, rows)
    manual_path = store.output.parent / 'manual_review.csv'
    if not manual_path.exists():
        write_csv(manual_path, manual_rows)
    atomic_json(store.output.parent / 'summary.json', summary)
    (store.output.parent / 'review.md').write_text('\n'.join(review), encoding='utf-8')
    archive = store.output.parent.with_name(store.output.parent.name + '_results.zip')
    temporary = archive.with_suffix('.zip.tmp')
    paths = [store.output, manual_path, store.output.parent / 'summary.json', store.output.parent / 'review.md',
             store.manifest_path, store.directory / 'samples.json']
    paths += [store.records_dir / (s['question_id'] + '.json') for s in store.samples]
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in paths:
            if path.is_file() and not path.is_symlink():
                z.write(path, path.relative_to(store.output.parent.parent))
    os.replace(temporary, archive)
    return summary


def run_comparison(samples, output_dir, *, report_only=False, retry_errors=False, model_factory=None,
                   use_4bit=True, require_cuda=True, max_input_tokens=DEFAULT_MAX_INPUT_TOKENS,
                   plan_tokens=DEFAULT_PLAN_TOKENS):
    if any(type(n) is not int or n < 1 for n in (max_input_tokens, plan_tokens)):
        raise ValueError('Token budgets must be positive integers.')
    if MAX_PLAN_NODES != 4:
        raise ValueError('This comparison is pinned to the accepted max4 operadic baseline.')
    settings = {'schema_version': 1, 'code_sha256': code_digest(), 'n_samples': len(samples),
                'samples_sha256': digest(samples), 'backend': 'injected_test' if model_factory else 'LocalQwen',
                'model': MODEL_NAME, 'model_revision': MODEL_REVISION, 'seed': RANDOM_SEED,
                'use_4bit': use_4bit, 'require_cuda': require_cuda, 'max_input_tokens': max_input_tokens,
                'plan_tokens': plan_tokens, 'intermediate_tokens': DEFAULT_INTERMEDIATE_TOKENS,
                'simple_prompt': SIMPLE_SYSTEM, 'simple_prompt_sha256': hashlib.sha256(SIMPLE_SYSTEM.encode()).hexdigest(),
                'operadic_prompt_sha256': hashlib.sha256(PLAN_SYSTEM.encode()).hexdigest(),
                'requested_max_subquestions_both': 4, 'simple_attempts': 1,
                'operadic_structural_attempts': PLAN_ATTEMPTS, 'judge_calls': 0,
                'order': 'simple-first for odd question positions; operadic-first for even positions'}
    output = Path(output_dir).expanduser().resolve() / 'comparison.csv'
    if report_only and not (output.with_name(output.name + '.state') / 'manifest.json').exists():
        raise ValueError('No existing comparison to report.')
    store = RunStore(output, settings, lambda: samples)
    if store.samples != samples:
        raise ValueError('The provided cohort differs from the saved snapshot.')
    summary = export_reports(store)
    pending = lambda: any(pilot.should_run(store.read(s['question_id'])['phases'].get(m, {}), retry_errors)
                          for s in samples for m in METHODS)
    if report_only or not pending():
        return summary
    model, identity = (model_factory or pilot.create_model)(settings)
    store.bind_runtime(identity)
    try:
        for index, sample in enumerate(store.samples, 1):
            record = store.read(sample['question_id'])
            order = METHODS if index % 2 else METHODS[::-1]
            for method in order:
                if pilot.should_run(record['phases'].get(method, {}), retry_errors):
                    print(f'[{index}/{len(samples)}] {method}: {sample["question_id"]}', flush=True)
                    run_phase(store, record, method, model, sample['question'])
                    export_reports(store)
    finally:
        summary = export_reports(store)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples-json', default=str(ROOT / 'evaluation/samples.json'))
    parser.add_argument('--output-dir', default=str(ROOT / 'results/simple_vs_operadic_v1'))
    parser.add_argument('--max-input-tokens', type=int, default=DEFAULT_MAX_INPUT_TOKENS)
    parser.add_argument('--plan-tokens', type=int, default=DEFAULT_PLAN_TOKENS)
    parser.add_argument('--no-4bit', action='store_true')
    parser.add_argument('--allow-cpu', action='store_true')
    parser.add_argument('--report-only', action='store_true')
    parser.add_argument('--retry-errors', action='store_true')
    args = parser.parse_args()
    try:
        samples, _ = pilot.load_cohort(args.samples_json)
        summary = run_comparison(samples, args.output_dir, report_only=args.report_only,
                                 retry_errors=args.retry_errors, use_4bit=not args.no_4bit,
                                 require_cuda=not args.allow_cpu, max_input_tokens=args.max_input_tokens,
                                 plan_tokens=args.plan_tokens)
    except KeyboardInterrupt:
        print('Interrupted; saved phases and reports retained. Rerun to resume.')
        return 130
    except Exception as exc:
        print(f'Comparison blocked: {type(exc).__name__}: {exc}')
        return 2
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print('Results ZIP:', str(Path(args.output_dir).resolve()) + '_results.zip')
    return 0 if summary['incomplete_phases'] == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
