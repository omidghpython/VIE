"""Offline paired-generation, recovery and accounting checks; no quality claim."""
import copy
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from contextlib import redirect_stdout
import zipfile

import decomposition_comparison as compare
from test_decomposition_pilot import ScriptedModel, SAMPLES, CHAIN


class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name) / 'paired'
        self.loads = 0
        self.model = ScriptedModel()

    def factory(self, settings):
        self.loads += 1
        return self.model, {'backend': 'scripted'}

    def run_comparison(self, samples=None, **kwargs):
        with redirect_stdout(io.StringIO()):
            return compare.run_comparison(samples or SAMPLES, self.output,
                                          model_factory=self.factory, **kwargs)

    def record(self):
        return json.loads((self.output / 'comparison.csv.state/questions/example1.json').read_text())

    def test_both_methods_get_question_only_no_judge_or_typed_conversion_of_simple(self):
        raw = '1. Who wrote The Lantern?\n2. Where was that person born?'
        self.model = ScriptedModel([raw, CHAIN])
        summary = self.run_comparison()
        self.assertEqual(len(self.model.messages), 2)
        self.assertFalse(self.model.prompts)
        self.assertEqual(self.model.messages[0], [{'role': 'system', 'content': compare.SIMPLE_SYSTEM},
                                                {'role': 'user', 'content': SAMPLES[0]['question']}])
        for messages in self.model.messages:
            self.assertEqual(messages[-1]['content'], SAMPLES[0]['question'])
            self.assertNotIn(SAMPLES[0]['answer'], str(messages))
            self.assertNotIn(SAMPLES[0]['context'], str(messages))
        self.assertEqual(self.record()['phases']['simple']['result']['raw_output'], raw)
        self.assertNotIn('plan', self.record()['phases']['simple']['result'])
        self.assertEqual(summary['total_cost_including_recorded_retries']['simple']['total_tokens'], 15)
        self.assertIsNone(summary['automatic_winner'])
        self.assertFalse(summary['semantic_correctness_measured'])

    def test_nonnumbered_and_over_four_outputs_are_preserved_without_retry(self):
        for raw in ('Find the author, then their birthplace.', '\n'.join(f'{i}. Question?' for i in range(1, 7))):
            with self.subTest(raw=raw), tempfile.TemporaryDirectory() as tmp:
                self.output = Path(tmp) / 'paired'
                self.model = ScriptedModel([raw, CHAIN])
                self.run_comparison()
                phase = self.record()['phases']['simple']
                self.assertEqual(phase['result']['raw_output'], raw)
                self.assertEqual(len(phase['calls']), 1)
                self.assertEqual(phase['status'], 'observed')

    def test_empty_output_is_explicit_and_not_replaced(self):
        self.model = ScriptedModel(['', CHAIN])
        summary = self.run_comparison()
        self.assertEqual(summary['status_counts']['simple'], {'empty_output': 1})
        self.assertEqual(self.record()['phases']['simple']['result']['raw_output'], '')

    def test_first_output_retained_separately_from_operadic_repair(self):
        self.model = ScriptedModel(['1. Question?', '{}', CHAIN])
        summary = self.run_comparison()
        self.assertEqual(summary['first_call_cost']['operadic']['total_tokens'], 15)
        self.assertEqual(summary['total_cost_including_recorded_retries']['operadic']['total_tokens'], 30)
        phase = self.record()['phases']['operadic']
        self.assertEqual(phase['calls'][0]['raw_output'], '{}')
        self.assertEqual(phase['result']['plan'], CHAIN)
        self.assertIn('Invalid tree:\n{}', phase['calls'][1]['messages'][-1]['content'])
        self.assertFalse(self.model.prompts)

    def test_operadic_failure_does_not_hide_simple_output(self):
        self.model = ScriptedModel(['1. Question?', '{}', '{}'])
        summary = self.run_comparison()
        self.assertEqual(summary['status_counts']['operadic'], {'invalid': 1})
        self.assertEqual(self.record()['phases']['simple']['status'], 'observed')
        self.run_comparison()
        self.assertEqual(self.loads, 1)

    def test_method_order_alternates_without_sharing_previous_answer(self):
        samples = copy.deepcopy(SAMPLES) + [dict(SAMPLES[0], question_id='example2', question='Another question?')]
        self.model = ScriptedModel(['1. First?', CHAIN, CHAIN, '1. Second?'])
        self.run_comparison(samples)
        self.assertEqual([m[0]['content'] == compare.SIMPLE_SYSTEM for m in self.model.messages],
                         [True, False, False, True])
        self.assertNotIn('First?', str(self.model.messages[2:]))

    def test_resume_and_report_only_do_not_load_model_or_erase_manual_notes(self):
        self.model = ScriptedModel(['1. Question?', CHAIN])
        self.run_comparison()
        manual = self.output / 'manual_review.csv'
        original = manual.read_bytes()
        manual.write_bytes(original + b'\nREVIEWER_NOTE\n')
        self.run_comparison(report_only=True)
        self.run_comparison()
        self.assertEqual(self.loads, 1)
        self.assertTrue(manual.read_bytes().endswith(b'REVIEWER_NOTE\n'))
        with zipfile.ZipFile(self.output.with_name('paired_results.zip')) as z:
            self.assertEqual(z.read('paired/manual_review.csv'), manual.read_bytes())

    def test_interrupted_operadic_phase_resumes_without_regenerating_simple(self):
        self.model = ScriptedModel(['1. Question?', KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt):
            self.run_comparison()
        self.assertEqual(self.record()['phases']['simple']['status'], 'observed')
        self.model = ScriptedModel([CHAIN])
        summary = self.run_comparison()
        self.assertEqual(len(self.model.messages), 1)
        self.assertEqual(summary['total_cost_including_recorded_retries']['operadic']['llm_calls'], 2)
        self.assertIsNone(self.record()['phases']['operadic']['history'][0]['calls'][0]['raw_output'])

    def test_failed_call_cost_retained_and_retry_is_explicit(self):
        self.model = ScriptedModel([RuntimeError('simulated backend failure')])
        with self.assertRaises(RuntimeError):
            self.run_comparison()
        self.model = ScriptedModel([CHAIN])
        summary = self.run_comparison()
        self.assertEqual(summary['incomplete_phases'], 1)
        self.model = ScriptedModel(['1. Recovered?'])
        summary = self.run_comparison(retry_errors=True)
        self.assertEqual(summary['incomplete_phases'], 0)
        self.assertEqual(summary['total_cost_including_recorded_retries']['simple']['llm_calls'], 2)
        self.assertEqual(summary['first_call_cost']['simple']['llm_calls'], 1)
        self.assertEqual(len(self.record()['phases']['simple']['history']), 2)

    def test_changed_settings_and_runtime_are_blocked(self):
        self.model = ScriptedModel(['1. Question?', KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt):
            self.run_comparison()
        with self.assertRaises(ValueError):
            self.run_comparison(plan_tokens=2048)
        with patch.object(compare, 'SIMPLE_SYSTEM', 'Changed prompt'), self.assertRaises(ValueError):
            self.run_comparison()
        with self.assertRaisesRegex(ValueError, 'identity differs'):
            compare.run_comparison(SAMPLES, self.output,
                                   model_factory=lambda settings: (self.model, {'backend': 'different'}))

    def test_report_only_requires_existing_run(self):
        with self.assertRaisesRegex(ValueError, 'No existing'):
            self.run_comparison(report_only=True)
        self.assertEqual(self.loads, 0)

    def test_raw_markdown_and_unicode_survive_reports_and_archive(self):
        raw = '1. سؤال؟\n```\nuntouched\n```'
        self.model = ScriptedModel([raw, CHAIN])
        self.run_comparison()
        with (self.output / 'comparison.csv').open(encoding='utf-8-sig', newline='') as f:
            row = next(csv.DictReader(f))
        self.assertEqual(row['simple_first_raw'], raw)
        self.assertIn(raw, (self.output / 'review.md').read_text())
        with zipfile.ZipFile(self.output.with_name('paired_results.zip')) as z:
            self.assertIsNone(z.testzip())
            saved = json.loads(z.read('paired/comparison.csv.state/questions/example1.json'))
            self.assertEqual(saved, self.record())

    def test_all_40_recorded_operadic_outputs_and_simple_calls_are_paired(self):
        samples, baselines = compare.pilot.load_cohort(compare.ROOT / 'evaluation/samples.json')
        replies = []
        for index, row in enumerate(baselines['runs']['v3.2.4']['questions'], 1):
            operadic = [t['raw_output'] for t in row['trace']]
            replies.extend(['1. Subquestion?'] + operadic if index % 2 else operadic + ['1. Subquestion?'])
        self.model = ScriptedModel(replies)
        summary = self.run_comparison(samples)
        self.assertEqual(summary['requested'], 40)
        self.assertEqual(summary['status_counts']['simple'], {'observed': 40})
        self.assertEqual(summary['status_counts']['operadic'], {'valid': 35, 'invalid': 5})
        self.assertEqual(summary['total_cost_including_recorded_retries']['simple']['llm_calls'], 40)
        self.assertEqual(summary['total_cost_including_recorded_retries']['operadic']['llm_calls'], 49)
        self.assertEqual(summary['first_call_cost']['operadic']['llm_calls'], 40)
        with (self.output / 'comparison.csv').open(encoding='utf-8-sig', newline='') as handle:
            self.assertEqual(len(list(csv.DictReader(handle))), 40)
        self.assertFalse(self.model.plans)
        self.assertFalse(self.model.prompts)


if __name__ == '__main__':
    unittest.main()
