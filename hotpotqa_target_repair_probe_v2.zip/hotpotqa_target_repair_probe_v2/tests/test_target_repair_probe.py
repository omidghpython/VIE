"""Single-call probe safeguards; no live Qwen accuracy claims."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import target_repair_probe as probe
from hotpotqa_operadic_rag.checkpoint import atomic_json
from hotpotqa_operadic_rag.decomposition import plan_instructions
from test_decomposition_pilot import ScriptedModel


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.output = Path(self.tmp.name) / 'probe'
        self.fixture = probe.load_fixture()
        self.loads = 0

    def factory(self, settings):
        self.loads += 1
        return self.model, {'backend': 'scripted'}

    def run_probe(self, **kwargs):
        return probe.run_probe(self.output, model_factory=self.factory, **kwargs)

    def record(self):
        return self.output / 'probe.csv.state/questions' / (self.fixture['question_id'] + '.json')

    def test_messages_use_exact_first_output_and_original_system_without_second_output_or_gold(self):
        fixture = copy.deepcopy(self.fixture)
        fixture['gold_answer'] = 'GOLD_SENTINEL'
        fixture['context'] = 'CONTEXT_SENTINEL'
        fixture['previous_repair_raw_output'] = 'OLD_REPAIR_SENTINEL'
        messages = probe.repair_messages(fixture)
        self.assertEqual(messages[0]['content'], plan_instructions(fixture['question']))
        self.assertIn(fixture['first_raw_output'], messages[1]['content'])
        self.assertTrue(messages[1]['content'].startswith(fixture['question']+'\n'))
        self.assertNotIn('SENTINEL', json.dumps(messages))

    def test_valid_target_does_not_claim_semantic_success_or_trigger_judge(self):
        # Deliberately incomplete semantics: structure/target checks must not
        # turn this copied question into certified correct decomposition.
        plan = {'nodes': [{'id': 'q1', 'question': self.fixture['question'],
                          'dependencies': {}, 'answer_type': 'organization'}], 'final': 'q1'}
        self.model = ScriptedModel([plan])
        summary = self.run_probe()
        self.assertEqual(summary['structure_status'], 'valid')
        self.assertEqual(summary['target_status'], 'compatible')
        self.assertEqual(summary['semantic_correctness'], 'not_established')
        self.assertEqual(summary['qualifier_preservation'], 'manual_review_required')
        self.assertEqual(summary['current_cost']['llm_calls'], 1)
        self.assertEqual(summary['current_cost']['total_tokens'], 15)
        self.assertTrue(summary['current_cost_complete'])
        self.assertEqual(self.model.prompts, [])
        self.assertEqual(self.run_probe(), summary)
        self.assertEqual(self.run_probe(report_only=True), summary)
        self.assertEqual(self.loads, 1)
        with zipfile.ZipFile(self.output.with_name('probe_results.zip')) as z:
            self.assertIsNone(z.testzip())
            self.assertIn('probe/messages.json', z.namelist())
            self.assertEqual(json.loads(z.read('probe/summary.json')), summary)

    def test_original_target_failure_is_preserved_without_another_attempt(self):
        self.model = ScriptedModel([self.fixture['first_raw_output']])
        summary = self.run_probe()
        self.assertEqual(summary['structure_status'], 'valid')
        self.assertEqual(summary['target_status'], 'mismatch')
        self.assertEqual(self.run_probe(), summary)
        self.assertEqual(len(self.model.messages), 1)

    def test_historical_bad_repair_stays_invalid_with_exact_error_and_raw_output(self):
        raw = self.fixture['previous_repair_raw_output']
        self.model = ScriptedModel([raw])
        summary = self.run_probe()
        result = json.loads(self.record().read_text())['phases']['repair']['result']
        self.assertEqual(summary['structure_status'], 'invalid')
        self.assertEqual(result['structure_error'], self.fixture['previous_repair_error'])
        self.assertEqual(result['raw_output'], raw)
        self.assertEqual(summary['target_status'], 'not_checked')
        self.assertEqual(self.run_probe(), summary)
        self.assertEqual(len(self.model.messages), 1)

    def test_backend_failure_records_cost_and_is_not_automatically_retried(self):
        self.model = ScriptedModel([RuntimeError('synthetic backend failure')])
        with self.assertRaisesRegex(RuntimeError, 'synthetic'):
            self.run_probe()
        summary = self.run_probe()
        self.assertEqual(summary['phase_status'], 'error')
        self.assertEqual(summary['current_cost']['llm_calls'], 1)
        self.assertEqual(self.loads, 1)
        self.assertTrue((self.output / 'review.md').exists())

    def test_abrupt_inference_exit_marker_does_not_allow_silent_second_call(self):
        self.model = ScriptedModel([self.fixture['first_raw_output']])
        self.run_probe()
        record = json.loads(self.record().read_text())
        record['phases']['repair'] = {'status': 'started', 'error': 'Cost may be incomplete.', 'result': {}, 'history': []}
        atomic_json(self.record(), record)
        summary = self.run_probe()
        self.assertEqual(summary['phase_status'], 'started')
        self.assertFalse(summary['current_cost_complete'])
        self.assertEqual(self.loads, 1)

    def test_changed_repair_message_cannot_resume_old_checkpoint(self):
        self.model = ScriptedModel([self.fixture['first_raw_output']])
        self.run_probe()
        with patch.object(probe, 'REPAIR_INSTRUCTION', 'changed'):
            with self.assertRaisesRegex(ValueError, 'settings/code differ'):
                self.run_probe()
        self.assertEqual(self.loads, 1)

    def test_tampered_fixture_fails_before_any_model_load(self):
        with patch.object(probe, 'FIXTURE_SHA256', 'wrong'):
            with self.assertRaisesRegex(ValueError, 'pinned'):
                self.run_probe()
        self.assertEqual(self.loads, 0)

    def test_report_only_without_run_does_not_load_model(self):
        with self.assertRaisesRegex(ValueError, 'No existing probe'):
            self.run_probe(report_only=True)
        self.assertEqual(self.loads, 0)


if __name__ == '__main__':
    unittest.main()
