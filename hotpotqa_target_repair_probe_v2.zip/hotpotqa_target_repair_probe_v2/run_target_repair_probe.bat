@echo off
setlocal
cd /d "%~dp0"
set "PILOT_PYTHON=%~dp0.venv\Scripts\python.exe"
if defined CONDA_PREFIX set "PILOT_PYTHON=%CONDA_PREFIX%\python.exe"
if defined VIRTUAL_ENV set "PILOT_PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PILOT_PYTHON=%HOTPOT_PYTHON%"
if not exist "%PILOT_PYTHON%" (
  echo ERROR: Activate the Python environment used for v3.2 or set HOTPOT_PYTHON to its python.exe.
  echo See README_WINDOWS_FA.txt. No new environment or model download is needed.
  pause
  exit /b 1
)
set "HF_HUB_OFFLINE=1"
set "TRANSFORMERS_OFFLINE=1"
"%PILOT_PYTHON%" target_repair_probe.py %*
set "PILOT_EXIT=%ERRORLEVEL%"
echo.
if "%PILOT_EXIT%"=="0" (
  echo One saved-tree repair completed. Read review.md; semantic correctness needs inspection.
  echo Send results\target_repair_probe_v2_results.zip for review.
) else (
  echo Probe incomplete. Read the error above. Saved output is preserved.
  echo A saved invocation is not automatically retried. --report-only rebuilds the report.
)
pause
exit /b %PILOT_EXIT%
