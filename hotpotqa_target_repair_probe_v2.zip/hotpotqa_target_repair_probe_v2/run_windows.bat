@echo off
call "%~dp0run_target_repair_probe.bat" %*
exit /b %ERRORLEVEL%
