"""Advisory diagnostics only: never called by generation, validation or judging.

no_violation_found means only that supported patterns passed these narrow checks.
unknown is an abstention, and suspicious is not a semantic verdict or a rejection.
"""
import re
from collections import Counter
from .contracts import validate_plan


def norm(text):
    return ' '.join(re.findall(r"[a-z0-9]+", text.casefold()))


def finding(code, nodes, reason, **evidence):
    return dict(code=code, nodes=nodes, reason=reason, evidence=evidence)


def analyze(question, plan):
    try:
        clean = validate_plan(plan)
    except (ValueError, TypeError, KeyError) as exc:
        return dict(status='unknown', supported_checks=[], findings=[], reason='No structurally valid plan: ' + str(exc))
    supported, findings = inspect(question, clean)
    if len(clean['nodes']) == 1:
        return dict(status='unknown', supported_checks=[], findings=[], reason='Single-node plan: human review of decomposition need required; no minimum-node rule is imposed.')
    return dict(status='suspicious' if findings else ('no_violation_found' if supported else 'unknown'),
                supported_checks=supported, findings=findings,
                reason='Advisory pattern checks only; no assertion of complete semantic correctness.')


def build_report(store):
    rows = []
    for order, sample in enumerate(store.samples, 1):
        result = store.read(sample['question_id'])['phases'].get('structure', {}).get('result', {})
        rows.append(dict(order=order, question_id=sample['question_id'], question=sample['question'],
                         diagnostic=analyze(sample['question'], result.get('plan'))))
    report = dict(experiment=EXPERIMENT, role='advisory_only', calls=0,
                  status_counts=dict(Counter(row['diagnostic']['status'] for row in rows)), questions=rows,
                  limitation='No automatic rejection, repair, gold answers, or model calls. Unknown patterns abstain.')
    lines = ['# Advisory diagnostics', '', report['limitation'], '',
             'no_violation_found covers supported checks only; it is not semantic validity.', '']
    for row in rows:
        lines += [f"## {row['order']}. {row['question_id']}: {row['diagnostic']['status']}", '', row['question'], '']
        lines += [f"- {item['code']} ({', '.join(item['nodes'])}): {item['reason']} Evidence: {item['evidence']}"
                  for item in row['diagnostic']['findings']]
        if not row['diagnostic']['findings']:
            lines += [row['diagnostic']['reason']]
        lines += ['']
    return report, '\n'.join(lines)


EXPERIMENT = 'max4_05_decomposition_diagnostics_v1'


def inspect(question, plan):
    nodes = plan['nodes']
    if len(nodes) == 1:
        # A single node can be atomic or undecomposed. Neither conclusion follows from its count.
        return [], []
    supported, findings = [], []
    by_id = {n['id']: n for n in nodes}
    for node in nodes:
        if not node['dependencies']:
            continue
        bare = re.sub(r'\{\{q\d+\}\}', '', node['question'])
        # Ignore empty parenthetical slot lists, not meaningful parenthesized qualifiers.
        bare = re.sub(r'\(\s*(?:(?:and|or)\s*)*\)', '', bare, flags=re.I)
        if norm(bare) == norm(question) or any(norm(bare) == norm(by_id[d]['question']) for d in node['dependencies']):
            supported.append('literal_repetition:' + node['id'])
            findings.append(finding('question_repeated_after_slot_removal', [node['id']],
                'Removing the input slots leaves the original/child question unchanged; actual use of the intermediate value is unproven.'))
        for dep in node['dependencies']:
            slot = re.escape('{{' + dep + '}}')
            identity = re.fullmatch(r'(?:who is|what is the name of)\s+' + slot + r'\s*\?', node['question'], re.I)
            if identity and by_id[dep]['answer_type'] == 'person':
                supported.append('identity_only:' + node['id'])
                findings.append(finding('possible_identity_only_hop', [dep, node['id']],
                    'This step appears to request the identity already returned upstream; entity resolution could still justify it.'))
        # Narrow supported example of using an identity in a new relation, not just an appended reference.
        if re.fullmatch(r'(?:Where|When) was \{\{q\d+\}\} (?:born|founded)\s*\?', node['question'], re.I):
            supported.append('explicit_relation_use:' + node['id'])
    return supported, findings
