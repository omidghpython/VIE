import copy
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from hotpotqa_operadic_rag.experiment_diagnostics import analyze, EXPERIMENT
import decomposition_pilot as pilot
from hotpotqa_operadic_rag.checkpoint import RunStore


def node(nid, question, kind='other', deps=None):
    return dict(id=nid, question=question, answer_type=kind, dependencies=deps or {})


def plan(*nodes):
    return dict(nodes=list(nodes), final=nodes[-1]['id'])


class DiagnosticsTests(unittest.TestCase):
    def check(self, question, tree, status, code=None):
        old = copy.deepcopy(tree)
        result = analyze(question, tree)
        self.assertEqual(result['status'], status, result)
        if code:
            self.assertIn(code, [f['code'] for f in result['findings']])
        self.assertEqual(tree, old)
        return result

    def test_invalid_and_missing_plan_abstain(self):
        self.check('Which river?', None, 'unknown')
        self.check('Who?', {'nodes': [], 'final': 'q1'}, 'unknown')

    def test_unknown_wording_abstains(self):
        self.check('Explain the phenomenon.', plan(node('q1', 'Explain the phenomenon.')), 'unknown')

    def test_reports_are_in_archive_and_no_model_load(self):
        samples = [dict(question_id='synthetic', question='Who wrote Alpha?', type='bridge')]
        with tempfile.TemporaryDirectory() as tmp:
            store = RunStore(Path(tmp)/'run/trees.csv', dict(backend='injected_test', n_samples=1), lambda: samples)
            summary = pilot.export_reports(store, {})
            self.assertEqual(summary['total_cost']['llm_calls'], 0)
            with zipfile.ZipFile(Path(tmp)/'run_results.zip') as z:
                self.assertIn('run/diagnostics.json', z.namelist())
                self.assertIn('run/diagnostics.md', z.namelist())
                report = json.loads(z.read('run/diagnostics.json'))
                self.assertEqual(report['status_counts'], {'unknown': 1})
                self.assertEqual(report['role'], 'advisory_only')

    def test_single_node_not_rejected_or_certified(self):
        for question in ['Who is Ada?', 'Where was the author of Lantern born?']:
            with self.subTest(question=question):
                result = self.check(question, plan(node('q1', question)), 'unknown')
                self.assertIn('no minimum-node', result['reason'])

    def test_appended_slot_full_question_repeat(self):
        q = 'Where was the author of Lantern born?'
        self.check(q, plan(node('q1', 'Who wrote Lantern?', 'person'),
                           node('q2', q + ' ({{q1}})', 'place', {'q1':'person'})),
                   'suspicious', 'question_repeated_after_slot_removal')

    def test_two_appended_slots_repeat(self):
        q = 'Are Alex and Blair American?'
        self.check(q, plan(node('q1', 'Is Alex American?', 'boolean'), node('q2', 'Is Blair American?', 'boolean'),
                    node('q3', q + ' ({{q1}} and {{q2}})', 'boolean', {'q1':'boolean','q2':'boolean'})),
                   'suspicious', 'question_repeated_after_slot_removal')

    def test_actual_intermediate_use_supported(self):
        self.check('Where was the author of Lantern born?', plan(node('q1', 'Who wrote Lantern?', 'person'),
                   node('q2', 'Where was {{q1}} born?', 'place', {'q1':'person'})), 'no_violation_found')

    def test_identity_only_hop(self):
        self.check('Who wrote Lantern?', plan(node('q1', 'Who wrote Lantern?', 'person'),
                   node('q2', 'Who is {{q1}}?', 'person', {'q1':'person'})), 'suspicious', 'possible_identity_only_hop')

    def test_name_of_place_not_person_identity_rule(self):
        self.check('What place?', plan(node('q1', 'Where is Lantern?', 'place'),
                   node('q2', 'What is the name of {{q1}}?', 'place', {'q1':'place'})), 'unknown')

    def test_unknown_operation_not_certified(self):
        self.check('What follows?', plan(node('q1', 'What happened?', 'other'),
                   node('q2', 'What follows from {{q1}}?', 'other', {'q1':'other'})), 'unknown')

