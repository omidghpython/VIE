@echo off
setlocal
cd /d "%~dp0"
set "PILOT_PYTHON=%~dp0.venv\Scripts\python.exe"
if defined CONDA_PREFIX set "PILOT_PYTHON=%CONDA_PREFIX%\python.exe"
if defined VIRTUAL_ENV set "PILOT_PYTHON=%VIRTUAL_ENV%\Scripts\python.exe"
if defined HOTPOT_PYTHON set "PILOT_PYTHON=%HOTPOT_PYTHON%"
if not exist "%PILOT_PYTHON%" (
  echo ERROR: Activate the Python environment used for v3.2.4 or set HOTPOT_PYTHON to its python.exe.
  echo See README_WINDOWS_FA.txt. No new environment or model download is needed.
  pause
  exit /b 1
)
set "HF_HUB_OFFLINE=1"
set "TRANSFORMERS_OFFLINE=1"
echo Reviewing saved v3.2.4 trees only. No new tree generation or semantic repair.
"%PILOT_PYTHON%" review_pilot.py %*
set "PILOT_EXIT=%ERRORLEVEL%"
echo.
if "%PILOT_EXIT%"=="0" (
  echo Reviewer experiment complete. Judge quality still requires comparison of the saved reasons.
  echo Send results\review_pilot_v3_2_5_results.zip for analysis.
) else (
  echo Experiment incomplete. Read the error above. Saved phases are preserved.
  echo Rerun to resume an interruption. Use --retry-errors only after fixing a saved backend error.
)
pause
exit /b %PILOT_EXIT%
