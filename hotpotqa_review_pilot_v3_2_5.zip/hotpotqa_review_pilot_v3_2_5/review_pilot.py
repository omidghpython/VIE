"""Review the saved v3.2.4 trees once, without generating or repairing trees."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import zipfile

from decomposition_pilot import (
    ROOT, COST_KEYS, create_model, direct_reference, load_cohort, markdown_code_block,
    review_result, run_phase, should_run, structure_trace_markdown,
)
from hotpotqa_operadic_rag.checkpoint import RunStore, atomic_json, digest
from hotpotqa_operadic_rag.config import MODEL_NAME, MODEL_REVISION, MAX_PLAN_NODES
from hotpotqa_operadic_rag.contracts import validate_plan, expand_typed_plan
from hotpotqa_operadic_rag.cost_comparison import pilot_token_report
from hotpotqa_operadic_rag.decomposition import PLAN_SYSTEM, REVIEW_SYSTEM, semantic_precheck
from hotpotqa_operadic_rag.utils import configure_logging

SOURCE = ROOT / 'evaluation' / 'review_source_v3_2_4'


def code_digest():
    paths = [Path(__file__).resolve(), ROOT / 'decomposition_pilot.py',
             *sorted((ROOT / 'hotpotqa_operadic_rag').rglob('*.py'))]
    return digest({p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})


def load_source(directory):
    """Read-only snapshot: pair questions, plans and all historical costs by ID."""
    directory = Path(directory).expanduser().resolve()
    samples, _ = load_cohort(directory / 'samples.json')
    manifest = json.loads((directory / 'manifest.json').read_text(encoding='utf-8'))
    ids = [s['question_id'] for s in samples]
    if (manifest['question_ids'] != ids or manifest['samples_sha256'] != digest(samples)
            or manifest['settings']['n_samples'] != len(ids)):
        raise ValueError('Source manifest/question identity differs.')
    settings = manifest['settings']
    if (settings['model'] != MODEL_NAME or settings['model_revision'] != MODEL_REVISION
            or settings['plan_prompt_sha256'] != hashlib.sha256(PLAN_SYSTEM.encode()).hexdigest()):
        raise ValueError('Source must use the unchanged v3.2.4 generator and pinned Qwen.')
    paths = [directory / 'manifest.json', directory / 'samples.json']
    paths += [directory / 'questions' / (qid + '.json') for qid in ids]
    records = {}
    for qid, path in zip(ids, paths[2:]):
        record = json.loads(path.read_text(encoding='utf-8'))
        if record['question_id'] != qid:
            raise ValueError('Source record ID mismatch.')
        structure = record['phases']['structure']
        if structure['status'] not in ('valid', 'invalid'):
            raise ValueError('Source generation must be finished; no trees will be regenerated.')
        if structure['status'] == 'valid':
            validate_plan(structure['result']['plan'], max_nodes=MAX_PLAN_NODES)
            if record['phases'].get('review', {}).get('status') != 'observed':
                raise ValueError('A finished source review is required for a paired comparison.')
        for phase in record['phases'].values():
            phase_cost(phase)  # Validate cumulative counters before using them.
        records[qid] = record
    files = {p.relative_to(directory).as_posix(): p.read_bytes() for p in paths}
    checksum = digest({name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()})
    return {'directory': directory, 'samples': samples, 'manifest': manifest,
            'records': records, 'files': files, 'sha256': checksum}


def add_cost(*costs):
    return {key: sum(cost.get(key, 0) for cost in costs) for key in COST_KEYS}


def phase_cost(phase):
    if not phase:
        return add_cost()
    events = phase.get('history') or [{'telemetry': phase['telemetry']}]
    for event in events:
        values = event['telemetry']
        for key in ('llm_calls', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'retrieval_steps'):
            if type(values[key]) is not int or values[key] < 0:
                raise ValueError('Invalid source/checkpoint cost counter: ' + key)
        if values['total_tokens'] != values['prompt_tokens'] + values['completion_tokens']:
            raise ValueError('Token total differs from input + output.')
    return add_cost(*(event['telemetry'] for event in events))


def read_audit():
    return json.loads((ROOT / 'evaluation' / 'review_audit_v3_2_4.json').read_text(encoding='utf-8'))


def verdict(phase):
    return phase.get('result', {}).get('verdict', {'status': 'not_reviewed', 'errors': []})


def audit_report(source, store, audit):
    """Analyst checks on a selected development subset, never model input or gold accuracy."""
    rows = []
    for case in audit['cases']:
        qid = case['question_id']
        if qid not in source['records']:
            continue
        old = source['records'][qid]['phases']
        plan = old['structure']['result'].get('plan')
        if digest(plan) != case['plan_sha256']:
            raise ValueError('Audit annotation refers to a different saved tree.')
        new = store.read(qid)['phases'].get('review', {})
        rows.append({**case, 'old_status': verdict(old.get('review', {}))['status'],
                     'new_status': verdict(new)['status'], 'new_errors': verdict(new)['errors']})
    counts = {}
    for version in ('old', 'new'):
        counts[version] = {expected: dict(Counter(row[version + '_status'] for row in rows
                                                if row['expected_status'] == expected))
                           for expected in ('valid', 'revise')}
    return {'scope': audit['scope'], 'decision_counts': counts, 'cases': rows,
            'reason_correctness': 'Read each reason against the recorded defect; not scored by string matching.',
            'independent_accuracy_estimate': False}


def export_reports(store, source, audit):
    old_generation, old_review, new_review = add_cost(), add_cost(), add_cost()
    rows, details_md = [], []
    new_status, response_status, sources, transitions = Counter(), Counter(), Counter(), Counter()
    incomplete, eligible, source_invalid = 0, 0, 0
    for index, sample in enumerate(store.samples, 1):
        qid = sample['question_id']
        prior = source['records'][qid]['phases']
        structure = prior['structure']
        old = prior.get('review', {})
        new = store.read(qid)['phases'].get('review', {})
        generation_cost, old_cost, new_cost = phase_cost(structure), phase_cost(old), phase_cost(new)
        old_generation = add_cost(old_generation, generation_cost)
        old_review = add_cost(old_review, old_cost)
        new_review = add_cost(new_review, new_cost)
        plan = structure['result'].get('plan')
        valid_tree = structure['status'] == 'valid'
        if valid_tree:
            eligible += 1
            incomplete += new.get('status') != 'observed'
        else:
            source_invalid += 1
        result = new.get('result', {})
        detail = result.get('details', {})
        status = verdict(new)['status'] if valid_tree else 'source_structure_invalid'
        new_status[status] += 1
        transitions[verdict(old)['status'] + ' -> ' + status] += 1
        if new:
            response_status[detail.get('response_status', new['status'])] += 1
            sources[detail.get('source', 'backend_error')] += 1
        row = {'index': index, 'question_id': qid, 'question': sample['question'], 'type': sample['type'],
               'source_structure_status': structure['status'], 'plan_sha256': digest(plan) if plan else '',
               'old_status': verdict(old)['status'], 'new_status': status,
               'new_model_status': detail.get('model_status'), 'new_source': detail.get('source'),
               'response_status': detail.get('response_status'),
               'old_errors': json.dumps(verdict(old)['errors'], ensure_ascii=False),
               'new_errors': json.dumps(verdict(new)['errors'], ensure_ascii=False),
               'old_raw_review': old.get('result', {}).get('raw_output'),
               'new_raw_review': result.get('raw_output'), 'phase_error': new.get('error', ''),
               'historical_generation_tokens': generation_cost['total_tokens'],
               'old_review_tokens': old_cost['total_tokens'], 'new_review_tokens': new_cost['total_tokens'],
               'new_input_tokens': new_cost['prompt_tokens'], 'new_output_tokens': new_cost['completion_tokens'],
               'new_review_calls': new_cost['llm_calls']}
        rows.append(row)
        details_md += [f'## {index}. {qid}', '', sample['question'], '',
                       f"Source structure: {structure['status']}; old: {row['old_status']}; new: {status}.",
                       f"New model status: {detail.get('model_status')}; source: {detail.get('source')}; "
                       f"response status: {detail.get('response_status')}.", '', 'Saved tree (unchanged):',
                       markdown_code_block(json.dumps(plan, ensure_ascii=False, indent=2), 'json'), '']
        if plan:
            details_md += ['Composed tree:', markdown_code_block(expand_typed_plan(plan)), '']
        for label, phase in [('Old', old), ('New', new)]:
            details_md += [label + ' effective verdict:', markdown_code_block(
                json.dumps(verdict(phase), ensure_ascii=False), 'json'), '', label + ' raw output:',
                markdown_code_block(phase.get('result', {}).get('raw_output') or '(no model output)'), '']
        if new.get('error'):
            details_md += ['Backend/phase error:', markdown_code_block(new['error']), '']
        details_md += structure_trace_markdown(structure['result'].get('decomposition_trace', []))
    estimate = add_cost(old_generation, new_review)
    experiment = add_cost(old_generation, old_review, new_review)
    runtime = store.manifest.get('runtime_identity')
    runtime_same = runtime == source['manifest'].get('runtime_identity') if runtime else None
    comparison = pilot_token_report(store.samples, store.manifest['settings'], estimate['total_tokens'],
                                    direct_reference(), incomplete)
    comparison['scope'] = 'Historical generation plus new review only; not a new full decomposed RAG run.'
    summary = {'mode': 'review_saved_trees_only', 'source_sha256': source['sha256'],
               'source_version': 'v3.2.4', 'requested': len(rows), 'eligible_saved_trees': eligible,
               'source_structurally_invalid': source_invalid, 'incomplete_questions': incomplete,
               'new_status': dict(new_status), 'response_status': dict(response_status),
               'review_source': dict(sources), 'old_to_new_status': dict(transitions),
               'new_experiment_cost': new_review, 'historical_generation_cost': old_generation,
               'historical_review_cost': old_review,
               'generation_plus_replacement_review_estimate': estimate,
               'all_experiments_including_old_review_cost': experiment,
               'review_tokens_difference_if_complete': new_review['total_tokens'] - old_review['total_tokens']
                   if not incomplete else None,
               'cost_note': 'All failed/interrupted/retried calls included. Cached generation is historical cost, '
                            'not free production planning. Replacement estimate excludes superseded old review; '
                            'all-experiment total includes it. Compare review costs only when all 35 eligible '
                            'trees are processed. The 5 invalid source trees remain in the cohort and cost.',
               'runtime_matches_source': runtime_same, 'runtime_identity': runtime,
               'inference_backend': store.manifest['settings']['backend'],
               'new_tree_generation_calls': 0, 'semantic_repair_calls': 0,
               'whole_method_token_condition': comparison,
               'semantic_correctness_measured': False, 'answer_accuracy_measured': False,
               'selected_development_audit': audit_report(source, store, audit)}
    if runtime_same is False:
        summary['runtime_note'] = 'Runtime differs from source; results are not a controlled same-runtime comparison.'
    atomic_json(store.output.parent / 'summary.json', summary)
    with store.output.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    intro = ['# Saved-tree reviewer comparison v3.2.5', '',
             'Old trees and old verdicts are preserved. Only Question and the expanded tree reach the new judge.',
             'Status changes are not proof of correctness; a specific reason may still be wrong.',
             'Audit annotations describe a selected development subset, not independent test accuracy.', '',
             markdown_code_block(json.dumps(summary, ensure_ascii=False, indent=2), 'json'), '']
    (store.output.parent / 'review.md').write_text('\n'.join(intro + details_md), encoding='utf-8')
    output = store.output.parent
    archive = output.with_name(output.name + '_results.zip')
    temporary = archive.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
        for path in [store.output, output / 'summary.json', output / 'review.md',
                     *sorted(store.directory.rglob('*.json'))]:
            zipped.write(path, output.name + '/' + path.relative_to(output).as_posix())
        for name, raw in source['files'].items():
            zipped.writestr(output.name + '/source_v3_2_4/' + name, raw)
    temporary.replace(archive)
    return summary


def run_review_pilot(source, output_dir, *, retry_errors=False, report_only=False, model_factory=None):
    output = Path(output_dir).expanduser().resolve()
    original = source['directory']
    if output == original or original in output.parents or output in original.parents:
        raise ValueError('Choose a separate output directory; the source snapshot must remain unchanged.')
    audit = read_audit()
    settings = {key: source['manifest']['settings'][key] for key in (
        'model', 'model_revision', 'seed', 'use_4bit', 'require_cuda', 'max_input_tokens',
        'intermediate_tokens', 'plan_tokens', 'max_nodes', 'plan_attempts')}
    settings.update(schema_version=1, mode='review_saved_trees_only', n_samples=len(source['samples']),
                    code_sha256=code_digest(), source_sha256=source['sha256'],
                    review_prompt_sha256=hashlib.sha256(REVIEW_SYSTEM.encode()).hexdigest(),
                    audit_sha256=digest(audit), direct_reference_sha256=digest(direct_reference()),
                    backend='injected_test' if model_factory else 'LocalQwen', semantic_repair_attempts=0)
    if report_only and not (output / 'reviews.csv.state' / 'manifest.json').exists():
        raise ValueError('No existing reviewer run to report.')
    store = RunStore(output / 'reviews.csv', settings, lambda: source['samples'])
    def pending(sample):
        return source['records'][sample['question_id']]['phases']['structure']['status'] == 'valid' and should_run(
            store.read(sample['question_id'])['phases'].get('review', {}), retry_errors)
    summary = export_reports(store, source, audit)
    if report_only or not any(pending(sample) for sample in store.samples):
        return summary
    # Lazy loading; deterministic prechecks consume no model call.
    llm = None
    try:
        for index, sample in enumerate(store.samples, 1):
            if not pending(sample):
                continue
            qid = sample['question_id']
            record = store.read(qid)
            plan = source['records'][qid]['phases']['structure']['result']['plan']
            print(f'[{index}/{len(store.samples)}] Review saved tree: {qid}', flush=True)
            if llm is None and not semantic_precheck(sample['question'], plan)['errors']:
                llm, identity = (model_factory or create_model)(settings)
                store.bind_runtime(identity)
            # review_result sets last_raw_output; code-only checks need a harmless holder.
            judge = llm if llm is not None else type('NoModel', (), {})()
            record['source_plan_sha256'] = digest(plan)
            run_phase(store, record, 'review', lambda: review_result(judge, sample['question'], plan))
            export_reports(store, source, audit)
    finally:
        summary = export_reports(store, source, audit)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-state', default=str(SOURCE))
    parser.add_argument('--output-dir', default=str(ROOT / 'results' / 'review_pilot_v3_2_5'))
    parser.add_argument('--retry-errors', action='store_true', help='Retry saved backend errors after fixing them.')
    parser.add_argument('--report-only', action='store_true', help='Rebuild reports without loading Qwen.')
    args = parser.parse_args()
    configure_logging()
    try:
        source = load_source(args.source_state)
        summary = run_review_pilot(source, args.output_dir, retry_errors=args.retry_errors,
                                   report_only=args.report_only)
    except KeyboardInterrupt:
        print('Interrupted. Results are saved; run the same command to resume missing reviews.')
        return 130
    except Exception as exc:
        print(f'Review pilot blocked: {type(exc).__name__}: {exc}')
        return 2
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    output = Path(args.output_dir).expanduser().resolve()
    print('Results ZIP:', output.with_name(output.name + '_results.zip'))
    return 0 if summary['incomplete_questions'] == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
