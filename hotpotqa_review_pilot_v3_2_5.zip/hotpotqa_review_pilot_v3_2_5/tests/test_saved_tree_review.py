"""Offline replay/resume/cost tests. Scripted verdicts do not predict Qwen behavior."""
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import review_pilot as pilot
from hotpotqa_operadic_rag.checkpoint import digest
from hotpotqa_operadic_rag.contracts import expand_typed_plan
from hotpotqa_operadic_rag.decomposition import review_plan, semantic_precheck, vague_review
from hotpotqa_operadic_rag.telemetry import TelemetryTracker, activate_tracker
from test_decomposition_pilot import CHAIN, SAMPLES, ScriptedModel


class SavedTreeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = pilot.load_source(pilot.SOURCE)

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.output = Path(self.temporary.name) / 'review'
        self.loads = 0
        self.model = ScriptedModel(verdicts=self.recorded_reviews())

    def recorded_reviews(self):
        return [r['phases']['review']['result']['raw_output'] for r in self.source['records'].values()
                if r['phases'].get('review', {}).get('result', {}).get('details', {}).get('source') == 'model']

    def factory(self, settings):
        self.loads += 1
        return self.model, {'backend': 'scripted-test'}

    def run_pilot(self, source=None, **options):
        with redirect_stdout(io.StringIO()), patch('decomposition_pilot.generate_plan',
                    side_effect=AssertionError('Tree generation forbidden')), patch(
                    'hotpotqa_operadic_rag.decomposition.generate_plan',
                    side_effect=AssertionError('Tree generation forbidden')):
            return pilot.run_review_pilot(source or self.source, self.output,
                                          model_factory=self.factory, **options)

    def test_replay_unchanged_40_trees_with_only_32_model_reviews(self):
        before = {name: hashlib.sha256((pilot.SOURCE / name).read_bytes()).hexdigest()
                  for name in self.source['files']}
        summary = self.run_pilot()
        self.assertEqual(summary['eligible_saved_trees'], 35)
        self.assertEqual(summary['source_structurally_invalid'], 5)
        self.assertEqual(summary['new_experiment_cost']['llm_calls'], 32)
        self.assertEqual(summary['new_experiment_cost']['retrieval_steps'], 0)
        self.assertEqual(summary['review_source'], {'model': 32, 'root_rule': 3})
        self.assertEqual(summary['new_status'], {'uncertain': 16, 'source_structure_invalid': 5,
                                                'valid': 11, 'revise': 8})
        self.assertEqual(summary['response_status']['vague_reason'], 16)
        self.assertEqual(summary['new_tree_generation_calls'], 0)
        self.assertEqual(summary['semantic_repair_calls'], 0)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.assertEqual(self.model.messages, [])
        self.assertFalse(self.model.verdicts)
        expected = []
        for sample in self.source['samples']:
            structure = self.source['records'][sample['question_id']]['phases']['structure']
            if structure['status'] == 'valid':
                plan = structure['result']['plan']
                if not semantic_precheck(sample['question'], plan)['errors']:
                    expected.append((sample['question'], plan))
        for prompt, (question, plan) in zip(self.model.prompts, expected):
            self.assertTrue(prompt.endswith('\nOriginal question:\n' + question +
                '\nFinal node ID: ' + plan['final'] + '\nExpanded typed tree:\n' + expand_typed_plan(plan)))
        self.assertEqual(before, {name: hashlib.sha256((pilot.SOURCE / name).read_bytes()).hexdigest()
                                  for name in before})
        for record_path in (self.output / 'reviews.csv.state/questions').glob('*.json'):
            record = json.loads(record_path.read_text())
            self.assertEqual(set(record['phases']), {'review'})
            old_plan = self.source['records'][record['question_id']]['phases']['structure']['result']['plan']
            self.assertEqual(record['source_plan_sha256'], digest(old_plan))
        with zipfile.ZipFile(self.output.with_name('review_results.zip')) as archive:
            for name, raw in self.source['files'].items():
                self.assertEqual(archive.read('review/source_v3_2_4/' + name), raw)
        self.assertEqual(self.run_pilot(), summary)
        self.assertEqual(self.run_pilot(report_only=True), summary)
        self.assertEqual(self.loads, 1, 'Completed resume/report-only must not reload the model.')

    def test_historical_costs_are_not_free_and_replay_is_not_a_live_result(self):
        summary = self.run_pilot()
        self.assertEqual(summary['historical_generation_cost']['total_tokens'], 36135)
        self.assertEqual(summary['historical_review_cost']['total_tokens'], 13374)
        self.assertEqual(summary['new_experiment_cost']['total_tokens'], 32 * 15)
        self.assertEqual(summary['generation_plus_replacement_review_estimate']['total_tokens'], 36135 + 480)
        self.assertEqual(summary['all_experiments_including_old_review_cost']['total_tokens'], 49509 + 480)
        self.assertEqual(summary['whole_method_token_condition']['status'], 'not_measured_scripted_backend')
        self.assertIsNone(summary['whole_method_token_condition']['full_token_condition_met'])
        self.assertFalse(summary['semantic_correctness_measured'])
        audit = summary['selected_development_audit']
        self.assertFalse(audit['independent_accuracy_estimate'])
        self.assertEqual(audit['decision_counts']['old'], {'valid': {'revise': 6}, 'revise': {'revise': 4}})
        self.assertEqual(len(audit['cases']), 10)

    def test_interrupted_review_resumes_only_missing_calls_and_counts_both_attempts(self):
        replies = self.recorded_reviews()
        self.model = ScriptedModel(verdicts=[replies[0], KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt):
            self.run_pilot()
        partial = json.loads((self.output / 'summary.json').read_text())
        self.assertEqual(partial['new_experiment_cost']['llm_calls'], 2)
        self.assertIsNone(partial['review_tokens_difference_if_complete'])
        self.model = ScriptedModel(verdicts=replies[1:])
        summary = self.run_pilot()
        self.assertEqual(len(self.model.prompts), 31)
        self.assertEqual(summary['new_experiment_cost']['llm_calls'], 33)
        self.assertEqual(summary['new_experiment_cost']['total_tokens'], 33 * 15)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.assertTrue(self.output.with_name('review_results.zip').exists())

    def test_backend_error_requires_explicit_retry_and_keeps_failed_cost(self):
        self.model = ScriptedModel(verdicts=[RuntimeError('GPU failure')])
        with self.assertRaisesRegex(RuntimeError, 'GPU failure'):
            self.run_pilot()
        self.model = ScriptedModel(verdicts=self.recorded_reviews()[1:])
        summary = self.run_pilot()
        self.assertEqual(summary['incomplete_questions'], 1)
        self.assertEqual(summary['new_experiment_cost']['llm_calls'], 32)
        self.model = ScriptedModel(verdicts=self.recorded_reviews()[:1])
        summary = self.run_pilot(retry_errors=True)
        self.assertEqual(summary['incomplete_questions'], 0)
        self.assertEqual(summary['new_experiment_cost']['llm_calls'], 33)

    def test_format_error_is_terminal_without_a_repair_call(self):
        replies = self.recorded_reviews()
        self.model = ScriptedModel(verdicts=['not JSON'] + replies[1:])
        summary = self.run_pilot()
        self.assertEqual(summary['new_status']['invalid_response'], 1)
        self.assertEqual(summary['new_experiment_cost']['llm_calls'], 32)
        self.run_pilot(retry_errors=True)
        self.assertEqual(self.loads, 1)

    def test_source_and_checkpoint_changes_cannot_mix_review_runs(self):
        self.run_pilot()
        changed = dict(self.source, sha256='different-source')
        with self.assertRaisesRegex(ValueError, 'settings/code differ'):
            self.run_pilot(source=changed)
        with patch.object(pilot, 'code_digest', return_value='different-code'):
            with self.assertRaisesRegex(ValueError, 'settings/code differ'):
                self.run_pilot()

    def test_source_output_overlap_and_missing_report_do_not_load_model(self):
        with self.assertRaisesRegex(ValueError, 'No existing'):
            self.run_pilot(report_only=True)
        for output in (pilot.SOURCE, pilot.SOURCE / 'new_output', pilot.SOURCE.parent):
            self.output = output
            with self.assertRaisesRegex(ValueError, 'separate output'):
                self.run_pilot()
        self.assertEqual(self.loads, 0)

    def test_report_preserves_old_new_raw_and_generation_errors(self):
        self.run_pilot()
        text = (self.output / 'review.md').read_text()
        for record in self.source['records'].values():
            phases = record['phases']
            for event in phases['structure']['result']['decomposition_trace']:
                self.assertIn(event['raw_output'], text)
                if event.get('error'):
                    self.assertIn(event['error'], text)
            if phases.get('review', {}).get('result', {}).get('raw_output') is not None:
                self.assertIn(phases['review']['result']['raw_output'], text)


class ReviewReasonTests(unittest.TestCase):
    def test_generic_node_prefix_or_schema_copy_is_uncertain_not_valid(self):
        for reason in ('q2: adds a relation absent from Question.',
                       '  Q3:   adds a relation absent from Question. ',
                       '<node ID>: <actual relation/constraint> vs <required relation/constraint>'):
            details = {}
            model = ScriptedModel(verdicts=[{'status': 'revise', 'errors': [reason]}])
            with activate_tracker(TelemetryTracker('test')):
                result = review_plan(model, SAMPLES[0]['question'], CHAIN, details=details)
            self.assertEqual(result, {'status': 'uncertain', 'errors': [reason]})
            self.assertEqual(details['model_status'], 'revise')
            self.assertEqual(details['model_errors'], [reason])
            self.assertEqual(details['response_status'], 'vague_reason')
            self.assertEqual(len(model.prompts), 1)

    def test_repeated_specific_reasons_or_mixed_evidence_are_not_blindly_downgraded(self):
        specific = 'q2: asks for the employer of the person instead of that person\'s birthplace.'
        self.assertFalse(vague_review([specific, specific]))
        self.assertFalse(vague_review(['q1: adds a relation absent from Question.', specific]))

    def test_source_loader_rejects_altered_cohort_and_incomplete_generation(self):
        source = pilot.load_source(pilot.SOURCE)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'source'
            for name, raw in source['files'].items():
                destination = path / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(raw)
            samples_path = path / 'samples.json'
            samples = json.loads(samples_path.read_text())
            samples[0]['question'] += ' changed'
            samples_path.write_text(json.dumps(samples))
            with self.assertRaisesRegex(ValueError, 'unchanged'):
                pilot.load_source(path)
            samples_path.write_bytes(source['files']['samples.json'])
            qid = source['samples'][0]['question_id']
            record_path = path / 'questions' / (qid + '.json')
            record = json.loads(record_path.read_text())
            record['phases']['structure']['status'] = 'interrupted'
            record_path.write_text(json.dumps(record))
            with self.assertRaisesRegex(ValueError, 'generation must be finished'):
                pilot.load_source(path)


if __name__ == '__main__':
    unittest.main()
