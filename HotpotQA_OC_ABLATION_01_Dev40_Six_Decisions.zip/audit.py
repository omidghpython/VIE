import csv
import io
import json
import sys
from pathlib import Path
from zipfile import ZipFile

repo=Path(sys.argv[1]).resolve()
if any(Path.cwd().iterdir()):
    raise SystemExit('Run this audit in an empty scratch directory.')
base='HotpotQA_OC_ABLATION_01_Dev40'
sys.path.insert(0,str(repo/'experiments/oc_ablation_01'))
from planning_lab.common import digest
from planning_lab.paired_review import score
def readcsv(b):
    return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'), newline='')))
def loadzip(suffix):
    return ZipFile(repo/(base+suffix+'.zip'))
with loadzip('') as published:
    py='oc_ablation_01/planning_lab/paired_review.py'
    assert published.read(py)==(repo/'experiments'/py).read_bytes()
with loadzip('_Claude_Gemini') as z:
    flagged=json.loads(z.read('flagged_transfer_traces.json'))
    c=readcsv(z.read('claude_scoring.csv'))
    raw=readcsv(z.read('decision_completed.csv'))
with loadzip('_Gemini') as z:
    g=readcsv(z.read('decision_completed.csv'))
decisions={
 'd5aaa61188d363b4b1d7':('unknown','5:1, 8:1, 0:4','A death year is missing. Two adaptations and two directors are visible. The query explores one named candidate but neither distinguishes the adaptations nor establishes why that candidate is the intended director.'),
 'fc9ce4be6921c0f57bff':('yes','7:0, 7:1, 1:0, 1:1','Wenling is directly supported. An inland/coastal finding for Ruili is still missing from the explicit evidence for q2. The verbose query names the right entity and property.'),
 'f352fc81df5488bb50a3':('yes','7:0, 7:1, 1:0, 1:1','Same target, query and evidence as the dependent arm. The independent goal already proposed Wenling, but the controller rejected it.'),
 '3900fa3b8cd657a655c8':('yes','4:0, 3:2, 5:0, 6:0','Smith is documented as church president. Wong is documented as a filmmaker. His comparative church role is unverified. The support gate remained closed at the retrieval limit.'),
 'd4d84aebd4eca74d9220':('yes','4:0, 3:2, 5:0, 6:0','The independent goal proposed Smith. Comparative support remained unverified and the retrieval budget was spent.'),
 '305dfeb684642c31408b':('yes','5:0, 7:0, 7:1','Viglen was explicit from the first search; the IT-products qualifier was unverified. The later Continuum candidate confuses Tkachuk with Mike Long. The dependent goal was blocked at the cap.')}
arms=['dependent','independent']
with loadzip('_Results') as z:
    packets={p['review_id']:p for p in map(json.loads,z.read('results/decision_packets.jsonl').splitlines())}
    mapping=json.loads(z.read('results/decision_mapping.json'))
    qs=json.loads(z.read('results/runtime_questions.json'))
    z.extractall(Path.cwd())
by_id=lambda rs:{r['review_id']:r for r in rs}
gm,cm,crm=map(by_id,(g,c,raw))
assert len(g)==len(c)==len(gm)==len(cm)==661 and cm.keys()==gm.keys()==packets.keys()==mapping.keys()
actions=[i for i,m in mapping.items() if m['task']=='action']
assert len(actions)==219
assert {i for i in actions if cm[i]['action_appropriate']!=gm[i]['action_appropriate']}==decisions.keys()
assert len(flagged)==len({r['review_id'] for r in flagged})==57
for item in flagged:
    packet=packets[item['review_id']]
    assert packet['event']['kind']=='node_assessed'
    assert packet['inputs']['node_id']==packet['event']['id']
    assert packet['inputs']['consumed_dependencies']=={}
review=[]
for i,(label,refs,note) in decisions.items():
    p=packets[i]; m=mapping[i]; qid=m['question_id']; arm=m['arm']
    n=next(j for j,q in enumerate(qs,1) if q['question_id']==qid)
    trial=json.loads(Path(f'results/trials/{qid}--{arm}.json').read_bytes())
    seq=trial['events']
    j=next(j for j in range(len(seq)) if digest([qid,arm,j])[:20]==i)
    assert p['event']==seq[j]
    visible=[idx for e in seq[:j] if e['kind']=='retrieval_executed' for idx in e['new_indices']]
    assert [e['index'] for e in p['evidence']]==visible
    evidence={f"{e['index']}:{sid}":text for e in p['evidence'] for sid,text in zip(e['sentence_ids'],e['sentences'])}
    def ratings(r):
        return {k:r[k] for k in ['action_appropriate','unnecessary_retrieval','premature_stop','reason']}
    review.append(dict(question_number=n,review_id=i,**m,event_index_zero_based=j,previous_retrievals=sum(e['kind']=='retrieval_executed' for e in seq[:j]),claude_original=ratings(crm[i]),gemini_original=ratings(gm[i]),packet=p,cited_passages={ref:evidence[ref] for ref in refs.split(', ')},adjudicated_action_appropriate=label,rationale=note))
# The primary endpoint uses only action_appropriate. Keep the two baselines separate.
cases={}
for name,rows in [('claude',c),('gemini',g)]:
    mod=[dict(r) for r in rows]
    for r in mod:
        if r['review_id'] in decisions:
            r['action_appropriate']=decisions[r['review_id']][0]
    path=Path(name+'_sensitivity.csv')
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=mod[0]);w.writeheader();w.writerows(mod)
    score(Path('results'),path)
    scores=json.loads(Path('results/paired_decision_scores.json').read_bytes())
    cases[name]=[(q['question_id'],q['dependent_outcome']) for q in scores['questions']]
    print(name,scores['counts'])
assert cases['claude']==cases['gemini']
obj=dict(source_commit='23c99ebc7945a36f3e771f0235813af540631e01',review_type='Retrospective review of six disputed action_appropriate labels, with reviewer reasons visible',primary_metric='Count of inappropriate actions per question and arm',review=review,sensitivity_counts=scores['counts'],sensitivity_by_question=[dict(number=j,question_id=q,dependent_outcome=x) for j,(q,x) in enumerate(cases['claude'],1)])
Path('six_decisions.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
