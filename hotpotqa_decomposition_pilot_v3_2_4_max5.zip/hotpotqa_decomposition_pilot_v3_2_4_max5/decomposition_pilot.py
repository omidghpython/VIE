"""Observe tree generation, limited semantic checks and self-judgment on 40 saved questions.

No retriever, answering, semantic repair, or answer-accuracy claim is involved.
The full pipeline's semantic gate is not changed by this diagnostic entry point.
"""
import argparse
from collections import Counter
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import zipfile

from hotpotqa_operadic_rag.checkpoint import RunStore, atomic_json, digest
from hotpotqa_operadic_rag.config import (
    MODEL_NAME, MODEL_REVISION, RANDOM_SEED, DEFAULT_MAX_INPUT_TOKENS,
    DEFAULT_MAX_NEW_TOKENS, DEFAULT_INTERMEDIATE_TOKENS, DEFAULT_PLAN_TOKENS,
    MAX_PLAN_NODES, PLAN_ATTEMPTS,
)
from hotpotqa_operadic_rag.decomposition import (
    PLAN_SYSTEM, REVIEW_SYSTEM, DecompositionError, generate_plan, review_plan, semantic_precheck,
)
from hotpotqa_operadic_rag.contracts import expand_typed_plan
from hotpotqa_operadic_rag.cost_comparison import pilot_token_report
from hotpotqa_operadic_rag.telemetry import TelemetryTracker, activate_tracker
from hotpotqa_operadic_rag.utils import configure_logging, set_seed, check_runtime

ROOT = Path(__file__).resolve().parent
COST_KEYS = ('llm_calls', 'prompt_tokens', 'completion_tokens', 'total_tokens',
             'execution_time_sec', 'retrieval_steps')


def direct_reference():
    return json.loads((ROOT / 'evaluation' / 'direct_rag_reference.json').read_text(encoding='utf-8'))


def code_digest():
    checksum = hashlib.sha256()
    for path in [Path(__file__).resolve(), *sorted((ROOT / 'hotpotqa_operadic_rag').rglob('*.py'))]:
        checksum.update(path.relative_to(ROOT).as_posix().encode())
        checksum.update(path.read_bytes())
    return checksum.hexdigest()


def load_cohort(path):
    samples = json.loads(Path(path).read_text(encoding='utf-8'))
    baselines = json.loads((ROOT / 'evaluation' / 'decomposition_baselines.json').read_text(encoding='utf-8'))
    expected = json.loads((ROOT / 'evaluation' / 'manifest.json').read_text(encoding='utf-8'))
    if len(samples) != 40 or digest(samples) != expected['samples_sha256']:
        raise ValueError('Use the unchanged evaluation/samples.json: this pilot compares the same 40 questions.')
    for run in baselines['runs'].values():
        if run['samples_sha256'] != digest(samples):
            raise ValueError('Baseline sample identity differs.')
        if [(q['question_id'], q['question'], q['type']) for q in run['questions']] != [
                (s['question_id'], s['question'], s['type']) for s in samples]:
            raise ValueError('Baseline question text, order or type differs.')
    reference = direct_reference()
    if (reference['samples_sha256'] != digest(samples) or
            [(r['question_id'], r['question'], r['type']) for r in reference['questions']] !=
            [(s['question_id'], s['question'], s['type']) for s in samples]):
        raise ValueError('Standard RAG reference must contain exactly the unchanged 40 questions.')
    if any(type(r[k]) is not int or r[k] < 0 for r in reference['questions']
           for k in ('input_tokens', 'output_tokens', 'llm_calls')):
        raise ValueError('Invalid Standard RAG reference token/call counts.')
    return samples, baselines


def create_model(settings):
    # Lazy loading: --help, --report-only and a completed resume do not load Qwen.
    from hotpotqa_operadic_rag.llm import LocalQwen

    class RecordingQwen(LocalQwen):
        last_raw_output = None

        def generate(self, messages, max_new_tokens=None):
            self.last_raw_output = None
            raw = super().generate(messages, max_new_tokens=max_new_tokens)
            self.last_raw_output = raw
            return raw

    check_runtime(require_cuda=settings['require_cuda'])
    set_seed()
    llm = RecordingQwen(use_4bit=settings['use_4bit'],
        max_input_tokens=settings['max_input_tokens'], max_new_tokens=DEFAULT_MAX_NEW_TOKENS,
        intermediate_tokens=settings['intermediate_tokens'], plan_tokens=settings['plan_tokens'])
    revision = getattr(llm.model.config, '_commit_hash', None)
    if revision != MODEL_REVISION:
        raise RuntimeError('Loaded Qwen revision could not be matched to the original experiment.')
    packages = {}
    for name in ('torch', 'transformers', 'accelerate', 'bitsandbytes'):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    return llm, {'qwen_revision': revision, 'packages': packages, 'backend': 'LocalQwen'}


def should_run(phase, retry_errors):
    return not phase or phase['status'] == 'interrupted' or (
        retry_errors and phase['status'] == 'error')


def pending_work(record, retry_errors):
    structure = record['phases'].get('structure', {})
    return should_run(structure, retry_errors) or (
        structure['status'] == 'valid' and should_run(record['phases'].get('review', {}), retry_errors))


def run_phase(store, record, name, function):
    previous = record['phases'].get(name, {})
    tracker = TelemetryTracker(name)
    outcome = {'status': 'error', 'error': '', 'result': {}}
    try:
        with activate_tracker(tracker):
            outcome['result'] = function()
            outcome['status'] = 'valid' if name == 'structure' else 'observed'
    except DecompositionError as exc:
        outcome.update(status='invalid', error=str(exc), result=exc.details)
    except KeyboardInterrupt:
        outcome.update(status='interrupted', error='Interrupted; this phase can resume.')
        raise
    except Exception as exc:
        outcome['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        outcome['telemetry'] = tracker.as_dict()
        outcome['history'] = previous.get('history', []) + [{
            'status': outcome['status'], 'error': outcome['error'], 'telemetry': tracker.as_dict()}]
        record['phases'][name] = outcome
        store.write(record)


def generate_result(llm, question):
    plan, trace = generate_plan(llm, question)
    return {'plan': plan, 'decomposition_trace': trace}


def review_result(llm, question, plan):
    llm.last_raw_output = None
    details = {}
    verdict = review_plan(llm, question, plan, details=details)
    return {'verdict': verdict, 'raw_output': llm.last_raw_output,
            'details': details, 'role': 'observation_only', 'semantic_correctness': 'not_established'}


def summarize_baselines(baselines):
    summaries = {}
    for label, run in baselines.get('runs', {}).items():
        rows = run['questions']
        sizes = [len(r['plan']['nodes']) for r in rows if r['status'] == 'valid']
        summaries[label] = {'requested': len(rows), 'structure_status': dict(Counter(r['status'] for r in rows)),
            'single_node': sizes.count(1), 'multiple_nodes': sum(n > 1 for n in sizes),
            'scope': 'Recorded structure before semantic review; multiple nodes do not prove correct meaning.'}
    return summaries


def markdown_code_block(raw, language='text'):
    """Preserve raw output even when it contains its own Markdown fences."""
    longest = max((len(run) for run in re.findall(r'`+', raw)), default=0)
    fence = '`' * max(3, longest + 1)
    return fence + language + '\n' + raw + '\n' + fence


def structure_trace_markdown(trace):
    lines = ['### Structure attempts', '']
    if not trace:
        return lines + ['No generation attempt was recorded.', '']
    for event in trace:
        lines += [f"#### Attempt {event['attempt']} ({event.get('status', 'unknown')})", '',
                  'Exact validation error:',
                  markdown_code_block(event.get('error') or '(none)'), '',
                  'Raw model output (unmodified):',
                  markdown_code_block(event['raw_output']), '']
    return lines


def export_reports(store, baselines):
    rows, review_text = [], ['# Decomposition pilot', '',
        'Inspect every tree against its original question. Model judgments are observations, not ground truth.',
        'Check required decomposition, entity/property binding, direction, constraints/negation and final answer type.',
        'Several nodes alone do not establish correct decomposition. Answers and retrieval are not evaluated.',
        'invalid_response is a reviewer format failure, not semantic uncertainty or a demonstrated tree defect.', '']
    statuses, verdicts, model_verdicts, sources, response_statuses = (Counter() for _ in range(5))
    costs = {phase: {key: 0 for key in COST_KEYS} for phase in ('structure', 'review')}
    baseline_rows = {label: {r['question_id']: r for r in run['questions']}
                     for label, run in baselines.get('runs', {}).items()}
    incomplete, backend_errors = 0, 0
    for order, sample in enumerate(store.samples, 1):
        record = store.read(sample['question_id'])
        structure, review = (record['phases'].get(name, {}) for name in ('structure', 'review'))
        status = structure.get('status', 'pending')
        plan = structure.get('result', {}).get('plan')
        trace = structure.get('result', {}).get('decomposition_trace', [])
        verdict = review.get('result', {}).get('verdict', {})
        raw_review = review.get('result', {}).get('raw_output')
        verdict_status = verdict.get('status', 'not_reviewed')
        details = review.get('result', {}).get('details', {})
        precheck = semantic_precheck(sample['question'], plan) if plan else {}
        check = precheck.get('root_contract', {})
        source = details.get('source', 'not_reviewed')
        response_status = details.get('response_status', 'not_reviewed')
        model_status = details.get('model_status') or ('format_error' if response_status == 'format_error' else 'not_called')
        statuses[status] += 1
        verdicts[verdict_status] += 1
        model_verdicts[model_status] += 1
        sources[source] += 1
        response_statuses[response_status] += 1
        incomplete += int(status not in ('valid', 'invalid') or
                          (status == 'valid' and review.get('status') != 'observed'))
        backend_errors += sum(p.get('status') == 'error' for p in (structure, review))
        row = {'question_id': sample['question_id'], 'question': sample['question'], 'type': sample['type'],
            'structure_status': status, 'structure_attempts': len(trace), 'structure_error': structure.get('error', ''),
            'node_count': len(plan['nodes']) if plan else '', 'single_node_flag': bool(plan and len(plan['nodes']) == 1),
            'root_contract_status': check.get('status', 'not_checked'),
            'root_expected_mode': check.get('expected_mode'),
            'root_expected_target': json.dumps(check.get('expected_target'), ensure_ascii=False),
            'root_question_target': json.dumps(check.get('root_question_target'), ensure_ascii=False),
            'root_answer_type': check.get('root_answer_type'),
            'root_contract_errors': json.dumps(check.get('errors', []), ensure_ascii=False),
            'binding_errors': json.dumps(precheck.get('binding_errors', []), ensure_ascii=False),
            'geographic_precision_errors': json.dumps(precheck.get('geographic_precision_errors', []), ensure_ascii=False),
            'review_status': verdict_status, 'review_source': source,
            'review_response_status': response_status,
            'review_format_error_kind': details.get('format_error_kind') or '',
            'review_errors': json.dumps(verdict.get('errors', []), ensure_ascii=False),
            'judge_status': model_status, 'judge_errors': json.dumps(details.get('model_errors') or [], ensure_ascii=False),
            'judge_format_cleanup': details.get('format_cleanup', 'not_called'),
            'judge_runtime_error': review.get('error', ''), 'semantic_correctness': 'not_evaluated',
            'plan_json': json.dumps(plan, ensure_ascii=False),
            'expanded_typed_tree': expand_typed_plan(plan) if plan else ''}
        for phase in costs:
            phase_cost = {key: sum(h['telemetry'].get(key, 0)
                                  for h in record['phases'].get(phase, {}).get('history', [])) for key in COST_KEYS}
            for key, value in phase_cost.items():
                costs[phase][key] += value
                row[f'{phase}_{key}'] = value
        for label, lookup in baseline_rows.items():
            old = lookup[sample['question_id']]
            row[label + '_structure_status'] = old['status']
            row[label + '_node_count'] = len(old['plan']['nodes']) if old['plan'] else ''
        rows.append(row)
        review_text += [f'## {order}. {sample["question_id"]} ({sample["type"]})', '', sample['question'], '',
            f'Structure: {status}; root check: {check.get("status", "not_checked")}; '
            f'review: {verdict_status} ({source}); model judgment: {model_status}.',
            f'Response handling: {response_status}; semantic correctness: not evaluated.', '',
            '```json', json.dumps(plan, ensure_ascii=False, indent=2), '```', '',
            'Expanded typed tree (same representation sent to the judge if called):', '',
            row['expanded_typed_tree'], '',
            'Root errors: ' + row['root_contract_errors'], 'Review errors: ' + row['review_errors'],
            'Binding errors: ' + row['binding_errors'], 'Geographic precision errors: ' + row['geographic_precision_errors'],
            'Original model errors: ' + row['judge_errors'], 'Structure error: ' + row['structure_error'], '',
            'Reviewer format error kind: ' + (row['review_format_error_kind'] or '(none)'), '',
            'Raw model review (unmodified; no code-rule response is substituted):',
            markdown_code_block(raw_review if raw_review is not None else '(not recorded / model not called)'), '']
        review_text += structure_trace_markdown(trace)
        review_text += ['Manual review: pending.', '']
    summary = {'requested': len(rows), 'structure_status': dict(statuses),
        'single_node': sum(r['node_count'] == 1 for r in rows),
        'multiple_nodes': sum(isinstance(r['node_count'], int) and r['node_count'] > 1 for r in rows),
        'valid_on_first_attempt': sum(r['structure_status'] == 'valid' and r['structure_attempts'] == 1 for r in rows),
        'review_status': dict(verdicts), 'review_source': dict(sources),
        'judge_status': dict(model_verdicts), 'review_response_status': dict(response_statuses),
        'invalid_review_responses': verdicts['invalid_response'],
        'review_format_error_kind': dict(Counter(r['review_format_error_kind'] for r in rows
                                                if r['review_format_error_kind'])),
        'semantic_uncertainty_responses': response_statuses['semantic_uncertainty'],
        'vague_reason_responses': response_statuses['vague_reason'],
        'root_contract_status': dict(Counter(r['root_contract_status'] for r in rows)),
        'judge_calls_avoided_by_root_rule': sources['root_rule'],
        'judge_calls_avoided_by_all_rules': sum(sources[k] for k in ('root_rule', 'binding_rule', 'geography_rule')),
        'closing_fence_responses_recovered': sum(r['judge_format_cleanup'] == 'closing_fence_removed'
                                                and r['review_response_status'] != 'format_error' for r in rows),
        'single_node_accepted_by_judge': sum(r['single_node_flag'] and r['judge_status'] == 'valid' for r in rows),
        'semantic_correctness_measured': False, 'answer_accuracy_measured': False,
        'inference_backend': store.manifest['settings']['backend'],
        'judge_role': 'observation_only; same Qwen; at most one call per structurally valid tree; '
                      'clear root target/binding/geographic precision issues use code rules and zero judge calls; no semantic repair',
        'incomplete_questions': incomplete, 'backend_errors': backend_errors,
        'cost_including_previous_attempts': costs,
        'total_cost': {key: sum(p[key] for p in costs.values()) for key in COST_KEYS},
        'baselines_before_semantic_review': summarize_baselines(baselines),
        'note': 'All requested questions are counted. Structural validity, node count and root-rule compatibility '
                'are not semantic accuracy. Code-rule decisions are separate from actual model judgments. '
                'Invalid reviewer responses are not counted as semantic uncertainty. '
                'A pilot below the historical Standard total does not establish full-method savings.'}
    summary['whole_method_token_condition'] = pilot_token_report(
        store.samples, store.manifest['settings'], summary['total_cost']['total_tokens'], direct_reference(), incomplete)
    summary['evaluation_priority'] = 'Semantic correctness and complete decomposition; token cost is diagnostic.'
    summary['whole_method_token_condition'].update(
        criterion='Historical token comparison; current acceptance priority is correctness and completeness.',
        role='diagnostic_only_not_acceptance_gate')
    temporary = store.output.with_suffix('.csv.tmp')
    with temporary.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, store.output)
    atomic_json(store.output.parent / 'summary.json', summary)
    (store.output.parent / 'review.md').write_text('\n'.join(review_text), encoding='utf-8')
    archive = store.output.parent.with_name(store.output.parent.name + '_results.zip')
    temporary_zip = archive.with_suffix('.zip.tmp')
    report_files = [store.output, store.output.parent / 'summary.json', store.output.parent / 'review.md',
                    store.manifest_path, store.directory / 'samples.json']
    report_files += [store.records_dir / (qid + '.json') for qid in store.manifest['question_ids']]
    with zipfile.ZipFile(temporary_zip, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in report_files:
            if path.is_file() and not path.is_symlink():
                z.write(path, path.relative_to(store.output.parent.parent))
    os.replace(temporary_zip, archive)
    return summary


def run_pilot(samples, baselines, output_dir, *, use_4bit=True, require_cuda=True,
              max_input_tokens=DEFAULT_MAX_INPUT_TOKENS, intermediate_tokens=DEFAULT_INTERMEDIATE_TOKENS,
              plan_tokens=DEFAULT_PLAN_TOKENS, retry_errors=False, report_only=False, model_factory=None):
    if any(type(n) is not int or n < 1 for n in (max_input_tokens, intermediate_tokens, plan_tokens)):
        raise ValueError('Token budgets must be positive integers.')
    settings = {'schema_version': 4, 'n_samples': len(samples), 'code_sha256': code_digest(),
        'sample_snapshot_sha256': digest(samples), 'baselines_sha256': digest(baselines),
        'direct_reference_sha256': digest(direct_reference()),
        'plan_prompt_sha256': hashlib.sha256(PLAN_SYSTEM.encode()).hexdigest(),
        'review_prompt_sha256': hashlib.sha256(REVIEW_SYSTEM.encode()).hexdigest(),
        'backend': 'injected_test' if model_factory else 'LocalQwen',
        'model': MODEL_NAME, 'model_revision': MODEL_REVISION, 'seed': RANDOM_SEED,
        'use_4bit': use_4bit, 'require_cuda': require_cuda, 'max_input_tokens': max_input_tokens,
        'intermediate_tokens': intermediate_tokens, 'plan_tokens': plan_tokens,
        'max_nodes': MAX_PLAN_NODES, 'plan_attempts': PLAN_ATTEMPTS, 'semantic_repair_attempts': 0}
    output_dir = Path(output_dir).expanduser().resolve()
    if report_only and not (output_dir / 'trees.csv.state' / 'manifest.json').exists():
        raise ValueError('No existing pilot run to report.')
    store = RunStore(output_dir / 'trees.csv', settings, lambda: samples)
    summary = export_reports(store, baselines)
    if report_only or not any(pending_work(store.read(s['question_id']), retry_errors) for s in samples):
        return summary
    llm, identity = (model_factory or create_model)(settings)
    store.bind_runtime(identity)
    try:
        for order, sample in enumerate(store.samples, 1):
            record = store.read(sample['question_id'])
            if not pending_work(record, retry_errors):
                continue
            print(f'[{order}/{len(samples)}] {sample["question_id"]}', flush=True)
            if should_run(record['phases'].get('structure', {}), retry_errors):
                run_phase(store, record, 'structure', lambda: generate_result(llm, sample['question']))
            if record['phases']['structure']['status'] == 'valid' and should_run(
                    record['phases'].get('review', {}), retry_errors):
                plan = record['phases']['structure']['result']['plan']
                run_phase(store, record, 'review', lambda: review_result(llm, sample['question'], plan))
            export_reports(store, baselines)
    finally:
        summary = export_reports(store, baselines)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples-json', default=str(ROOT / 'evaluation' / 'samples.json'))
    parser.add_argument('--output-dir', default=str(ROOT / 'results' / 'decomposition_pilot_v3_2_4_max5'))
    parser.add_argument('--max-input-tokens', type=int, default=DEFAULT_MAX_INPUT_TOKENS)
    parser.add_argument('--intermediate-tokens', type=int, default=DEFAULT_INTERMEDIATE_TOKENS)
    parser.add_argument('--plan-tokens', type=int, default=DEFAULT_PLAN_TOKENS)
    parser.add_argument('--use-4bit', dest='use_4bit', action='store_true', default=True)
    parser.add_argument('--no-4bit', dest='use_4bit', action='store_false')
    parser.add_argument('--allow-cpu', action='store_true')
    parser.add_argument('--retry-errors', action='store_true', help='Retry saved backend errors; never repeat terminal structural-invalid results.')
    parser.add_argument('--report-only', action='store_true', help='Rebuild reports/ZIP from saved outputs; no model load.')
    args = parser.parse_args()
    configure_logging()
    try:
        samples, baselines = load_cohort(args.samples_json)
        summary = run_pilot(samples, baselines, args.output_dir, use_4bit=args.use_4bit,
            require_cuda=not args.allow_cpu, max_input_tokens=args.max_input_tokens,
            intermediate_tokens=args.intermediate_tokens, plan_tokens=args.plan_tokens,
            retry_errors=args.retry_errors, report_only=args.report_only)
    except KeyboardInterrupt:
        print('Interrupted. Saved phases and a results ZIP are preserved. Rerun the same command to resume.')
        return 130
    except Exception as exc:
        print(f'Pilot blocked: {type(exc).__name__}: {exc}')
        return 2
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    output = Path(args.output_dir).expanduser().resolve()
    print('Results ZIP:', output.with_name(output.name + '_results.zip'))
    print('This is a generation diagnostic. Semantic correctness and answer accuracy still require evaluation.')
    return 0 if summary['incomplete_questions'] == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
