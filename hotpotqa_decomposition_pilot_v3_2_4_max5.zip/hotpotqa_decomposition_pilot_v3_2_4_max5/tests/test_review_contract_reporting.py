"""Reviewer contract and trace regressions; no claim of new Qwen semantic accuracy."""
import copy
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import decomposition_pilot as pilot
from hotpotqa_operadic_rag.decomposition import (
    REVIEW_SYSTEM, SemanticPlanError, decompose_question, review_plan, validate_review_verdict,
)
from hotpotqa_operadic_rag.telemetry import TelemetryTracker, activate_tracker
from test_decomposition_pilot import CHAIN, SAMPLES, ScriptedModel
from test_grounded_revision import Scripted


class ReviewContractTests(unittest.TestCase):
    def review(self, response):
        model = ScriptedModel(verdicts=[response])
        details = {}
        tracker = TelemetryTracker('review')
        with activate_tracker(tracker):
            result = review_plan(model, SAMPLES[0]['question'], CHAIN, details=details)
        self.assertEqual(tracker.llm_calls, 1)
        return result, details, model

    def test_prompt_examples_match_the_parser_contract(self):
        examples = [json.loads(line) for line in REVIEW_SYSTEM.splitlines() if line.startswith('{')]
        self.assertEqual({e['status'] for e in examples}, {'valid', 'revise', 'uncertain'})
        for example in examples:
            self.assertEqual(validate_review_verdict(example), example)

    def test_nested_errors_are_not_flattened_or_treated_as_semantic_uncertainty(self):
        raw = '{"status":"revise","errors":[["q1","person"],["q2","place"]]}'
        result, details, model = self.review(raw)
        self.assertEqual(result['status'], 'invalid_response')
        self.assertEqual(details['format_error_kind'], 'schema_error')
        self.assertEqual(details['response_status'], 'format_error')
        self.assertIsNone(details['model_status'])
        self.assertEqual(model.last_raw_output, raw)
        self.assertIn('flat list', result['errors'][0])

    def test_invalid_json_and_empty_output_preserve_raw_and_parse_error(self):
        for raw in ('', '{"status":"revise","errors":[["q1"]]'):
            with self.subTest(raw=raw):
                result, details, model = self.review(raw)
                self.assertEqual(result['status'], 'invalid_response')
                self.assertEqual(details['format_error_kind'], 'parse_error')
                self.assertEqual(model.last_raw_output, raw)

    def test_inconsistent_or_missing_fields_never_become_valid(self):
        bad = [None, {}, {'status': 'valid', 'errors': ['q1: wrong']},
               {'status': 'revise', 'errors': []}, {'status': 'uncertain', 'errors': []},
               {'status': 'valid', 'errors': [], 'extra': True},
               {'status': 'valid', 'errors': None}, {'status': 'revise', 'errors': [' ']},
               {'status': 'revise', 'errors': [{'node': 'q1', 'reason': 'wrong'}]},
               {'status': [], 'errors': []}]
        for value in bad:
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_review_verdict(value)

    def test_semantic_uncertainty_and_vague_reason_stay_separate(self):
        result, details, _ = self.review({'status': 'uncertain', 'errors': ['q1: unclear referent.']})
        self.assertEqual(result['status'], 'uncertain')
        self.assertEqual(details['response_status'], 'semantic_uncertainty')
        self.assertIsNone(details['format_error_kind'])
        result, details, _ = self.review({'status': 'revise', 'errors': ['different wording']})
        self.assertEqual(result['status'], 'uncertain')
        self.assertEqual(details['model_status'], 'revise')
        self.assertEqual(details['response_status'], 'vague_reason')
        self.assertIsNone(details['format_error_kind'])

    def test_a_specific_semantic_error_is_preserved_not_reclassified(self):
        verdict = {'status': 'revise', 'errors': ['q2: asks what the entity makes instead of what it is.']}
        result, details, _ = self.review(verdict)
        self.assertEqual(result, verdict)
        self.assertEqual(details['response_status'], 'parsed')
        self.assertEqual(details['model_errors'], verdict['errors'])

    def test_full_pipeline_does_not_repair_a_tree_using_a_format_error(self):
        model = Scripted([CHAIN], [{'status': 'revise', 'errors': [['q1', 'person']]}])
        with self.assertRaises(SemanticPlanError) as caught:
            decompose_question(model, SAMPLES[0]['question'])
        self.assertEqual(caught.exception.details['semantic_status'], 'invalid_response')
        self.assertEqual(caught.exception.details['structural_status'], 'valid')
        self.assertEqual((len(model.messages), len(model.prompts)), (1, 1))
        self.assertEqual([e['stage'] for e in caught.exception.details['decomposition_trace']],
                         ['structure', 'semantic_review'])

    def test_backend_failure_is_not_mislabeled_as_a_json_error(self):
        with self.assertRaisesRegex(RuntimeError, 'GPU failure'):
            self.review(RuntimeError('GPU failure'))


class ReportingTests(unittest.TestCase):
    def test_dynamic_fences_and_raw_whitespace_survive(self):
        raw = '  ```json\n{"question":"Čas?"}\n```\n trailing space  '
        block = pilot.markdown_code_block(raw)
        self.assertTrue(block.startswith('````text\n'))
        self.assertTrue(block.endswith('\n````'))
        self.assertIn('\n' + raw + '\n', block)
        event = {'attempt': 2, 'status': 'invalid', 'error': 'q2: slot missing.\nExact error.', 'raw_output': raw}
        report = '\n'.join(pilot.structure_trace_markdown([event]))
        self.assertIn('Attempt 2 (invalid)', report)
        self.assertIn(event['error'], report)
        self.assertIn(raw, report)

    def test_both_failed_structure_attempts_are_visible_without_judge_or_resume_calls(self):
        first = copy.deepcopy(CHAIN)
        first['nodes'][1]['dependencies'] = {}
        second = '```json\n{"nodes": [], "final":"q1"}\n```'
        model = ScriptedModel([first, second])
        loads = []
        def factory(settings):
            loads.append(True)
            return model, {'backend': 'scripted'}
        with tempfile.TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()):
            output = Path(tmp) / 'pilot'
            summary = pilot.run_pilot(SAMPLES, {}, output, model_factory=factory)
            record = json.loads((output / 'trees.csv.state/questions/example1.json').read_text())
            report = (output / 'review.md').read_text()
            for event in record['phases']['structure']['result']['decomposition_trace']:
                self.assertIn('Attempt ' + str(event['attempt']) + ' (invalid)', report)
                self.assertIn(event['error'], report)
                self.assertIn(event['raw_output'], report)
            self.assertEqual(summary['total_cost']['llm_calls'], 2)
            self.assertEqual(model.prompts, [])
            self.assertEqual(pilot.run_pilot(SAMPLES, {}, output, model_factory=factory, report_only=True), summary)
            self.assertEqual((output / 'review.md').read_text(), report)
        self.assertEqual(len(loads), 1)

    def test_legacy_12_node_v323_replay_separates_format_errors_and_keeps_all_traces(self):
        samples, baselines = pilot.load_cohort(pilot.ROOT / 'evaluation/samples.json')
        rows = baselines['runs']['v3.2.3']['questions']
        model = ScriptedModel(
            [event['raw_output'] for row in rows for event in row['trace']],
            [row['judge']['raw_output'] for row in rows if row['judge'].get('details', {}).get('source') == 'model'])
        # Reproduce historical validation messages under the historical cap.
        # The actual five-node cap and its error traces have separate coverage.
        with tempfile.TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()), \
                patch('hotpotqa_operadic_rag.decomposition.MAX_PLAN_NODES', 12), \
                patch.object(pilot, 'MAX_PLAN_NODES', 12):
            output = Path(tmp) / 'pilot'
            summary = pilot.run_pilot(samples, baselines, output,
                                      model_factory=lambda settings: (model, {'backend': 'scripted'}))
            self.assertEqual(summary['structure_status'], {'valid': 35, 'invalid': 5})
            self.assertEqual(summary['review_status'], {'valid': 25, 'not_reviewed': 5,
                                                      'invalid_response': 9, 'revise': 1})
            self.assertEqual(summary['review_format_error_kind'], {'schema_error': 7, 'parse_error': 2})
            self.assertEqual(summary['invalid_review_responses'], 9)
            self.assertEqual(summary['semantic_uncertainty_responses'], 0)
            self.assertEqual(summary['vague_reason_responses'], 0)
            self.assertEqual(summary['total_cost']['llm_calls'], 83)
            self.assertEqual(summary['whole_method_token_condition']['status'], 'not_measured_scripted_backend')
            self.assertFalse(summary['semantic_correctness_measured'])
            report = (output / 'review.md').read_text()
            for row in rows:
                for event in row['trace']:
                    self.assertIn(event['raw_output'], report)
                    if event.get('error'):
                        self.assertIn(event['error'], report)
                raw = row['judge'].get('raw_output')
                if raw is not None:
                    self.assertIn(raw, report)
            self.assertIn('### Structure attempts', report)
        self.assertFalse(model.plans)
        self.assertFalse(model.verdicts)


if __name__ == '__main__':
    unittest.main()
