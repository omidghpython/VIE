"""Synthetic display-hint checks; no claim about live model semantics."""
import copy
import unittest

from hotpotqa_operadic_rag.decomposition import (
    PLAN_SYSTEM, DecompositionError, generate_plan, plan_instructions,
    root_answer_check, target_display_phrase,
)
from hotpotqa_operadic_rag.semantic_checks import answer_target
from test_grounded_revision import Scripted


def atomic(question, kind='person'):
    return {'nodes': [{'id': 'q1', 'question': question,
                      'dependencies': {}, 'answer_type': kind}], 'final': 'q1'}


class TargetPhraseTests(unittest.TestCase):
    def test_coordinated_roles_are_preserved_for_display(self):
        for question, phrase in [
            ('Which author and composer was born in the village?', 'author and composer'),
            ('The festival featured which singer and director?', 'singer and director'),
            ('What writer and photographer has won the prize?', 'writer and photographer'),
            ('Which author and composer and director is credited?', 'author and composer and director'),
        ]:
            with self.subTest(question=question):
                self.assertEqual(plan_instructions(question),
                                 PLAN_SYSTEM + '\nFinal target: ' + phrase + ' (person).')

    def test_separate_people_are_not_joined(self):
        for question in [
            'Which author and which composer worked together?',
            'Which author and a composer worked together?',
            'Which author and the composer worked together?',
            'Which author and composer are siblings?',
            'Which author and composer were invited?',
            'Which author and composer duo performed?',
        ]:
            with self.subTest(question=question):
                self.assertEqual(plan_instructions(question),
                                 PLAN_SYSTEM + '\nFinal target: author (person).')

    def test_unsupported_or_ambiguous_syntax_falls_back(self):
        for question in [
            'Which author or composer was invited?',
            'Which author and painter was invited?',
            'Which author and acclaimed composer was invited?',
            'Which author and composer and architect was invited?',
            'Which author, composer and director was invited?',
            'Which author and company received an award?',
        ]:
            with self.subTest(question=question):
                self.assertEqual(plan_instructions(question),
                                 PLAN_SYSTEM + '\nFinal target: author (person).')

    def test_single_role_and_nonperson_hints_are_unchanged(self):
        for question, hint in [
            ('Which author wrote the poem?', 'author (person).'),
            ('What year did the author and composer meet?', 'year (date).'),
            ('Which city and country hosted the event?', 'city (place).'),
            ('Who was the author and composer?', 'who (person).'),
            ('Are the author and composer siblings?', 'yes/no (boolean).'),
        ]:
            with self.subTest(question=question):
                self.assertEqual(plan_instructions(question), PLAN_SYSTEM + '\nFinal target: ' + hint)

    def test_other_and_indirect_question_policy_is_preserved(self):
        self.assertEqual(plan_instructions('What type of product is advertised?'),
                         PLAN_SYSTEM + '\nFinal must return the requested name/value, not yes/no.')
        self.assertEqual(plan_instructions('Could you identify the author and composer?'), PLAN_SYSTEM)

    def test_titles_and_later_wh_clauses_do_not_replace_target(self):
        for question in [
            'Which film depicts which author and composer?',
            'Which film titled "Which author and composer?" won the award?',
            '"Which author and composer?" is the title of which film?',
        ]:
            self.assertEqual(plan_instructions(question), PLAN_SYSTEM + '\nFinal target: film (work).')

    def test_case_and_whitespace_are_normalized(self):
        self.assertTrue(plan_instructions('  WHICH Author\n and  Composer WAS invited?').endswith(
            '\nFinal target: author and composer (person).'))

    def test_target_contract_and_input_mapping_are_not_modified(self):
        question = 'Which author and composer was invited?'
        target = answer_target(question)
        self.assertEqual(target, {'head': 'author', 'type': 'person'})
        saved = copy.deepcopy(target)
        self.assertEqual(target_display_phrase(question, target), 'author and composer')
        self.assertEqual(target, saved)
        self.assertEqual(answer_target(question), saved)

    def test_existing_root_checks_still_reject_boolean_target(self):
        question = 'Which author and composer was invited?'
        check = root_answer_check(question, atomic('Was a guest invited?', 'boolean'))
        self.assertTrue(check['errors'])
        self.assertFalse(root_answer_check(question, atomic(question))['errors'])

    def test_repair_preserves_question_and_enriched_system(self):
        question = 'Which author and composer was invited to the festival in 1981?'
        correct = atomic(question)
        model = Scripted([{}, correct])
        plan, trace = generate_plan(model, question)
        self.assertEqual(plan, correct)
        self.assertEqual(len(trace), 2)
        self.assertEqual(model.messages[0][-1]['content'], question)
        self.assertTrue(model.messages[1][-1]['content'].startswith(question + '\nInvalid tree:\n'))
        for message in model.messages:
            self.assertEqual(message[0]['content'], plan_instructions(question))
        self.assertEqual(model.prompts, [])

    def test_generation_budget_stays_two(self):
        model = Scripted([{}, {}, atomic('Who attended?')])
        with self.assertRaises(DecompositionError):
            generate_plan(model, 'Which author and composer was invited?')
        self.assertEqual(len(model.messages), 2)
        self.assertEqual(len(model.plans), 1)
        self.assertEqual(model.prompts, [])


if __name__ == '__main__':
    unittest.main()
