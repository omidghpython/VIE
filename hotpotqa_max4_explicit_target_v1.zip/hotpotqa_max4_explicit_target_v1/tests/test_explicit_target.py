"""Synthetic phase-one boundaries; these are not model-quality tests."""
import json
import unittest
from hotpotqa_operadic_rag.semantic_checks import answer_target, incompatible_types
from hotpotqa_operadic_rag.decomposition import plan_instructions, root_answer_check, generate_plan, review_plan


def single(question, kind):
    return {'nodes': [{'id': 'q1', 'question': question, 'answer_type': kind, 'dependencies': {}}], 'final': 'q1'}

class ExplicitTargetTests(unittest.TestCase):
    def test_dual_role(self):
        self.assertEqual(answer_target('Which writer and director is credited?'),
                         {'type': 'person', 'head': 'writer and director'})
    def test_repeated_determiner(self):
        for q in ('Which writer and which director?', 'Which writer and a director?',
                  'Which writer and the director?', 'Which writer and another director?'):
            self.assertNotIn(' and ', answer_target(q)['head'])
    def test_plural_predicate(self):
        self.assertNotIn(' and ', answer_target('Which writer and director are credited?')['head'])
    def test_plural_roles(self):
        self.assertIsNone(answer_target('Which writers and directors are credited?'))
    def test_mixed_types(self):
        self.assertNotIn(' and ', answer_target('Which writer and company?')['head'])
    def test_role_possessive(self):
        self.assertIsNone(answer_target("Which writer and director's birthplace?"))
    def test_quoted_role_text(self):
        self.assertEqual(answer_target('Which book is titled "Which writer and director?"?')['head'], 'book')
    def test_category_variants(self):
        for prefix in ('type', 'kind', 'sort', 'form'):
            t=answer_target(f'What {prefix} of material is used?')
            self.assertEqual(t, {'type':'other','head':f'{prefix} of material','explicit_other':True})
    def test_known_category(self):
        self.assertEqual(answer_target('What type of company is this?'),
                         {'type':'organization','head':'type of company'})
    def test_category_possessive_not_explicit(self):
        for q in ("What type of maker's tool is used?", 'What type of the tool is used?',
                  'What type of painted material is used?'):
            self.assertFalse(answer_target(q).get('explicit_other', False))
    def test_bare_type_remains_ambiguous(self):
        self.assertEqual(answer_target('What type is used?'), {'type':'other','head':'type'})
        self.assertNotIn('Final target: type (other)', plan_instructions('What type is used?'))
    def test_explicit_other_hints(self):
        for head in ('nationality', 'profession', 'occupation', 'currency', 'focus'):
            self.assertIn(f'Final target: {head} (other).',plan_instructions(f'What {head} is specified?'))
    def test_category_hint(self):
        self.assertIn('Final target: type of material (other).',plan_instructions('What type of material is used?'))
    def test_known_target_rejects_other_label(self):
        self.assertEqual(root_answer_check('Which writer is credited?',single('Identify the credited writer.', 'other'))['status'],'mismatch')
    def test_unknown_root_text_abstains(self):
        r=root_answer_check('Which writer is credited?',single('Identify the credited contributor.', 'person'))
        self.assertIsNone(r['root_question_target']); self.assertFalse(r['errors'])
    def test_unknown_original_abstains(self):
        self.assertFalse(root_answer_check('Identify the relevant contribution.',single('Identify it.', 'other'))['errors'])
    def test_explicit_other_rejects_bad_labels(self):
        for kind in ('person','place','date','number','work','boolean'):
            self.assertTrue(root_answer_check('What currency is used?',single('Identify the currency.', kind))['errors'])
    def test_other_allows_requested_organization_exception(self):
        self.assertFalse(root_answer_check('What currency is used?',single('Identify the currency.', 'organization'))['errors'])
    def test_correct_other(self):
        self.assertFalse(root_answer_check('What currency is used?',single('Identify the currency.', 'other'))['errors'])
    def test_date_number_compatibility_preserved(self):
        self.assertFalse(incompatible_types('date','number'))
        self.assertFalse(root_answer_check('Which year was it founded?',single('What year was it founded?', 'number'))['errors'])
    def test_global_other_policy_unchanged(self):
        self.assertFalse(incompatible_types('person','other'))
        self.assertFalse(incompatible_types('other','work'))
    def test_no_new_generation_retry(self):
        class Model:
            calls=0
            def generate(self,*a,**k):
                self.calls+=1
                return json.dumps(single('Identify the credited writer.', 'other'))
        model=Model(); _,trace=generate_plan(model,'Which writer is credited?')
        self.assertEqual(model.calls,1); self.assertEqual(trace[0]['root_contract']['status'],'mismatch')
    def test_precheck_blocks_bad_label_before_judge(self):
        class NoCalls:
            def ask_json(self,*a,**k): raise AssertionError('Unexpected model call')
        details={}
        verdict=review_plan(NoCalls(),'What currency is used?',single('Identify the currency.', 'work'),details=details)
        self.assertEqual(verdict['status'],'revise'); self.assertEqual(details['source'],'root_rule')
