@echo off
call "%~dp0run_direction_probe.bat" %*
exit /b %ERRORLEVEL%
