"""Budget, isolation and reporting checks; no live model accuracy assertion."""
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import direction_probe as probe
from hotpotqa_operadic_rag.checkpoint import atomic_json
from hotpotqa_operadic_rag.decomposition import plan_instructions
from test_decomposition_pilot import ScriptedModel

PLAN = {'nodes': [{'id': 'q1', 'question': 'Which river lies east of the town?',
                   'dependencies': {}, 'answer_type': 'place'}], 'final': 'q1'}


class DirectionProbeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.output = Path(self.tmp.name) / 'probe'
        self.cases = probe.load_cases()['cases']
        self.model = ScriptedModel([PLAN] * 10)
        self.loads = 0

    def factory(self, settings):
        self.loads += 1
        return self.model, {'backend': 'scripted'}

    def run_probe(self, **kwargs):
        with redirect_stdout(io.StringIO()):
            return probe.run_probe(self.output, model_factory=self.factory, **kwargs)

    def test_only_appendix_differs_and_manual_reference_never_enters_prompt(self):
        for sample in self.cases:
            a,b = [probe.messages_for(sample,m) for m in probe.METHODS]
            self.assertEqual(a[0]['content'],plan_instructions(sample['question']))
            self.assertEqual(b[0]['content'],a[0]['content']+'\n'+probe.DIRECTION_TEMPLATE)
            self.assertEqual(a[1],b[1]); self.assertEqual(a[1]['content'],sample['question'])
            self.assertNotIn(sample['manual_relation'],json.dumps(b))
        for name in ('Innviertel','Velora','Merovin'):
            self.assertNotIn(name,probe.DIRECTION_TEMPLATE)

    def test_ten_calls_alternate_order_and_do_not_add_judge_or_repair(self):
        s=self.run_probe()
        self.assertEqual(s['completed_calls'],10)
        self.assertEqual(s['total_cost']['llm_calls'],10)
        self.assertEqual(s['total_cost']['total_tokens'],150)
        self.assertEqual(self.model.prompts,[])
        for i,sample in enumerate(self.cases):
            order=probe.METHODS if i%2==0 else probe.METHODS[::-1]
            for offset,method in enumerate(order):
                self.assertEqual(self.model.messages[2*i+offset],probe.messages_for(sample,method))
        self.assertIsNone(s['automatic_winner']);self.assertFalse(s['semantic_accuracy_measured'])
        self.assertEqual(self.run_probe(),s)
        self.assertEqual(self.run_probe(report_only=True),s)
        self.assertEqual(self.loads,1)
        with zipfile.ZipFile(self.output.with_name('probe_results.zip')) as z:
            self.assertIsNone(z.testzip())
            self.assertEqual(json.loads(z.read('probe/summary.json')),s)

    def test_invalid_json_kept_and_not_repaired(self):
        self.model=ScriptedModel(['not json']*10)
        s=self.run_probe()
        self.assertEqual(s['structure_status'],{m:{'invalid':5} for m in probe.METHODS})
        self.assertEqual(s['total_cost']['llm_calls'],10)
        rows=json.loads((self.output/'comparison.json').read_text())
        self.assertEqual(rows[0]['arms']['baseline']['result']['raw_output'],'not json')

    def test_failed_call_not_repeated_on_resume_but_unstarted_arms_continue(self):
        self.model=ScriptedModel([RuntimeError('test failure')]+[PLAN]*9)
        with self.assertRaisesRegex(RuntimeError,'test failure'):self.run_probe()
        s=self.run_probe()
        self.assertEqual(s['completed_calls'],9);self.assertEqual(s['pending_phases'],0)
        self.assertEqual(s['total_cost']['llm_calls'],10)
        self.assertEqual(s['phase_status']['baseline'],{'error':1,'observed':4})
        self.assertEqual(self.run_probe(),s);self.assertEqual(self.loads,2)

    def test_unknown_abrupt_exit_is_flagged_not_automatically_retried(self):
        self.run_probe()
        path=self.output/'comparison.csv.state/questions'/(self.cases[0]['question_id']+'.json')
        record=json.loads(path.read_text());record['phases']['baseline']={'status':'started','error':'Incomplete cost','result':{},'history':[]}
        atomic_json(path,record)
        s=self.run_probe()
        self.assertEqual(s['completed_calls'],9);self.assertEqual(self.loads,1)
        row=json.loads((self.output/'comparison.json').read_text())[0]
        self.assertFalse(row['arms']['baseline']['cost_complete'])

    def test_changed_appendix_cannot_resume_old_run(self):
        self.run_probe()
        with patch.object(probe,'DIRECTION_TEMPLATE','different'):
            with self.assertRaisesRegex(ValueError,'settings/code differ'):self.run_probe()
        self.assertEqual(self.loads,1)

    def test_tampered_cases_fail_before_model_load(self):
        with patch.object(probe,'CASE_SHA256','wrong'):
            with self.assertRaisesRegex(ValueError,'pinned'):self.run_probe()
        self.assertEqual(self.loads,0)

    def test_report_only_requires_existing_checkpoint(self):
        with self.assertRaisesRegex(ValueError,'No existing'):self.run_probe(report_only=True)
        self.assertEqual(self.loads,0)


if __name__ == '__main__':
    unittest.main()
