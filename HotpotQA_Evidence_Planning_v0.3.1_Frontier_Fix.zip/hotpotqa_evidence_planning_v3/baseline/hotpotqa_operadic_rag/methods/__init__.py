"""RAG method implementations."""
