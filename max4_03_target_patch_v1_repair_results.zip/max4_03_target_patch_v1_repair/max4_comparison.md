# Comparison with original max4

Saved original max4 output comparison only. Structural counts and model verdicts are not semantic accuracy. No gold data enters generation.

Same complete cohort: True

| Case | Baseline structure | Current structure | Identical plan | Baseline tokens | Current tokens |
|---|---|---|---|---|---|
| 1 | valid | valid | True | 1202 | 1202 |
| 2 | invalid | invalid | True | 1598 | 1598 |
| 3 | valid | valid | True | 1037 | 1037 |
| 4 | valid | valid | True | 1135 | 1135 |
| 5 | valid | valid | True | 1136 | 1136 |
| 6 | valid | valid | True | 1128 | 1128 |
| 7 | valid | valid | True | 1168 | 1168 |
| 8 | valid | valid | True | 1051 | 1051 |
| 9 | valid | valid | True | 1025 | 1025 |
| 10 | valid | valid | True | 1181 | 1181 |
| 11 | valid | valid | True | 1161 | 1161 |
| 12 | valid | valid | True | 1160 | 1160 |
| 13 | valid | valid | True | 1149 | 1149 |
| 14 | valid | valid | True | 1107 | 1107 |
| 15 | valid | valid | True | 1869 | 1869 |
| 16 | valid | valid | True | 1125 | 1125 |
| 17 | valid | valid | True | 1146 | 1146 |
| 18 | valid | valid | True | 2163 | 2163 |
| 19 | valid | valid | False | 689 | 1497 |
| 20 | valid | valid | True | 1996 | 1996 |
| 21 | valid | valid | True | 735 | 735 |
| 22 | valid | valid | True | 1168 | 1168 |
| 23 | valid | valid | True | 1169 | 1169 |
| 24 | valid | valid | True | 1107 | 1107 |
| 25 | valid | valid | False | 1083 | 1080 |
| 26 | valid | valid | True | 1061 | 1061 |
| 27 | valid | valid | True | 1130 | 1130 |
| 28 | valid | valid | True | 1123 | 1123 |
| 29 | valid | valid | True | 1085 | 1085 |
| 30 | valid | valid | True | 1113 | 1113 |
| 31 | valid | valid | True | 1167 | 1167 |
| 32 | invalid | invalid | True | 1673 | 1673 |
| 33 | valid | valid | False | 1107 | 1141 |
| 34 | valid | valid | True | 1089 | 1089 |
| 35 | valid | valid | True | 1916 | 1916 |
| 36 | valid | valid | True | 679 | 1069 |
| 37 | valid | valid | True | 1130 | 1130 |
| 38 | valid | valid | True | 1069 | 1069 |
| 39 | invalid | invalid | True | 1418 | 1418 |
| 40 | valid | valid | True | 696 | 1115 |