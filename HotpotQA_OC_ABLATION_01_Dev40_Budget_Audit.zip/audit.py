"""Rebuild the Dev40 retrieval-budget audit from released artifacts and analyst notes."""
import argparse
import csv
import hashlib
import io
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

BASE = 'HotpotQA_OC_ABLATION_01_Dev40'
ARMS = ('dependent', 'independent')
def read_csv(raw, delimiter=','):
    return list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'), newline=''), delimiter=delimiter))

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=Path)
    parser.add_argument('output', type=Path, help='New directory for the generated files')
    args = parser.parse_args()
    notes = {}
    for row in read_csv(Path(__file__).with_name('assessments.tsv').read_bytes(), '\t'):
        arms = ARMS if row['arm']=='both' else (row['arm'],)
        for arm in arms:
            key = (int(row['question']), arm)
            assert key not in notes and arm in ARMS
            notes[key] = row
    results_path = args.repo/(BASE+'_Results.zip')
    labels_path = args.repo/'experiments/oc_ablation_01/private/original_samples.json'
    samples = {r['id']:r for r in json.loads(labels_path.read_bytes())}
    with ZipFile(args.repo/(BASE+'_Claude_Gemini.zip')) as package:
        claude = {r['review_id']:r for r in read_csv(package.read('claude_scoring.csv'))}
    with ZipFile(args.repo/(BASE+'_Gemini.zip')) as package:
        gemini = {r['review_id']:r for r in read_csv(package.read('decision_completed.csv'))}
    status = {arm:Counter() for arm in ARMS}
    records, rows, used = [], [], set()
    with ZipFile(results_path) as archive:
        def get(filename):
            return json.loads(archive.read('results/'+filename))
        questions = get('runtime_questions.json')
        mapping = get('decision_mapping.json')
        assert len(questions)==len(samples)==40
        for num,q in enumerate(questions,1):
            qid=q['question_id']
            passages={p['index']:p for p in q['passages']}
            facts=samples[qid]['supporting_facts']
            expected = set(zip(facts['title'],facts['sent_id']))
            # Analyst-identified bridge/qualifier outside the retrieved set.
            missing_refs={12:'7:0',25:'0:0',31:'8:1',36:'2:0',40:'5:0'}
            final_id=q['frozen_plan'].get('final') if q.get('frozen_plan') else None
            for arm in ARMS:
                trial=get(f'trials/{qid}--{arm}.json')
                assert (trial['question_id'],trial['method'])==(qid,arm)
                status[arm][trial['status']]+=1
                if trial['status']!='budget_exhausted':
                    continue
                note=notes[(num,arm)]
                used.add((num,arm))
                events=trial['events']
                searches=[e for e in events if e['kind']=='retrieval_executed']
                calls=[e for e in events if e['kind']=='controller_decision']
                completed=[e for e in events if e['kind']=='round_completed']
                assert len(searches)==len(completed)==trial['costs']['retrieval_calls']==2
                assert [e['action'] for e in calls]==['retrieve','retrieve','budget_exhausted']
                assert calls[-1]['reason']==trial['error']=='retrieval_calls' and not trial['answer']
                refs=note['refs'].split()
                found, first_visible, ref_map, rounds=set(), {}, {}, []
                node_review=[]
                for j,e in enumerate(events):
                    if e['kind']!='node_assessed':
                        continue
                    # Project review IDs are SHA256 prefixes over canonical JSON arrays.
                    key=json.dumps([qid,arm,j],separators=(',',':'),ensure_ascii=False).encode()
                    rid=hashlib.sha256(key).hexdigest()[:20]
                    assert mapping[rid]==dict(question_id=qid,arm=arm,task='node')
                    node_review.append(dict(event_index=j,node=e['id'],review_id=rid,
                         candidate=e['candidate']['answer'],runtime_status=e['status'],
                         sufficient_candidate=e['candidate']['sufficient'],
                         claude=claude[rid]['supported_answer_rejected'],gemini=gemini[rid]['supported_answer_rejected']))
                for k,(search,rd,call) in enumerate(zip(searches,completed,calls),1):
                    assert len(search['new_indices'])==3 and not rd['stop_gate']['allowed']
                    for i in search['new_indices']:
                        p=passages[i]
                        for sid,s in zip(p['sentence_ids'],p['sentences'],strict=True):
                            ref=f'{i}:{sid}'; assert ref not in first_visible
                            first_visible[ref]=k
                            ref_map[ref]=s.strip()
                            found.add((p['title'],sid))
                    rounds.append(dict(number=k,query=call['query'],target=call['target_node'],
                        new_indices=search['new_indices'],gold_present=sorted(expected&found),
                        gold_missing=sorted(expected-found),nodes=rd['nodes'],gate=rd['stop_gate'],
                        goal_certificate=rd['goal_certificate']))
                assert set(refs)<=ref_map.keys()
                assert note['evidence_status'] in ('supported','gap','ambiguous')
                final_round=rounds[-1]
                nodes=final_round['nodes']
                final=next(n for n in nodes if n['id']==final_id)
                rejected=[n for n in nodes if n.get('certificate') and n['status']=='insufficient']
                # Agreement on a rejected proposal is a review signal, not independent ground truth.
                both_rejected=[n for n in node_review if n['runtime_status']=='insufficient'
                    and n['sufficient_candidate'] and n['candidate'] and n['claude']==n['gemini']=='yes']
                missing_in_corpus={}
                if note['evidence_status']=='gap' and num in missing_refs:
                    ref=missing_refs[num]
                    pid,sid=map(int,ref.split(':'))
                    p=passages[pid]
                    assert ref not in first_visible
                    missing_in_corpus[ref]=dict(title=p['title'],text=p['sentences'][p['sentence_ids'].index(sid)].strip())
                result=dict(available_but_unretrieved_premise=missing_in_corpus,question_number=num,question_id=qid,question=q['question'],arm=arm,
                    evidence_status=note['evidence_status'],evidence_and_gap_fa=note['evidence_and_gap_fa'],
                    node_diagnosis_fa=note['node_diagnosis_fa'],
                    cited_sentences={ref:dict(first_round=first_visible[ref],text=ref_map[ref]) for ref in refs},
                    rounds=rounds,final_node=final_id,final_node_status=final['status'],
                    node_reviews=node_review,terminal_event=calls[-1],
                    all_retrieved_sentences=ref_map)
                records.append(result)
                rows.append(dict(question_number=num,question_id=qid,arm=arm,question=q['question'],
                    evidence_status=note['evidence_status'],
                    available_but_unretrieved_premise=' '.join(missing_in_corpus),cited_refs=' '.join(refs),all_cited_refs_visible_by=max(first_visible[ref] for ref in refs),
                    annotated_facts_total=len(expected),annotated_facts_after_first=len(rounds[0]['gold_present']),
                    annotated_facts_after_second=len(expected&found),final_node_status=final['status'],
                    final_unresolved=' '.join(final_round['gate']['unresolved_nodes']),
                    final_blocked=sum(n['status']=='blocked' for n in nodes),
                    final_invalid_certificates=sum(not n['certificate']['valid_format'] for n in rejected),
                    final_valid_negative_certificates=sum(n['certificate']['valid_format'] for n in rejected),
                    final_no_certificate=sum(n['status']=='insufficient' and n.get('certificate') is None for n in nodes),
                    joint_rejection_flags_both_rounds=len(both_rejected),
                    evidence_and_gap_fa=note['evidence_and_gap_fa'],node_diagnosis_fa=note['node_diagnosis_fa']))
        assert len(records)==69 and used==notes.keys()
    breakdown={}
    for arm in ARMS:
        group=[r for r in rows if r['arm']==arm]
        breakdown[arm]=dict(all_trial_status=status[arm],exhausted=len(group),
            evidence_status=Counter(r['evidence_status'] for r in group),
            supported_refs_available_r1=sum(r['evidence_status']=='supported' and r['all_cited_refs_visible_by']==1 for r in group),
            all_annotated_r1=sum(r['annotated_facts_after_first']==r['annotated_facts_total'] for r in group),
            all_annotated_r2=sum(r['annotated_facts_after_second']==r['annotated_facts_total'] for r in group),
            runs_with_identified_missing_corpus_premise=sum(bool(r['available_but_unretrieved_premise']) for r in group),
            final_node_status=Counter(r['final_node_status'] for r in group),
            runs_with_final_invalid_certificate=sum(bool(r['final_invalid_certificates']) for r in group),
            runs_with_final_valid_negative_certificate=sum(bool(r['final_valid_negative_certificates']) for r in group),
            runs_with_final_no_certificate=sum(bool(r['final_no_certificate']) for r in group),
            trials_with_both_judges_flagging_a_rejected_candidate=sum(bool(r['joint_rejection_flags_both_rounds']) for r in group))
    summary=dict(result_archive_sha256=hashlib.sha256(results_path.read_bytes()).hexdigest(),
        original_samples_sha256=hashlib.sha256(labels_path.read_bytes()).hexdigest(),exhausted_questions=len(set(r['question_id'] for r in rows)),by_arm=breakdown)
    args.output.mkdir(parents=True,exist_ok=False)
    write_json(args.output/'summary.json',summary)
    write_json(args.output/'traces.json',records)
    with (args.output/'trials.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    main()
