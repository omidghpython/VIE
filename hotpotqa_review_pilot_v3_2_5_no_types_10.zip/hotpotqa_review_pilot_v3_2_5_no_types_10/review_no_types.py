"""Controlled ten-tree v3.2.5 experiment: hide node type labels from the judge."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import zipfile

import review_pilot as previous
from decomposition_pilot import ROOT, create_model, run_phase, should_run, markdown_code_block
from hotpotqa_operadic_rag.checkpoint import RunStore, atomic_json, digest
from hotpotqa_operadic_rag.contracts import expand_typed_plan
from hotpotqa_operadic_rag.decomposition import build_review_prompt, review_plan, semantic_precheck
from hotpotqa_operadic_rag.utils import configure_logging

BASELINE = ROOT / 'evaluation' / 'review_source_v3_2_5'
OUTPUT_NAME = 'review_pilot_v3_2_5_no_types_10'


def code_digest():
    return digest({'base': previous.code_digest(),
                   'runner': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})


def load_inputs():
    source = previous.load_source(previous.SOURCE)
    files = {p.relative_to(BASELINE).as_posix(): p.read_bytes()
             for p in sorted(BASELINE.rglob('*.json'))}
    manifest = json.loads(files['manifest.json'])
    samples = json.loads(files['samples.json'])
    if (digest(samples) != digest(source['samples']) or
            manifest['question_ids'] != source['manifest']['question_ids'] or
            manifest['settings']['source_sha256'] != source['sha256']):
        raise ValueError('v3.2.5 baseline does not match the original questions and source trees.')
    original = json.loads((ROOT / 'VERIFICATION_v3_2_5.json').read_text(encoding='utf-8'))
    if (manifest['settings']['code_sha256'] != original['review_pilot_code_sha256'] or
            manifest['settings']['review_prompt_sha256'] != original['review_prompt_sha256']):
        raise ValueError('Baseline must be the recorded original v3.2.5 reviewer run.')
    records = {json.loads(raw)['question_id']: json.loads(raw) for name, raw in files.items()
               if name.startswith('questions/')}
    expected_ids = {qid for qid, r in source['records'].items()
                    if r['phases']['structure']['status'] == 'valid'}
    if set(records) != expected_ids:
        raise ValueError('The complete v3.2.5 review baseline must be preserved.')
    for qid, record in records.items():
        tree = source['records'][qid]['phases']['structure']['result']['plan']
        if record['source_plan_sha256'] != digest(tree) or record['phases']['review']['status'] != 'observed':
            raise ValueError('Baseline tree identity/review completion mismatch.')
        previous.phase_cost(record['phases']['review'])
    audit = previous.read_audit()
    if len(audit['cases']) != 10 or len({case['question_id'] for case in audit['cases']}) != 10:
        raise ValueError('Use the fixed ten-tree development audit.')
    by_id = {s['question_id']: s for s in samples}
    selected = []
    for case in audit['cases']:
        qid = case['question_id']
        tree = source['records'][qid]['phases']['structure']['result']['plan']
        if case['plan_sha256'] != digest(tree):
            raise ValueError('Audit/tree identity mismatch.')
        if semantic_precheck(by_id[qid]['question'], tree)['errors']:
            raise ValueError('Selected tree unexpectedly triggers a code rule; controlled comparison blocked.')
        selected.append(by_id[qid])
    return {'source': source, 'baseline_manifest': manifest, 'baseline_records': records,
            'baseline_files': files, 'baseline_sha256': digest({
                name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()}),
            'samples': selected, 'audit': audit}


def review_result(llm, question, plan):
    llm.last_raw_output = None
    details = {}
    prompt = build_review_prompt(question, plan, include_types=False)
    verdict = review_plan(llm, question, plan, details=details, include_types=False)
    return {'verdict': verdict, 'raw_output': llm.last_raw_output, 'details': details,
            'judge_input': prompt, 'judge_input_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
            'role': 'observation_only', 'semantic_correctness': 'not_established',
            'node_types_visible_to_judge': False}


def export_reports(store, inputs):
    new_cost, old_cost, generation_cost = previous.add_cost(), previous.add_cost(), previous.add_cost()
    statuses, sources, handling = Counter(), Counter(), Counter()
    rows, cases, details = [], [], []
    incomplete = 0
    for sample, case in zip(store.samples, inputs['audit']['cases']):
        qid = sample['question_id']
        original = inputs['source']['records'][qid]['phases']['structure']
        plan = original['result']['plan']
        old = inputs['baseline_records'][qid]['phases']['review']
        new = store.read(qid)['phases'].get('review', {})
        old_verdict, new_verdict = previous.verdict(old), previous.verdict(new)
        new_result, old_result = new.get('result', {}), old['result']
        metadata = new_result.get('details', {})
        c_new, c_old = previous.phase_cost(new), previous.phase_cost(old)
        new_cost, old_cost = previous.add_cost(new_cost, c_new), previous.add_cost(old_cost, c_old)
        generation_cost = previous.add_cost(generation_cost, previous.phase_cost(original))
        incomplete += new.get('status') != 'observed'
        statuses[new_verdict['status']] += 1
        if new:
            sources[metadata.get('source', 'backend_error')] += 1
            handling[metadata.get('response_status', new['status'])] += 1
        row = {'original_index': case['index'], 'question_id': qid, 'question': sample['question'],
               'plan_sha256': digest(plan), 'analyst_expected_status': case['expected_status'],
               'analyst_rationale': case['rationale'], 'old_v325_status': old_verdict['status'],
               'new_status': new_verdict['status'], 'new_model_status': metadata.get('model_status'),
               'response_status': metadata.get('response_status'),
               'old_errors': json.dumps(old_verdict['errors'], ensure_ascii=False),
               'new_errors': json.dumps(new_verdict['errors'], ensure_ascii=False),
               'old_raw_output': old_result.get('raw_output'), 'new_raw_output': new_result.get('raw_output'),
               'old_input_tokens': c_old['prompt_tokens'], 'old_output_tokens': c_old['completion_tokens'],
               'old_total_tokens': c_old['total_tokens'], 'new_input_tokens': c_new['prompt_tokens'],
               'new_output_tokens': c_new['completion_tokens'], 'new_total_tokens': c_new['total_tokens'],
               'new_calls': c_new['llm_calls'], 'phase_error': new.get('error', '')}
        rows.append(row)
        cases.append({**case, 'old_status': old_verdict['status'], 'new_status': new_verdict['status'],
                      'new_errors': new_verdict['errors']})
        details += [f"## Original sample {case['index']}: {qid}", '', sample['question'], '',
                    'Saved typed tree (unchanged; JSON is not sent to the judge):',
                    markdown_code_block(json.dumps(plan, ensure_ascii=False, indent=2), 'json'), '',
                    'Exact new judge input:', markdown_code_block(new_result.get('judge_input') or
                        build_review_prompt(sample['question'], plan, include_types=False)), '',
                    'Old v3.2.5 raw output:', markdown_code_block(old_result.get('raw_output') or '(none)'), '',
                    'New raw output:', markdown_code_block(new_result.get('raw_output') or '(none)'), '',
                    'New effective verdict:', markdown_code_block(json.dumps(new_verdict, ensure_ascii=False), 'json'), '',
                    'Analyst reference (not sent to model): ' + case['rationale'], '',
                    'Phase error: ' + new.get('error', ''), '']
    counts = {version: {expected: dict(Counter(c[version + '_status'] for c in cases
                 if c['expected_status'] == expected)) for expected in ('valid', 'revise')}
              for version in ('old', 'new')}
    identity = store.manifest.get('runtime_identity')
    same_runtime = identity == inputs['baseline_manifest'].get('runtime_identity') if identity else None
    summary = {'mode': 'v3.2.5_hide_node_types_ten_saved_trees', 'requested': 10,
               'original_cohort_size': 40, 'unselected_questions_not_run': 30,
               'original_indices': [c['index'] for c in cases], 'incomplete_questions': incomplete,
               'new_status': dict(statuses), 'review_source': dict(sources), 'response_status': dict(handling),
               'new_review_cost': new_cost, 'previous_v325_review_cost_same_10': old_cost,
               'historical_generation_cost_same_10': generation_cost,
               'review_token_difference_if_complete': new_cost['total_tokens'] - old_cost['total_tokens']
                   if not incomplete else None,
               'inference_backend': store.manifest['settings']['backend'],
               'runtime_identity': identity, 'runtime_matches_v325': same_runtime,
               'source_trees_sha256': inputs['source']['sha256'],
               'v325_baseline_sha256': inputs['baseline_sha256'],
               'new_tree_generation_calls': 0, 'semantic_repair_calls': 0,
               'node_type_assignments_preserved': True, 'node_types_visible_to_judge': False,
               'whole_method_token_condition': {'status': 'not_established_subset_review_only',
                    'full_token_condition_met': None,
                    'note': 'Ten selected reviews only; never compare this subset cost with forty-question '
                            'Standard RAG. Cached generation is not free production planning. Full planning, '
                            'review, repair, answering and retries on all same questions remain unmeasured.'},
               'selected_development_audit': {'scope': inputs['audit']['scope'], 'decision_counts': counts,
                    'cases': cases, 'independent_accuracy_estimate': False,
                    'reason_correctness': 'Inspect each reason manually; valid count alone is not success.'},
               'semantic_correctness_measured': False, 'answer_accuracy_measured': False,
               'cost_note': 'Old and new costs cover exactly the same ten trees and include phase history. '
                            'Backend errors/interrupted attempts count. Only source node annotations and their '
                            'notation guide/header are hidden; v3.2.5 verdict schema and logic are retained.'}
    if same_runtime is False:
        summary['runtime_note'] = 'Runtime differs from v3.2.5; this is not a controlled same-runtime comparison.'
    output = store.output.parent
    atomic_json(output / 'summary.json', summary)
    with store.output.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    (output / 'review.md').write_text('\n'.join([
        '# v3.2.5: node type labels hidden, ten fixed development trees', '',
        'Questions, trees and types remain unchanged. No generation, repair or answering.',
        'The preselected audit is not independent accuracy; inspect decision AND reason.', '',
        markdown_code_block(json.dumps(summary, ensure_ascii=False, indent=2), 'json'), '', *details]), encoding='utf-8')
    archive = output.with_name(output.name + '_results.zip')
    temporary = archive.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
        for path in [store.output, output / 'summary.json', output / 'review.md',
                     *sorted(store.directory.rglob('*.json'))]:
            zipped.write(path, output.name + '/' + path.relative_to(output).as_posix())
        for prefix, files in [('source_v3_2_4', inputs['source']['files']),
                              ('baseline_v3_2_5', inputs['baseline_files'])]:
            for name, raw in files.items(): zipped.writestr(output.name + '/' + prefix + '/' + name, raw)
    temporary.replace(archive)
    return summary


def run_pilot(inputs, output_dir, *, retry_errors=False, report_only=False, model_factory=None):
    output = Path(output_dir).expanduser().resolve()
    for original in (previous.SOURCE.resolve(), BASELINE.resolve()):
        if output == original or original in output.parents or output in original.parents:
            raise ValueError('Use a separate output directory; source snapshots are read-only.')
    settings = {k: inputs['baseline_manifest']['settings'][k] for k in (
        'model', 'model_revision', 'seed', 'use_4bit', 'require_cuda', 'max_input_tokens',
        'intermediate_tokens', 'plan_tokens', 'max_nodes', 'plan_attempts')}
    settings.update(schema_version=1, mode=OUTPUT_NAME, n_samples=10, code_sha256=code_digest(),
                    source_sha256=inputs['source']['sha256'], baseline_sha256=inputs['baseline_sha256'],
                    audit_sha256=digest(inputs['audit']), node_types_visible_to_judge=False,
                    backend='injected_test' if model_factory else 'LocalQwen', semantic_repair_attempts=0)
    if report_only and not (output / 'reviews.csv.state/manifest.json').exists():
        raise ValueError('No existing run to report.')
    store = RunStore(output / 'reviews.csv', settings, lambda: inputs['samples'])
    def pending(sample):
        return should_run(store.read(sample['question_id'])['phases'].get('review', {}), retry_errors)
    summary = export_reports(store, inputs)
    if report_only or not any(pending(s) for s in store.samples): return summary
    llm, identity = (model_factory or create_model)(settings)
    store.bind_runtime(identity)
    try:
        for i, sample in enumerate(store.samples, 1):
            if not pending(sample): continue
            qid = sample['question_id']
            print(f'[{i}/10] Review saved tree without type labels: {qid}', flush=True)
            record = store.read(qid)
            plan = inputs['source']['records'][qid]['phases']['structure']['result']['plan']
            record['source_plan_sha256'] = digest(plan)
            run_phase(store, record, 'review', lambda: review_result(llm, sample['question'], plan))
            export_reports(store, inputs)
    finally:
        summary = export_reports(store, inputs)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', default=str(ROOT / 'results' / OUTPUT_NAME))
    parser.add_argument('--retry-errors', action='store_true')
    parser.add_argument('--report-only', action='store_true')
    args = parser.parse_args()
    configure_logging()
    try:
        summary = run_pilot(load_inputs(), args.output_dir,
                            retry_errors=args.retry_errors, report_only=args.report_only)
    except KeyboardInterrupt:
        print('Interrupted; rerun the same command to resume missing reviews. Results ZIP preserved.')
        return 130
    except Exception as exc:
        print(f'Experiment blocked: {type(exc).__name__}: {exc}')
        return 2
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    output = Path(args.output_dir).expanduser().resolve()
    print('Results ZIP:', output.with_name(output.name + '_results.zip'))
    return 0 if summary['incomplete_questions'] == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
