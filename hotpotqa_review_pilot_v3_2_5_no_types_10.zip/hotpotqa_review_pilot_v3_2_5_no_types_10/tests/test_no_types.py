"""Controlled-input, fixed-cohort and resume/cost tests; no live model quality claim."""
import copy
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import review_no_types as pilot
from hotpotqa_operadic_rag.contracts import expand_typed_plan
from hotpotqa_operadic_rag.decomposition import build_review_prompt, REVIEW_SYSTEM
from test_decomposition_pilot import CHAIN, ScriptedModel


class DisplayTests(unittest.TestCase):
    def test_only_display_labels_change_and_source_types_are_untouched(self):
        plan = copy.deepcopy(CHAIN)
        plan['nodes'][0]['question'] = 'Which person wrote the literal q7:date in The Lantern?'
        original = copy.deepcopy(plan)
        hidden = expand_typed_plan(plan, include_types=False)
        self.assertEqual(hidden, '[answer q2 | Where was [answer q1 | Which person wrote the literal '
                         'q7:date in The Lantern?] born?]')
        self.assertEqual(plan, original)
        question = '  Where was that person born?\nKeep the qualifier.  '
        typed = build_review_prompt(question, plan)
        expected_typed = (REVIEW_SYSTEM + '\nOriginal question:\n' + question +
            '\nFinal node ID: q2\nExpanded typed tree:\n' + expand_typed_plan(plan))
        self.assertEqual(typed, expected_typed)
        no_types = build_review_prompt(question, plan, include_types=False)
        self.assertEqual(no_types, REVIEW_SYSTEM.replace('[answer q1:person | ...]', '[answer q1 | ...]') +
            '\nOriginal question:\n' + question + '\nFinal node ID: q2\nExpanded tree:\n' + hidden)
        self.assertIn(' vs ', no_types, 'Output schema must remain the v3.2.5 schema in this experiment.')

    def test_hidden_labels_do_not_disable_validation_or_allow_clipping(self):
        broken = copy.deepcopy(CHAIN)
        broken['nodes'][1]['dependencies']['q1'] = 'place'
        with self.assertRaises(ValueError): expand_typed_plan(broken, include_types=False)
        with self.assertRaisesRegex(ValueError, 'nothing was truncated'):
            expand_typed_plan(CHAIN, max_chars=5, include_types=False)
        with self.assertRaises(ValueError): expand_typed_plan(CHAIN, include_types='false')


class TenTreeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inputs = pilot.load_inputs()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.output = Path(self.tmp.name) / 'no_types'
        self.loads = 0
        self.model = ScriptedModel(verdicts=self.replies())

    def replies(self):
        return [self.inputs['baseline_records'][s['question_id']]['phases']['review']['result']['raw_output']
                for s in self.inputs['samples']]

    def factory(self, settings):
        self.loads += 1
        self.assertEqual((settings['max_nodes'], settings['max_input_tokens'], settings['intermediate_tokens']),
                         (12, 8500, 512))
        return self.model, {'backend': 'scripted-test'}

    def run_pilot(self, **kwargs):
        with redirect_stdout(io.StringIO()), patch('decomposition_pilot.generate_plan',
                side_effect=AssertionError('No generation allowed')), patch(
                'hotpotqa_operadic_rag.decomposition.generate_plan',
                side_effect=AssertionError('No generation allowed')):
            return pilot.run_pilot(self.inputs, self.output, model_factory=self.factory, **kwargs)

    def test_exact_ten_immutable_trees_and_inputs_no_labels_or_annotation_leak(self):
        source_before = copy.deepcopy(self.inputs['source']['records'])
        summary = self.run_pilot()
        self.assertEqual(summary['original_indices'], [8, 10, 13, 14, 15, 23, 25, 29, 35, 38])
        self.assertEqual(summary['new_review_cost']['llm_calls'], 10)
        self.assertEqual(summary['new_tree_generation_calls'], 0)
        self.assertEqual(summary['semantic_repair_calls'], 0)
        self.assertEqual(summary['new_review_cost']['retrieval_steps'], 0)
        self.assertEqual(summary['new_status'], {'revise': 10})
        self.assertEqual(summary['unselected_questions_not_run'], 30)
        self.assertEqual(self.model.messages, [])
        self.assertEqual(self.inputs['source']['records'], source_before)
        for prompt, sample in zip(self.model.prompts, self.inputs['samples']):
            tree = source_before[sample['question_id']]['phases']['structure']['result']['plan']
            self.assertEqual(prompt, build_review_prompt(sample['question'], tree, include_types=False))
            for case in self.inputs['audit']['cases']:
                self.assertNotIn(case['rationale'], prompt)
            self.assertNotRegex(prompt, r'\[answer q\d+:(?:person|organization|place|date|number|work|boolean|other) \|')
            record = json.loads((self.output / 'reviews.csv.state/questions' / (sample['question_id']+'.json')).read_text())
            self.assertEqual(set(record['phases']), {'review'})
            self.assertEqual(record['phases']['review']['result']['judge_input'], prompt)
        self.assertEqual(self.run_pilot(), summary)
        self.assertEqual(self.run_pilot(report_only=True), summary)
        self.assertEqual(self.loads, 1)

    def test_cost_pairs_only_ten_cases_and_cannot_claim_full_method_savings(self):
        summary = self.run_pilot()
        expected = sum(self.inputs['baseline_records'][s['question_id']]['phases']['review']['telemetry']['total_tokens']
                       for s in self.inputs['samples'])
        self.assertEqual(summary['previous_v325_review_cost_same_10']['total_tokens'], expected)
        self.assertEqual(summary['previous_v325_review_cost_same_10']['llm_calls'], 10)
        self.assertEqual(summary['new_review_cost']['total_tokens'], 150)
        self.assertEqual(summary['review_token_difference_if_complete'], 150 - expected)
        self.assertEqual(summary['whole_method_token_condition']['status'], 'not_established_subset_review_only')
        self.assertIsNone(summary['whole_method_token_condition']['full_token_condition_met'])
        self.assertFalse(summary['selected_development_audit']['independent_accuracy_estimate'])
        self.assertEqual(summary['selected_development_audit']['decision_counts']['old'],
                         {'valid': {'revise': 6}, 'revise': {'revise': 4}})
        self.assertEqual(summary['inference_backend'], 'injected_test')

    def test_interruption_resumes_missing_reviews_and_counts_all_attempts(self):
        replies = self.replies()
        self.model = ScriptedModel(verdicts=[replies[0], KeyboardInterrupt()])
        with self.assertRaises(KeyboardInterrupt): self.run_pilot()
        partial = json.loads((self.output / 'summary.json').read_text())
        self.assertIsNone(partial['review_token_difference_if_complete'])
        self.assertEqual(partial['new_review_cost']['llm_calls'], 2)
        self.model = ScriptedModel(verdicts=replies[1:])
        summary = self.run_pilot()
        self.assertEqual(len(self.model.prompts), 9)
        self.assertEqual(summary['new_review_cost']['llm_calls'], 11)
        self.assertEqual(summary['incomplete_questions'], 0)

    def test_format_error_is_observed_without_automatic_extra_review_or_repair(self):
        self.model = ScriptedModel(verdicts=['not JSON'] + self.replies()[1:])
        summary = self.run_pilot()
        self.assertEqual(summary['new_status']['invalid_response'], 1)
        self.assertEqual(summary['new_review_cost']['llm_calls'], 10)
        self.run_pilot(retry_errors=True)
        self.assertEqual(self.loads, 1)

    def test_backend_error_is_retried_only_explicitly_with_cost_retained(self):
        self.model = ScriptedModel(verdicts=[RuntimeError('GPU failure')])
        with self.assertRaisesRegex(RuntimeError, 'GPU failure'): self.run_pilot()
        self.model = ScriptedModel(verdicts=self.replies()[1:])
        self.assertEqual(self.run_pilot()['incomplete_questions'], 1)
        self.model = ScriptedModel(verdicts=self.replies()[:1])
        summary = self.run_pilot(retry_errors=True)
        self.assertEqual(summary['new_review_cost']['llm_calls'], 11)
        self.assertEqual(summary['incomplete_questions'], 0)

    def test_checkpoint_is_not_reused_after_code_or_baseline_change(self):
        self.run_pilot()
        with patch.object(pilot, 'code_digest', return_value='changed'):
            with self.assertRaisesRegex(ValueError, 'settings/code differ'): self.run_pilot()
        changed = dict(self.inputs, baseline_sha256='changed')
        with self.assertRaisesRegex(ValueError, 'settings/code differ'):
            pilot.run_pilot(changed, self.output, model_factory=self.factory)

    def test_report_only_and_source_overlap_never_load_model(self):
        with self.assertRaisesRegex(ValueError, 'No existing'): self.run_pilot(report_only=True)
        for output in (pilot.BASELINE, pilot.previous.SOURCE, pilot.BASELINE / 'output'):
            with self.assertRaisesRegex(ValueError, 'separate output'):
                pilot.run_pilot(self.inputs, output, model_factory=self.factory)
        self.assertEqual(self.loads, 0)

    def test_archive_preserves_baselines_byte_for_byte_and_saves_inputs(self):
        self.run_pilot()
        with zipfile.ZipFile(self.output.with_name('no_types_results.zip')) as archive:
            for prefix, files in [('source_v3_2_4', self.inputs['source']['files']),
                                  ('baseline_v3_2_5', self.inputs['baseline_files'])]:
                for name, raw in files.items():
                    self.assertEqual(archive.read('no_types/' + prefix + '/' + name), raw)
            report = archive.read('no_types/review.md').decode('utf-8')
            for prompt in self.model.prompts: self.assertIn(prompt, report)
        for name, raw in self.inputs['baseline_files'].items():
            self.assertEqual((pilot.BASELINE / name).read_bytes(), raw)


if __name__ == '__main__':
    unittest.main()
