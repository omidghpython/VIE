"""Guidance delivery and isolation checks; not semantic/model-quality tests."""
import unittest
from hotpotqa_operadic_rag.decomposition import ROLE_IDENTITY_HINT, PLAN_SYSTEM, plan_instructions, generate_plan
from hotpotqa_operadic_rag.semantic_checks import answer_target
from test_grounded_revision import Scripted
from test_target_phrase import atomic

class RoleIdentityTests(unittest.TestCase):
    def test_guidance_only_once_for_coordinated_target(self):
        p=plan_instructions('Which writer and director is credited?')
        self.assertEqual(p.count(ROLE_IDENTITY_HINT),1)
        self.assertTrue(p.startswith(PLAN_SYSTEM))
    def test_does_not_assert_one_person_from_types(self):
        self.assertIn('If one person is requested',ROLE_IDENTITY_HINT)
        self.assertIn('If distinct people are requested',ROLE_IDENTITY_HINT)
        self.assertIn('Matching person types alone do not establish identity',ROLE_IDENTITY_HINT)
        self.assertIn('Preserve ambiguity rather than guess',ROLE_IDENTITY_HINT)
    def test_no_guidance_for_explicit_distinct_people(self):
        for q in ('Which writer and which director worked together?',
                  'Which writer and another director worked together?',
                  'Which writer and director are siblings?'):
            self.assertNotIn(ROLE_IDENTITY_HINT,plan_instructions(q))
    def test_no_guidance_from_quoted_title(self):
        self.assertNotIn(ROLE_IDENTITY_HINT,plan_instructions('Which film is titled "Which writer and director?"?'))
    def test_no_guidance_for_mixed_type_or_unknown_role(self):
        for q in ('Which writer and company?', 'Which writer and engraver?'):
            self.assertNotIn(ROLE_IDENTITY_HINT,plan_instructions(q))
    def test_validator_target_remains_original(self):
        self.assertEqual(answer_target('Which writer and director is credited?'),{'head':'writer','type':'person'})
        self.assertEqual(answer_target('What type of product is used?'),{'head':'type','type':'other'})
    def test_original_question_and_guidance_survive_structural_retry(self):
        q='Which writer and director is credited for the second film in 1985?'
        m=Scripted([{},atomic(q)]);_,trace=generate_plan(m,q)
        self.assertEqual(len(trace),2)
        self.assertEqual(m.messages[0][-1]['content'],q)
        for messages in m.messages:
            self.assertEqual(messages[0]['content'],plan_instructions(q))
            self.assertEqual(messages[0]['content'].count(ROLE_IDENTITY_HINT),1)
        self.assertTrue(m.messages[1][-1]['content'].startswith(q+'\nInvalid tree:\n'))
