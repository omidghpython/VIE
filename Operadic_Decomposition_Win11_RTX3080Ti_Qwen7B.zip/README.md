# Operadic Question Decomposition — Windows 11 / RTX 3080 Ti

This modular Python application **only decomposes questions**. It does not retrieve documents, answer the original question or subquestions, or calculate answer-consistency scores. Semantic correctness requires human review.

## Your profile

| Setting | Value |
|---|---|
| Guest OS | Windows 11 x64, running under VMware |
| GPU | NVIDIA RTX 3080 Ti, 12GB VRAM, visible inside the guest |
| Model | `qwen2.5:7b-instruct-q4_K_M` through local Ollama |
| Precision | Q4_K_M quantization, not 7B FP16 |
| Context / output | 8192 / 1536 tokens |
| Scope | Question decomposition only |

Q4 quantization keeps model memory practical for 12GB VRAM. FP16 7B weights alone are roughly 14GB before runtime/context overhead, so FP16 is not this profile's default. GPU memory availability and other loaded models still matter. Allocate at least about 16GB guest RAM if possible (24–32GB gives more headroom) and at least 15GB free on the user-profile drive for software/model/temp files. These are planning guidelines, not measured guarantees.

You confirmed that `nvidia-smi` in the VMware guest already lists the GPU. The installer checks this again and **keeps the working driver**. It does not change the hypervisor or host configuration.

## Install and run

1. Extract the entire ZIP, for example into `C:\OperadicDecomposition`. Do not run files directly inside the ZIP.
2. Double-click **`INSTALL_WINDOWS.cmd`** as your normal Windows user. Internet access is needed for software/model downloads. Approve official Windows installation dialogs if shown.
3. When installation reports `READY`, double-click **`RUN_WINDOWS.cmd`** for one question.
4. Use **`RUN_PILOT30.cmd`** to run the Persian 30-question pilot. It creates a new results directory each time.

The installer:

- checks Windows x64, the visible RTX 3080 Ti, approximate VRAM, RAM and free disk;
- installs Python 3.12 if no compatible x64 Python >=3.10 exists, using WinGet;
- installs Ollama if absent, using WinGet;
- creates a local `.venv` and checks `requirements.txt`;
- runs the offline software tests;
- starts local Ollama if necessary, without terminating an existing service;
- downloads the selected 7B model using `ollama pull`;
- loads the model with an **empty prompt**, then checks reported GPU residency;
- writes installation and diagnostic logs to `install_logs`.

No question is answered by the installation check. The ZIP contains source, scripts, tests and pilot questions, **not** multi-gigabyte model weights or third-party installers. Re-running installation reuses an existing environment/model where possible. It never deletes your results, removes a driver, or reboots Windows automatically.

### Required software, and what is not required

Python, Ollama and a compatible NVIDIA driver in the Windows guest are required. Python runtime dependencies are standard-library only. A separate CUDA Toolkit, cuDNN installation, PyTorch, Transformers or embedding model is **not required** for this Ollama-based pipeline; Ollama supplies its inference runtime.

The installer uses WinGet package IDs `Python.Python.3.12` and `Ollama.Ollama`, from the `winget` source. If WinGet is absent, install/update **Microsoft App Installer** from Microsoft Store and rerun, or install Python and Ollama from their official sites first:

- https://www.python.org/downloads/windows/
- https://ollama.com/download/windows
- https://www.nvidia.com/Download/index.aspx

External downloads were not performed or installed into your VM from this chat. Availability of those services and current WinGet manifests is checked on your computer when you run the installer.

### NVIDIA driver helper (only if needed)

Because your current driver works, do not replace it unnecessarily. If the guest driver is missing/broken, `INSTALL_GPU_DRIVER.cmd` can launch a downloaded NVIDIA `.exe` **after checking its Authenticode signature and asking for confirmation**. NVIDIA's own installer handles compatibility and any UAC prompt. Save work and reboot yourself if NVIDIA requests it.

Alternatively, from PowerShell, supply an exact official NVIDIA HTTPS download URL or local installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\windows\install.ps1 -NvidiaDriverInstaller "C:\Downloads\nvidia-driver.exe"
# Or use -NvidiaDriverUrl with the exact .exe URL selected from NVIDIA.
```

The URL helper accepts only approved NVIDIA download hosts, refuses redirects, and checks the downloaded signature before launch. It does not guess a current driver version. Host drivers, VMware passthrough/vGPU setup and enterprise driver policies cannot be safely auto-configured by this guest installer. The `.cmd` wrappers use execution-policy bypass for that process only; they do not permanently change PowerShell policy or disable security software.

## Commands

Run these from the extracted project folder after installation:

```powershell
.venv\Scripts\python.exe -m decomposition_lab plan --question "In which city was the author of Hamlet born?" --output plan.json
.venv\Scripts\python.exe -m decomposition_lab validate --plan plan.json
.venv\Scripts\python.exe -m decomposition_lab batch --language en
.venv\Scripts\python.exe -m decomposition_lab doctor --load-model
```

`validate` is entirely offline. `doctor --load-model` requests an empty-prompt model load, not an answer. Without `--load-model`, the model must already be resident for the residency check to pass.

GPU mode is the default. It requests GPU offload and checks `/api/ps` after successful generation. If the requested model has no positive reported VRAM residency, the run fails rather than accepting an unverified CPU fallback. **Positive residency does not prove that every layer/token ran exclusively on the GPU.** Inspect `ollama ps` and the saved diagnostic data for actual offload; free VRAM, context and concurrent models affect it.

CPU is only an explicit override, for example `--device cpu`. There is no automatic model downgrade or CPU fallback. Old 3B models are not deleted, but this application selects the specified 7B tag by default.

`configs/windows_rtx3080ti.json` records the profile and supplies model/package settings to the installer. Normal execution uses matching CLI defaults; per-run changes use `--model`, `--device`, `--context-tokens`, `--max-output-tokens`, `--max-nodes`, `--attempts` or `--timeout`. Editing the manifest alone does not override CLI defaults.

## Outputs and human review

Single runs produce a plan JSON and `NAME.review.csv`. Batch runs produce `results.json`, `summary.json`, `human_review.csv`, and one checkpoint per question. Existing result paths are not silently overwritten. Question text and raw model responses are logged locally; check logs for private data before sharing them.

Plans use `nodes` and `final`, with each node containing `id`, `question`, `dependencies` and `answer_type`. The validator enforces a typed rooted tree, not a general shared DAG. It checks JSON, slots, types, acyclicity and connectivity. It **cannot prove semantic equivalence**. An atomic question may use one node; an unchanged multi-hop question in one node must still be caught by human review.

`expanded_plan` displays nested question templates; it is not answer substitution and is not a semantic certificate. `semantic_status` remains `unreviewed`. Complete the review CSV with `yes/no/uncertain` for criteria and `correct/incorrect/uncertain` for `verdict`; record the reviewer and reasons. Do not equate valid JSON with correct decomposition.

The 30 sample questions are assistant-authored pilot material, not an official benchmark or human-validated gold standard: 10 one-hop, 10 two-hop and 10 multi-hop. Only the selected question is sent to the model, not group labels, IDs or expected plans. First-attempt and post-repair structural success are reported separately; failures and unattempted questions remain in the requested denominator. No semantic accuracy is fabricated.

## Modules

```text
decomposition_lab/
  backend.py       Local Ollama, GPU/CPU policy, context checks
  contracts.py     Strict JSON and typed-tree validation
  planner.py       Question-only generation and bounded repair
  doctor.py        GPU/model diagnostics; no QA
  cli.py           Single/batch runs and human-review exports
scripts/windows/   Installer, driver helper and shared functions
configs/           Target settings manifest
examples/          30 question-only pilot items
tests/             Offline controlled software tests
```

## Troubleshooting and verification limits

- GPU missing in `nvidia-smi`: fix the guest driver or host passthrough; VMware virtual 3D graphics is not sufficient for CUDA.
- Ollama cannot use GPU: inspect local logs, driver compatibility and `ollama ps`; close other GPU workloads or reduce context. The program will not silently declare GPU success.
- Port 11434 occupied: use the existing local Ollama service; the installer does not kill unrelated processes.
- Context budget exceeded: reduce question/repair size or increase context only if VRAM permits. The input guard is conservative and not tokenizer-exact.
- Invalid plan: review all attempts. Repairs fix structural errors, not guaranteed semantic errors.
- WinGet/Store/network policy blocks installation: use approved official installers or your administrator; do not disable security controls.

Run `python -m unittest discover -s tests -v` for offline tests. Their scripted model outputs are **not real Qwen accuracy measurements**. Windows installer scripts have static checks, but native Windows installation, actual VMware GPU offload and real Qwen7B quality have not been tested in this Linux workspace. `VERIFICATION.json` records the distinction. The local installer/doctor verifies your actual machine before reporting readiness.

This is an engineering implementation inspired by the two operadic-reasoning papers, not an exact reproduction of their experiments or a guarantee of correct decomposition.
