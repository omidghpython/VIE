"""Local Ollama adapter with explicit GPU/CPU policy, using the standard library.

The adapter never downloads a model and never sends prompts to a remote service.
JSON-schema output constrains syntax, not the meaning or accuracy of an answer.
"""
from __future__ import annotations

import json
import http.client
import math
import re
import socket
import time
from typing import Any
from urllib import error, parse, request


class BackendError(RuntimeError):
    """A local model call failed or did not produce a complete response."""


class _NoRedirect(request.HTTPRedirectHandler):
    """A local endpoint may not redirect private prompts to another endpoint."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise BackendError("Ollama HTTP redirects are disabled; use its local /api/chat endpoint.")


def _integer(name: str, value: Any, minimum: int, maximum: int) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError(f"{name} must be an integer in {minimum}..{maximum}.")
    return value


class OllamaBackend:
    """Call a preinstalled model, requiring observed GPU residency by default.

    GPU mode requests all layers and checks Ollama's /api/ps after generation.
    Positive VRAM residency confirms GPU use is available to the loaded model;
    it does not prove every layer ran on GPU or identify a particular GPU card.
    CPU mode is an explicit opt-in (``num_gpu=0``), never an implicit fallback.

    ``stats`` contains per-call counts/timings/statuses, never prompt or answer text.
    ``timeout`` is a socket timeout, not a strict whole-call deadline: CPU generation
    may be slow, and callers should also keep the number of calls bounded.
    A conservative UTF-8-byte input guard reserves output space before each call.
    This is a heuristic (especially for non-Qwen models), not exact tokenization
    or a proof of how every server/model applies its chat template.
    """

    MAX_RESPONSE_BYTES = 4 * 1024 * 1024
    MAX_REQUEST_BYTES = 4 * 1024 * 1024
    TEMPLATE_RESERVE = 512

    def __init__(
        self,
        model: str = "qwen2.5:7b-instruct-q4_K_M",
        base_url: str = "http://127.0.0.1:11434",
        timeout: float = 180,
        context_tokens: int = 8192,
        max_output_tokens: int = 1536,
        threads: int = 0,
        device: str = "gpu",
    ):
        if not isinstance(model, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", model):
            raise ValueError("model must be a nonempty Ollama model name without whitespace.")
        if not isinstance(base_url, str) or any(c.isspace() for c in base_url):
            raise ValueError("base_url must be a local HTTP URL without whitespace.")
        try:
            parsed = parse.urlsplit(base_url)
            port = parsed.port
        except ValueError as exc:
            raise ValueError("Invalid local Ollama URL.") from exc
        if (
            parsed.scheme != "http"
            or parsed.hostname not in {"localhost", "127.0.0.1", "::1"}
            or parsed.username is not None
            or parsed.password is not None
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
            or (port is not None and not 1 <= port <= 65535)
        ):
            raise ValueError("Only local HTTP Ollama URLs (localhost, 127.0.0.1 or [::1]) are allowed; no credentials, path, query or fragment.")
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 3600:
            raise ValueError("timeout must be a finite number of seconds in (0, 3600].")
        if device not in ("gpu", "cpu"):
            raise ValueError("device must be 'gpu' or 'cpu'; CPU fallback is never automatic.")
        self.model = model
        self.device = device
        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)
        self.context_tokens = _integer("context_tokens", context_tokens, 512, 131072)
        self.max_output_tokens = _integer("max_output_tokens", max_output_tokens, 16, 32768)
        if self.max_output_tokens >= self.context_tokens:
            raise ValueError("max_output_tokens must be smaller than context_tokens, leaving room for the prompt.")
        self.threads = _integer("threads", threads, 0, 1024)
        self.stats: list[dict[str, Any]] = []
        # Do not forward local prompts through an HTTP proxy configured in the environment.
        self._opener = request.build_opener(request.ProxyHandler({}), _NoRedirect())

    def _gpu_residency(self) -> dict[str, Any]:
        """Observe the requested model's VRAM allocation without guessing offload."""
        req = request.Request(self.base_url + "/api/ps", headers={"Accept": "application/json"}, method="GET")
        try:
            with self._opener.open(req, timeout=self.timeout) as response:
                raw = response.read(self.MAX_RESPONSE_BYTES + 1)
        except error.HTTPError as exc:
            code = exc.code
            exc.close()
            raise BackendError(f"Cannot verify GPU residency: Ollama /api/ps returned HTTP {code}. Update/check Ollama; no CPU fallback was accepted.") from exc
        except (error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError, http.client.HTTPException) as exc:
            raise BackendError("Cannot verify GPU residency from local Ollama /api/ps; no CPU fallback was accepted.") from exc
        if len(raw) > self.MAX_RESPONSE_BYTES:
            raise BackendError("GPU-residency response exceeded the size limit.")
        try:
            payload = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BackendError("Ollama /api/ps returned malformed JSON; GPU residency is unverified.") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("models"), list):
            raise BackendError("Ollama /api/ps has no model list; GPU residency is unverified.")
        for model in payload["models"]:
            if not isinstance(model, dict) or self.model not in (model.get("name"), model.get("model")):
                continue
            vram = model.get("size_vram")
            if type(vram) is not int or vram <= 0:
                continue
            observed = {"gpu_verification": "positive_vram_residency_observed", "size_vram": vram,
                        "full_gpu_offload_verified": False}
            for key in ("size", "context_length"):
                value = model.get(key)
                if type(value) is int and value >= 0:
                    observed[key] = value
            if isinstance(model.get("digest"), str):
                observed["digest"] = model["digest"]
            return observed
        raise BackendError(
            "GPU residency was not observed for the requested model. Check NVIDIA drivers and GPU "
            "passthrough inside the Windows VM. No silent CPU fallback is accepted; use --device cpu "
            "only if you intentionally want CPU execution."
        )

    def generate(self, messages: list[dict[str, str]], schema: dict | None = None) -> str:
        if not isinstance(messages, list) or not messages:
            raise ValueError("messages must be a nonempty list.")
        for message in messages:
            if (
                not isinstance(message, dict)
                or set(message) != {"role", "content"}
                or not isinstance(message["role"], str)
                or message["role"] not in {"system", "user", "assistant"}
                or not isinstance(message["content"], str)
            ):
                raise ValueError("Each message requires exactly role (system/user/assistant) and string content.")
        if schema is not None and not isinstance(schema, dict):
            raise ValueError("schema must be a JSON-schema object or None.")
        try:
            input_budget_units = sum(len(message["content"].encode("utf-8")) for message in messages) + self.TEMPLATE_RESERVE
        except UnicodeError as exc:
            raise ValueError("Message content must be valid UTF-8 text.") from exc
        available_input_units = self.context_tokens - self.max_output_tokens
        if input_budget_units > available_input_units:
            raise BackendError(
                f"Conservative input-context budget exceeded ({input_budget_units} byte-based units; "
                f"{available_input_units} available after reserving output). Reduce question/repair context "
                "or increase --context-tokens. No request was sent. This guard is not an exact tokenizer count."
            )
        options = {
            "temperature": 0,
            "num_gpu": 999 if self.device == "gpu" else 0,
            "num_ctx": self.context_tokens,
            "num_predict": self.max_output_tokens,
        }
        if self.threads:
            options["num_thread"] = self.threads
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "format": schema if schema is not None else "json",
            "options": options,
            "keep_alive": "5m",
        }
        try:
            body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
        except (ValueError, TypeError) as exc:
            raise ValueError("The request is not finite JSON-serializable data.") from exc
        if len(body) > self.MAX_REQUEST_BYTES:
            raise BackendError("The Ollama request is too large; reduce question and repair-context size.")
        req = request.Request(
            self.base_url + "/api/chat", data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        started = time.perf_counter()
        stat: dict[str, Any] = {
            "model": self.model, "status": "error", "cpu_only": self.device == "cpu",
            "device_requested": self.device,
            "gpu_verification": "not_requested" if self.device == "cpu" else "not_checked",
            "input_budget_units": input_budget_units,
            "available_input_units": available_input_units,
        }
        try:
            try:
                with self._opener.open(req, timeout=self.timeout) as response:
                    raw = response.read(self.MAX_RESPONSE_BYTES + 1)
            except error.HTTPError as exc:
                # Do not include arbitrary server response bodies or prompts in logs/errors.
                code = exc.code
                exc.close()
                if code == 404:
                    raise BackendError(f"Ollama returned HTTP 404. Check the model name and install it manually with: ollama pull {self.model}") from exc
                raise BackendError(f"Ollama returned HTTP {code}; check the local server and installed model.") from exc
            except (error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError, http.client.HTTPException) as exc:
                raise BackendError(
                    "Cannot complete the local Ollama call. Start Ollama, install the selected model, "
                    "and check its logs. Loading/generation may require a larger --timeout or a smaller model."
                ) from exc
            if len(raw) > self.MAX_RESPONSE_BYTES:
                raise BackendError("Ollama response exceeded the size limit.")
            try:
                result = json.loads(raw)
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise BackendError("Ollama returned malformed JSON.") from exc
            if not isinstance(result, dict):
                raise BackendError("Ollama returned a non-object response.")
            if result.get("error"):
                raise BackendError("Ollama reported a model error; inspect the local server logs.")
            if result.get("done_reason") == "length":
                raise BackendError("Model output was truncated. Increase --max-output-tokens (and context if needed), or request a smaller plan.")
            if result.get("done") is not True:
                raise BackendError("Ollama did not mark the non-streaming response as complete.")
            message = result.get("message")
            if not isinstance(message, dict) or not isinstance(message.get("content"), str) or not message["content"].strip():
                raise BackendError("Ollama returned no nonempty text content.")
            for key in ("prompt_eval_count", "eval_count", "total_duration", "load_duration", "prompt_eval_duration", "eval_duration"):
                value = result.get(key)
                if type(value) is int and value >= 0:
                    stat[key] = value
            stat["generation_completed"] = True
            if self.device == "gpu":
                stat["gpu_verification"] = "failed"
                stat.update(self._gpu_residency())
            stat["status"] = "ok"
            return message["content"]
        finally:
            stat["elapsed_seconds"] = round(time.perf_counter() - started, 6)
            self.stats.append(stat)
