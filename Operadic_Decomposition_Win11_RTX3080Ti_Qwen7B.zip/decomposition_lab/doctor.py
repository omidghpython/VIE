"""Read-only device diagnostics; optional model loading uses an EMPTY prompt."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import io
import http.client
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
from urllib.request import Request

from .backend import BackendError, OllamaBackend


def _nvidia_smi():
    executable = shutil.which("nvidia-smi")
    if not executable and os.name == "nt":
        for base in (os.environ.get("ProgramFiles", "C:/Program Files"), os.environ.get("SystemRoot", "C:/Windows")):
            for suffix in ("NVIDIA Corporation/NVSMI/nvidia-smi.exe", "System32/nvidia-smi.exe"):
                candidate = Path(base) / suffix
                if candidate.is_file():
                    executable = str(candidate)
                    break
    if not executable:
        raise RuntimeError("nvidia-smi is not available in this guest. Check GPU passthrough and the NVIDIA guest driver.")
    process = subprocess.run([executable, "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, timeout=15, check=False)
    if process.returncode != 0:
        raise RuntimeError("nvidia-smi could not access the GPU; inspect the NVIDIA driver inside the guest.")
    gpus = []
    for row in csv.reader(io.StringIO(process.stdout)):
        if len(row) != 3:
            continue
        name, memory, driver = (value.strip() for value in row)
        try:
            memory_mib = int(memory)
        except ValueError:
            continue
        gpus.append({"name": name, "memory_total_mib": memory_mib, "driver_version": driver})
    if not gpus:
        raise RuntimeError("nvidia-smi returned no usable GPU information.")
    return gpus


def _http(backend, route, payload=None):
    data = None if payload is None else json.dumps(payload, allow_nan=False).encode("utf-8")
    request = Request(backend.base_url + route, data=data,
                      headers={"Accept": "application/json", "Content-Type": "application/json"},
                      method="GET" if data is None else "POST")
    with backend._opener.open(request, timeout=backend.timeout) as response:
        raw = response.read(backend.MAX_RESPONSE_BYTES + 1)
    if len(raw) > backend.MAX_RESPONSE_BYTES:
        raise ValueError("Diagnostic response exceeds the size limit.")
    value = json.loads(raw)
    if not isinstance(value, dict) or value.get("error"):
        raise ValueError("Ollama returned an invalid/error diagnostic response.")
    return value


def diagnose(model="qwen2.5:7b-instruct-q4_K_M", endpoint="http://127.0.0.1:11434",
             load_model=False, context_tokens=8192, timeout=180):
    backend = OllamaBackend(model=model, base_url=endpoint, context_tokens=context_tokens,
                            timeout=timeout, device="gpu")
    report = {"status": "blocked", "model": model, "platform": platform.platform(),
              "time_utc": datetime.now(timezone.utc).isoformat(), "checks": {}, "errors": [],
              "retrieval_calls": 0, "question_answering_calls": 0, "decomposition_calls": 0,
              "model_load_requested": bool(load_model), "full_gpu_offload_verified": False}
    try:
        gpus = _nvidia_smi()
        report["checks"]["nvidia_gpus"] = gpus
        if not any(re.search(r"RTX\s*3080\s*Ti", gpu["name"], re.I) and gpu["memory_total_mib"] >= 11000 for gpu in gpus):
            raise RuntimeError("The requested RTX 3080 Ti with approximately 12GB VRAM was not found inside the guest.")
        report["checks"]["target_gpu_present"] = True
    except (RuntimeError, OSError, subprocess.SubprocessError) as exc:
        report["errors"].append(str(exc))
        return report
    try:
        version = _http(backend, "/api/version")
        if not isinstance(version.get("version"), str):
            raise ValueError("The local endpoint did not identify an Ollama version.")
        report["checks"]["ollama_version"] = version["version"]
        tags = _http(backend, "/api/tags")
        if not isinstance(tags.get("models"), list):
            raise ValueError("Ollama did not provide the installed-model list.")
        installed = next((item for item in tags["models"] if isinstance(item, dict)
                          and model in (item.get("name"), item.get("model"))), None)
        if installed is None:
            raise RuntimeError(f"Model is not installed. Run: ollama pull {model}")
        report["checks"]["model_installed"] = True
        report["checks"]["model_digest"] = installed.get("digest")
        if load_model:
            loaded = _http(backend, "/api/generate", {
                "model": model, "prompt": "", "stream": False, "keep_alive": "5m",
                "options": {"num_gpu": 999, "num_ctx": context_tokens, "num_predict": 1},
            })
            if loaded.get("done") is not True:
                raise RuntimeError("Ollama did not confirm the empty-prompt model-load operation.")
        report["checks"]["gpu_residency"] = backend._gpu_residency()
        report["status"] = "ready"
    except (BackendError, RuntimeError, OSError, ValueError, http.client.HTTPException) as exc:
        report["errors"].append(str(exc))
    return report
