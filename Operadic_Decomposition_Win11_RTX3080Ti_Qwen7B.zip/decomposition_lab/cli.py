"""GPU-ready decomposition CLI and human-review exports. Never retrieves or answers."""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from uuid import uuid4

from . import __version__
from .backend import OllamaBackend
from .contracts import expand_plan, parse_json_object, validate_plan
from .doctor import diagnose
from .planner import Decomposer


REVIEW_FIELDS = [
    "id", "group", "question", "structural_status", "first_attempt_structurally_valid",
    "attempts_used", "semantic_status", "meaning_preserved", "constraints_preserved",
    "dependencies_correct", "decomposition_adequate", "answer_type_correct",
    "verdict", "reviewer", "notes",
]


def positive_int(value):
    try:
        number = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Expected a positive integer.") from exc
    if number <= 0:
        raise argparse.ArgumentTypeError("Expected a positive integer.")
    return number


def positive_seconds(value):
    try:
        number = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Expected finite positive seconds.") from exc
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError("Expected finite positive seconds.")
    return number


def _options(parser):
    parser.add_argument("--model", default="qwen2.5:7b-instruct-q4_K_M")
    parser.add_argument("--device", choices=("gpu", "cpu"), default="gpu", help="CPU fallback is explicit, never automatic.")
    parser.add_argument("--endpoint", default="http://127.0.0.1:11434", help="Local Ollama only.")
    parser.add_argument("--timeout", type=positive_seconds, default=180)
    parser.add_argument("--context-tokens", type=positive_int, default=8192)
    parser.add_argument("--max-output-tokens", type=positive_int, default=1536)
    parser.add_argument("--threads", type=int, default=0, help="CPU threads; 0 lets Ollama choose.")
    parser.add_argument("--max-nodes", type=positive_int, default=8)
    parser.add_argument("--attempts", type=positive_int, default=2, help="Total attempts, including the first.")


def build_parser():
    parser = argparse.ArgumentParser(description="Typed question decomposition only; no document retrieval or answers.")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)
    plan = sub.add_parser("plan", help="Decompose one question and export a human-review sheet.")
    _options(plan)
    plan.add_argument("--question", required=True)
    plan.add_argument("--output", type=Path, help="New JSON file. Also writes NAME.review.csv.")
    batch = sub.add_parser("batch", help="Run a question-only pilot and preserve all attempted outputs.")
    _options(batch)
    batch.add_argument("--questions", type=Path, default=Path("examples/questions30.json"))
    batch.add_argument("--language", choices=("fa", "en"), default="fa")
    batch.add_argument("--output-dir", type=Path, help="New directory; omitted creates a unique results/pilot_* directory.")
    validation = sub.add_parser("validate", help="Offline structural validation; does not call any model.")
    validation.add_argument("--plan", type=Path, required=True)
    validation.add_argument("--max-nodes", type=positive_int, default=8)
    interactive = sub.add_parser("interactive", help="Ask for one question and save the decomposition, not an answer.")
    _options(interactive)
    interactive.add_argument("--results", type=Path, default=Path("results"))
    doctor = sub.add_parser("doctor", help="Check guest GPU and Ollama; no questions are answered.")
    doctor.add_argument("--model", default="qwen2.5:7b-instruct-q4_K_M")
    doctor.add_argument("--endpoint", default="http://127.0.0.1:11434")
    doctor.add_argument("--context-tokens", type=positive_int, default=8192)
    doctor.add_argument("--timeout", type=positive_seconds, default=180)
    doctor.add_argument("--load-model", action="store_true", help="Load with an empty prompt, then inspect GPU residency.")
    doctor.add_argument("--output", type=Path)
    return parser


def _backend(args):
    return OllamaBackend(model=args.model, base_url=args.endpoint, timeout=args.timeout,
                         context_tokens=args.context_tokens, max_output_tokens=args.max_output_tokens,
                         threads=args.threads, device=args.device)


def _runtime(args):
    return {"version": __version__, "model": args.model, "cpu_only": args.device == "cpu",
            "device_requested": args.device,
            "context_tokens": args.context_tokens, "max_output_tokens": args.max_output_tokens,
            "max_nodes": args.max_nodes, "attempts_per_question": args.attempts,
            "retrieval_calls": 0, "question_answering_calls": 0,
            "time_utc": datetime.now(timezone.utc).isoformat()}


def _write_json(path, value, exclusive=True):
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    with Path(path).open("x" if exclusive else "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def _csv_cell(value):
    if isinstance(value, str) and value.lstrip(" \t\r\n\x00").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _review(path, rows, exclusive=True):
    with Path(path).open("x" if exclusive else "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=REVIEW_FIELDS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_cell(row.get(key, "")) for key in REVIEW_FIELDS})


def _row(result, qid="Q01", group="unspecified"):
    return {"id": qid, "group": group, "question": result["question"],
            "structural_status": result.get("structural_status", "not_run"),
            "first_attempt_structurally_valid": result.get("first_attempt_structurally_valid", ""),
            "attempts_used": result.get("attempts_used", 0),
            "semantic_status": "unreviewed"}


def _preflight_file(path):
    if path.exists() or path.is_symlink():
        raise ValueError(f"File already exists; choose a new name: {path}")
    if not path.parent.is_dir():
        raise ValueError(f"Output directory does not exist: {path.parent}")


def _single(args):
    review_path = None
    if args.output is not None:
        review_path = args.output.with_name(args.output.stem + ".review.csv")
        if args.output == review_path:
            raise ValueError("Use a .json output filename distinct from the review CSV.")
        _preflight_file(args.output)
        _preflight_file(review_path)
    decomposer = Decomposer(_backend(args), max_nodes=args.max_nodes, attempts=args.attempts)
    result = decomposer.decompose(args.question)
    result["runtime"] = _runtime(args)
    if args.output is None:
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    else:
        _write_json(args.output, result)
        _review(review_path, [_row(result)])
        print(f"Saved: {args.output.resolve()}\nHuman review: {review_path.resolve()}")
        print(f"Structure: {result['structural_status']}; semantics: unreviewed")
        if result.get("error"):
            print(f"Error: {result['error']}")
    return 0 if result["status"] == "planned" else 2


def _load_questions(path, language):
    if path.stat().st_size > 8_000_000:
        raise ValueError("Question dataset exceeds the size limit.")
    data = parse_json_object(path.read_text(encoding="utf-8-sig"))
    items = data.get("items")
    if not isinstance(items, list) or not 1 <= len(items) <= 1000:
        raise ValueError("Dataset needs an items list containing 1..1000 questions.")
    seen, selected = set(), []
    field = "question_fa" if language == "fa" else "question"
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Each question must be an object.")
        qid, group, question = item.get("id"), item.get("group", "unspecified"), item.get(field)
        if not isinstance(qid, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", qid) or qid in seen:
            raise ValueError("Question IDs must be unique safe ASCII identifiers.")
        if not isinstance(group, str) or not group.strip() or len(group) > 100:
            raise ValueError("Question group must be a short nonempty string.")
        if not isinstance(question, str) or not question.strip() or len(question) > 2000:
            raise ValueError(f"{qid}: missing or oversized {field} (maximum 2000 characters).")
        seen.add(qid)
        # No gold plan, group label, ID or alternate-language text reaches the model.
        selected.append({"id": qid, "group": group, "question": question.strip()})
    return selected


def _summary(items, results):
    def counts(subset):
        found = [results[item["id"]] for item in subset if item["id"] in results]
        first = sum(value.get("first_attempt_structurally_valid") is True for value in found)
        valid = sum(value.get("structural_status") == "valid" for value in found)
        return {"requested_count": len(subset), "attempted_count": len(found),
                "not_run_count": len(subset) - len(found),
                "first_attempt_structurally_valid_count": first,
                "final_structurally_valid_count": valid,
                "first_attempt_valid_fraction_of_all_requested": first / len(subset),
                "final_valid_fraction_of_all_requested": valid / len(subset)}
    return {"status": "completed" if len(results) == len(items) else "incomplete", **counts(items),
            "semantic_accuracy": None, "semantic_review": "human review required",
            "by_group": {group: counts([i for i in items if i["group"] == group])
                         for group in sorted({i["group"] for i in items})},
            "retrieval_calls": 0, "question_answering_calls": 0}


def _batch(args):
    items = _load_questions(args.questions, args.language)
    if args.output_dir is None:
        args.output_dir = Path("results") / f"pilot_{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}_{uuid4().hex[:8]}"
    if args.output_dir.exists() or args.output_dir.is_symlink():
        raise ValueError("Output directory already exists; choose a new run directory.")
    decomposer = Decomposer(_backend(args), max_nodes=args.max_nodes, attempts=args.attempts)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    checkpoints = args.output_dir / "questions"
    checkpoints.mkdir()
    metadata = {**_runtime(args), "language": args.language,
                "dataset_sha256": hashlib.sha256(args.questions.read_bytes()).hexdigest(),
                "group_counts": dict(Counter(item["group"] for item in items))}
    results = {}

    def checkpoint():
        summary = _summary(items, results)
        _write_json(args.output_dir / "summary.json", summary, exclusive=False)
        _write_json(args.output_dir / "results.json", {"metadata": metadata, "summary": summary,
                    "results": list(results.values())}, exclusive=False)
        rows = [_row(results.get(item["id"], {"question": item["question"]}), item["id"], item["group"]) for item in items]
        _review(args.output_dir / "human_review.csv", rows, exclusive=False)

    checkpoint()
    try:
        for number, item in enumerate(items, 1):
            result = decomposer.decompose(item["question"])
            result.update(id=item["id"], group=item["group"])
            results[item["id"]] = result
            _write_json(checkpoints / (item["id"] + ".json"), result)
            checkpoint()
            print(f"[{number}/{len(items)}] {item['id']}: {result['structural_status']}", flush=True)
            if result.get("structural_status") == "unavailable":
                print("Stopped: model execution unavailable. Remaining questions are recorded as not run.", file=sys.stderr)
                break
    except KeyboardInterrupt:
        checkpoint()
        raise
    summary = _summary(items, results)
    print(f"Saved: {args.output_dir.resolve()}")
    print("Semantic correctness is not automatically scored; complete human_review.csv.")
    return 0 if summary["status"] == "completed" else 2


def _validate(args):
    if args.plan.stat().st_size > 1_000_000:
        raise ValueError("Plan file is too large.")
    bundle = parse_json_object(args.plan.read_text(encoding="utf-8-sig"))
    plan = validate_plan(bundle.get("plan") if "plan" in bundle else bundle, max_nodes=args.max_nodes)
    print(json.dumps({"structural_status": "valid", "semantic_status": "unreviewed",
                      "expanded_plan": expand_plan(plan), "model_calls": 0,
                      "retrieval_calls": 0, "question_answering_calls": 0}, ensure_ascii=False, indent=2))
    return 0


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
    args = build_parser().parse_args(argv)
    try:
        if args.command == "doctor":
            if args.output:
                _preflight_file(args.output)
            result = diagnose(model=args.model, endpoint=args.endpoint, load_model=args.load_model,
                              context_tokens=args.context_tokens, timeout=args.timeout)
            if args.output:
                _write_json(args.output, result)
                print(f"Diagnostics saved: {args.output.resolve()}")
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["status"] == "ready" else 2
        if args.command == "interactive":
            print("Question decomposition only — no document retrieval or answering.")
            args.question = input("Question / سؤال: ").strip()
            if not args.question:
                raise ValueError("Question must not be empty.")
            args.results.mkdir(parents=True, exist_ok=True)
            args.output = args.results / f"plan_{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}_{uuid4().hex[:8]}.json"
            return _single(args)
        if args.command == "plan":
            return _single(args)
        if args.command == "batch":
            return _batch(args)
        return _validate(args)
    except (ValueError, OSError, UnicodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    except (KeyboardInterrupt, EOFError):
        print("Cancelled; no semantic correctness claim is made.", file=sys.stderr)
        return 130
