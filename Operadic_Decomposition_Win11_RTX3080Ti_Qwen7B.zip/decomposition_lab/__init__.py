"""Question decomposition only: no retrieval and no question answering."""

__version__ = "0.2.0"
