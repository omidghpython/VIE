@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "PYTHONUTF8=1"
pushd "%~dp0"
if errorlevel 1 exit /b 2
if not exist ".venv\Scripts\python.exe" goto missing
".venv\Scripts\python.exe" -m decomposition_lab batch --questions examples/questions30.json --language fa
set "RUN_EXIT=%errorlevel%"
goto finish
:missing
echo Run INSTALL_WINDOWS.cmd first.
set "RUN_EXIT=2"
:finish
popd
pause
exit /b %RUN_EXIT%
