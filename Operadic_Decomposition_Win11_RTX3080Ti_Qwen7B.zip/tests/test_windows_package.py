"""Static package consistency checks; NOT native Windows execution tests."""
import json
from pathlib import Path
import unittest

from decomposition_lab.cli import build_parser


ROOT = Path(__file__).resolve().parents[1]


class PackageTests(unittest.TestCase):
    def test_native_command_launch_cannot_reuse_old_success(self):
        common = (ROOT / 'scripts/windows/common.ps1').read_text()
        self.assertIn('Get-Command -Name $File -CommandType Application -ErrorAction Stop', common)
        self.assertIn('$global:LASTEXITCODE = 1', common)

    def test_settings_manifest_matches_cli_defaults(self):
        manifest = json.loads((ROOT / 'configs/windows_rtx3080ti.json').read_text())
        args = build_parser().parse_args(['plan', '--question', 'Q?'])
        for key in ('model', 'device', 'context_tokens', 'max_output_tokens', 'max_nodes', 'attempts'):
            self.assertEqual(getattr(args, key), manifest[key])
        self.assertEqual(manifest['scope'], 'question_decomposition_only')

    def test_launchers_use_local_virtualenv_and_no_answer_command(self):
        for name in ('RUN_WINDOWS.cmd', 'RUN_PILOT30.cmd'):
            text = (ROOT / name).read_text()
            self.assertIn('.venv\\Scripts\\python.exe', text)
            self.assertIn('DisableDelayedExpansion', text)
            self.assertIn('exit /b %RUN_EXIT%', text)
            self.assertNotIn('decomposition_lab ask', text)

    def test_installer_and_driver_safety_markers(self):
        installer = (ROOT / 'scripts/windows/install.ps1').read_text()
        driver = (ROOT / 'scripts/windows/driver.ps1').read_text()
        self.assertIn('Assert-TargetGpu', installer)
        self.assertIn("'doctor'", installer)
        self.assertIn("'--load-model'", installer)
        self.assertIn('Get-AuthenticodeSignature', driver)
        self.assertIn('-Verb RunAs', driver)
        self.assertIn('-MaximumRedirection 0', driver)
        for text in (installer, driver):
            self.assertNotIn('Restart-Computer', text)
            self.assertNotIn('Remove-Item', text)


if __name__ == '__main__':
    unittest.main()
