"""Offline software tests, not measurements of model quality."""
