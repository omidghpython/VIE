"""Offline CLI tests. Scripted model outputs are not measured model capability."""
from contextlib import redirect_stderr, redirect_stdout
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from decomposition_lab import cli
from decomposition_lab.backend import BackendError
from tests.test_planner import PLAN, QUESTION, ScriptedBackend


class CLITests(unittest.TestCase):
    def test_gpu_profile_defaults_and_explicit_cpu(self):
        args = cli.build_parser().parse_args(['plan', '--question', QUESTION])
        self.assertEqual(args.device, 'gpu')
        self.assertEqual(args.model, 'qwen2.5:7b-instruct-q4_K_M')
        args = cli.build_parser().parse_args(['plan', '--question', QUESTION, '--device', 'cpu'])
        self.assertEqual(args.device, 'cpu')

    def test_batch_output_directory_can_be_automatic(self):
        args = cli.build_parser().parse_args(['batch'])
        self.assertIsNone(args.output_dir)

    def test_doctor_ready_and_blocked_exit_codes(self):
        with patch.object(cli, 'diagnose', return_value={'status': 'ready'}):
            self.assertEqual(self.run_cli(['doctor']), 0)
        with patch.object(cli, 'diagnose', return_value={'status': 'blocked'}):
            self.assertEqual(self.run_cli(['doctor']), 2)

    def run_cli(self, argv):
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            return cli.main(argv)

    def dataset(self, root):
        path = Path(root) / "questions.json"
        path.write_text(json.dumps({"items": [
            {"id": "Q1", "group": "two_hop", "question": QUESTION, "question_fa": "پرسش اول؟",
             "gold_plan": {"secret": "not sent"}},
            {"id": "Q2", "group": "multi_hop", "question": "Another question?", "question_fa": "پرسش دوم؟"},
        ]}), encoding="utf-8")
        return path

    def test_no_retrieval_or_answer_command(self):
        for command in ("ask", "retrieve", "answer"):
            with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                cli.build_parser().parse_args([command])

    def test_single_exports_plan_and_blank_semantic_review(self):
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend", return_value=ScriptedBackend([PLAN])):
            path = Path(root) / "plan.json"
            self.assertEqual(self.run_cli(["plan", "--question", QUESTION, "--output", str(path)]), 0)
            result = json.loads(path.read_text(encoding="utf-8"))
            self.assertNotIn("answer", result)
            self.assertEqual(result["runtime"]["retrieval_calls"], 0)
            self.assertEqual(result["semantic_status"], "unreviewed")
            with (Path(root) / "plan.review.csv").open(encoding="utf-8-sig", newline="") as handle:
                row = next(csv.DictReader(handle))
            self.assertEqual(row["verdict"], "")
            self.assertEqual(row["meaning_preserved"], "")

    def test_preexisting_outputs_never_call_model(self):
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend") as backend:
            path = Path(root) / "plan.json"
            path.write_text("original", encoding="utf-8")
            self.assertEqual(self.run_cli(["plan", "--question", QUESTION, "--output", str(path)]), 2)
            backend.assert_not_called()
            self.assertEqual(path.read_text(), "original")

    def test_existing_review_file_is_also_protected(self):
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend") as backend:
            (Path(root) / "plan.review.csv").write_text("human labels", encoding="utf-8")
            self.assertEqual(self.run_cli(["plan", "--question", QUESTION, "--output", str(Path(root) / "plan.json")]), 2)
            backend.assert_not_called()

    def test_validate_is_offline_and_not_semantic_approval(self):
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend") as backend:
            path = Path(root) / "plan.json"
            path.write_text(json.dumps({"question": QUESTION, "plan": PLAN, "semantic_status": "approved"}), encoding="utf-8")
            out = io.StringIO()
            with redirect_stdout(out):
                self.assertEqual(cli.main(["validate", "--plan", str(path)]), 0)
            self.assertEqual(json.loads(out.getvalue())["semantic_status"], "unreviewed")
            backend.assert_not_called()

    def test_batch_keeps_failures_and_never_leaks_labels(self):
        backend = ScriptedBackend([{}, PLAN, {}, {}])
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend", return_value=backend):
            dataset = self.dataset(root)
            output = Path(root) / "run"
            self.assertEqual(self.run_cli(["batch", "--questions", str(dataset), "--language", "en", "--output-dir", str(output)]), 0)
            summary = json.loads((output / "summary.json").read_text())
            self.assertEqual(summary["requested_count"], 2)
            self.assertEqual(summary["attempted_count"], 2)
            self.assertEqual(summary["final_structurally_valid_count"], 1)
            self.assertEqual(summary["first_attempt_structurally_valid_count"], 0)
            self.assertEqual(summary["final_valid_fraction_of_all_requested"], 0.5)
            self.assertIsNone(summary["semantic_accuracy"])
            for call in backend.calls:
                payload = json.loads(call["messages"][1]["content"])
                self.assertEqual(set(payload), {"question"})
                self.assertNotIn("secret", call["messages"][1]["content"])
            self.assertEqual(len(list((output / "questions").glob("*.json"))), 2)

    def test_unavailable_backend_preserves_full_denominator(self):
        backend = ScriptedBackend([BackendError("offline")])
        with tempfile.TemporaryDirectory() as root, patch.object(cli, "_backend", return_value=backend):
            dataset = self.dataset(root)
            output = Path(root) / "run"
            self.assertEqual(self.run_cli(["batch", "--questions", str(dataset), "--output-dir", str(output)]), 2)
            summary = json.loads((output / "summary.json").read_text())
            self.assertEqual(summary["status"], "incomplete")
            self.assertEqual(summary["attempted_count"], 1)
            self.assertEqual(summary["not_run_count"], 1)
            self.assertEqual(summary["requested_count"], 2)
            with (output / "human_review.csv").open(encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[1]["structural_status"], "not_run")
            self.assertEqual(len(backend.calls), 1)

    def test_persian_language_selection_and_csv_formula_safety(self):
        with tempfile.TemporaryDirectory() as root:
            selected = cli._load_questions(self.dataset(root), "fa")
            self.assertEqual(selected[0]["question"], "پرسش اول؟")
            for text in ("=1+1", "+SUM(A1)", "-2", "@cmd", " \t=1+1"):
                self.assertTrue(cli._csv_cell(text).startswith("'"))
            self.assertEqual(cli._csv_cell("پرسش؟"), "پرسش؟")

    def test_duplicate_or_unsafe_question_id_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path = self.dataset(root)
            data = json.loads(path.read_text())
            for qid in ("Q1", "../outside"):
                data["items"][1]["id"] = qid
                path.write_text(json.dumps(data))
                with self.assertRaises(ValueError):
                    cli._load_questions(path, "en")

    def test_pilot_has_only_questions_and_balanced_groups(self):
        path = Path(__file__).resolve().parents[1] / "examples" / "questions30.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(len(data["items"]), 30)
        self.assertEqual(set(data), {"description", "items"})
        self.assertEqual(dict(cli.Counter(row["group"] for row in data["items"])),
                         {"one_hop": 10, "two_hop": 10, "multi_hop": 10})
        for row in data["items"]:
            self.assertEqual(set(row), {"id", "group", "question", "question_fa"})


if __name__ == "__main__":
    unittest.main()
