import io
import json
import subprocess
import unittest
from unittest.mock import patch

from decomposition_lab.backend import BackendError
from decomposition_lab.doctor import _nvidia_smi, diagnose


GPU = [{"name": "NVIDIA GeForce RTX 3080 Ti", "memory_total_mib": 12288, "driver_version": "570.00"}]
MODEL = "qwen2.5:7b-instruct-q4_K_M"


class DoctorTests(unittest.TestCase):
    def test_target_gpu_csv(self):
        completed = subprocess.CompletedProcess([], 0, 'NVIDIA GeForce RTX 3080 Ti, 12288, 570.00\n', '')
        with patch('decomposition_lab.doctor.shutil.which', return_value='nvidia-smi'), patch('decomposition_lab.doctor.subprocess.run', return_value=completed) as run:
            self.assertEqual(_nvidia_smi(), GPU)
            self.assertFalse(run.call_args.kwargs.get('shell', False))

    def test_missing_gpu_blocks_before_model_loading(self):
        with patch('decomposition_lab.doctor._nvidia_smi', side_effect=RuntimeError('GPU absent')), patch('decomposition_lab.doctor._http') as http:
            result = diagnose(load_model=True)
            self.assertEqual(result['status'], 'blocked')
            http.assert_not_called()

    def test_wrong_gpu_blocks(self):
        with patch('decomposition_lab.doctor._nvidia_smi', return_value=[dict(GPU[0], name='VMware SVGA 3D')]):
            self.assertEqual(diagnose()['status'], 'blocked')

    def test_load_model_uses_empty_prompt_not_a_question(self):
        responses = [{'version': 'test-only'}, {'models': [{'name': MODEL, 'digest': 'test'}]}, {'done': True}]
        with patch('decomposition_lab.doctor._nvidia_smi', return_value=GPU), patch('decomposition_lab.doctor._http', side_effect=responses) as http, patch('decomposition_lab.backend.OllamaBackend._gpu_residency', return_value={'size_vram': 5000}):
            result = diagnose(load_model=True)
            self.assertEqual(result['status'], 'ready')
            payload = http.call_args_list[2].args[2]
            self.assertEqual(payload['prompt'], '')
            self.assertEqual(payload['options']['num_gpu'], 999)
            self.assertEqual(result['question_answering_calls'], 0)
            self.assertEqual(result['decomposition_calls'], 0)

    def test_uninstalled_model_never_loads(self):
        with patch('decomposition_lab.doctor._nvidia_smi', return_value=GPU), patch('decomposition_lab.doctor._http', side_effect=[{'version': 'test'}, {'models': []}]) as http:
            result = diagnose(load_model=True)
            self.assertEqual(result['status'], 'blocked')
            self.assertEqual(http.call_count, 2)

    def test_cpu_residency_is_not_success(self):
        responses = [{'version': 'test'}, {'models': [{'name': MODEL}]}]
        with patch('decomposition_lab.doctor._nvidia_smi', return_value=GPU), patch('decomposition_lab.doctor._http', side_effect=responses), patch('decomposition_lab.backend.OllamaBackend._gpu_residency', side_effect=BackendError('CPU only')):
            result = diagnose()
            self.assertEqual(result['status'], 'blocked')
            self.assertIn('CPU only', result['errors'])

    def test_remote_endpoint_rejected(self):
        with self.assertRaises(ValueError):
            diagnose(endpoint='https://example.com')


if __name__ == '__main__':
    unittest.main()
