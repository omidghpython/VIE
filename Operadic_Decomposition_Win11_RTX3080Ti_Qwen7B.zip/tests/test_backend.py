import json
import unittest
from unittest.mock import Mock
from urllib.error import HTTPError, URLError

from decomposition_lab.backend import BackendError, OllamaBackend, _NoRedirect


class FakeResponse:
    def __init__(self, value):
        self.value = value if isinstance(value, bytes) else json.dumps(value).encode()
        self.closed = False

    def read(self, limit):
        return self.value[:limit]

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True


class BackendTests(unittest.TestCase):
    messages = [{"role": "user", "content": "سؤال نمونه"}]

    def backend_with(self, response):
        backend = OllamaBackend(device="cpu")
        backend._opener = Mock()
        backend._opener.open.return_value = FakeResponse(response)
        return backend

    def test_cpu_json_schema_and_statistics(self):
        backend = self.backend_with({"done": True, "message": {"content": '{"x":1}'}, "eval_count": 7, "prompt_eval_count": 13})
        schema = {"type": "object"}
        self.assertEqual(backend.generate(self.messages, schema), '{"x":1}')
        req = backend._opener.open.call_args.args[0]
        body = json.loads(req.data)
        self.assertEqual(req.full_url, "http://127.0.0.1:11434/api/chat")
        self.assertEqual(body["format"], schema)
        self.assertEqual(body["options"]["num_gpu"], 0)
        self.assertEqual(body["options"]["num_ctx"], 8192)
        self.assertEqual(body["options"]["temperature"], 0)
        self.assertFalse(body["stream"])
        self.assertNotIn("num_thread", body["options"])
        self.assertEqual(backend.stats[0]["eval_count"], 7)
        self.assertNotIn("messages", backend.stats[0])
        self.assertTrue(backend._opener.open.return_value.closed)

    def test_threads_and_json_mode(self):
        backend = OllamaBackend(threads=2, device="cpu")
        backend._opener = Mock()
        backend._opener.open.return_value = FakeResponse({"done": True, "message": {"content": "{}"}})
        backend.generate(self.messages)
        body = json.loads(backend._opener.open.call_args.args[0].data)
        self.assertEqual(body["format"], "json")
        self.assertEqual(body["options"]["num_thread"], 2)

    def test_local_urls_only(self):
        for url in ("https://example.com", "http://example.com", "http://localhost.evil", "http://user:pass@localhost", "http://127.0.0.1/path", "http://localhost?x=1", "http://localhost#x", "http://localhost:0", "http://localhost:99999", "http://localhost\n"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                OllamaBackend(base_url=url)
        for url in ("http://localhost:11434/", "http://127.0.0.1:12345", "http://[::1]:11434"):
            OllamaBackend(base_url=url)

    def test_options_are_validated(self):
        for kwargs in ({"timeout": float("nan")}, {"timeout": float("inf")}, {"timeout": 0}, {"timeout": True}, {"context_tokens": True}, {"threads": -1}, {"max_output_tokens": 0}, {"model": ""}, {"model": "model\nsecret"}, {"context_tokens": 512, "max_output_tokens": 512}, {"device": "auto"}, {"device": []}, {"device": None}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                OllamaBackend(**kwargs)

    def test_failures_are_clear_and_counted(self):
        for response in (b"invalid", [], {"error": "internal"}, {"done": False}, {"done": True, "message": {"content": None}}, {"done": True, "message": {"content": " "}}, {"done": True, "done_reason": "length", "message": {"content": "{"}}):
            with self.subTest(response=response):
                backend = self.backend_with(response)
                with self.assertRaises(BackendError):
                    backend.generate(self.messages)
                self.assertEqual(backend.stats[0]["status"], "error")

    def test_http_and_connection_errors(self):
        for exc in (URLError("connection refused"), TimeoutError(), HTTPError("http://localhost", 404, "missing", {}, None)):
            backend = OllamaBackend()
            backend._opener = Mock()
            backend._opener.open.side_effect = exc
            with self.subTest(exc=exc), self.assertRaises(BackendError):
                backend.generate(self.messages)
            self.assertEqual(len(backend.stats), 1)

    def test_response_size_limit(self):
        backend = self.backend_with(b"x" * 21)
        backend.MAX_RESPONSE_BYTES = 20
        with self.assertRaisesRegex(BackendError, "size limit"):
            backend.generate(self.messages)

    def test_request_size_limit(self):
        backend = OllamaBackend()
        backend.MAX_REQUEST_BYTES = 2
        with self.assertRaisesRegex(BackendError, "too large"):
            backend.generate(self.messages)

    def test_context_guard_rejects_before_sending(self):
        backend = OllamaBackend(context_tokens=1024, max_output_tokens=256)
        backend._opener = Mock()
        with self.assertRaisesRegex(BackendError, "Conservative input-context budget exceeded"):
            backend.generate([{"role": "user", "content": "a" * 257}])
        backend._opener.open.assert_not_called()
        self.assertEqual(backend.stats, [])

    def test_context_guard_counts_utf8_not_characters(self):
        backend = OllamaBackend(context_tokens=1024, max_output_tokens=256)
        backend._opener = Mock()
        with self.assertRaisesRegex(BackendError, "No request was sent"):
            backend.generate([{"role": "user", "content": "ش" * 129}])
        backend._opener.open.assert_not_called()

    def test_context_guard_allows_exact_boundary(self):
        backend = OllamaBackend(context_tokens=1024, max_output_tokens=256, device="cpu")
        backend._opener = Mock()
        backend._opener.open.return_value = FakeResponse({"done": True, "message": {"content": "{}"}})
        self.assertEqual(backend.generate([{"role": "user", "content": "a" * 256}]), "{}")
        self.assertEqual(backend.stats[0]["input_budget_units"], 768)
        self.assertEqual(backend.stats[0]["available_input_units"], 768)

    def test_invalid_request_fields(self):
        backend = OllamaBackend()
        for messages in ([], "not-list", [{"role": "tool", "content": "x"}], [{"role": [], "content": "x"}], [{"role": "user", "content": None}], [{"role": "user", "content": "x", "name": "extra"}]):
            with self.subTest(messages=messages), self.assertRaises(ValueError):
                backend.generate(messages)
        with self.assertRaises(ValueError):
            backend.generate(self.messages, schema=[])

    def test_redirects_refused(self):
        with self.assertRaisesRegex(BackendError, "redirects"):
            _NoRedirect().redirect_request(None, None, 302, "", {}, "https://example.com")

    def gpu_backend(self, ps_result):
        backend = OllamaBackend()
        backend._opener = Mock()
        second = ps_result if isinstance(ps_result, Exception) else FakeResponse(ps_result)
        backend._opener.open.side_effect = [
            FakeResponse({"done": True, "message": {"content": "{}"}, "eval_count": 10}), second,
        ]
        return backend

    def test_gpu_is_default_and_vram_is_observed(self):
        backend = self.gpu_backend({"models": [{"name": "qwen2.5:7b-instruct-q4_K_M",
            "size_vram": 5_000_000_000, "size": 5_100_000_000, "context_length": 8192, "digest": "abc"}]})
        self.assertEqual(backend.device, "gpu")
        self.assertEqual(backend.generate(self.messages), "{}")
        chat, ps = [call.args[0] for call in backend._opener.open.call_args_list]
        body = json.loads(chat.data)
        self.assertEqual(body["options"]["num_gpu"], 999)
        self.assertEqual(body["keep_alive"], "5m")
        self.assertEqual(body["model"], "qwen2.5:7b-instruct-q4_K_M")
        self.assertEqual(ps.full_url, "http://127.0.0.1:11434/api/ps")
        self.assertEqual(ps.get_method(), "GET")
        stat = backend.stats[0]
        self.assertEqual(stat["gpu_verification"], "positive_vram_residency_observed")
        self.assertEqual(stat["size_vram"], 5_000_000_000)
        self.assertFalse(stat["full_gpu_offload_verified"])
        self.assertFalse(stat["cpu_only"])

    def test_gpu_rejects_missing_zero_or_wrong_model_residency(self):
        for models in ([], [{"name": "different", "size_vram": 100}],
                       [{"name": "qwen2.5:7b-instruct-q4_K_M", "size_vram": 0}],
                       [{"name": "qwen2.5:7b-instruct-q4_K_M", "size_vram": True}],
                       [{"name": "qwen2.5:7b-instruct-q4_K_M", "size_vram": "100"}]):
            with self.subTest(models=models):
                backend = self.gpu_backend({"models": models})
                with self.assertRaisesRegex(BackendError, "GPU residency was not observed"):
                    backend.generate(self.messages)
                self.assertEqual(backend.stats[0]["status"], "error")
                self.assertTrue(backend.stats[0]["generation_completed"])
                self.assertEqual(backend.stats[0]["gpu_verification"], "failed")
                self.assertEqual(backend.stats[0]["eval_count"], 10)

    def test_gpu_probe_errors_do_not_accept_generation(self):
        for response in (b"invalid", [], {"models": None}, URLError("offline"),
                         HTTPError("http://localhost/api/ps", 404, "missing", {}, None)):
            with self.subTest(response=response):
                backend = self.gpu_backend(response)
                with self.assertRaises(BackendError):
                    backend.generate(self.messages)
                self.assertEqual(backend.stats[0]["status"], "error")

    def test_gpu_model_field_supported_and_checked_after_every_call(self):
        backend = OllamaBackend()
        good = {"models": [{"model": backend.model, "size_vram": 500}]}
        backend._opener = Mock()
        backend._opener.open.side_effect = [
            FakeResponse({"done": True, "message": {"content": "{}"}}), FakeResponse(good),
            FakeResponse({"done": True, "message": {"content": "{}"}}), FakeResponse({"models": []}),
        ]
        backend.generate(self.messages)
        with self.assertRaises(BackendError):
            backend.generate(self.messages)
        self.assertEqual(backend._opener.open.call_count, 4)
        self.assertEqual([s["status"] for s in backend.stats], ["ok", "error"])

    def test_explicit_cpu_mode_needs_no_gpu_probe(self):
        backend = self.backend_with({"done": True, "message": {"content": "{}"}})
        backend.generate(self.messages)
        self.assertEqual(backend._opener.open.call_count, 1)
        self.assertEqual(backend.stats[0]["device_requested"], "cpu")
        self.assertEqual(backend.stats[0]["gpu_verification"], "not_requested")


if __name__ == "__main__":
    unittest.main()
