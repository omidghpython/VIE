"""Controlled software tests, not measurements of a real model's accuracy."""
import copy
import json
import unittest
from unittest.mock import patch

from decomposition_lab.backend import BackendError
from decomposition_lab.planner import Decomposer, PLAN_SYSTEM, plan_schema


QUESTION = "Where was the author of The Lantern born?"
PLAN = {"nodes": [
    {"id": "q1", "question": "Who wrote The Lantern?", "dependencies": {}, "answer_type": "person"},
    {"id": "q2", "question": "Where was {{q1}} born?", "dependencies": {"q1": "person"}, "answer_type": "place"},
], "final": "q2"}


class ScriptedBackend:
    model = "scripted-test-only"

    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.calls = []
        self.stats = []

    def generate(self, messages, schema=None):
        self.calls.append({"messages": copy.deepcopy(messages), "schema": copy.deepcopy(schema)})
        if not self.outputs:
            raise AssertionError("Unexpected model call")
        value = self.outputs.pop(0)
        if isinstance(value, Exception):
            self.stats.append({"status": "error"})
            raise value
        self.stats.append({"status": "ok"})
        return json.dumps(value) if isinstance(value, dict) else value


class PlannerTests(unittest.TestCase):
    def test_generation_rejected_after_gpu_check_is_still_counted(self):
        class Backend:
            stats = []
            def generate(self, messages, schema=None):
                self.stats.append({'status': 'error', 'generation_completed': True})
                raise BackendError('GPU residency not confirmed after generation')
        result = Decomposer(Backend()).decompose(QUESTION)
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['costs']['completed_backend_calls'], 0)
        self.assertEqual(result['costs']['model_generations_completed'], 1)

    def test_only_original_question_is_sent(self):
        backend = ScriptedBackend([PLAN])
        result = Decomposer(backend).decompose(QUESTION)
        payload = json.loads(backend.calls[0]["messages"][1]["content"])
        self.assertEqual(payload, {"question": QUESTION})
        self.assertEqual(result["status"], "planned")
        self.assertEqual(result["semantic_status"], "unreviewed")
        self.assertEqual(result["first_attempt_structurally_valid"], True)
        self.assertEqual(result["attempts_used"], 1)
        self.assertNotIn("answer", result)
        self.assertNotIn("evidence", result)
        self.assertIn("[q1: Who wrote The Lantern?]", result["expanded_plan"])

    def test_semantically_unrelated_tree_not_certified(self):
        leaf = {"nodes": [PLAN["nodes"][0]], "final": "q1"}
        result = Decomposer(ScriptedBackend([leaf])).decompose("What is the capital of France?")
        self.assertEqual(result["structural_status"], "valid")
        self.assertEqual(result["semantic_status"], "unreviewed")
        self.assertNotIn("semantic_valid", result)

    def test_atomic_question_one_node(self):
        question = "پایتخت فرانسه کدام شهر است؟"
        plan = {"nodes": [{"id": "q1", "question": question, "dependencies": {}, "answer_type": "place"}], "final": "q1"}
        result = Decomposer(ScriptedBackend([plan])).decompose(question)
        self.assertEqual(result["plan"], plan)
        self.assertEqual(result["expanded_plan"], question)

    def test_invalid_then_repaired_logs_both(self):
        backend = ScriptedBackend([{}, PLAN])
        result = Decomposer(backend).decompose(QUESTION)
        self.assertEqual(result["status"], "planned")
        self.assertFalse(result["first_attempt_structurally_valid"])
        self.assertEqual(result["attempts_used"], 2)
        self.assertEqual([entry["status"] for entry in result["trace"]], ["invalid", "valid"])
        self.assertIn("Repair the structural error", backend.calls[1]["messages"][-1]["content"])
        self.assertEqual(result["trace"][0]["raw_output"], "{}")
        self.assertEqual(result["trace"][1]["messages"][2]["content"], "{}")

    def test_invalid_output_and_null_are_bounded(self):
        for raw in ["null", None, "[]", "not json", {"nodes": [], "final": []}]:
            with self.subTest(raw=raw):
                backend = ScriptedBackend([raw, raw])
                result = Decomposer(backend, attempts=2).decompose(QUESTION)
                self.assertEqual(result["status"], "failed")
                self.assertEqual(result["structural_status"], "invalid")
                self.assertEqual(result["attempts_used"], 2)
                self.assertTrue(result["error"])
                self.assertIsNone(result["plan"])
                json.dumps(result, allow_nan=False)

    def test_backend_failure_has_no_fake_successful_call(self):
        backend = ScriptedBackend([BackendError("Local service unavailable")])
        result = Decomposer(backend).decompose(QUESTION)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["structural_status"], "unavailable")
        self.assertEqual(result["costs"]["generation_attempts"], 1)
        self.assertEqual(result["costs"]["completed_backend_calls"], 0)
        self.assertEqual(result["attempts_used"], 1)

    def test_context_preflight_no_completed_inference(self):
        class Guarded:
            stats = []
            def generate(self, messages, schema=None):
                raise BackendError("Context too large; request was not sent")
        result = Decomposer(Guarded()).decompose(QUESTION)
        self.assertEqual(result["costs"]["backend_calls"], [])
        self.assertEqual(result["costs"]["completed_backend_calls"], 0)
        self.assertEqual(result["costs"]["generation_attempts"], 1)

    def test_state_and_costs_reset_between_questions(self):
        backend = ScriptedBackend([{}, PLAN, PLAN])
        decomposer = Decomposer(backend)
        first = decomposer.decompose(QUESTION)
        second = decomposer.decompose(QUESTION)
        self.assertEqual(first["attempts_used"], 2)
        self.assertEqual(second["attempts_used"], 1)
        self.assertEqual(len(first["trace"]), 2)
        self.assertEqual(len(second["costs"]["backend_calls"]), 1)
        self.assertTrue(second["first_attempt_structurally_valid"])

    def test_answer_fields_rejected(self):
        plan = copy.deepcopy(PLAN)
        plan["nodes"][0]["answer"] = "An invented value"
        result = Decomposer(ScriptedBackend([plan]), attempts=1).decompose(QUESTION)
        self.assertEqual(result["structural_status"], "invalid")

    def test_fanout_tree_and_type_errors_rejected(self):
        for change in [{"dependencies": {"q1": "number"}}, {"question": "Compare {{q1}} with {{q1}}"}]:
            plan = copy.deepcopy(PLAN)
            plan["nodes"][1].update(change)
            result = Decomposer(ScriptedBackend([plan]), attempts=1).decompose(QUESTION)
            self.assertEqual(result["structural_status"], "invalid")

    def test_schema_and_prompt_do_not_request_answers(self):
        schema = plan_schema(8)
        self.assertEqual(schema["properties"]["nodes"]["maxItems"], 8)
        self.assertNotIn("answer", schema["properties"]["nodes"]["items"]["properties"])
        self.assertIn("Do not answer", PLAN_SYSTEM)

    def test_expansion_failure_is_explicit(self):
        with patch("decomposition_lab.planner.expand_plan", side_effect=ValueError("display budget exceeded")):
            result = Decomposer(ScriptedBackend([PLAN])).decompose(QUESTION)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["structural_status"], "valid")
        self.assertIsNotNone(result["plan"])
        self.assertIsNone(result["expanded_plan"])
        self.assertIn("Display expansion failed", result["error"])

    def test_constructor_validation(self):
        for kwargs in [{"attempts": 0}, {"attempts": True}, {"max_nodes": 0}, {"max_nodes": 33}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                Decomposer(ScriptedBackend([]), **kwargs)
        with self.assertRaises(ValueError):
            Decomposer(object())

    def test_invalid_input_fails_without_call(self):
        backend = ScriptedBackend([])
        for question in [None, "", " ", "x" * 2001]:
            with self.subTest(question=question), self.assertRaises(ValueError):
                Decomposer(backend).decompose(question)
        self.assertEqual(backend.calls, [])


if __name__ == "__main__":
    unittest.main()
