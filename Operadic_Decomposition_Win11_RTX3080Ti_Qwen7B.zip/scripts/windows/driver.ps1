[CmdletBinding()]
param([string]$InstallerPath = '', [string]$DownloadUrl = '')

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($InstallerPath -and $DownloadUrl) { throw 'Provide a local installer OR a URL, not both.' }
if (-not $InstallerPath -and -not $DownloadUrl) {
    Write-Host 'Keep a working driver. Select the correct Windows guest driver, not the VMware host driver.'
    Write-Host 'Official selector: https://www.nvidia.com/Download/index.aspx'
    $InstallerPath = Read-Host 'Full path to a downloaded NVIDIA .exe (blank cancels)'
    if (-not $InstallerPath) { throw 'No driver selected; nothing changed.' }
}
if ($DownloadUrl) {
    $uri = [uri]$DownloadUrl
    if ($uri.Scheme -ne 'https' -or $uri.Host -notin @('us.download.nvidia.com', 'international.download.nvidia.com', 'download.nvidia.com') -or $uri.UserInfo -or $uri.AbsolutePath -notmatch '\.exe$') {
        throw 'Only an exact HTTPS .exe URL on an approved NVIDIA download host is accepted.'
    }
    $downloadDirectory = Join-Path ([IO.Path]::GetTempPath()) ('operadic_nvidia_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $downloadDirectory | Out-Null
    $InstallerPath = Join-Path $downloadDirectory 'nvidia-driver.exe'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $uri -OutFile $InstallerPath -UseBasicParsing -MaximumRedirection 0
}
$InstallerPath = (Resolve-Path -LiteralPath $InstallerPath).Path
if ([IO.Path]::GetExtension($InstallerPath) -ne '.exe') { throw 'Expected a signed NVIDIA .exe installer.' }
$signature = Get-AuthenticodeSignature -LiteralPath $InstallerPath
if ($signature.Status -ne 'Valid' -or -not $signature.SignerCertificate -or $signature.SignerCertificate.Subject -notmatch '(?i)NVIDIA') {
    throw 'A valid NVIDIA Authenticode signature is required. Nothing was launched.'
}
Write-Host ('Verified NVIDIA installer: ' + $InstallerPath)
Write-Host 'This changes the guest display driver and may require a restart.'
$confirmation = Read-Host 'Type INSTALL to launch the official driver UI with administrator approval'
if ($confirmation -cne 'INSTALL') { throw 'Driver installation cancelled.' }
$process = Start-Process -FilePath $InstallerPath -Verb RunAs -Wait -PassThru
if ($process.ExitCode -notin @(0, 3010)) { throw ('NVIDIA installer exited with code ' + $process.ExitCode) }
Write-Host 'If NVIDIA requests a restart, save work and restart Windows yourself, then rerun INSTALL_WINDOWS.cmd.'
