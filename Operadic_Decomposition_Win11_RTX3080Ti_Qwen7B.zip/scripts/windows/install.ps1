[CmdletBinding()]
param([string]$NvidiaDriverInstaller = '', [string]$NvidiaDriverUrl = '')

. (Join-Path $PSScriptRoot 'common.ps1')
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$logDirectory = Join-Path $root 'install_logs'
$transcriptStarted = $false
$exitCode = 1
try {
    if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem -or -not [Environment]::Is64BitProcess) { throw 'Use 64-bit PowerShell on Windows 11 x64.' }
    $os = Get-CimInstance Win32_OperatingSystem
    if ([int]$os.BuildNumber -lt 22000) { throw 'This installer targets Windows 11 (build 22000 or newer).' }
    New-Item -ItemType Directory -Force -Path $logDirectory | Out-Null
    $runId = (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,8)
    Start-Transcript -LiteralPath (Join-Path $logDirectory ('install_' + $runId + '.log')) | Out-Null
    $transcriptStarted = $true
    Set-Location -LiteralPath $root
    Write-Host 'Installing decomposition ONLY. No document retrieval or question answering.'
    $config = Get-Content -LiteralPath (Join-Path $root 'configs\windows_rtx3080ti.json') -Raw | ConvertFrom-Json
    try { Assert-TargetGpu } catch {
        if ($NvidiaDriverInstaller -or $NvidiaDriverUrl) {
            & (Join-Path $PSScriptRoot 'driver.ps1') -InstallerPath $NvidiaDriverInstaller -DownloadUrl $NvidiaDriverUrl
            Assert-TargetGpu
        } else { throw ($_.Exception.Message + ' No driver is guessed or replaced. Use INSTALL_GPU_DRIVER.cmd for a signed official NVIDIA installer, then rerun after any required restart.') }
    }
    Write-Host 'Keeping the working NVIDIA driver. CUDA Toolkit, cuDNN and PyTorch are not required.'
    $ram = [double](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB
    if ($ram -lt 15) { Write-Warning ('Guest RAM is ' + [math]::Round($ram,1) + ' GB. Allocate at least 16GB where possible; more is preferable.') }
    $profileDrive = (Get-Item -LiteralPath $env:USERPROFILE).PSDrive
    if ($profileDrive.Free -lt 15GB) { throw 'Provide at least 15GB free on the user-profile drive for software, model download and temporary files.' }
    $python = Find-Python
    if (-not $python) {
        Install-WingetPackage $config.python_winget_id
        $python = Find-Python
        if (-not $python) { throw 'A compatible Python x64 interpreter was not found after installation. Reopen the terminal and rerun.' }
    }
    $ollama = Find-Ollama
    if (-not $ollama) {
        Install-WingetPackage $config.ollama_winget_id
        $ollama = Find-Ollama
        if (-not $ollama) { throw 'ollama.exe was not found after installation. Reopen the terminal and rerun.' }
    }
    $venv = Join-Path $root '.venv'
    $venvPython = Join-Path $venv 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $venv)) { Invoke-Checked $python @('-m', 'venv', $venv) }
    if (-not (Test-Path -LiteralPath $venvPython -PathType Leaf)) { throw 'Existing .venv is incomplete. Rename it for recovery, then rerun; it is never deleted automatically.' }
    Invoke-Checked $venvPython @('-m', 'pip', 'install', '--no-index', '--disable-pip-version-check', '-r', (Join-Path $root 'requirements.txt'))
    Invoke-Checked $venvPython @('-m', 'unittest', 'discover', '-s', 'tests', '-q')
    $env:OLLAMA_HOST = '127.0.0.1:11434'
    if (-not (Test-Ollama)) {
        $env:OLLAMA_NUM_PARALLEL = '1'
        $env:OLLAMA_MAX_LOADED_MODELS = '1'
        Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
        $available = $false
        for ($i = 0; $i -lt 30; $i++) {
            if (Test-Ollama) { $available = $true; break }
            Start-Sleep -Seconds 2
        }
        if (-not $available) { throw 'Ollama did not start on localhost:11434. Check logs/port; no existing process was killed.' }
    }
    Write-Host ('Downloading model (several GB, first run only): ' + $config.model)
    Invoke-Checked $ollama @('pull', $config.model)
    Invoke-Checked $venvPython @('-m', 'decomposition_lab', 'doctor', '--model', $config.model, '--context-tokens', [string]$config.context_tokens, '--load-model', '--timeout', '300', '--output', (Join-Path $logDirectory ('diagnostics_' + $runId + '.json')))
    Write-Host 'READY. Use RUN_WINDOWS.cmd or RUN_PILOT30.cmd. GPU residency was observed; semantic correctness still needs human review.'
    $exitCode = 0
} catch {
    Write-Host ('INSTALLATION BLOCKED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Resolve the issue and rerun. No automatic reboot or driver removal is performed.'
} finally { if ($transcriptStarted) { Stop-Transcript | Out-Null } }
exit $exitCode
