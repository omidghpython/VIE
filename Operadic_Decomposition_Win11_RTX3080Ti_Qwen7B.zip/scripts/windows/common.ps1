Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-Checked {
    param([string]$File, [string[]]$Arguments)
    $executable = Get-Command -Name $File -CommandType Application -ErrorAction Stop
    $code = 1
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $global:LASTEXITCODE = 1
        & $executable.Source @Arguments
        $code = $global:LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    if ($code -ne 0) { throw "Command failed (exit $code): $File" }
}

function Assert-TargetGpu {
    $command = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
    $smi = $null
    if ($command) { $smi = $command.Source }
    if (-not $smi) {
        foreach ($candidate in @((Join-Path $env:WINDIR 'System32\nvidia-smi.exe'), (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVSMI\nvidia-smi.exe'))) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { $smi = $candidate; break }
        }
    }
    if (-not $smi) { throw 'nvidia-smi is unavailable inside this VM. Check GPU passthrough and the guest NVIDIA driver.' }
    $rows = @(& $smi '--query-gpu=name,memory.total,driver_version' '--format=csv,noheader,nounits')
    if ($LASTEXITCODE -ne 0) { throw 'nvidia-smi could not access the GPU inside the guest.' }
    $match = $false
    foreach ($row in $rows) {
        $fields = $row -split ','
        if ($fields.Count -eq 3) {
            $memory = 0
            if (($fields[0] -match 'RTX\s*3080\s*Ti') -and [int]::TryParse($fields[1].Trim(), [ref]$memory) -and $memory -ge 11000) {
                Write-Host ('GPU detected: ' + $row.Trim())
                $match = $true
            }
        }
    }
    if (-not $match) { throw 'RTX 3080 Ti with approximately 12GB VRAM was not found INSIDE Windows. VMware 3D acceleration alone is not CUDA passthrough.' }
}

function Find-Python {
    $candidates = @()
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $oldPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { $found = @(& $launcher.Source -3 -c 'import sys; print(sys.executable)' 2>$null) }
        finally { $ErrorActionPreference = $oldPreference }
        if ($LASTEXITCODE -eq 0 -and $found.Count -gt 0) { $candidates += $found[-1].ToString().Trim() }
    }
    $candidates += (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe')
    $command = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($command) { $candidates += $command.Source }
    foreach ($candidate in $candidates) {
        if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and ($candidate -notmatch 'WindowsApps')) {
            $oldPreference = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try { & $candidate -c 'import struct,sys; sys.exit(not (sys.version_info >= (3,10) and struct.calcsize(chr(80))==8))' *> $null }
            finally { $ErrorActionPreference = $oldPreference }
            if ($LASTEXITCODE -eq 0) { return $candidate }
        }
    }
    return $null
}

function Find-Ollama {
    $command = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    $candidate = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
    if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    return $null
}

function Install-WingetPackage {
    param([string]$PackageId)
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { throw 'WinGet is missing. Install/update Microsoft App Installer from Microsoft Store, then rerun. See README.md for manual official installers.' }
    Invoke-Checked $winget.Source @('install', '--exact', '--id', $PackageId, '--source', 'winget', '--silent', '--accept-package-agreements', '--accept-source-agreements', '--disable-interactivity')
    $env:PATH = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
}

function Test-Ollama {
    try {
        $response = Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/version' -TimeoutSec 3 -Method Get
        return ($null -ne $response.version)
    } catch { return $false }
}
