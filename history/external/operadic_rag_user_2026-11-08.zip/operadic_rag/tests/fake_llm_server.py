"""Scripted OpenAI-compatible server for tests. It mimics a model that is perfect at reading evidence
(answers only when the needed fact is literally in the passages) so we can test control flow, budgets
and accounting. It says NOTHING about how well Qwen2.5-7B will behave."""
from __future__ import annotations

import argparse
import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from oprag import prompts  # noqa: E402

DECOMP = {
    "Which country is the director of the film Inception from?":
        {"q1": "Who directed the film Inception?", "q1_type": "person", "q2": "Which country is [A1] from?", "answer_type": "place"},
    "What river flows through the capital of France?":
        {"q1": "What is the capital of France?", "q1_type": "place", "q2": "Which river flows through [A1]?", "answer_type": "other"},
    "Which city hosts the headquarters of the company founded by Ada Quill?":
        {"q1": "Which company was founded by Ada Quill?", "q1_type": "other", "q2": "Which city hosts the headquarters of [A1]?", "answer_type": "place"},
    "Where did the founder of Quasar Labs study?":
        {"q1": "Who founded Quasar Labs?", "q1_type": "person", "q2": "Where did [A1] study?", "answer_type": "place"},
}
# sub-question regex, needle that must appear in the evidence, answer, rewrite query if evidence lacks the needle
FACTS = [
    (r"Who directed the film Inception", "directed by Christopher Nolan", "Christopher Nolan", "Inception film director"),
    (r"Which country is Christopher Nolan from", "born in London, United Kingdom", "United Kingdom", "Christopher Nolan born"),
    (r"What is the capital of France", "capital and most populous city of France", "Paris", "capital of France"),
    (r"Which river flows through Paris", "Seine is a river", "Seine", "river Paris"),
    (r"Which company was founded by Ada Quill", "founded Brightwave", "Brightwave Systems", "Ada Quill company"),
    (r"headquarters of Brightwave Systems", "headquartered in Lisbon", "Lisbon", "Brightwave Systems headquartered"),
    (r"Who founded Quasar Labs", "Tomas Reyes started", "Tomas Reyes", "Quasar Labs garage startup"),
    (r"Where did Tomas Reyes study", "studied computer science", "University of Porto", "Tomas Reyes studied"),
]
# whole-question needles for Standard RAG: answer only if ALL needles are in the evidence
STD = {
    "Which country is the director of the film Inception from?": (["directed by Christopher Nolan", "born in London, United Kingdom"], "United Kingdom"),
    "What river flows through the capital of France?": (["capital and most populous city of France", "Seine is a river"], "Seine"),
    "Which city hosts the headquarters of the company founded by Ada Quill?": (["founded Brightwave", "headquartered in Lisbon"], "Lisbon"),
    "Where did the founder of Quasar Labs study?": (["Tomas Reyes started", "studied computer science"], "University of Porto"),
}
DIRECT = {  # closed-book answers (two are deliberately wrong to create inconsistency)
    "Which country is the director of the film Inception from?": "United Kingdom",
    "What river flows through the capital of France?": "Seine",
    "Which city hosts the headquarters of the company founded by Ada Quill?": "Berlin",
    "Where did the founder of Quasar Labs study?": "MIT",
}


def respond(messages: list[dict], mode: str = "normal") -> str:
    system, user = messages[0]["content"], messages[1]["content"]
    if system == prompts.DECOMPOSE_SYSTEM:
        q = re.search(r"Question: (.*)\n", user).group(1)
        return json.dumps(DECOMP[q])
    if system == prompts.ASSESS_SYSTEM:
        sub = re.search(r"Sub-question: (.*)\n", user).group(1)
        for pat, needle, ans, rewrite in FACTS:
            if re.search(pat, sub):
                # "overconfident" = a model that always claims sufficiency (and happens to know the answer)
                if mode == "overconfident" or (mode != "never_sufficient" and needle in user.split("Evidence passages:")[1]):
                    return json.dumps({"answer": ans, "sufficiency": "sufficient", "reason": "stated in passage",
                                       "missing": "", "next_action": "none", "next_query": ""})
                act = "deepen" if mode == "deepen" else "rewrite_query"
                return json.dumps({"answer": "unknown", "sufficiency": "insufficient", "reason": "fact not in passages",
                                   "missing": "the key fact", "next_action": act,
                                   "next_query": "" if act == "deepen" else rewrite})
        return "not json at all"
    if system in (prompts.standard_system(False), prompts.standard_system(True)):
        q = re.search(r"Question: (.*)\nAnswer:", user).group(1)
        needles, ans = STD[q]
        ev = user.split("Question:")[0]
        if all(n in ev for n in needles) and mode != "never_sufficient":
            return ans
        return "unknown guess" if system == prompts.standard_system(True) else prompts.ABSTAIN_TOKEN
    if system == prompts.DIRECT_SYSTEM:
        q = re.search(r"Question: (.*)\nAnswer:", user).group(1)
        return DIRECT[q]
    raise AssertionError("unrecognised prompt")


class FakeServer:
    def __init__(self, mode: str = "normal", port: int = 0, report_usage: bool = True):
        self.mode, self.report_usage = mode, report_usage
        self.requests: list[dict] = []   # {"messages", "text", "usage"}
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                text = respond(body["messages"], outer.mode)
                pt = max(1, sum(len(m["content"]) for m in body["messages"]) // 4)
                ct = max(1, len(text) // 4)
                outer.requests.append({"messages": body["messages"], "text": text, "usage": (pt, ct)})
                resp = {"choices": [{"message": {"role": "assistant", "content": text}}]}
                if outer.report_usage:
                    resp["usage"] = {"prompt_tokens": pt, "completion_tokens": ct, "total_tokens": pt + ct}
                data = json.dumps(resp).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self.httpd = HTTPServer(("127.0.0.1", port), H)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.httpd.server_address[1]}/v1"

    def start(self):
        self.thread.start()
        return self

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8123)
    ap.add_argument("--mode", default="normal")
    a = ap.parse_args()
    s = FakeServer(a.mode, a.port).start()
    print("fake server on", s.base_url, flush=True)
    s.thread.join()
