import csv
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from oprag import prompts_tree as P  # noqa: E402
from oprag.decomp_eval import (answer_correct, render_review, render_summary,  # noqa: E402
                               run_decomposition_eval, summarize, wilson, write_review_csv)
from oprag.llm import BaseLLM  # noqa: E402
from oprag.tracking import Tracker  # noqa: E402
from oprag.tree import build_tree, check_against_gold, normalize_ph, title_in_text  # noqa: E402

# ----------------------------------------------------------------------------- synthetic HotpotQA-format data
ORIG = [
    {"_id": "b1", "question": "Which country is the director of the film Inception from?", "answer": "United Kingdom",
     "type": "bridge", "level": "medium",
     "supporting_facts": [["Inception", 0], ["Christopher Nolan", 0]],
     "context": [["Inception", ["Inception is a 2010 film directed by Christopher Nolan."]],
                 ["Christopher Nolan", ["Christopher Nolan is a filmmaker born in London, United Kingdom."]],
                 ["Paris", ["Paris is the capital of France."]]]},
    {"_id": "b2", "question": "What river flows through the capital of France?", "answer": "Seine", "type": "bridge",
     "level": "easy", "supporting_facts": [["Paris", 0], ["Seine", 0]],
     "context": [["Paris", ["Paris is the capital of France."]], ["Seine", ["The Seine flows through Paris."]]]},
    {"_id": "c1", "question": "Which was released earlier, the album Thriller or the album Back in Black?",
     "answer": "Back in Black", "type": "comparison", "level": "easy",
     "supporting_facts": [["Thriller (album)", 0], ["Back in Black", 0]],
     "context": [["Thriller (album)", ["Thriller was released in 1982."]],
                 ["Back in Black", ["Back in Black was released in 1980."]]]},
    {"_id": "c2", "question": "Are the cities of Oslo and Bergen located in the same country?", "answer": "yes",
     "type": "comparison", "level": "easy", "supporting_facts": [["Oslo", 0], ["Bergen", 0]],
     "context": [["Oslo", ["Oslo is a city in Norway."]], ["Bergen", ["Bergen is a city in Norway."]]]},
]

TREES = {  # what the scripted "model" outputs first (list = consecutive attempts)
    ORIG[0]["question"]: [{"type": "bridge", "sub_questions": ["Who directed the film Inception?"],
                           "root": "Which country is [A1] from?"}],
    # attempt 1 forgets the placeholder -> repaired on attempt 2
    ORIG[1]["question"]: [{"type": "bridge", "sub_questions": ["What is the capital of France?"],
                           "root": "Which river flows through the capital?"},
                          {"type": "bridge", "sub_questions": ["What is the capital of France?"],
                           "root": "Which river flows through {A1}?"}],
    # valid structure but WRONG type for a comparison question: must not be repaired (gold is never shown)
    ORIG[2]["question"]: [{"type": "bridge", "sub_questions": ["When was the album Thriller released?"],
                           "root": "Which was released earlier than [A1]: Thriller or Back in Black?"}],
    ORIG[3]["question"]: [{"type": "comparison",
                           "sub_questions": ["In which country is the city of Oslo located?",
                                             "In which country is the city of Bergen located?"],
                           "root": "Are the cities of Oslo (located in [A1]) and Bergen (located in [A2]) located in the same country?"}],
}
LEAF = {"Who directed the film Inception?": "Christopher Nolan", "What is the capital of France?": "Paris",
        "In which country is the city of Oslo located?": "Norway",
        "In which country is the city of Bergen located?": "Norway"}
FILLED = {"Which country is Christopher Nolan from?": "United Kingdom", "Which river flows through Paris?": "Seine",
          "Are the cities of Oslo (located in Norway) and Bergen (located in Norway) located in the same country?": "yes"}
DIRECT = {ORIG[0]["question"]: "United Kingdom", ORIG[1]["question"]: "Seine",
          ORIG[2]["question"]: "Back in Black", ORIG[3]["question"]: "yes"}


class ScriptedLLM(BaseLLM):
    def __init__(self, tracker):
        super().__init__(tracker)
        self.queue = {q: list(v) for q, v in TREES.items()}
        self.repairs_seen = []

    def _complete(self, messages, max_tokens, temperature):
        system, user = messages[0]["content"], messages[1]["content"]
        q = user.split("Question: ", 1)[1].split("\n")[0] if "Question: " in user else ""
        if system == P.DECOMPOSE_TREE_SYSTEM:
            if "Your previous output was invalid" in user:
                self.repairs_seen.append(user)
            seq = self.queue[q]
            out = seq.pop(0) if len(seq) > 1 else seq[0]
            return json.dumps(out), {"prompt_tokens": 100, "completion_tokens": 30}
        if system == P.EXEC_LEAF_SYSTEM:
            ans = LEAF.get(q) or FILLED.get(q) or DIRECT.get(q, "UNKNOWN")
            return ans, {"prompt_tokens": 40, "completion_tokens": 3}
        if system == P.EXEC_ROOT_SYSTEM:
            return FILLED.get(q, "UNKNOWN"), {"prompt_tokens": 20, "completion_tokens": 3}
        raise AssertionError("unknown prompt")


def questions_from_prepare(tmp: str) -> list[dict]:
    src = os.path.join(tmp, "hot.json")
    out = os.path.join(tmp, "q.jsonl")
    with open(src, "w", encoding="utf-8") as f:
        json.dump(ORIG, f)
    subprocess.run([sys.executable, "-I", str(ROOT / "scripts" / "prepare_hotpot.py"), "--json", src, "--n", "4",
                    "--out", out], check=True, capture_output=True)
    with open(out, encoding="utf-8") as f:
        return sorted((json.loads(x) for x in f), key=lambda d: d["id"])


class TreeRules(unittest.TestCase):
    O = "Which country is the director of the film Inception from?"

    def test_placeholders_normalised(self):
        self.assertEqual(normalize_ph("Where is {A1} and <ANSWER2>?", False), "Where is [A1] and [A2]?")
        self.assertEqual(normalize_ph("Where is [A]?", True), "Where is [A1]?")

    def test_valid_bridge_and_comparison(self):
        t, p, _ = build_tree(self.O, {"type": "bridge", "sub_questions": ["Who directed the film Inception?"],
                                      "root": "Which country is {A1} from?"})
        self.assertIsNotNone(t, p)
        self.assertEqual(t.fill_root(["Nolan"]), "Which country is Nolan from?")
        t2, p2, _ = build_tree("Are Oslo and Bergen in the same country?", TREES[ORIG[3]["question"]][0])
        self.assertIsNotNone(t2, p2)
        self.assertEqual(t2.arity, 2)

    def test_structural_errors(self):
        bad = [
            ({"type": "triple", "sub_questions": ["a b c"], "root": "x y z [A1]"}, "type"),
            ({"type": "bridge", "sub_questions": ["Who directed Inception?"], "root": "Which country is he from?"}, "placeholder"),
            ({"type": "bridge", "sub_questions": ["Who directed Inception?", "Who wrote Inception?"], "root": "Is [A1] from [A2] anywhere?"}, "exactly 1"),
            ({"type": "bridge", "sub_questions": ["Who directed [A1] Inception?"], "root": "Which country is [A1] from?"}, "must not contain"),
            ({"type": "comparison", "sub_questions": ["When was Thriller released?", "When was Thriller released?"],
              "root": "Which is earlier: Thriller ([A1]) or Thriller ([A2])?"}, "identical"),
            ({"type": "comparison", "sub_questions": ["When was Thriller released?", "When was Dune released?"],
              "root": "Which was released earlier than [A1] here?"}, "exactly once"),
            ({"type": "bridge", "sub_questions": [self.O], "root": "Which country is [A1] from?"}, "repeats"),
            ({"type": "bridge", "sub_questions": ["Who directed Inception?"], "root": "[A1]"}, "too short"),
        ]
        for obj, needle in bad:
            tree, probs, _ = build_tree(self.O, obj)
            self.assertIsNone(tree, obj)
            self.assertTrue(any(needle in p for p in probs), (needle, probs))
        self.assertIsNone(build_tree(self.O, "garbage")[0])

    def test_warnings_do_not_reject(self):
        t, p, w = build_tree(self.O, {"type": "bridge", "sub_questions": ["Who directed it?"],
                                      "root": "Which country is [A1] from?"})
        self.assertIsNotNone(t, p)
        self.assertTrue(any("self-contained" in x for x in w))
        self.assertTrue(any("inception" in x for x in w))      # dropped entity token (reported normalised)

    def test_gold_checks(self):
        t, _, _ = build_tree("x", TREES[ORIG[3]["question"]][0])
        g = check_against_gold(t, "comparison", ["Oslo", "Bergen"])
        self.assertTrue(g["structure_ok"])
        self.assertFalse(check_against_gold(t, "bridge", ["Oslo", "Bergen"])["structure_ok"])
        same, _, _ = build_tree("Q about Oslo and Bergen", {
            "type": "comparison", "sub_questions": ["In which country is Oslo located?", "How big is Oslo city?"],
            "root": "Are Oslo ([A1]) and Bergen ([A2]) in the same country?"})
        self.assertFalse(check_against_gold(same, "comparison", ["Oslo", "Bergen"])["leaves_cover_distinct_entities"])
        self.assertTrue(title_in_text("Thriller (album)", "When was the album Thriller released?"))
        self.assertFalse(title_in_text("Ed Wood", "Who is Wood Allen?"))

    def test_answer_matching_and_wilson(self):
        self.assertTrue(answer_correct("The United Kingdom", "United Kingdom"))
        self.assertTrue(answer_correct("Yes", "yes"))
        self.assertFalse(answer_correct("no", "yes"))
        self.assertFalse(answer_correct("UNKNOWN", "Seine"))
        lo, hi = wilson(25, 50)
        self.assertTrue(0.36 < lo < 0.38 and 0.62 < hi < 0.64)


class PipelineTests(unittest.TestCase):
    def _run(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        qs = questions_from_prepare(tmp.name)
        tracker = Tracker()
        llm = ScriptedLLM(tracker)
        recs = run_decomposition_eval(qs, llm, tracker, max_attempts=3, log=lambda *_: None)
        return tmp.name, qs, tracker, llm, {r["id"]: r for r in recs}

    def test_prepare_script_keeps_only_gold_paragraphs(self):
        with tempfile.TemporaryDirectory() as d:
            qs = questions_from_prepare(d)
        by = {q["id"]: q for q in qs}
        self.assertEqual(set(by), {"b1", "b2", "c1", "c2"})
        self.assertEqual(set(by["b1"]["paragraphs"]), {"Inception", "Christopher Nolan"})   # distractor dropped
        self.assertEqual(by["b1"]["supporting_titles"], ["Inception", "Christopher Nolan"])

    def test_verdicts_and_repair_policy(self):
        _, _, _, llm, r = self._run()
        self.assertTrue(r["b1"]["tree_valid"] and r["b1"]["decomp_ok_auto"])
        self.assertTrue(r["c2"]["tree_valid"] and r["c2"]["decomp_ok_auto"])
        # b2 needed one repair (placeholder missing), then ok
        self.assertEqual(r["b2"]["attempts"], 2)
        self.assertFalse(r["b2"]["first_attempt_valid"])
        self.assertTrue(r["b2"]["decomp_ok_auto"])
        # c1: structurally valid but wrong type -> NOT repaired (the gold label never reaches the model)
        self.assertEqual(r["c1"]["attempts"], 1)
        self.assertFalse(r["c1"]["tree_valid"])
        self.assertFalse(r["c1"]["gold_checks"]["type_ok"])
        self.assertFalse(r["c1"]["decomp_ok_auto"])
        # repair prompts mention structural problems only, never gold data
        self.assertEqual(len(llm.repairs_seen), 1)
        self.assertNotIn("gold", llm.repairs_seen[0].lower())
        self.assertNotIn("bridge or comparison", llm.repairs_seen[0])

    def test_cost_is_split_and_complete(self):
        _, qs, tracker, _, r = self._run()
        dec_calls = sum(x["cost_decomposition"]["llm_calls"] for x in r.values())
        ev_calls = sum(x["cost_evaluation"]["llm_calls"] for x in r.values())
        self.assertEqual(dec_calls + ev_calls, len(tracker.llm_calls))
        self.assertEqual(dec_calls, 5)                        # 4 questions + 1 repair
        self.assertTrue(all(c.stage.startswith(("decompose", "eval_")) for c in tracker.llm_calls))
        self.assertEqual(sum(x["cost_decomposition"]["total_tokens"] + x["cost_evaluation"]["total_tokens"]
                             for x in r.values()),
                         sum(c.prompt_tokens + c.completion_tokens for c in tracker.llm_calls))
        # c1 has a valid-structure tree, so evaluation ran; bridge b2 = 2 leaf-style calls + direct
        self.assertEqual(r["b1"]["cost_evaluation"]["llm_calls"], 3)       # leaf, root, direct
        self.assertEqual(r["c2"]["cost_evaluation"]["llm_calls"], 4)       # 2 leaves, root, direct

    def test_summary_and_review_files(self):
        _, _, _, _, r = self._run()
        recs = list(r.values())
        s = summarize(recs)
        self.assertEqual((s["n"], s["tree_built"], s["tree_valid"], s["decomp_ok_auto"]), (4, 4, 3, 3))
        self.assertEqual(s["first_attempt_valid"], 3)
        self.assertEqual(s["by_type"]["comparison"]["tree_valid"], 1)
        md = render_summary(s)
        self.assertIn("tree_valid", md)
        self.assertIn("Decomposition", md)
        review = render_review(recs)
        self.assertIn("`-- [A1] <- Who directed the film Inception?", review)
        self.assertIn("Christopher Nolan", review)
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "review.csv")
            write_review_csv(path, recs)
            with open(path, encoding="utf-8-sig", newline="") as f:
                rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 4)
        self.assertIn("human_tree_ok(y/n)", rows[0])
        self.assertEqual({x["id"]: x["auto_verdict"] for x in rows}["c1"], "TREE_INVALID")


if __name__ == "__main__":
    unittest.main()
