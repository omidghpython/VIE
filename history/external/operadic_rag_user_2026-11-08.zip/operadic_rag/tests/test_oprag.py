import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from fake_llm_server import FakeServer  # noqa: E402
from oprag.config import Config  # noqa: E402
from oprag.experiment import load_questions, run_experiment, write_outputs  # noqa: E402
from oprag.llm import OpenAICompatLLM  # noqa: E402
from oprag.operad import (EvidenceBundle, QuestionTemplate, build_chain,  # noqa: E402
                          normalize_placeholders)
from oprag.retriever import BM25Retriever, Passage, load_corpus  # noqa: E402
from oprag.scoring import agreement, f1_score  # noqa: E402
from oprag.tracking import Tracker  # noqa: E402
from oprag.util import clean_answer, parse_json_object  # noqa: E402

CORPUS = str(ROOT / "data" / "toy_corpus.jsonl")
QUESTIONS = str(ROOT / "data" / "toy_questions.jsonl")


class UnitTests(unittest.TestCase):
    def test_scoring(self):
        self.assertEqual(agreement("Yes, with caveats", "yes"), 1.0)
        self.assertEqual(agreement("yes", "No"), 0.0)
        self.assertEqual(agreement("about 1,961 people", "1961 inhabitants"), 1.0)
        self.assertAlmostEqual(f1_score("the Seine river", "Seine"), 0.6666, places=3)

    def test_json_and_answer_cleaning(self):
        self.assertEqual(parse_json_object('text ```json\n{"a": {"b": 1}, "c": "x}"}\n``` tail')["c"], "x}")
        self.assertIsNone(parse_json_object("no json"))
        self.assertEqual(clean_answer('Answer: "Lisbon."\nextra'), "Lisbon")

    def test_operad_substitution_and_validation(self):
        self.assertEqual(normalize_placeholders("Who is {A1}'s wife? <ANSWER>"), "Who is [A1]'s wife? [A1]")
        t = QuestionTemplate("Which country is [A1] from?")
        self.assertEqual((t.arity, t.fill(["Nolan"])), (1, "Which country is Nolan from?"))
        orig = "Which country is the director of Inception from?"
        ok, probs = build_chain(orig, {"q1": "Who directed Inception?", "q2": "Which country is {A1} from?"})
        self.assertIsNotNone(ok, probs)
        self.assertEqual(ok.instantiate_q2("Nolan"), "Which country is Nolan from?")
        for bad in ({"q1": "Who directed [A1]?", "q2": "Where is [A1]?"},     # placeholder in q1
                    {"q1": "Who directed Inception?", "q2": "Where is he from?"},  # no placeholder
                    {"q1": orig, "q2": "What about [A1] here?"},               # q1 repeats the question
                    "not a dict"):
            self.assertIsNone(build_chain(orig, bad)[0])

    def test_evidence_union_and_bm25_exclude(self):
        a = EvidenceBundle([Passage("1", "", "x")])
        b = a.union([Passage("1", "", "x"), Passage("2", "", "y")])
        self.assertEqual([p.id for p in b.passages], ["1", "2"])
        r = BM25Retriever(load_corpus(CORPUS))
        first = r.search("Who founded Quasar Labs?", k=1)
        second = r.search("Who founded Quasar Labs?", k=1, exclude={first[0].id})
        self.assertNotEqual(first[0].id, second[0].id)


class PipelineTests(unittest.TestCase):
    def _run(self, mode="normal", cfg=None, report_usage=True, methods=("A", "B")):
        srv = FakeServer(mode, report_usage=report_usage).start()
        self.addCleanup(srv.stop)
        tracker = Tracker()
        llm = OpenAICompatLLM(tracker, srv.base_url, "fake")
        retriever = BM25Retriever(load_corpus(CORPUS))
        traces = run_experiment(load_questions(QUESTIONS), retriever, llm, tracker, cfg or Config(k=1),
                                methods=methods, log=lambda *_: None)
        return srv, tracker, traces

    def test_end_to_end_and_accounting(self):
        srv, tracker, traces = self._run()
        by = {(t["qid"], t["method"]): t for t in traces}
        # Method B resolves every toy question with 1 sub-question follow-up only where needed.
        for qid, gold in (("t1", "United Kingdom"), ("t2", "Seine"), ("t3", "Lisbon"), ("t4", "University of Porto")):
            self.assertEqual(by[(qid, "B")]["answer"], gold, qid)
        self.assertTrue(by[("t4", "B")]["detail"]["q1"]["retrieval_steps"] == 2, "Q1 of t4 needs a follow-up")
        self.assertEqual(by[("t4", "B")]["detail"]["q1"]["steps"][0]["next_action"], "rewrite_query")
        # consistency: t3/t4 direct answers were deliberately wrong
        self.assertTrue(by[("t1", "B")]["detail"]["consistent"])
        self.assertFalse(by[("t3", "B")]["detail"]["consistent"])
        # accounting: tracker totals == what the server actually served
        self.assertEqual(len(tracker.llm_calls), len(srv.requests))
        self.assertEqual(sum(c.prompt_tokens for c in tracker.llm_calls), sum(r["usage"][0] for r in srv.requests))
        self.assertEqual(sum(c.completion_tokens for c in tracker.llm_calls), sum(r["usage"][1] for r in srv.requests))
        self.assertTrue(all(c.latency_s > 0 for c in tracker.llm_calls))
        for t in traces:
            s = tracker.summarize(t["method"], t["qid"])
            self.assertEqual(s["llm_calls"], t["cost"]["llm_calls"])
            self.assertGreater(t["cost"]["wall_time_s"], 0)
        # every call is attributed to a method and question
        self.assertTrue(all(c.method in "AB" and c.qid for c in tracker.llm_calls))
        # Method A uses at most 2 LLM calls / 2 retrievals per question
        for t in traces:
            if t["method"] == "A":
                self.assertLessEqual(t["cost"]["llm_calls"], 2)
                self.assertLessEqual(t["cost"]["retrieval_calls"], 2)

    def test_retrieval_cap_is_never_exceeded(self):
        # Model never says "sufficient": the budget must still stop at 2 steps per sub-question / question.
        for mode in ("never_sufficient", "deepen"):
            _, tracker, traces = self._run(mode=mode)
            for t in traces:
                if t["method"] == "A":
                    self.assertLessEqual(t["cost"]["retrieval_calls"], 2)
                else:
                    d = t["detail"]
                    self.assertLessEqual(d["q1"]["retrieval_steps"], 2)
                    self.assertLessEqual(d["q2"]["retrieval_steps"], 2)
                    self.assertLessEqual(t["cost"]["retrieval_calls"], 4)

    def test_max_retrievals_one_and_no_fallback(self):
        _, _, traces = self._run(cfg=Config(k=1, max_retrievals=1, std_fallback=False))
        for t in traces:
            self.assertEqual(t["cost"]["retrieval_calls"], 1 if t["method"] == "A" else 2)

    def test_direct_source_std_rag_costs_one_call_less(self):
        _, _, base = self._run()
        _, _, reuse = self._run(cfg=Config(k=1, direct_source="std_rag"))
        for b0, b1 in zip([t for t in base if t["method"] == "B"], [t for t in reuse if t["method"] == "B"]):
            self.assertEqual(b1["cost"]["llm_calls"], b0["cost"]["llm_calls"] - 1)
            self.assertEqual(b1["detail"]["direct_source"], "std_rag")

    def test_estimated_tokens_when_server_gives_no_usage(self):
        _, tracker, _ = self._run(report_usage=False, methods=("A",))
        self.assertTrue(tracker.llm_calls and all(c.estimated for c in tracker.llm_calls))

    def test_decomposition_failure_falls_back_to_single_unit(self):
        from oprag import prompts
        import fake_llm_server as fs
        orig = dict(fs.DECOMP)
        try:
            fs.DECOMP["What river flows through the capital of France?"] = {"q1": "x", "q2": "no placeholder here"}
            _, tracker, traces = self._run(methods=("B",))
        finally:
            fs.DECOMP.clear()
            fs.DECOMP.update(orig)
        t2 = [t for t in traces if t["qid"] == "t2"][0]
        self.assertTrue(t2["detail"]["decomposition_failed"])
        self.assertEqual(t2["detail"]["decomposition"]["attempts"], 2)
        stages = [c.stage for c in tracker.llm_calls if c.qid == "t2"]
        self.assertIn("decompose_retry", stages)

    def test_outputs_written(self):
        _, tracker, traces = self._run()
        with tempfile.TemporaryDirectory() as d:
            summary = write_outputs(d, traces, tracker, Config(k=1))
            for f in ("traces.jsonl", "llm_calls.jsonl", "retrieval_calls.jsonl", "summary.json", "summary.md"):
                self.assertTrue(os.path.getsize(os.path.join(d, f)) > 0, f)
            with open(os.path.join(d, "traces.jsonl")) as fh:
                first = json.loads(fh.readline())
            self.assertIn("cost", first)
        self.assertGreater(summary["methods"]["B"]["avg_llm_calls"], summary["methods"]["A"]["avg_llm_calls"])


if __name__ == "__main__":
    unittest.main()
