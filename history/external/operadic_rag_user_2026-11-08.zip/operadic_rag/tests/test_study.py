import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from fake_llm_server import FakeServer  # noqa: E402
from oprag.analysis import (_confusion, detection_report, guidance_report,  # noqa: E402
                            paired_bootstrap)
from oprag.config import Config  # noqa: E402
from oprag.experiment import load_questions, oracle_label  # noqa: E402
from oprag.llm import OpenAICompatLLM  # noqa: E402
from oprag.retriever import BM25Retriever, load_corpus  # noqa: E402
from oprag.study import run_study  # noqa: E402

CORPUS = str(ROOT / "data" / "toy_corpus.jsonl")
QUESTIONS = str(ROOT / "data" / "toy_questions.jsonl")


class AnalysisUnit(unittest.TestCase):
    def test_confusion_math(self):
        ev = ([{"pred_insufficient": True, "oracle_insufficient": True}] * 3
              + [{"pred_insufficient": True, "oracle_insufficient": False}] * 1
              + [{"pred_insufficient": False, "oracle_insufficient": True}] * 2
              + [{"pred_insufficient": False, "oracle_insufficient": False}] * 4)
        c = _confusion(ev)
        self.assertEqual((c["tp"], c["fp"], c["fn"], c["tn"]), (3, 1, 2, 4))
        self.assertAlmostEqual(c["precision"], 0.75)
        self.assertAlmostEqual(c["recall"], 0.6)
        self.assertAlmostEqual(c["gap_prevalence"], 0.5)
        self.assertAlmostEqual(c["always_sufficient_accuracy"], 0.5)

    def test_oracle_label(self):
        hops = {"q1": ["d1"], "q2": ["d2"]}
        self.assertTrue(oracle_label("q1", ["d1", "d9"], "", hops, [], []))
        self.assertFalse(oracle_label("q1", ["d9"], "", hops, [], []))
        self.assertIsNone(oracle_label("q1", ["d9"], "", {}, [], ["x"]))               # no oracle for Q1 without hop ids
        self.assertTrue(oracle_label("q2", [], "it is lisbon today", {}, [], ["Lisbon"]))  # answer-string fallback
        self.assertFalse(oracle_label("q2", [], "nothing here", {}, [], ["Lisbon"]))

    def test_bootstrap(self):
        m, lo, hi = paired_bootstrap([1.0] * 10)
        self.assertEqual((m, lo, hi), (1.0, 1.0, 1.0))
        self.assertIsNone(paired_bootstrap([]))


class StudyEndToEnd(unittest.TestCase):
    def _study(self, mode):
        srv = FakeServer(mode).start()
        self.addCleanup(srv.stop)
        retriever = BM25Retriever(load_corpus(CORPUS))
        with tempfile.TemporaryDirectory() as d:
            res = run_study(load_questions(QUESTIONS), retriever,
                            lambda tr: OpenAICompatLLM(tr, srv.base_url, "fake"), Config(k=1), out_dir=d, log=lambda *_: None)
            md = open(os.path.join(d, "study.md"), encoding="utf-8").read()
            self.assertTrue(os.path.exists(os.path.join(d, "B-guided", "summary.md")))
        return res, md

    def test_policies_control_followups_and_cost_ordering(self):
        res, md = self._study("normal")
        ret = {n: v["summary"]["avg_retrieval_calls"] for n, v in res.items()}
        tok = {n: v["summary"]["avg_tokens_excl_direct"] for n, v in res.items()}
        self.assertEqual(ret["B-never"], 2.0)                    # exactly one retrieval per sub-question
        self.assertEqual(ret["B-always"], 4.0)                   # follow-up for every sub-question
        self.assertTrue(ret["B-never"] < ret["B-guided"] < ret["B-always"])
        self.assertTrue(tok["B-never"] < tok["B-guided"] < tok["B-always"])
        # the budget cap holds under every policy
        for n, v in res.items():
            for t in v["traces"]:
                self.assertLessEqual(t["cost"]["retrieval_calls"], 4 if v["method"] == "B" else 2, n)
        # follow-up cost is attributed only to steps >= 2
        self.assertEqual(res["B-never"]["summary"]["avg_followup_tokens"], 0)
        self.assertGreater(res["B-guided"]["summary"]["avg_followup_tokens"], 0)
        # guided recovers the same answers as the blind policy here, at lower cost
        self.assertEqual(res["B-guided"]["summary"]["f1"], 1.0)
        self.assertLess(res["B-never"]["summary"]["f1"], 1.0)
        self.assertIn("RQ1", md)
        self.assertIn("B-guided − B-never", md)

    def test_detection_with_calibrated_model(self):
        res, _ = self._study("normal")
        det = detection_report(res["B-guided"]["traces"])["scopes"]["step1"]
        self.assertEqual(det["fn"], 0)                           # a model that reads evidence never claims sufficiency falsely
        self.assertGreaterEqual(det["tp"], 1)                    # t4/Q1 is a real gap and was flagged
        g = guidance_report(res["B-guided"]["traces"])
        self.assertEqual(g["gaps_fixed"], g["gaps_triggered"])
        self.assertEqual(g["gaps_missed_no_followup"], 0)
        self.assertEqual(g["wasted_followups"], 0)

    def test_overconfident_model_shows_missed_gaps(self):
        res, _ = self._study("overconfident")
        det = detection_report(res["B-guided"]["traces"])["scopes"]["step1"]
        self.assertGreaterEqual(det["fn"], 1)                    # claims sufficiency while gold evidence is missing
        self.assertEqual(det["tp"], 0)
        self.assertLess(det["recall"] or 0, 1.0)
        g = guidance_report(res["B-guided"]["traces"])
        self.assertGreaterEqual(g["gaps_missed_no_followup"], 1)


if __name__ == "__main__":
    unittest.main()
