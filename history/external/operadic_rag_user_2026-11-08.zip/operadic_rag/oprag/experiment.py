"""Run both methods over a question set, log everything, write a comparison report."""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict
from statistics import mean

from .config import Config
from .llm import BaseLLM
from .operadic_rag import run_operadic_rag
from .retriever import BM25Retriever, RetrievalService
from .scoring import normalize_answer, score_against_gold
from .standard_rag import run_standard_rag
from .tracking import Tracker

METHOD_NAMES = {"A": "Standard RAG", "B": "Operadic-Guided RAG"}


def load_questions(path: str) -> list[dict]:
    """JSONL with: id (optional), question, answer (optional; string or list of aliases)."""
    out = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if line.strip():
                d = json.loads(line)
                d.setdefault("id", str(i))
                out.append(d)
    return out


def _golds(q: dict) -> list[str]:
    a = q.get("answer")
    if a is None:
        return []
    return [str(x) for x in a] if isinstance(a, list) else [str(a)]


# ---------------------------------------------------------------------------------------------
# Evidence oracle (post-hoc; the pipeline itself never sees gold information).
#   * hop_ids        {"q1": [ids], "q2": [ids]}  -> unit is truly sufficient iff its gold passages were retrieved
#   * supporting_ids [ids]                       -> used for the whole question / the single-unit fallback "q"
#   * gold answer    -> fallback oracle for the final hop: answer string occurs in the retrieved text
# Caveat: hop labels assume the model's Q1/Q2 line up with gold hop 1/hop 2.
# ---------------------------------------------------------------------------------------------
def _gold_info(q: dict):
    sup = [str(x) for x in (q.get("supporting_ids") or [])]
    hops = q.get("hop_ids") or {}
    if isinstance(hops, list):
        hops = {"q1": hops[0], "q2": hops[1]} if len(hops) == 2 else {}
    return sup, {k: [str(x) for x in v] for k, v in hops.items()}


def _contains(text_norm: str, gold: str) -> bool:
    g = normalize_answer(gold)
    return bool(g) and f" {g} " in f" {text_norm} "


def oracle_label(sid: str, ids, text_norm: str, hops: dict, sup: list, golds: list):
    """True/False = evidence truly sufficient / not; None = no oracle available for this unit."""
    gold_ids = hops.get(sid) or (sup if sid == "q" else None)
    if gold_ids:
        return set(gold_ids) <= set(ids)
    if sid in ("q2", "q") and golds:
        return any(_contains(text_norm, g) for g in golds)
    return None


def annotate_trace(trace: dict, q: dict, texts: dict) -> None:
    sup, hops = _gold_info(q)
    golds, d = trace["gold"], trace["detail"]
    ids = d["evidence_ids"]
    ev_norm = normalize_answer(" ".join(texts.get(i, "") for i in ids))
    trace["evidence_recall"] = (len(set(sup) & set(ids)) / len(sup)) if sup else None
    trace["answer_in_evidence"] = any(_contains(ev_norm, g) for g in golds) if golds else None
    if trace["method"] != "B":
        return
    for key in ("q1", "q2"):
        u = d.get(key)
        if not u:
            continue
        cum: list = []
        for st in u["steps"]:
            cum += st["new_doc_ids"]
            cn = normalize_answer(" ".join(texts.get(i, "") for i in cum))
            st["oracle_sufficient"] = oracle_label(u["sid"], cum, cn, hops, sup, golds)


def run_experiment(questions: list[dict], retriever: BM25Retriever, llm: BaseLLM, tracker: Tracker,
                   cfg: Config, methods=("A", "B"), log=print) -> list[dict]:
    cfg.validate()
    texts = {p.id: f"{p.title} {p.text}" for p in retriever.passages}
    if cfg.direct_source == "std_rag" and not ("A" in methods and "B" in methods):
        raise ValueError("direct_source='std_rag' needs both methods A and B")
    retrieval = RetrievalService(retriever, tracker)
    traces: list[dict] = []
    for i, q in enumerate(questions, 1):
        qid, question, golds = str(q["id"]), q["question"], _golds(q)
        res_a = None
        for m in methods:
            with tracker.scope(m, qid):
                t0 = time.perf_counter()
                if m == "A":
                    res = res_a = run_standard_rag(question, llm, retrieval, cfg)
                else:
                    direct = res_a["answer"] if cfg.direct_source == "std_rag" else None
                    res = run_operadic_rag(question, llm, retrieval, cfg, direct_answer=direct)
                wall = time.perf_counter() - t0
            cost = tracker.summarize(m, qid)
            cost["wall_time_s"] = wall
            em, f1 = score_against_gold(res["answer"], golds) if golds else (None, None)
            traces.append({"qid": qid, "method": m, "question": question, "gold": golds,
                           "answer": res["answer"], "em": em, "f1": f1, "cost": cost, "detail": res})
            annotate_trace(traces[-1], q, texts)
        log(f"[{i}/{len(questions)}] {qid}: " + " | ".join(
            f"{m}={t['answer']!r}" for t in traces[-len(methods):] for m in [t['method']]))
    return traces


def _avg(xs):
    xs = [x for x in xs if x is not None]
    return mean(xs) if xs else None


def summarize_traces(traces: list[dict], tracker: Tracker, cfg: Config) -> dict:
    out: dict = {"config": asdict(cfg), "methods": {}}
    for m in sorted({t["method"] for t in traces}):
        ts = [t for t in traces if t["method"] == m]
        c = lambda key: _avg([t["cost"][key] for t in ts])  # noqa: E731
        s = {
            "name": METHOD_NAMES[m], "n_questions": len(ts),
            "em": _avg([t["em"] for t in ts]), "f1": _avg([t["f1"] for t in ts]),
            "avg_llm_calls": c("llm_calls"), "avg_prompt_tokens": c("prompt_tokens"),
            "avg_completion_tokens": c("completion_tokens"), "avg_total_tokens": c("total_tokens"),
            "avg_retrieval_calls": c("retrieval_calls"), "avg_passages_retrieved": c("passages_retrieved"),
            "avg_llm_time_s": c("llm_time_s"), "avg_retrieval_time_s": c("retrieval_time_s"),
            "avg_wall_time_s": c("wall_time_s"),
            "avg_tokens_excl_direct": _avg([t["cost"]["total_tokens"] - t["cost"]["direct_tokens"] for t in ts]),
            "avg_followup_tokens": c("followup_tokens"), "avg_followup_llm_calls": c("followup_llm_calls"),
            "avg_followup_time_s": c("followup_time_s"),
            "evidence_recall": _avg([t.get("evidence_recall") for t in ts]),
            "answer_in_evidence": _avg([None if t.get("answer_in_evidence") is None
                                        else float(t["answer_in_evidence"]) for t in ts]),
            "total_llm_calls": sum(t["cost"]["llm_calls"] for t in ts),
            "total_tokens": sum(t["cost"]["total_tokens"] for t in ts),
            "total_wall_time_s": sum(t["cost"]["wall_time_s"] for t in ts),
            "tokens_estimated": any(t["cost"]["tokens_estimated"] for t in ts),
            "by_stage": tracker.by_stage(m),
        }
        if m == "B":
            d = [t["detail"] for t in ts]
            ok = [x for x in d if not x["decomposition_failed"]]
            s["decomposition_failure_rate"] = 1 - len(ok) / len(d)
            s["consistency_rate"] = mean(1.0 if x["consistent"] else 0.0 for x in d)
            s["avg_consistency_score"] = mean(x["consistency_score"] for x in d)
            for sid in ("q1", "q2"):
                parts = [x[sid] for x in ok if x[sid]]
                if parts:
                    s[f"{sid}_final_insufficient_rate"] = mean(
                        1.0 if p["sufficiency"] != "sufficient" else 0.0 for p in parts)
                    s[f"{sid}_followup_rate"] = mean(1.0 if p["retrieval_steps"] > 1 else 0.0 for p in parts)
            for flag, name in ((True, "consistent"), (False, "inconsistent")):
                sub = [t["f1"] for t in ts if t["detail"]["consistent"] is flag]
                s[f"f1_when_{name}"] = _avg(sub)
                s[f"n_{name}"] = len(sub)
        if m == "A":
            s["fallback_round_rate"] = mean(1.0 if t["detail"]["retrieval_steps"] > 1 else 0.0 for t in ts)
        out["methods"][m] = s
    return out


def _fmt(v, nd=3):
    if v is None:
        return "-"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def render_markdown(summary: dict) -> str:
    ms = summary["methods"]
    cols = [m for m in ("A", "B") if m in ms]
    rows = [
        ("Questions", "n_questions"), ("EM", "em"), ("F1", "f1"),
        ("LLM calls / question", "avg_llm_calls"), ("Prompt tokens / question", "avg_prompt_tokens"),
        ("Completion tokens / question", "avg_completion_tokens"), ("Total tokens / question", "avg_total_tokens"),
        ("Tokens excl. consistency check / question", "avg_tokens_excl_direct"),
        ("Follow-up (step>=2) tokens / question", "avg_followup_tokens"),
        ("Gold-evidence recall", "evidence_recall"), ("Gold answer in evidence", "answer_in_evidence"),
        ("Retrieval calls / question", "avg_retrieval_calls"), ("Passages retrieved / question", "avg_passages_retrieved"),
        ("LLM time / question (s)", "avg_llm_time_s"), ("Retrieval time / question (s)", "avg_retrieval_time_s"),
        ("Wall time / question (s)", "avg_wall_time_s"),
        ("Total LLM calls", "total_llm_calls"), ("Total tokens", "total_tokens"), ("Total wall time (s)", "total_wall_time_s"),
    ]
    lines = ["| Metric | " + " | ".join(f"{m}: {ms[m]['name']}" for m in cols) + " |",
             "|---|" + "---|" * len(cols)]
    for label, key in rows:
        lines.append(f"| {label} | " + " | ".join(_fmt(ms[m].get(key), 2 if "tokens" in key or "calls" in key or "passages" in key else 3)
                                                  for m in cols) + " |")
    if "B" in ms:
        b = ms["B"]
        lines += ["", "**Method B diagnostics**", "",
                  f"- Decomposition failure rate: {_fmt(b['decomposition_failure_rate'])}",
                  f"- Consistency rate (direct vs final): {_fmt(b['consistency_rate'])}; mean agreement {_fmt(b['avg_consistency_score'])}",
                  f"- F1 when consistent (n={b['n_consistent']}): {_fmt(b['f1_when_consistent'])}; "
                  f"when inconsistent (n={b['n_inconsistent']}): {_fmt(b['f1_when_inconsistent'])}"]
        for sid in ("q1", "q2"):
            if f"{sid}_followup_rate" in b:
                lines.append(f"- {sid.upper()}: follow-up retrieval rate {_fmt(b[sid + '_followup_rate'])}; "
                             f"still not sufficient after retrieval {_fmt(b[sid + '_final_insufficient_rate'])}")
    if "A" in ms:
        lines.append(f"- Method A fallback (2nd retrieval) rate: {_fmt(ms['A']['fallback_round_rate'])}")
    est = any(ms[m]["tokens_estimated"] for m in cols)
    if est:
        lines.append("- NOTE: the server returned no token usage for some calls; those counts are estimates (chars/4).")
    lines += ["", "**Cost by stage (totals over all questions)**", "",
              "| Method | Stage | Calls | Prompt tok | Completion tok | Time (s) |", "|---|---|---|---|---|---|"]
    for m in cols:
        for stage, v in sorted(ms[m]["by_stage"].items()):
            lines.append(f"| {m} | {stage} | {v['calls']} | {v.get('prompt_tokens', 0)} | "
                         f"{v.get('completion_tokens', 0)} | {v['time_s']:.3f} |")
    return "\n".join(lines) + "\n"


def write_outputs(out_dir: str, traces: list[dict], tracker: Tracker, cfg: Config) -> dict:
    os.makedirs(out_dir, exist_ok=True)

    def dump(name, rows):
        with open(os.path.join(out_dir, name), "w", encoding="utf-8") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

    dump("traces.jsonl", traces)
    dump("llm_calls.jsonl", [asdict(c) for c in tracker.llm_calls])
    dump("retrieval_calls.jsonl", [asdict(c) for c in tracker.retrieval_calls])
    summary = summarize_traces(traces, tracker, cfg)
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "summary.md"), "w", encoding="utf-8") as f:
        f.write(render_markdown(summary))
    return summary
