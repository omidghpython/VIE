"""Decomposition tree in the questions operad.

  bridge      : leaves = [Q1],      root in Q(c1; d)      -> original = root o_1 Q1   (arity 1)
  comparison  : leaves = [Q1, Q2],  root in Q(c1, c2; d)  -> original = root o (Q1, Q2) (arity 2)

Two kinds of checks, kept apart on purpose:
  * build_tree           gold-free structural rules. Its problems are fed back to the model for repair.
  * check_against_gold   evaluation only (uses HotpotQA labels). NEVER shown to the model.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from . import prompts_tree as P
from .operad import QuestionTemplate
from .scoring import normalize_answer
from .util import parse_json_object

KINDS = ("bridge", "comparison")
_PH = re.compile(r"\[A(\d+)\]")
_PH_VARIANT = re.compile(r"[\[\{<]\s*(?:A|ANS|ANSWER)\s*[_-]?\s*(\d)\s*[\]\}>]", re.I)
_PH_BARE = re.compile(r"[\[\{<]\s*(?:A|ANS|ANSWER)\s*[\]\}>]", re.I)
_PRONOUNS = {"he", "she", "him", "her", "his", "hers", "they", "them", "their", "it", "its", "this", "these", "those"}
_TITLE_STOP = {"the", "a", "an", "of", "and", "in", "on", "at", "for"}


def _norm(s: str) -> str:
    return normalize_answer(_PH.sub(" ", s))


def normalize_ph(text: str, bare_to_a1: bool) -> str:
    """Map '{A1}', '[a_2]', '<ANSWER>' ... to the canonical '[A1]', '[A2]'. A bare '[A]' means [A1] (bridge only)."""
    t = _PH_VARIANT.sub(lambda m: f"[A{m.group(1)}]", text or "")
    if bare_to_a1:
        t = _PH_BARE.sub("[A1]", t)
    return t.strip()


@dataclass(frozen=True)
class DecompositionTree:
    original: str
    kind: str
    leaves: tuple
    root: str

    @property
    def arity(self) -> int:
        return len(self.leaves)

    def fill_root(self, answers: list[str]) -> str:
        """Algebra action: plug the leaf answers into the blanks of the root template."""
        return QuestionTemplate(self.root).fill(list(answers))

    def to_dict(self) -> dict:
        return {"type": self.kind, "sub_questions": list(self.leaves), "root": self.root}

    def render(self, answers: list[str] | None = None) -> str:
        """ASCII tree (ASCII only: Windows consoles choke on box-drawing characters)."""
        lines = [f"[{self.kind}] {self.original}", f"  ROOT: {self.root}"]
        for i, leaf in enumerate(self.leaves, 1):
            ans = f"   => {answers[i - 1]!r}" if answers and i <= len(answers) else ""
            lines.append(f"   `-- [A{i}] <- {leaf}{ans}")
        return "\n".join(lines)


def _named_tokens(question: str) -> list[str]:
    toks = re.findall(r"[A-Za-z0-9][A-Za-z0-9'\-\.]*", question)
    out = [normalize_answer(t) for i, t in enumerate(toks) if i > 0 and (t[0].isupper() or t[0].isdigit())]
    return [t for t in out if t]


def build_tree(original: str, obj):
    """Return (tree | None, problems, warnings). `problems` are hard structural errors (gold-free)."""
    if not isinstance(obj, dict):
        return None, ["output is not a JSON object"], []
    problems: list[str] = []
    kind = str(obj.get("type", "")).strip().lower()
    if kind not in KINDS:
        problems.append('"type" must be "bridge" or "comparison"')
    subs = obj.get("sub_questions")
    if not isinstance(subs, list) or not all(isinstance(s, str) for s in subs):
        problems.append('"sub_questions" must be a list of strings')
        subs = []
    root = obj.get("root")
    if not isinstance(root, str):
        problems.append('"root" must be a string')
        root = ""
    if problems:
        return None, problems, []

    want = 1 if kind == "bridge" else 2
    if len(subs) != want:
        problems.append(f"a {kind} question needs exactly {want} sub-question(s), got {len(subs)}")
    leaves = [normalize_ph(s, False) for s in subs]
    root = normalize_ph(root, kind == "bridge")
    for i, leaf in enumerate(leaves, 1):
        if len(leaf.split()) < 3:
            problems.append(f"sub-question {i} is empty or too short")
        if _PH.search(leaf) or _PH_BARE.search(leaf):
            problems.append(f"sub-question {i} must not contain a placeholder")
        if _norm(leaf) == _norm(original):
            problems.append(f"sub-question {i} just repeats the original question")
    if len({_norm(x) for x in leaves}) < len(leaves):
        problems.append("the sub-questions are identical")
    found = sorted(int(x) for x in _PH.findall(root))
    expected = list(range(1, want + 1))
    if found != expected:
        problems.append("root must contain the placeholders " + ", ".join(f"[A{i}]" for i in expected)
                        + " exactly once each")
    rest = _PH.sub("", root)
    if len(rest.split()) < 3:
        problems.append("root is too short or is only a placeholder")
    elif _norm(rest) == _norm(original):
        problems.append("root just repeats the original question")
    if problems:
        return None, problems, []

    warnings: list[str] = []
    for i, leaf in enumerate(leaves, 1):
        pr = sorted({w for w in re.findall(r"[a-z]+", leaf.lower()) if w in _PRONOUNS})
        if pr:
            warnings.append(f"sub-question {i} may not be self-contained (contains {', '.join(pr)})")
    tree_tokens = set(normalize_answer(" ".join(leaves + [_PH.sub(" ", root)])).split())
    missing = sorted({t for t in _named_tokens(original) if t not in tree_tokens})
    if missing:
        warnings.append("tree drops tokens of the question: " + ", ".join(missing))
    return DecompositionTree(original, kind, tuple(leaves), root), [], warnings


def decompose_tree(llm, question: str, max_attempts: int = 3):
    """Ask the model for a tree; on structural problems send them back (never gold information)."""
    history, prev, problems = [], "", []
    for attempt in range(1, max_attempts + 1):
        user = (P.decompose_user(question) if attempt == 1
                else P.decompose_repair_user(question, prev, problems))
        raw = llm.chat(P.DECOMPOSE_TREE_SYSTEM, user,
                       stage="decompose" if attempt == 1 else "decompose_retry", max_tokens=300)
        tree, problems, warns = build_tree(question, parse_json_object(raw))
        history.append({"attempt": attempt, "raw": raw, "problems": problems, "warnings": warns})
        if tree is not None:
            return tree, {"attempts": attempt, "history": history, "warnings": warns}
        prev = raw
    return None, {"attempts": max_attempts, "history": history, "warnings": []}


# ------------------------------------------------------------------ gold-based (evaluation only)
def title_in_text(title: str, text: str) -> bool:
    nt = normalize_answer(re.sub(r"\s*\([^)]*\)", "", title))
    nx = normalize_answer(text)
    if not nt:
        return False
    if f" {nt} " in f" {nx} ":
        return True
    toks = [w for w in nt.split() if w not in _TITLE_STOP]
    if len(toks) < 2:
        return False
    words = set(nx.split())
    return sum(w in words for w in toks) / len(toks) >= 0.8


def check_against_gold(tree: DecompositionTree, gold_type: str, titles: list[str]) -> dict:
    """HotpotQA labels: question type and the titles of the two gold paragraphs.
    For comparison questions the gold titles are (almost always) the two compared entities, so
    each leaf must cover a different one and the root must restate both. Heuristic: confirm by hand."""
    out: dict = {"type_ok": tree.kind == gold_type}
    leaf_hits = [{t for t in titles if title_in_text(t, leaf)} for leaf in tree.leaves]
    if tree.kind == "comparison":
        distinct = len(leaf_hits) == 2 and any(a != b for a in leaf_hits[0] for b in leaf_hits[1])
        root_hits = {t for t in titles if title_in_text(t, tree.root)}
        out["leaves_cover_distinct_entities"] = distinct
        out["root_restates_entities"] = len(root_hits) >= 2
        out["entities_ok"] = distinct and len(root_hits) >= 2
    else:
        out["anchor_in_q1"] = bool(leaf_hits[0])      # soft: Q1 names an entity of a gold paragraph
        out["entities_ok"] = True
    out["structure_ok"] = out["type_ok"] and out["entities_ok"]
    return out
