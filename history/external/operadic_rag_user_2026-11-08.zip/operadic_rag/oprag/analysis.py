"""Analysis that answers the two research questions.

RQ1  Can the operadic decomposition flag sub-problems whose evidence is still insufficient?
     -> detection_report: confusion matrix of the model's sufficiency label vs the evidence oracle,
        at each assessment event (step 1 = the moment that matters).
RQ2  Is that information useful for steering the next retrieval, without a large cost increase?
     -> guidance_report (what happened to flagged gaps) and compare_variants
        (guided vs never vs always vs deepen-only vs wide Standard RAG: quality, evidence recall, cost).
"""
from __future__ import annotations

import random
from statistics import mean

SID_ORDER = ("q1", "q2", "q")


# ------------------------------------------------------------------ RQ1
def _events(traces):
    for t in traces:
        if t["method"] != "B":
            continue
        for key in ("q1", "q2"):
            u = t["detail"].get(key)
            if not u:
                continue
            for st in u["steps"]:
                if "sufficiency" in st and st.get("oracle_sufficient") is not None:
                    yield {"qid": t["qid"], "sid": u["sid"], "step": st["step"],
                           "pred_insufficient": st["sufficiency"] != "sufficient",
                           "oracle_insufficient": not st["oracle_sufficient"]}


def _confusion(ev: list[dict]) -> dict:
    tp = sum(e["pred_insufficient"] and e["oracle_insufficient"] for e in ev)
    fp = sum(e["pred_insufficient"] and not e["oracle_insufficient"] for e in ev)   # unneeded trigger
    fn = sum(not e["pred_insufficient"] and e["oracle_insufficient"] for e in ev)   # missed gap
    tn = sum(not e["pred_insufficient"] and not e["oracle_insufficient"] for e in ev)
    n = len(ev)
    prec = tp / (tp + fp) if tp + fp else None
    rec = tp / (tp + fn) if tp + fn else None
    f1 = 2 * prec * rec / (prec + rec) if prec and rec else (0.0 if prec is not None and rec is not None else None)
    prev = (tp + fn) / n if n else None
    return {"n": n, "tp": tp, "fp": fp, "fn": fn, "tn": tn, "gap_prevalence": prev,
            "precision": prec, "recall": rec, "f1": f1, "accuracy": (tp + tn) / n if n else None,
            # accuracy of the trivial detector that always says "sufficient"
            "always_sufficient_accuracy": (1 - prev) if prev is not None else None}


def detection_report(traces: list[dict]) -> dict:
    """'positive' = evidence insufficient (a gap). Step 1 = first retrieval for a sub-question."""
    ev = list(_events(traces))
    scopes = {"step1": [e for e in ev if e["step"] == 1],
              "step2": [e for e in ev if e["step"] == 2],
              "all_steps": ev}
    for sid in SID_ORDER:
        scopes[f"step1_{sid}"] = [e for e in ev if e["step"] == 1 and e["sid"] == sid]
    return {"scopes": {k: _confusion(v) for k, v in scopes.items() if v}}


# ------------------------------------------------------------------ RQ2 (a): what happened to gaps
def guidance_report(traces: list[dict]) -> dict:
    units = []
    for t in traces:
        if t["method"] != "B":
            continue
        for key in ("q1", "q2"):
            u = t["detail"].get(key)
            if not u or not u["steps"]:
                continue
            o1 = u["steps"][0].get("oracle_sufficient")
            if o1 is None:
                continue
            units.append({"o1": o1, "ofin": u["steps"][-1].get("oracle_sufficient"),
                          "triggered": len(u["steps"]) > 1, "action": u["steps"][0].get("next_action")})
    gaps = [x for x in units if not x["o1"]]
    trig_gaps = [x for x in gaps if x["triggered"]]
    fixed = [x for x in trig_gaps if x["ofin"]]
    per_action = {}
    for a in ("rewrite_query", "deepen"):
        sub = [x for x in trig_gaps if x["action"] == a]
        if sub:
            per_action[a] = {"n": len(sub), "fixed": sum(1 for x in sub if x["ofin"]),
                             "fix_rate": sum(1 for x in sub if x["ofin"]) / len(sub)}
    n = len(units)
    return {
        "n_units": n,
        "gaps_after_first_retrieval": len(gaps),
        "followups_triggered": sum(x["triggered"] for x in units),
        "gaps_triggered": len(trig_gaps),
        "gaps_fixed": len(fixed),
        "gaps_missed_no_followup": len(gaps) - len(trig_gaps),
        "wasted_followups": sum(1 for x in units if x["o1"] and x["triggered"]),
        "fix_rate_of_triggered_gaps": (len(fixed) / len(trig_gaps)) if trig_gaps else None,
        "followup_precision": (len(trig_gaps) / sum(x["triggered"] for x in units))
        if any(x["triggered"] for x in units) else None,
        "per_action": per_action,
    }


# ------------------------------------------------------------------ RQ2 (b): quality and cost
def paired_bootstrap(diffs: list[float], n_boot: int = 2000, seed: int = 0):
    """(mean, lo95, hi95) of a paired difference; None if empty."""
    n = len(diffs)
    if n == 0:
        return None
    rng = random.Random(seed)
    means = sorted(sum(diffs[rng.randrange(n)] for _ in range(n)) / n for _ in range(n_boot))
    return (sum(diffs) / n, means[int(0.025 * n_boot)], means[int(0.975 * n_boot) - 1])


def _per_q(traces, fn):
    out = {}
    for t in traces:
        v = fn(t)
        if v is not None:
            out[t["qid"]] = v
    return out


def _ratio(num, den, eps=1e-9):
    return None if den is None or num is None or abs(den) < eps else num / den


def compare_variants(variants: dict, ref: str = "A", base: str = "B-never", guided: str = "B-guided",
                     always: str = "B-always") -> dict:
    rows = {}
    for name, v in variants.items():
        s = v["summary"]
        rows[name] = {"method": v["method"], "f1": s["f1"], "em": s["em"], "evidence_recall": s["evidence_recall"],
                      "answer_in_evidence": s["answer_in_evidence"], "llm_calls": s["avg_llm_calls"],
                      "tokens": s["avg_tokens_excl_direct"], "followup_tokens": s["avg_followup_tokens"],
                      "retrieval_calls": s["avg_retrieval_calls"], "passages": s["avg_passages_retrieved"],
                      "wall_s": s["avg_wall_time_s"]}

    def f1s(n):
        return _per_q(variants[n]["traces"], lambda t: t["f1"])

    def toks(n):
        return _per_q(variants[n]["traces"], lambda t: t["cost"]["total_tokens"] - t["cost"]["direct_tokens"])

    paired = []
    for a, b in [(guided, ref), (guided, base), (always, base), (guided, always),
                 ("B-deepen", guided), ("A-wide", guided)]:
        if a not in variants or b not in variants:
            continue
        fa, fb, ta, tb = f1s(a), f1s(b), toks(a), toks(b)
        common = sorted(set(fa) & set(fb))
        d_f1 = paired_bootstrap([fa[q] - fb[q] for q in common])
        d_tok = mean(ta[q] - tb[q] for q in common) if common else None
        paired.append({"a": a, "b": b, "n": len(common), "d_f1": d_f1, "d_tokens": d_tok,
                       "f1_gain_per_1k_tokens": (d_f1[0] / (d_tok / 1000)) if d_f1 and d_tok and d_tok > 0 else None})

    eff = None
    if all(n in rows for n in (base, guided, always)):
        rb, rg, ra = rows[base], rows[guided], rows[always]
        eff = {
            "extra_tokens_always_vs_never": ra["tokens"] - rb["tokens"],
            "extra_tokens_guided_vs_never": rg["tokens"] - rb["tokens"],
            "share_of_extra_cost_spent": _ratio(rg["tokens"] - rb["tokens"], ra["tokens"] - rb["tokens"]),
            "share_of_f1_gain_captured": _ratio(
                None if None in (rg["f1"], rb["f1"]) else rg["f1"] - rb["f1"],
                None if None in (ra["f1"], rb["f1"]) else ra["f1"] - rb["f1"]),
            "share_of_recall_gain_captured": _ratio(
                None if None in (rg["evidence_recall"], rb["evidence_recall"]) else rg["evidence_recall"] - rb["evidence_recall"],
                None if None in (ra["evidence_recall"], rb["evidence_recall"]) else ra["evidence_recall"] - rb["evidence_recall"]),
        }
    return {"rows": rows, "paired": paired, "efficiency": eff}


# ------------------------------------------------------------------ report
def _f(v, nd=3):
    if v is None:
        return "n/a"
    return f"{v:.{nd}f}" if isinstance(v, float) else str(v)


def render_study(variants: dict, guided: str = "B-guided") -> tuple[str, dict]:
    comp = compare_variants(variants, guided=guided)
    L = ["# Study report", "",
         "Oracle labels use gold passage ids (`hop_ids` / `supporting_ids`) or, for the final hop, the gold answer "
         "string in the retrieved text. Small n -> read differences with the confidence intervals.", "",
         "## Variants: quality, evidence and cost", "",
         "| Variant | F1 | EM | Evidence recall | Answer in evidence | LLM calls/q | Tokens/q (excl. consistency) "
         "| Follow-up tokens/q | Retrievals/q | Passages/q | Wall s/q |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for n, r in comp["rows"].items():
        L.append(f"| {n} | {_f(r['f1'])} | {_f(r['em'])} | {_f(r['evidence_recall'])} | {_f(r['answer_in_evidence'])} | "
                 f"{_f(r['llm_calls'], 2)} | {_f(r['tokens'], 1)} | {_f(r['followup_tokens'], 1)} | "
                 f"{_f(r['retrieval_calls'], 2)} | {_f(r['passages'], 2)} | {_f(r['wall_s'], 3)} |")
    detection = guidance = None
    if guided in variants:
        tr = variants[guided]["traces"]
        detection, guidance = detection_report(tr), guidance_report(tr)
        L += ["", f"## RQ1: does the decomposition flag sub-problems that still lack evidence? ({guided})", "",
              "Positive = evidence insufficient. FN = the model said \"sufficient\" but the gold evidence was missing "
              "(the dangerous error); FP = unneeded follow-up trigger.", "",
              "| Scope | Events | Gap prevalence | TP | FP | FN | TN | Precision | Recall | F1 | Accuracy | Always-sufficient acc. |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for sc, c in detection["scopes"].items():
            L.append(f"| {sc} | {c['n']} | {_f(c['gap_prevalence'])} | {c['tp']} | {c['fp']} | {c['fn']} | {c['tn']} | "
                     f"{_f(c['precision'])} | {_f(c['recall'])} | {_f(c['f1'])} | {_f(c['accuracy'])} | "
                     f"{_f(c['always_sufficient_accuracy'])} |")
        g = guidance
        L += ["", f"## RQ2a: what the flags did to the next retrieval ({guided})", "",
              f"- Units with an oracle: {g['n_units']}; gaps after the first retrieval: {g['gaps_after_first_retrieval']}",
              f"- Follow-ups triggered: {g['followups_triggered']} (precision w.r.t. real gaps: {_f(g['followup_precision'])}); "
              f"wasted follow-ups (evidence was already enough): {g['wasted_followups']}",
              f"- Gaps fixed by the follow-up: {g['gaps_fixed']} of {g['gaps_triggered']} triggered "
              f"(fix rate {_f(g['fix_rate_of_triggered_gaps'])}); gaps never followed up: {g['gaps_missed_no_followup']}"]
        for a, v in g["per_action"].items():
            L.append(f"- Action `{a}`: {v['fixed']}/{v['n']} gaps fixed ({_f(v['fix_rate'])})")
    L += ["", "## RQ2b: is it worth the cost? (paired over questions, F1 difference with 95% bootstrap CI)", "",
          "| A vs B | n | ΔF1 [95% CI] | Δtokens/q | ΔF1 per +1k tokens |", "|---|---|---|---|---|"]
    for p in comp["paired"]:
        d = p["d_f1"]
        ci = f"{d[0]:+.3f} [{d[1]:+.3f}, {d[2]:+.3f}]" if d else "n/a"
        L.append(f"| {p['a']} − {p['b']} | {p['n']} | {ci} | {_f(p['d_tokens'], 1)} | {_f(p['f1_gain_per_1k_tokens'])} |")
    e = comp["efficiency"]
    if e:
        L += ["", f"Guided vs blind follow-up ({guided} vs B-always, both relative to B-never):", "",
              f"- Extra tokens/q: guided {_f(e['extra_tokens_guided_vs_never'], 1)} vs always {_f(e['extra_tokens_always_vs_never'], 1)}"
              f" → guided spends {_f(e['share_of_extra_cost_spent'])} of the always-policy's extra cost",
              f"- It captures {_f(e['share_of_f1_gain_captured'])} of its F1 gain and "
              f"{_f(e['share_of_recall_gain_captured'])} of its evidence-recall gain (n/a = no gain to share)"]
    return "\n".join(L) + "\n", {"comparison": comp, "detection": detection, "guidance": guidance}
