from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Config:
    # Passages returned by one retrieval step (Operadic: per sub-question step).
    k: int = 5
    # Optional separate k for Standard RAG (use it to equalise the passage budget).
    k_std: int | None = None
    # Hard cap on retrieval steps: Standard RAG = per question,
    # Operadic RAG = per sub-question (see README, "Retrieval budget").
    max_retrievals: int = 2
    # Standard RAG: allow a 2nd retrieval round if the model abstains in round 1.
    std_fallback: bool = True
    max_passage_chars: int = 600
    # Direct answer vs final answer agreement is "consistent" if score >= this.
    consistency_threshold: float = 0.5
    # "closed_book": one extra LLM call on the original question (as in the paper).
    # "std_rag": reuse Method A's answer (no extra call; needs method A in the run).
    direct_source: str = "closed_book"
    # Method B follow-up trigger:
    #   "guided": 2nd retrieval only when the sub-question is not judged sufficient (the proposed method)
    #   "always": 2nd retrieval for every sub-question (blind ablation: same budget, no signal)
    #   "never":  one retrieval per sub-question (decomposition only, cost floor)
    followup_policy: str = "guided"
    # Method B follow-up action: "model" = model picks rewrite_query/deepen, "deepen_only" = always deepen
    # (isolates the value of choosing the action from the value of the trigger).
    action_policy: str = "model"

    @property
    def k_standard(self) -> int:
        return self.k_std if self.k_std else self.k

    def validate(self) -> None:
        if not 1 <= self.max_retrievals <= 2:
            raise ValueError("max_retrievals must be 1 or 2 (task limit is two retrieval steps)")
        if self.k < 1:
            raise ValueError("k must be >= 1")
        if self.direct_source not in ("closed_book", "std_rag"):
            raise ValueError("direct_source must be 'closed_book' or 'std_rag'")
        if self.followup_policy not in ("guided", "always", "never"):
            raise ValueError("followup_policy must be 'guided', 'always' or 'never'")
        if self.action_policy not in ("model", "deepen_only"):
            raise ValueError("action_policy must be 'model' or 'deepen_only'")
