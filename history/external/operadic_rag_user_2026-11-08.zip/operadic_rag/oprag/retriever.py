"""Pure-python BM25 retriever + a thin service that logs every retrieval call."""
from __future__ import annotations

import json
import math
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Iterable

from .tracking import Tracker

_TOKEN = re.compile(r"[A-Za-z0-9؀-ۿ]+")
_STOP = {
    "a", "an", "the", "of", "in", "on", "at", "to", "is", "are", "was", "were", "by", "for", "and", "or",
    "what", "which", "who", "whom", "where", "when", "how", "did", "does", "do", "from", "with", "as",
    "that", "this", "it", "its", "be",
}


def tokenize(text: str) -> list[str]:
    return [t for t in (m.group().lower() for m in _TOKEN.finditer(text)) if t not in _STOP]


@dataclass(frozen=True)
class Passage:
    id: str
    title: str
    text: str
    score: float = 0.0


def load_corpus(path: str) -> list[Passage]:
    """JSONL with fields: id (optional), title (optional), text."""
    out = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if not line.strip():
                continue
            d = json.loads(line)
            out.append(Passage(str(d.get("id", i)), d.get("title", ""), d["text"]))
    return out


class BM25Retriever:
    def __init__(self, passages: Iterable[Passage], k1: float = 1.5, b: float = 0.75):
        self.passages = list(passages)
        self.k1, self.b = k1, b
        self.postings: dict[str, dict[int, int]] = defaultdict(dict)
        self.doc_len: list[int] = []
        for i, p in enumerate(self.passages):
            toks = tokenize(f"{p.title} {p.text}")
            self.doc_len.append(len(toks))
            for term, c in Counter(toks).items():
                self.postings[term][i] = c
        self.n = len(self.passages)
        self.avgdl = (sum(self.doc_len) / self.n) if self.n else 1.0

    def search(self, query: str, k: int = 5, exclude: Iterable[str] = ()) -> list[Passage]:
        exclude = set(exclude)
        scores: dict[int, float] = defaultdict(float)
        for term in set(tokenize(query)):
            post = self.postings.get(term)
            if not post:
                continue
            idf = math.log(1 + (self.n - len(post) + 0.5) / (len(post) + 0.5))
            for i, tf in post.items():
                denom = tf + self.k1 * (1 - self.b + self.b * self.doc_len[i] / self.avgdl)
                scores[i] += idf * tf * (self.k1 + 1) / denom
        out: list[Passage] = []
        for i, s in sorted(scores.items(), key=lambda x: (-x[1], x[0])):
            p = self.passages[i]
            if p.id in exclude:
                continue
            out.append(Passage(p.id, p.title, p.text, s))
            if len(out) >= k:
                break
        return out


class RetrievalService:
    """Wraps a retriever so each call is timed and logged under the current tracker scope."""

    def __init__(self, retriever: BM25Retriever, tracker: Tracker):
        self.retriever = retriever
        self.tracker = tracker

    def search(self, query: str, k: int, exclude: Iterable[str], stage: str) -> list[Passage]:
        t0 = time.perf_counter()
        docs = self.retriever.search(query, k=k, exclude=exclude)
        self.tracker.add_retrieval(stage, query, k, [d.id for d in docs], time.perf_counter() - t0)
        return docs
