"""Prompts for the decomposition-tree experiment (bridge = arity-1 root, comparison = arity-2 root).

The few-shot examples are hand-written (not taken from HotpotQA) so that no dev question leaks into the prompt.
"""
from __future__ import annotations

DECOMPOSE_TREE_SYSTEM = """You decompose a multi-hop question into a small tree of sub-questions, following a compositional (operadic) scheme.

There are exactly two kinds of questions.

1. "bridge": the answer needs a chain of two facts, and the second fact depends on the answer to the first.
   Output ONE sub-question in "sub_questions" that can be answered on its own, and a "root" question that contains the placeholder [A1] exactly once, standing for the answer to the sub-question.

2. "comparison": two entities are compared on the same property (which is older / larger / earlier, are they the same, do both have ...).
   Output TWO independent sub-questions, one per entity, each asking for the compared property. The "root" question must restate BOTH entities by name and contain the placeholders [A1] and [A2] exactly once each, standing for the answers to the first and the second sub-question, e.g. "... Entity1 (property [A1]) ... Entity2 (property [A2]) ...".

Rules:
- Sub-questions are self-contained: name every entity explicitly. Never use pronouns (he, she, it, they) or vague phrases such as "the film" without its name.
- Sub-questions contain NO placeholder. The root contains each required placeholder exactly once.
- If the placeholders are replaced by the correct answers, the root must have the same answer as the original question, and it must be answerable from the filled-in facts alone.
- Never just copy the original question. Keep every question short and specific.

Return ONLY a JSON object with keys "type", "sub_questions", "root". No other text.

Example 1
Question: Which country is the director of the film Inception from?
{"type": "bridge", "sub_questions": ["Who directed the film Inception?"], "root": "Which country is [A1] from?"}

Example 2
Question: What is the population of the city where the headquarters of Nintendo is located?
{"type": "bridge", "sub_questions": ["In which city is the headquarters of Nintendo located?"], "root": "What is the population of [A1]?"}

Example 3
Question: Which was released earlier, the album Thriller or the album Back in Black?
{"type": "comparison", "sub_questions": ["When was the album Thriller released?", "When was the album Back in Black released?"], "root": "Which was released earlier: the album Thriller (released [A1]) or the album Back in Black (released [A2])?"}

Example 4
Question: Are the cities of Oslo and Bergen located in the same country?
{"type": "comparison", "sub_questions": ["In which country is the city of Oslo located?", "In which country is the city of Bergen located?"], "root": "Are the cities of Oslo (located in [A1]) and Bergen (located in [A2]) located in the same country?"}"""


def decompose_user(question: str) -> str:
    return f"Question: {question}\nJSON:"


def decompose_repair_user(question: str, previous: str, problems: list[str]) -> str:
    return (
        f"Question: {question}\n"
        f"Your previous output was invalid:\n{previous}\n"
        "Problems: " + "; ".join(problems) + "\n"
        "Return ONLY the corrected JSON object."
    )


# ---- evaluation-only prompts (oracle execution of the tree with the gold paragraphs) ----
EXEC_LEAF_SYSTEM = (
    "Answer the question using ONLY the passages. Reply with the short answer only (a few words, no explanation). "
    "For yes/no questions reply exactly 'yes' or 'no'. If the passages do not contain the answer, reply exactly: UNKNOWN"
)


def exec_leaf_user(question: str, passages: str) -> str:
    return f"Passages:\n{passages}\n\nQuestion: {question}\nAnswer:"


EXEC_ROOT_SYSTEM = (
    "The question already contains the facts needed to answer it (inside the parentheses). Answer using those facts. "
    "Reply with the short answer only (a few words, no explanation). For yes/no questions reply exactly 'yes' or 'no'."
)


def exec_root_user(question: str) -> str:
    return f"Question: {question}\nAnswer:"
