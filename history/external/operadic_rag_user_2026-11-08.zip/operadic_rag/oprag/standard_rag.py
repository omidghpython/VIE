"""Method A: Standard RAG (the original question goes straight to retrieval + generation)."""
from __future__ import annotations

from . import prompts
from .config import Config
from .llm import BaseLLM
from .operad import EvidenceBundle
from .retriever import RetrievalService
from .util import clean_answer


def _abstained(answer: str) -> bool:
    return "insufficient" in answer.lower()


def run_standard_rag(question: str, llm: BaseLLM, retrieval: RetrievalService, cfg: Config) -> dict:
    """Round 1: top-k for the original question -> answer.
    Round 2 (only if cfg.std_fallback, max_retrievals>=2, and the model abstained): the next k unseen
    passages for the SAME query -> answer (forced best guess). No decomposition, no sufficiency JSON.
    """
    max_rounds = cfg.max_retrievals if cfg.std_fallback else 1
    evidence = EvidenceBundle()
    rounds: list[dict] = []
    answer = ""
    for r in range(1, max_rounds + 1):
        docs = retrieval.search(question, cfg.k_standard, evidence.ids, stage=f"retrieve_std#{r}")
        if r > 1 and not docs:
            break
        evidence = evidence.union(docs)
        final_round = r == max_rounds
        raw = llm.chat(
            prompts.standard_system(final_round),
            prompts.standard_user(question, evidence.render(cfg.max_passage_chars)),
            stage=f"answer_std#{r}",
            max_tokens=64,
        )
        answer = clean_answer(raw)
        abstained = (not final_round) and _abstained(answer)
        rounds.append({"round": r, "new_doc_ids": [d.id for d in docs], "answer": answer, "abstained": abstained})
        if not abstained:
            break
    if _abstained(answer):
        answer = ""
    return {
        "answer": answer,
        "retrieval_steps": len(rounds),
        "evidence_ids": [p.id for p in evidence.passages],
        "rounds": rounds,
    }
