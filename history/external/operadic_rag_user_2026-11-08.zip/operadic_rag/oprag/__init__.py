"""Standard RAG vs Operadic-Guided RAG (depth-2 questions operad)."""
from .config import Config

__all__ = ["Config"]
