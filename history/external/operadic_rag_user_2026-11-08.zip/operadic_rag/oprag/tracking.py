"""Logging of every LLM call, retrieval call, token count and latency."""
from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field


@dataclass
class LLMCall:
    method: str
    qid: str
    stage: str
    prompt_tokens: int
    completion_tokens: int
    latency_s: float
    estimated: bool = False  # True when the server returned no usage and we guessed
    system: str = ""
    user: str = ""
    response: str = ""


@dataclass
class RetrievalCall:
    method: str
    qid: str
    stage: str
    query: str
    k: int
    doc_ids: list = field(default_factory=list)
    latency_s: float = 0.0


def _prefix(stage: str) -> str:
    return stage.split("#")[0]


def _step(stage: str) -> int:
    """Retrieval step encoded as 'name#N' (1 when absent)."""
    tail = stage.split("#")[1] if "#" in stage else ""
    return int(tail) if tail.isdigit() else 1


class Tracker:
    def __init__(self, keep_text: bool = True):
        self.keep_text = keep_text
        self.llm_calls: list[LLMCall] = []
        self.retrieval_calls: list[RetrievalCall] = []
        self._method = ""
        self._qid = ""

    @contextmanager
    def scope(self, method: str, qid: str):
        prev = (self._method, self._qid)
        self._method, self._qid = method, str(qid)
        try:
            yield
        finally:
            self._method, self._qid = prev

    def add_llm(self, stage, prompt_tokens, completion_tokens, latency_s, estimated, system, user, response):
        self.llm_calls.append(
            LLMCall(
                self._method, self._qid, stage, int(prompt_tokens), int(completion_tokens), float(latency_s),
                bool(estimated),
                system if self.keep_text else "",
                user if self.keep_text else "",
                response if self.keep_text else "",
            )
        )

    def add_retrieval(self, stage, query, k, doc_ids, latency_s):
        self.retrieval_calls.append(
            RetrievalCall(self._method, self._qid, stage, query, k, list(doc_ids), float(latency_s))
        )

    def _sel(self, items, method, qid):
        return [c for c in items if c.method == method and (qid is None or c.qid == str(qid))]

    def summarize(self, method: str, qid=None) -> dict:
        calls = self._sel(self.llm_calls, method, qid)
        rets = self._sel(self.retrieval_calls, method, qid)
        pt = sum(c.prompt_tokens for c in calls)
        ct = sum(c.completion_tokens for c in calls)
        fu_calls = [c for c in calls if _step(c.stage) >= 2]
        fu_rets = [r for r in rets if _step(r.stage) >= 2]
        return {
            # cost of the consistency check (direct closed-book call), reported separately
            "direct_tokens": sum(c.prompt_tokens + c.completion_tokens for c in calls if _prefix(c.stage) == "direct"),
            # marginal cost of follow-up retrieval steps (step >= 2): LLM calls/tokens/time + retrieval time
            "followup_llm_calls": len(fu_calls),
            "followup_tokens": sum(c.prompt_tokens + c.completion_tokens for c in fu_calls),
            "followup_time_s": sum(c.latency_s for c in fu_calls) + sum(r.latency_s for r in fu_rets),
            "llm_calls": len(calls),
            "prompt_tokens": pt,
            "completion_tokens": ct,
            "total_tokens": pt + ct,
            "llm_time_s": sum(c.latency_s for c in calls),
            "retrieval_calls": len(rets),
            "passages_retrieved": sum(len(r.doc_ids) for r in rets),
            "retrieval_time_s": sum(r.latency_s for r in rets),
            "tokens_estimated": any(c.estimated for c in calls),
        }

    def by_stage(self, method: str) -> dict:
        out: dict = defaultdict(lambda: {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "time_s": 0.0})
        for c in self._sel(self.llm_calls, method, None):
            s = out[_prefix(c.stage)]
            s["calls"] += 1
            s["prompt_tokens"] += c.prompt_tokens
            s["completion_tokens"] += c.completion_tokens
            s["time_s"] += c.latency_s
        for r in self._sel(self.retrieval_calls, method, None):
            s = out[_prefix(r.stage)]
            s["calls"] += 1
            s["time_s"] += r.latency_s
        return {k: dict(v) for k, v in out.items()}
