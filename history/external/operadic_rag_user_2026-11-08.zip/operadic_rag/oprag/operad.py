"""The questions operad Q, restricted to the depth-2 chain used in the paper.

Paper vocabulary -> code:
  * question template with k blanks      -> QuestionTemplate (blank syntax: [A1])
  * composition  Q2 o_1 Q1               -> ChainOfQuestions (Q = Q2 o_1 Q1); the composite *text* is the
                                            original question, the *algebra action* is QuestionTemplate.fill
  * algebra over Q (model m as V_m)      -> answering Q1, substituting a1 into Q2, answering again
  * "evidence bundle" algebra (the paper lists it only as a future direction, undefined)
                                         -> EvidenceBundle: value = set of supporting passages,
                                            composition = union. This is OUR operationalisation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable

from .retriever import Passage

_BLANK = re.compile(r"\[A(\d+)\]")
_BLANK_VARIANTS = re.compile(r"[\[\{<]\s*(?:A\s*1|A|ANSWER|ANS|ANSWER\s*1)\s*[\]\}>]", re.I)
ANSWER_TYPES = ("person", "place", "time", "duration", "number", "yes_no", "other")


def normalize_placeholders(text: str) -> str:
    """Map '{A1}', '[a]', '<ANSWER>' ... to the canonical '[A1]'."""
    return _BLANK_VARIANTS.sub("[A1]", text or "")


@dataclass(frozen=True)
class QuestionTemplate:
    text: str
    answer_type: str = "other"

    @property
    def blanks(self) -> list[int]:
        return [int(m) for m in _BLANK.findall(self.text)]

    @property
    def arity(self) -> int:
        return len(set(self.blanks))

    def fill(self, values: list[str]) -> str:
        """Algebra action: plug values into the blanks (blank [Ai] <- values[i-1])."""
        def sub(m):
            i = int(m.group(1)) - 1
            return values[i] if 0 <= i < len(values) else m.group(0)
        return _BLANK.sub(sub, self.text)


@dataclass(frozen=True)
class ChainOfQuestions:
    """Depth-2 tree of questions: Q1 in Q(;c1), Q2 in Q(c1;d), original = Q2 o_1 Q1."""
    original: str
    q1: QuestionTemplate
    q2: QuestionTemplate

    def instantiate_q2(self, a1: str) -> str:
        return self.q2.fill([a1])


def _norm(s: str) -> str:
    return " ".join(re.sub(r"[^\w\s\[\]]", " ", s.lower()).split())


def build_chain(original: str, obj) -> tuple[ChainOfQuestions | None, list[str]]:
    """Validate a decomposition object {q1, q2, q1_type, answer_type}; return (chain, problems)."""
    problems: list[str] = []
    if not isinstance(obj, dict):
        return None, ["output is not a JSON object"]
    q1 = normalize_placeholders(str(obj.get("q1", "") or "")).strip()
    q2 = normalize_placeholders(str(obj.get("q2", "") or "")).strip()
    if not q1:
        problems.append("q1 is empty")
    if not q2:
        problems.append("q2 is empty")
    if problems:
        return None, problems
    t1 = QuestionTemplate(q1, str(obj.get("q1_type", "other")).lower())
    t2 = QuestionTemplate(q2, str(obj.get("answer_type", "other")).lower())
    if t1.arity != 0:
        problems.append("q1 must not contain a placeholder")
    if t2.blanks.count(1) != 1 or t2.arity != 1:
        problems.append("q2 must contain the placeholder [A1] exactly once")
    if not problems:
        rest = _BLANK.sub("", q2).strip()
        if len(rest.split()) < 2:
            problems.append("q2 is only a placeholder")
        if _norm(q1) == _norm(original):
            problems.append("q1 just repeats the original question")
        if _norm(_BLANK.sub("", q2)) == _norm(original):
            problems.append("q2 just repeats the original question")
    if problems:
        return None, problems
    t1 = QuestionTemplate(q1, t1.answer_type if t1.answer_type in ANSWER_TYPES else "other")
    t2 = QuestionTemplate(q2, t2.answer_type if t2.answer_type in ANSWER_TYPES else "other")
    return ChainOfQuestions(original, t1, t2), []


class Sufficiency(str, Enum):
    INSUFFICIENT = "insufficient"
    PARTIAL = "partial"
    SUFFICIENT = "sufficient"


_ORDER = {Sufficiency.INSUFFICIENT: 0, Sufficiency.PARTIAL: 1, Sufficiency.SUFFICIENT: 2}


def worst(*levels: Sufficiency) -> Sufficiency:
    return min(levels, key=lambda s: _ORDER[s])


@dataclass
class EvidenceBundle:
    passages: list[Passage] = field(default_factory=list)

    @property
    def ids(self) -> set[str]:
        return {p.id for p in self.passages}

    def union(self, other: "EvidenceBundle | Iterable[Passage]") -> "EvidenceBundle":
        """Composition in the evidence algebra: bundle of a composite = union of its parts' bundles."""
        extra = other.passages if isinstance(other, EvidenceBundle) else list(other)
        seen = self.ids
        merged = list(self.passages)
        for p in extra:
            if p.id not in seen:
                merged.append(p)
                seen.add(p.id)
        return EvidenceBundle(merged)

    def render(self, max_chars: int = 600) -> str:
        if not self.passages:
            return "(no passages)"
        lines = []
        for i, p in enumerate(self.passages, 1):
            text = p.text if len(p.text) <= max_chars else p.text[:max_chars].rstrip() + "..."
            head = f"{p.title}: " if p.title else ""
            lines.append(f"[{i}] {head}{text}")
        return "\n".join(lines)


@dataclass
class SubResult:
    sid: str                      # "q1", "q2" (or "q" when decomposition failed)
    question: str                 # the instantiated question that was asked
    answer: str
    sufficiency: Sufficiency
    reason: str
    evidence: EvidenceBundle
    steps: list[dict]             # one entry per retrieval step (query, action, status...)

    def to_dict(self) -> dict:
        return {
            "sid": self.sid,
            "question": self.question,
            "answer": self.answer,
            "sufficiency": self.sufficiency.value,
            "reason": self.reason,
            "retrieval_steps": len(self.steps),
            "evidence_ids": [p.id for p in self.evidence.passages],
            "steps": self.steps,
        }
