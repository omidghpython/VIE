"""Answer scoring: SQuAD-style EM/F1 plus a type-aware agreement score.

`agreement` follows the idea of the operadic-consistency scorer (companion paper): yes/no questions
compare the yes/no commitment, numeric answers compare the number, everything else uses token F1.
"""
from __future__ import annotations

import re
import string
from collections import Counter

_PUNCT = set(string.punctuation)
_ARTICLES = re.compile(r"\b(a|an|the)\b", re.I)
_BOOL = {"yes": True, "true": True, "no": False, "false": False}
_NUM = re.compile(r"-?\d[\d,]*(?:\.\d+)?")


def normalize_answer(s: str) -> str:
    s = "".join(ch for ch in (s or "").lower() if ch not in _PUNCT)
    return " ".join(_ARTICLES.sub(" ", s).split())


def exact_match(pred: str, gold: str) -> float:
    return float(normalize_answer(pred) == normalize_answer(gold))


def f1_score(pred: str, gold: str) -> float:
    p, g = normalize_answer(pred).split(), normalize_answer(gold).split()
    if not p and not g:
        return 1.0
    if not p or not g:
        return 0.0
    same = sum((Counter(p) & Counter(g)).values())
    if same == 0:
        return 0.0
    prec, rec = same / len(p), same / len(g)
    return 2 * prec * rec / (prec + rec)


def _first_bool(s: str):
    toks = normalize_answer(s).split()
    return _BOOL.get(toks[0]) if toks else None


def _first_number(s: str):
    m = _NUM.search(s or "")
    if not m:
        return None
    try:
        return float(m.group().replace(",", ""))
    except ValueError:
        return None


def agreement(a: str, b: str) -> float:
    ba, bb = _first_bool(a), _first_bool(b)
    if ba is not None and bb is not None:
        return float(ba == bb)
    na, nb = _first_number(a), _first_number(b)
    if na is not None and nb is not None:
        return float(na == nb)
    return f1_score(a, b)


def score_against_gold(pred: str, golds: list[str]) -> tuple[float, float]:
    """Best (EM, F1) over all gold aliases."""
    if not golds:
        return 0.0, 0.0
    return max(exact_match(pred, g) for g in golds), max(f1_score(pred, g) for g in golds)
