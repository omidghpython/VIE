from __future__ import annotations

import json
import re


def parse_json_object(text: str):
    """Extract the first balanced JSON object from model output (tolerates code fences)."""
    if not text:
        return None
    t = re.sub(r"```(?:json)?", "", text, flags=re.I).strip()
    start = t.find("{")
    if start == -1:
        return None
    depth, in_str, esc = 0, False, False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(t[start : i + 1])
                    except json.JSONDecodeError:
                        return None
    return None


def clean_answer(text: str) -> str:
    """Reduce a model reply to a short answer string."""
    if not text:
        return ""
    t = text.strip().splitlines()[0].strip() if text.strip() else ""
    t = re.sub(r"^(final\s+)?answer\s*:\s*", "", t, flags=re.I)
    t = t.strip().strip("\"'`").strip()
    if t.endswith(".") and not re.search(r"\b[A-Z]\.$", t):
        t = t[:-1]
    return t.strip()
