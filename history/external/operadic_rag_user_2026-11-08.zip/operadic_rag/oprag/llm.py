"""LLM backend: any OpenAI-compatible /v1/chat/completions server (vLLM, Ollama, TGI, Together, ...)."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse

from .tracking import Tracker


def approx_tokens(text: str) -> int:
    return max(1, round(len(text) / 4))


class BaseLLM:
    """Every call goes through chat(), which times it and logs token usage."""

    def __init__(self, tracker: Tracker):
        self.tracker = tracker

    def _complete(self, messages: list, max_tokens: int, temperature: float):
        raise NotImplementedError

    def chat(self, system: str, user: str, *, stage: str, max_tokens: int = 256, temperature: float = 0.0) -> str:
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        t0 = time.perf_counter()
        text, usage = self._complete(messages, max_tokens, temperature)
        dt = time.perf_counter() - t0
        pt, ct = usage.get("prompt_tokens"), usage.get("completion_tokens")
        estimated = False
        if pt is None or ct is None:
            pt, ct, estimated = approx_tokens(system + user), approx_tokens(text), True
        self.tracker.add_llm(stage, pt, ct, dt, estimated, system, user, text)
        return text


class OpenAICompatLLM(BaseLLM):
    def __init__(self, tracker: Tracker, base_url: str, model: str, api_key: str = "EMPTY",
                 timeout: float = 120.0, extra_body: dict | None = None):
        super().__init__(tracker)
        self.url = base_url.rstrip("/") + "/chat/completions"
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.extra_body = extra_body or {}
        host = urlparse(self.url).hostname or ""
        if host in ("localhost", "127.0.0.1", "::1"):
            self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        else:
            self._opener = urllib.request.build_opener()

    def _complete(self, messages, max_tokens, temperature):
        payload = {"model": self.model, "messages": messages, "max_tokens": max_tokens,
                   "temperature": temperature, **self.extra_body}
        req = urllib.request.Request(
            self.url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
            method="POST",
        )
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                body = json.load(resp)
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"LLM server returned HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:500]}") from e
        text = (body["choices"][0]["message"].get("content")) or ""
        return text, (body.get("usage") or {})
