"""Method B: Operadic-Guided RAG (depth-2 chain Q1 -> Q2 with evidence-sufficiency control)."""
from __future__ import annotations

from dataclasses import dataclass

from . import prompts
from .config import Config
from .llm import BaseLLM
from .operad import (ChainOfQuestions, EvidenceBundle, Sufficiency, SubResult, build_chain,
                     worst)
from .retriever import RetrievalService
from .scoring import agreement
from .util import clean_answer, parse_json_object

_SUFF = {"sufficient": Sufficiency.SUFFICIENT, "partial": Sufficiency.PARTIAL,
         "insufficient": Sufficiency.INSUFFICIENT}


@dataclass
class Assessment:
    answer: str
    sufficiency: Sufficiency
    reason: str
    next_action: str   # "rewrite_query" | "deepen" | "none"
    next_query: str


def _parse_assessment(text: str) -> Assessment | None:
    obj = parse_json_object(text)
    if not isinstance(obj, dict) or "answer" not in obj:
        return None
    suff = str(obj.get("sufficiency", "")).strip().lower()
    if suff not in _SUFF:
        return None
    action = str(obj.get("next_action", "none")).strip().lower()
    action = "rewrite_query" if action.startswith("rewrite") else ("deepen" if action.startswith("deepen") else "none")
    return Assessment(
        answer=clean_answer(str(obj.get("answer") or "")),
        sufficiency=_SUFF[suff],
        reason=str(obj.get("reason") or "")[:300],
        next_action=action,
        next_query=str(obj.get("next_query") or "").strip(),
    )


def _assess(llm: BaseLLM, sid: str, step: int, goal: str, question: str, evidence: EvidenceBundle,
            cfg: Config) -> Assessment:
    ev = evidence.render(cfg.max_passage_chars)
    raw = llm.chat(prompts.ASSESS_SYSTEM, prompts.assess_user(goal, question, ev),
                   stage=f"assess_{sid}#{step}", max_tokens=220)
    parsed = _parse_assessment(raw)
    if parsed is None:  # one repair attempt (counted as a separate call)
        raw2 = llm.chat(prompts.ASSESS_SYSTEM, prompts.assess_repair_user(goal, question, ev, raw),
                        stage=f"assess_{sid}_retry#{step}", max_tokens=220)
        parsed = _parse_assessment(raw2)
        if parsed is None:  # conservative fallback: treat as insufficient, keep the raw text as answer
            return Assessment(clean_answer(raw2 or raw), Sufficiency.INSUFFICIENT, "unparseable model output",
                              "deepen", "")
    return parsed


def _choose_next_action(a: Assessment, query: str) -> tuple[str, str]:
    """Next retrieval action for the SAME sub-question. 'none' while evidence is insufficient -> deepen."""
    if a.next_action == "rewrite_query" and a.next_query and a.next_query.lower() != query.lower():
        return "rewrite_query", a.next_query
    return "deepen", query


def solve_unit(llm: BaseLLM, retrieval: RetrievalService, sid: str, question: str, goal: str,
               cfg: Config) -> SubResult:
    """Retrieve -> answer + sufficiency; if not sufficient and budget remains, pick the next action
    (rewrite the query or go deeper in the ranking) for this same sub-question, then answer again."""
    evidence = EvidenceBundle()
    query = question
    steps: list[dict] = []
    answer, suff, reason = "", Sufficiency.INSUFFICIENT, ""
    for step in range(1, cfg.max_retrievals + 1):
        docs = retrieval.search(query, cfg.k, evidence.ids, stage=f"retrieve_{sid}#{step}")
        if step > 1 and not docs:
            steps.append({"step": step, "query": query, "new_doc_ids": [], "note": "no new passages"})
            break
        evidence = evidence.union(docs)
        a = _assess(llm, sid, step, goal, question, evidence, cfg)
        answer, suff, reason = a.answer, a.sufficiency, a.reason
        rec = {"step": step, "query": query, "new_doc_ids": [d.id for d in docs], "answer": a.answer,
               "sufficiency": a.sufficiency.value, "reason": a.reason}
        steps.append(rec)
        if step == cfg.max_retrievals or cfg.followup_policy == "never":
            break
        if suff is Sufficiency.SUFFICIENT and cfg.followup_policy != "always":
            break
        if cfg.action_policy == "deepen_only" or suff is Sufficiency.SUFFICIENT:
            action = "deepen"          # same query, next unseen passages
        else:
            action, query = _choose_next_action(a, query)
        rec["next_action"], rec["next_query"] = action, query
    return SubResult(sid, question, answer, suff, reason, evidence, steps)


def decompose(llm: BaseLLM, question: str) -> tuple[ChainOfQuestions | None, dict]:
    info: dict = {"attempts": 0, "problems": []}
    previous, problems = "", []
    for attempt in range(2):
        user = (prompts.decompose_user(question) if attempt == 0
                else prompts.decompose_repair_user(question, previous, problems))
        raw = llm.chat(prompts.DECOMPOSE_SYSTEM, user,
                       stage="decompose" if attempt == 0 else "decompose_retry", max_tokens=200)
        info["attempts"] += 1
        chain, problems = build_chain(question, parse_json_object(raw))
        if chain is not None:
            info["problems"] = []
            return chain, info
        previous = raw
        info["problems"] = problems
    return None, info


def run_operadic_rag(question: str, llm: BaseLLM, retrieval: RetrievalService, cfg: Config,
                     direct_answer: str | None = None) -> dict:
    chain, dinfo = decompose(llm, question)

    if chain is None:  # decomposition failed twice: treat the whole question as one unit
        unit = solve_unit(llm, retrieval, "q", question, question, cfg)
        final, r1, r2 = unit.answer, unit, None
        composition = {"operation": "none (decomposition failed)", "final": final}
        overall = unit.sufficiency
        propagated = False
        evidence_ids = [p.id for p in unit.evidence.passages]
    else:
        r1 = solve_unit(llm, retrieval, "q1", chain.q1.text, question, cfg)
        q2_text = chain.instantiate_q2(r1.answer)          # algebra action: plug a1 into Q2
        r2 = solve_unit(llm, retrieval, "q2", q2_text, question, cfg)
        final = r2.answer                                   # answer of the root vertex = composite answer
        union = r1.evidence.union(r2.evidence)              # evidence-bundle algebra: union
        overall = worst(r1.sufficiency, r2.sufficiency)
        propagated = r1.sufficiency is not Sufficiency.SUFFICIENT
        evidence_ids = [p.id for p in union.passages]
        composition = {
            "operation": "Q2 o_1 Q1",
            "q1": chain.q1.text, "q2_template": chain.q2.text, "q2_instantiated": q2_text,
            "a1": r1.answer, "a2": r2.answer, "final": final,
        }
    composition.update({
        "evidence_union_ids": evidence_ids,
        "overall_sufficiency": overall.value,
        "uncertainty_propagated_from_q1": propagated,
    })

    # Consistency check: final (decomposed) answer vs direct answer on the original question.
    if direct_answer is None:
        raw = llm.chat(prompts.DIRECT_SYSTEM, prompts.direct_user(question), stage="direct", max_tokens=64)
        direct_answer = clean_answer(raw)
        direct_source = "closed_book"
    else:
        direct_source = "std_rag"
    score = agreement(direct_answer, final)

    return {
        "answer": final,
        "decomposition_failed": chain is None,
        "decomposition": {**dinfo, **({"q1": chain.q1.text, "q2": chain.q2.text, "q1_type": chain.q1.answer_type,
                                       "answer_type": chain.q2.answer_type} if chain else {})},
        "q1": r1.to_dict(),
        "q2": r2.to_dict() if r2 else None,
        "composition": composition,
        "direct_answer": direct_answer,
        "direct_source": direct_source,
        "consistency_score": score,
        "consistent": score >= cfg.consistency_threshold,
        "evidence_ids": evidence_ids,
        "retrieval_steps": len(r1.steps) + (len(r2.steps) if r2 else 0),
    }
