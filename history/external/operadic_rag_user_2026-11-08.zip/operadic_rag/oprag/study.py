"""Run the full set of variants on the same questions and write the study report."""
from __future__ import annotations

import json
import os
from dataclasses import replace

from .analysis import render_study
from .config import Config
from .experiment import run_experiment, summarize_traces, write_outputs
from .retriever import BM25Retriever
from .tracking import Tracker


def default_variants(k: int) -> list[tuple[str, str, dict]]:
    """(name, method, config overrides)."""
    return [
        ("A", "A", {}),                                                   # Standard RAG
        ("A-wide", "A", {"k_std": 2 * k}),                                # Standard RAG with B's max passage budget
        ("B-never", "B", {"followup_policy": "never"}),                   # decomposition only (cost floor)
        ("B-guided", "B", {"followup_policy": "guided"}),                 # proposed method
        ("B-deepen", "B", {"followup_policy": "guided", "action_policy": "deepen_only"}),  # trigger, no action choice
        ("B-always", "B", {"followup_policy": "always"}),                 # blind follow-up (no signal)
    ]


def run_study(questions: list[dict], retriever: BM25Retriever, make_llm, cfg_base: Config,
              variants=None, out_dir: str | None = None, keep_text: bool = True, log=print) -> dict:
    """make_llm(tracker) -> LLM. Every variant gets its own tracker so costs never mix."""
    results: dict = {}
    for name, method, overrides in (variants or default_variants(cfg_base.k)):
        cfg = replace(cfg_base, **overrides)
        tracker = Tracker(keep_text=keep_text)
        traces = run_experiment(questions, retriever, make_llm(tracker), tracker, cfg,
                                methods=(method,), log=lambda *_: None)
        summary = summarize_traces(traces, tracker, cfg)["methods"][method]
        results[name] = {"method": method, "cfg": cfg, "traces": traces, "summary": summary, "tracker": tracker}
        log(f"[variant {name}] F1={summary['f1']} tokens/q={summary['avg_tokens_excl_direct']:.1f} "
            f"retrievals/q={summary['avg_retrieval_calls']:.2f}")
        if out_dir:
            write_outputs(os.path.join(out_dir, name), traces, tracker, cfg)
    if out_dir:
        md, data = render_study(results)
        with open(os.path.join(out_dir, "study.md"), "w", encoding="utf-8") as f:
            f.write(md)
        with open(os.path.join(out_dir, "study.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    return results
