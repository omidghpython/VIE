"""Decomposition-only evaluation: is the tree valid, and is the decomposition semantically correct?

(1) tree_valid          structural rules (gold-free) + type matches the HotpotQA label + comparison entities covered
(2) oracle execution    run the tree with the two GOLD paragraphs as evidence (no retrieval involved):
                        leaves are answered from the paragraphs, answers are plugged into the root, the root is
                        answered, and the result is compared with the gold answer.
                        A correct decomposition + perfect evidence must reproduce the gold answer.
    control             the ORIGINAL question is answered from the same paragraphs. If that control already fails,
                        a failed execution cannot be blamed on the decomposition.
(3) human review        review.md / review.csv for the final judgement (the automatic verdict is a proxy).
Decomposition cost (stages decompose*, tracked) is reported apart from the evaluation cost (stages eval_*).
"""
from __future__ import annotations

import csv
import math
import os
import re
from statistics import mean

from . import prompts_tree as P
from .scoring import f1_score, normalize_answer
from .tracking import Tracker
from .tree import DecompositionTree, check_against_gold, decompose_tree
from .util import clean_answer


# ------------------------------------------------------------------ answer matching
def answer_correct(pred: str, gold: str) -> bool:
    p, g = normalize_answer(pred), normalize_answer(gold)
    if not p or not g:
        return False
    if g in ("yes", "no"):
        return p.split()[0] == g
    if p == g:
        return True
    pt, gt = p.split(), g.split()
    if set(gt) <= set(pt) and len(pt) <= len(gt) + 4:      # gold contained, not a rambling answer
        return True
    return f1_score(pred, gold) >= 0.7


def _passages(paragraphs: dict) -> str:
    return "\n".join(f"[{i}] {t}: {x}" for i, (t, x) in enumerate(paragraphs.items(), 1))


def oracle_execute(tree: DecompositionTree, llm, question: str, gold: str, paragraphs: dict) -> dict:
    ctx = _passages(paragraphs)
    ctx_norm = normalize_answer(" ".join(paragraphs.values()))
    answers = []
    for i, leaf in enumerate(tree.leaves, 1):
        raw = llm.chat(P.EXEC_LEAF_SYSTEM, P.exec_leaf_user(leaf, ctx), stage=f"eval_leaf{i}", max_tokens=48)
        answers.append(clean_answer(raw))
    root_filled = tree.fill_root(answers)
    if tree.kind == "bridge":      # second hop: filled question + the evidence
        raw = llm.chat(P.EXEC_LEAF_SYSTEM, P.exec_leaf_user(root_filled, ctx), stage="eval_root", max_tokens=48)
    else:                          # comparison: the root must be answerable from the facts it carries
        raw = llm.chat(P.EXEC_ROOT_SYSTEM, P.exec_root_user(root_filled), stage="eval_root", max_tokens=48)
    final = clean_answer(raw)
    direct = clean_answer(llm.chat(P.EXEC_LEAF_SYSTEM, P.exec_leaf_user(question, ctx), stage="eval_direct",
                                   max_tokens=48))
    grounded = [bool(normalize_answer(a)) and normalize_answer(a) != "unknown"
                and f" {normalize_answer(a)} " in f" {ctx_norm} " for a in answers]
    return {"leaf_answers": answers, "root_filled": root_filled, "final": final,
            "final_correct": answer_correct(final, gold), "final_f1": f1_score(final, gold),
            "leaf_answers_grounded": grounded,
            "direct_oracle": direct, "direct_oracle_correct": answer_correct(direct, gold)}


# ------------------------------------------------------------------ run
def _cost(tracker: Tracker, qid: str, prefixes: tuple) -> dict:
    calls = [c for c in tracker.llm_calls if c.method == "D" and c.qid == qid and c.stage.startswith(prefixes)]
    return {"llm_calls": len(calls), "prompt_tokens": sum(c.prompt_tokens for c in calls),
            "completion_tokens": sum(c.completion_tokens for c in calls),
            "total_tokens": sum(c.prompt_tokens + c.completion_tokens for c in calls),
            "time_s": sum(c.latency_s for c in calls)}


def run_decomposition_eval(questions: list[dict], llm, tracker: Tracker, max_attempts: int = 3,
                           do_exec: bool = True, log=print) -> list[dict]:
    records = []
    for i, q in enumerate(questions, 1):
        qid = str(q["id"])
        rec = {"id": qid, "question": q["question"], "gold_answer": q["answer"], "gold_type": q["type"],
               "level": q.get("level"), "support_titles": q["supporting_titles"]}
        with tracker.scope("D", qid):
            tree, info = decompose_tree(llm, q["question"], max_attempts)
            rec.update(tree=tree.to_dict() if tree else None, attempts=info["attempts"],
                       attempt_history=info["history"], warnings=info["warnings"],
                       first_attempt_valid=bool(info["history"]) and not info["history"][0]["problems"])
            rec["gold_checks"] = check_against_gold(tree, q["type"], q["supporting_titles"]) if tree else None
            rec["tree_valid"] = bool(tree and rec["gold_checks"]["structure_ok"])
            rec["exec"] = (oracle_execute(tree, llm, q["question"], q["answer"], q["paragraphs"])
                           if (tree and do_exec) else None)
        ex = rec["exec"]
        rec["decomp_ok_auto"] = bool(rec["tree_valid"] and ex and ex["final_correct"])
        rec["cost_decomposition"] = _cost(tracker, qid, ("decompose",))
        rec["cost_evaluation"] = _cost(tracker, qid, ("eval_",))
        records.append(rec)
        log(f"[{i}/{len(questions)}] {qid} gold={q['type']:<10} tree_valid={rec['tree_valid']!s:<5} "
            f"exec_ok={ex['final_correct'] if ex else None}")
    return records


# ------------------------------------------------------------------ summary
def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return None, None
    p, d = k / n, 1 + z * z / n
    c, h = p + z * z / (2 * n), z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - h) / d, (c + h) / d


def _rate(k, n):
    if n == 0:
        return "n/a"
    lo, hi = wilson(k, n)
    return f"{k}/{n} = {k / n:.2f} (95% CI {lo:.2f}-{hi:.2f})"


def summarize(records: list[dict]) -> dict:
    n = len(records)
    s: dict = {"n": n, "gold_types": {t: sum(r["gold_type"] == t for r in records) for t in ("bridge", "comparison")}}
    built = [r for r in records if r["tree"]]
    s["tree_built"] = len(built)
    s["first_attempt_valid"] = sum(r["first_attempt_valid"] for r in records)
    s["no_valid_tree"] = n - len(built)
    s["type_ok"] = sum(r["gold_checks"]["type_ok"] for r in built)
    s["tree_valid"] = sum(r["tree_valid"] for r in records)
    s["with_warnings"] = sum(bool(r["warnings"]) for r in records)
    s["by_type"] = {}
    for t in ("bridge", "comparison"):
        rs = [r for r in records if r["gold_type"] == t]
        s["by_type"][t] = {"n": len(rs), "tree_valid": sum(r["tree_valid"] for r in rs),
                           "decomp_ok_auto": sum(r["decomp_ok_auto"] for r in rs),
                           "type_ok": sum(bool(r["gold_checks"] and r["gold_checks"]["type_ok"]) for r in rs)}
    ex = [r for r in records if r["exec"]]
    if ex:
        s["exec_run"] = len(ex)
        s["exec_correct"] = sum(r["exec"]["final_correct"] for r in ex)
        s["direct_oracle_correct"] = sum(r["exec"]["direct_oracle_correct"] for r in ex)
        s["decomp_ok_auto"] = sum(r["decomp_ok_auto"] for r in records)
        fails = [r for r in ex if not r["exec"]["final_correct"]]
        s["exec_fail_control_ok"] = sum(r["exec"]["direct_oracle_correct"] for r in fails)   # blame decomposition
        s["exec_fail_control_fail"] = len(fails) - s["exec_fail_control_ok"]                 # ambiguous
        g = [x for r in ex for x in r["exec"]["leaf_answers_grounded"]]
        s["leaf_grounded"], s["leaf_total"] = sum(g), len(g)
    for key in ("cost_decomposition", "cost_evaluation"):
        s[key] = {m: mean(r[key][m] for r in records) for m in
                  ("llm_calls", "prompt_tokens", "completion_tokens", "total_tokens", "time_s")}
        s[key]["total_tokens_all"] = sum(r[key]["total_tokens"] for r in records)
        s[key]["time_s_all"] = sum(r[key]["time_s"] for r in records)
    return s


def render_summary(s: dict) -> str:
    n = s["n"]
    L = ["# Decomposition report", "",
         f"Questions: {n} (gold types: bridge {s['gold_types']['bridge']}, comparison {s['gold_types']['comparison']})", "",
         "## 1. Is the tree valid?", "",
         f"- Valid tree produced at all (after up to the allowed repair attempts): {_rate(s['tree_built'], n)}",
         f"- Valid on the first attempt (no repair needed): {_rate(s['first_attempt_valid'], n)}",
         f"- Predicted type = gold type: {_rate(s['type_ok'], s['tree_built'])} of built trees",
         f"- **tree_valid** (structure ok + type ok + comparison entities covered): {_rate(s['tree_valid'], n)}",
         f"- Trees with heuristic warnings (pronouns / dropped question tokens): {s['with_warnings']}", ""]
    L += ["| Gold type | n | tree_valid | type correct | decomposition ok (auto) |", "|---|---|---|---|---|"]
    for t, v in s["by_type"].items():
        L.append(f"| {t} | {v['n']} | {v['tree_valid']} | {v['type_ok']} | {v['decomp_ok_auto']} |")
    if "exec_run" in s:
        L += ["", "## 2. Is the decomposition correct? (oracle execution with the gold paragraphs)", "",
              f"- Execution reproduces the gold answer: {_rate(s['exec_correct'], s['exec_run'])}",
              f"- Control (original question + same paragraphs): {_rate(s['direct_oracle_correct'], s['exec_run'])}",
              f"- Failures where the control succeeded (decomposition is the likely culprit): {s['exec_fail_control_ok']}; "
              f"where the control failed too (answerer limit, ambiguous): {s['exec_fail_control_fail']}",
              f"- Leaf answers found verbatim in the gold paragraphs: {_rate(s['leaf_grounded'], s['leaf_total'])}",
              f"- **decomposition_ok (auto)** = tree_valid AND execution correct: {_rate(s['decomp_ok_auto'], n)}"]
    L += ["", "## 3. Cost (per question, averages)", "",
          "| | LLM calls | Prompt tok | Completion tok | Total tok | Time (s) | Total tok (all) | Total time (s) |",
          "|---|---|---|---|---|---|---|---|"]
    for key, name in (("cost_decomposition", "Decomposition"), ("cost_evaluation", "Evaluation only")):
        c = s[key]
        L.append(f"| {name} | {c['llm_calls']:.2f} | {c['prompt_tokens']:.0f} | {c['completion_tokens']:.0f} | "
                 f"{c['total_tokens']:.0f} | {c['time_s']:.2f} | {c['total_tokens_all']} | {c['time_s_all']:.1f} |")
    L += ["", "The automatic verdict is a proxy: confirm it with the human columns in review.csv / review.md."]
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------ human review files
def _verdict(r: dict) -> str:
    if not r["tree"]:
        return "NO_TREE"
    if not r["tree_valid"]:
        return "TREE_INVALID"
    if not r["exec"]:
        return "TREE_OK (not executed)"
    return "OK" if r["exec"]["final_correct"] else "EXEC_MISMATCH"


def render_review(records: list[dict]) -> str:
    L = ["# Review of the decompositions", "",
         "Mark each item: (a) is the TREE well-formed? (b) is the DECOMPOSITION correct, i.e. do the sub-questions "
         "capture exactly the reasoning the question needs? Use review.csv for the marks.", ""]
    for r in records:
        L += [f"## {r['id']} | gold type: {r['gold_type']} | auto verdict: {_verdict(r)}", "",
              f"- Question: {r['question']}", f"- Gold answer: {r['gold_answer']}",
              f"- Gold paragraphs: {', '.join(r['support_titles'])}"]
        if r["tree"]:
            t = DecompositionTree(r["question"], r["tree"]["type"], tuple(r["tree"]["sub_questions"]), r["tree"]["root"])
            ex = r["exec"]
            L += ["", "```", t.render(ex["leaf_answers"] if ex else None)]
            if ex:
                L += [f"  filled root : {ex['root_filled']}", f"  final answer: {ex['final']!r}   "
                      f"(gold: {r['gold_answer']!r}) -> {'MATCH' if ex['final_correct'] else 'MISMATCH'}",
                      f"  control     : {ex['direct_oracle']!r} -> {'MATCH' if ex['direct_oracle_correct'] else 'MISMATCH'}"]
            L.append("```")
            if r["gold_checks"]:
                bad = [k for k, v in r["gold_checks"].items() if v is False]
                if bad:
                    L.append(f"- Failed checks: {', '.join(bad)}")
            for w in r["warnings"]:
                L.append(f"- Warning: {w}")
            if r["attempts"] > 1:
                L.append(f"- Needed {r['attempts']} attempts; problems seen: "
                         + " | ".join("; ".join(h["problems"]) for h in r["attempt_history"] if h["problems"]))
        else:
            L.append("- No valid tree. Problems per attempt: "
                     + " | ".join("; ".join(h["problems"]) for h in r["attempt_history"]))
            L += ["", "```", "last raw output: " + (r["attempt_history"][-1]["raw"] or "")[:500], "```"]
        L.append("")
    return "\n".join(L)


def write_review_csv(path: str, records: list[dict]) -> None:
    cols = ["id", "gold_type", "question", "gold_answer", "pred_type", "sub_questions", "root", "leaf_answers",
            "final_answer", "auto_verdict", "attempts", "warnings", "human_tree_ok(y/n)",
            "human_decomposition_ok(y/n)", "human_notes"]
    with open(path, "w", newline="", encoding="utf-8-sig") as f:      # utf-8-sig so Excel on Windows reads it
        w = csv.writer(f)
        w.writerow(cols)
        for r in records:
            t, ex = r["tree"], r["exec"]
            w.writerow([r["id"], r["gold_type"], r["question"], r["gold_answer"], t["type"] if t else "",
                        " || ".join(t["sub_questions"]) if t else "", t["root"] if t else "",
                        " || ".join(ex["leaf_answers"]) if ex else "", ex["final"] if ex else "", _verdict(r),
                        r["attempts"], " | ".join(r["warnings"]), "", "", ""])
