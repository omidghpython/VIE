"""All prompts (English; Qwen2.5-7B-Instruct works best with English instructions)."""
from __future__ import annotations

DECOMPOSE_SYSTEM = """You decompose a multi-hop question into exactly two dependent sub-questions.

Rules:
- q1 must be answerable on its own and must NOT contain any placeholder.
- q2 must contain the placeholder [A1] exactly once; [A1] stands for the answer to q1.
- If [A1] is replaced by the correct answer to q1, then answering q2 must give the final answer to the original question.
- Keep both sub-questions short, specific and self-contained (name the entities explicitly).
- q1_type is the answer type of q1; answer_type is the answer type of the ORIGINAL question. Each is one of: person, place, time, duration, number, yes_no, other.

Return ONLY a JSON object with keys q1, q1_type, q2, answer_type. No other text.

Example 1
Question: Which country is the director of the film Inception from?
{"q1": "Who directed the film Inception?", "q1_type": "person", "q2": "Which country is [A1] from?", "answer_type": "place"}

Example 2
Question: What river flows through the capital of France?
{"q1": "What is the capital of France?", "q1_type": "place", "q2": "Which river flows through [A1]?", "answer_type": "other"}"""


def decompose_user(question: str) -> str:
    return f"Question: {question}\nJSON:"


def decompose_repair_user(question: str, previous: str, problems: list[str]) -> str:
    return (
        f"Question: {question}\n"
        f"Your previous output was invalid ({'; '.join(problems)}):\n{previous}\n"
        "Return ONLY the corrected JSON object."
    )


ASSESS_SYSTEM = """You answer ONE sub-question using retrieved evidence passages and judge whether the evidence is sufficient.

Sufficiency levels:
- sufficient: the passages explicitly contain the information needed to answer the sub-question.
- partial: the passages are related, but the answer needs a guess, is ambiguous, or is only partly supported.
- insufficient: the passages do not contain the information.

Always put your best short answer (a few words) in "answer". If the evidence is not sufficient, still give your best guess, but set "sufficiency" accordingly.

If the evidence is not sufficient, choose the next retrieval action for this same sub-question:
- rewrite_query: search again with a different query. Put the new search query (key entities plus the missing fact) in "next_query".
- deepen: keep the same query and read lower-ranked results; leave "next_query" empty.

Return ONLY a JSON object with keys: answer, sufficiency, reason, missing, next_action, next_query.
If the evidence is sufficient use next_action "none" and leave missing and next_query empty."""


def assess_user(goal: str, question: str, evidence: str) -> str:
    return (
        f"Overall goal (context only, do not answer it directly): {goal}\n"
        f"Sub-question: {question}\n\n"
        f"Evidence passages:\n{evidence}\n\nJSON:"
    )


def assess_repair_user(goal: str, question: str, evidence: str, previous: str) -> str:
    return assess_user(goal, question, evidence) + f"\n\nYour previous output was not valid JSON:\n{previous}\nReturn ONLY the JSON object."


_STD_BASE = "Answer the question using the evidence passages. Reply with the short final answer only (a few words), no explanation."
ABSTAIN_TOKEN = "INSUFFICIENT_EVIDENCE"


def standard_system(final_round: bool) -> str:
    if final_round:
        return _STD_BASE + " If the passages are not conclusive, give your best guess."
    return _STD_BASE + f" If the passages do not contain enough information, reply exactly: {ABSTAIN_TOKEN}"


def standard_user(question: str, evidence: str) -> str:
    return f"Evidence passages:\n{evidence}\n\nQuestion: {question}\nAnswer:"


# Closed-book direct answer on the ORIGINAL question (same system message style as the paper's protocol).
DIRECT_SYSTEM = "You are a concise factual question-answering assistant. Answer with a short phrase or a few words. Do not explain your reasoning."


def direct_user(question: str) -> str:
    return f"Question: {question}\nAnswer:"
