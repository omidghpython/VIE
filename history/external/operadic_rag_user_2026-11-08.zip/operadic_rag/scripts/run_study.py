#!/usr/bin/env python3
"""Study: can operadic decomposition flag under-evidenced sub-questions, and does that guide retrieval cheaply?

Runs 6 variants on the same questions (A, A-wide, B-never, B-guided, B-deepen, B-always) and writes
<out>/study.md with the detection (RQ1) and guidance/cost (RQ2) analysis.

Gold evidence is read from the questions file (optional but needed for RQ1/RQ2 oracle metrics):
    "supporting_ids": ["d1","d2"], "hop_ids": {"q1": ["d1"], "q2": ["d2"]}
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oprag.config import Config  # noqa: E402
from oprag.experiment import load_questions  # noqa: E402
from oprag.llm import OpenAICompatLLM  # noqa: E402
from oprag.retriever import BM25Retriever, load_corpus  # noqa: E402
from oprag.study import default_variants, run_study  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--corpus", required=True)
    p.add_argument("--questions", required=True)
    p.add_argument("--out", default="runs/study1")
    p.add_argument("--base-url", default=os.environ.get("LLM_BASE_URL", "http://localhost:8000/v1"))
    p.add_argument("--model", default=os.environ.get("LLM_MODEL", "Qwen/Qwen2.5-7B-Instruct"))
    p.add_argument("--api-key", default=os.environ.get("LLM_API_KEY", "EMPTY"))
    p.add_argument("--timeout", type=float, default=120.0)
    p.add_argument("--k", type=int, default=5)
    p.add_argument("--max-passage-chars", type=int, default=600)
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--variants", default=None, help="comma list, e.g. A,B-never,B-guided,B-always")
    p.add_argument("--no-text-log", action="store_true")
    a = p.parse_args()

    cfg = Config(k=a.k, max_passage_chars=a.max_passage_chars)
    cfg.validate()
    variants = default_variants(a.k)
    if a.variants:
        want = set(a.variants.split(","))
        variants = [v for v in variants if v[0] in want]
    retriever = BM25Retriever(load_corpus(a.corpus))
    questions = load_questions(a.questions)[: a.limit]
    run_study(questions, retriever, lambda tr: OpenAICompatLLM(tr, a.base_url, a.model, a.api_key, a.timeout),
              cfg, variants=variants, out_dir=a.out, keep_text=not a.no_text_log)
    print(open(os.path.join(a.out, "study.md"), encoding="utf-8").read())


if __name__ == "__main__":
    main()
