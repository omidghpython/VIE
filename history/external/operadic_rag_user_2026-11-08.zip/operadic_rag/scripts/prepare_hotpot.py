#!/usr/bin/env python3
"""Sample N random HotpotQA questions (type bridge or comparison) and keep only the GOLD paragraphs.

Sources (pick one):
  --source hf    load hotpotqa/hotpot_qa (config "distractor") with the `datasets` package   [pip install datasets]
  --json PATH    original HotpotQA json (hotpot_dev_distractor_v1.json) downloaded by you

Reproducible: items are sorted by id, then sampled with random.Random(seed).
Output JSONL fields: id, question, answer, type, level, supporting_titles, paragraphs {title: text}
"""
import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def _from_original(d: dict) -> dict:
    ctx = {t: " ".join(s.strip() for s in sents) for t, sents in d["context"]}
    titles = list(dict.fromkeys(t for t, _ in d["supporting_facts"]))
    return {"id": d["_id"], "question": d["question"], "answer": d["answer"], "type": d["type"],
            "level": d.get("level"), "supporting_titles": titles,
            "paragraphs": {t: ctx[t] for t in titles if t in ctx}}


def _from_hf(d: dict) -> dict:
    ctx = {t: " ".join(s.strip() for s in sents) for t, sents in zip(d["context"]["title"], d["context"]["sentences"])}
    titles = list(dict.fromkeys(d["supporting_facts"]["title"]))
    return {"id": d["id"], "question": d["question"], "answer": d["answer"], "type": d["type"],
            "level": d.get("level"), "supporting_titles": titles,
            "paragraphs": {t: ctx[t] for t in titles if t in ctx}}


def load(args) -> list[dict]:
    if args.json:
        with open(args.json, encoding="utf-8") as f:
            return [_from_original(d) for d in json.load(f)]
    from datasets import load_dataset
    ds = load_dataset("hotpotqa/hotpot_qa", "distractor", split=args.split)
    return [_from_hf(d) for d in ds]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--source", choices=["hf"], default="hf")
    p.add_argument("--json", help="path to original HotpotQA json (overrides --source)")
    p.add_argument("--split", default="validation")
    p.add_argument("--n", type=int, default=50)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--balanced", action="store_true", help="n/2 bridge + n/2 comparison instead of a plain random sample")
    p.add_argument("--out", default="data/hotpot50.jsonl")
    a = p.parse_args()

    items = [x for x in load(a) if x["type"] in ("bridge", "comparison") and len(x["paragraphs"]) == 2]
    items.sort(key=lambda x: x["id"])
    rng = random.Random(a.seed)
    if a.balanced:
        pick = []
        for t in ("bridge", "comparison"):
            pool = [x for x in items if x["type"] == t]
            pick += rng.sample(pool, a.n // 2)
        rng.shuffle(pick)
    else:
        pick = rng.sample(items, a.n)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        for x in pick:
            f.write(json.dumps(x, ensure_ascii=False) + "\n")
    print(f"pool: {len(items)} eligible questions; wrote {len(pick)} to {a.out}")
    print("types:", dict(Counter(x["type"] for x in pick)), "| levels:", dict(Counter(x["level"] for x in pick)))


if __name__ == "__main__":
    main()
