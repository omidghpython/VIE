#!/usr/bin/env python3
"""Decomposition-only experiment: operadic trees for HotpotQA questions + validity and correctness checks.

Typical run (Ollama on Windows, model created from the Modelfile in README_DECOMPOSITION.md):
    python scripts/run_decomposition.py --questions data/hotpot50.jsonl ^
        --base-url http://localhost:11434/v1 --model qwen25-7b-8k --json-mode --out runs/decomp50
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from oprag.decomp_eval import (render_review, render_summary, run_decomposition_eval,  # noqa: E402
                               summarize, write_review_csv)
from oprag.llm import OpenAICompatLLM  # noqa: E402
from oprag.tracking import Tracker  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--questions", required=True, help="JSONL produced by prepare_hotpot.py")
    p.add_argument("--out", default="runs/decomp50")
    p.add_argument("--base-url", default=os.environ.get("LLM_BASE_URL", "http://localhost:11434/v1"))
    p.add_argument("--model", default=os.environ.get("LLM_MODEL", "qwen25-7b-8k"))
    p.add_argument("--api-key", default=os.environ.get("LLM_API_KEY", "EMPTY"))
    p.add_argument("--timeout", type=float, default=300.0)
    p.add_argument("--max-attempts", type=int, default=3, help="1 = no repair, only the first try counts")
    p.add_argument("--json-mode", action="store_true", help='send response_format={"type":"json_object"}')
    p.add_argument("--no-exec", action="store_true", help="skip the oracle-execution check (structure only)")
    p.add_argument("--limit", type=int, default=None)
    a = p.parse_args()

    with open(a.questions, encoding="utf-8") as f:
        questions = [json.loads(line) for line in f if line.strip()][: a.limit]
    extra = {"seed": 0}
    if a.json_mode:
        extra["response_format"] = {"type": "json_object"}
    tracker = Tracker(keep_text=True)
    llm = OpenAICompatLLM(tracker, a.base_url, a.model, a.api_key, a.timeout, extra_body=extra)

    records = run_decomposition_eval(questions, llm, tracker, max_attempts=a.max_attempts, do_exec=not a.no_exec)
    summary = summarize(records)

    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "decomposition.jsonl"), "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(a.out, "llm_calls.jsonl"), "w", encoding="utf-8") as f:
        from dataclasses import asdict
        for c in tracker.llm_calls:
            f.write(json.dumps(asdict(c), ensure_ascii=False) + "\n")
    with open(os.path.join(a.out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    md = render_summary(summary)
    with open(os.path.join(a.out, "summary.md"), "w", encoding="utf-8") as f:
        f.write(md)
    with open(os.path.join(a.out, "review.md"), "w", encoding="utf-8") as f:
        f.write(render_review(records))
    write_review_csv(os.path.join(a.out, "review.csv"), records)
    print("\n" + md)
    print(f"Written to {a.out}/: summary.md, review.md, review.csv, decomposition.jsonl, llm_calls.jsonl")


if __name__ == "__main__":
    main()
