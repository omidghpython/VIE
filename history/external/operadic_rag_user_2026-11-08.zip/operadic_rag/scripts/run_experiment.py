#!/usr/bin/env python3
"""Compare Standard RAG (A) and Operadic-Guided RAG (B) with an OpenAI-compatible LLM server.

Example (vLLM serving Qwen2.5-7B-Instruct on localhost:8000):
    python scripts/run_experiment.py --corpus data/toy_corpus.jsonl --questions data/toy_questions.jsonl \
        --base-url http://localhost:8000/v1 --model Qwen/Qwen2.5-7B-Instruct --out runs/toy
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from oprag.config import Config  # noqa: E402
from oprag.experiment import load_questions, render_markdown, run_experiment, write_outputs  # noqa: E402
from oprag.llm import OpenAICompatLLM  # noqa: E402
from oprag.retriever import BM25Retriever, load_corpus  # noqa: E402
from oprag.tracking import Tracker  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--corpus", required=True, help="JSONL passages: id, title, text")
    p.add_argument("--questions", required=True, help="JSONL: id, question, answer (optional)")
    p.add_argument("--out", default="runs/run1")
    p.add_argument("--base-url", default=os.environ.get("LLM_BASE_URL", "http://localhost:8000/v1"))
    p.add_argument("--model", default=os.environ.get("LLM_MODEL", "Qwen/Qwen2.5-7B-Instruct"))
    p.add_argument("--api-key", default=os.environ.get("LLM_API_KEY", "EMPTY"))
    p.add_argument("--timeout", type=float, default=120.0)
    p.add_argument("--k", type=int, default=5, help="passages per retrieval step")
    p.add_argument("--k-std", type=int, default=None, help="override k for Standard RAG only")
    p.add_argument("--max-retrievals", type=int, default=2, choices=[1, 2])
    p.add_argument("--no-std-fallback", action="store_true", help="Standard RAG: never do a 2nd retrieval round")
    p.add_argument("--direct-source", choices=["closed_book", "std_rag"], default="closed_book")
    p.add_argument("--methods", default="AB", help="A, B or AB")
    p.add_argument("--limit", type=int, default=None)
    p.add_argument("--max-passage-chars", type=int, default=600)
    p.add_argument("--no-text-log", action="store_true", help="do not store prompts/responses in llm_calls.jsonl")
    a = p.parse_args()

    cfg = Config(k=a.k, k_std=a.k_std, max_retrievals=a.max_retrievals, std_fallback=not a.no_std_fallback,
                 max_passage_chars=a.max_passage_chars, direct_source=a.direct_source)
    cfg.validate()
    tracker = Tracker(keep_text=not a.no_text_log)
    llm = OpenAICompatLLM(tracker, a.base_url, a.model, api_key=a.api_key, timeout=a.timeout)
    retriever = BM25Retriever(load_corpus(a.corpus))
    questions = load_questions(a.questions)[: a.limit]

    traces = run_experiment(questions, retriever, llm, tracker, cfg, methods=tuple(a.methods.upper()))
    summary = write_outputs(a.out, traces, tracker, cfg)
    print("\n" + render_markdown(summary))
    print(f"Outputs written to {a.out}/ (traces.jsonl, llm_calls.jsonl, retrieval_calls.jsonl, summary.json, summary.md)")


if __name__ == "__main__":
    main()
