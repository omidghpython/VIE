# Single saved-tree repair probe

Bordan Tkachuk was the former CEO of which company, which provides IT products?

Historical first output (unchanged):
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"Does {{q1}} provide IT products?","dependencies":{"q1":"organization"},"answer_type":"boolean"}],"final":"q2"}
```

Historical repair v1 (reference only; NOT sent to the model):
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What products does {{q1}} provide?","dependencies":{"q1":"organization"},"answer_type":"work"}],"final":"q1"}
```
Historical structure error: final must be the root and cannot be consumed by another node.

New repair v2:
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"Does {{q1}} provide IT products?","dependencies":{"q1":"organization"},"answer_type":"boolean"},{"id":"q3","question":"Which company was Bordan Tkachuk the former CEO of, and does it provide IT products?","dependencies":{"q1":"organization","q2":"boolean"},"answer_type":"organization"}],"final":"q3"}
```

Phase: observed
Runtime error: 
Structure: invalid
Structure error: q3: placeholders and declared dependencies must match exactly.
Target: not_checked
Target errors: []

Expanded tree:


Manual review REQUIRED: Does final return the original requested entity/value? Are all relations and qualifiers preserved on that same entity? Does each node contribute necessary information rather than repeat or rename the original request?

No automatic semantic success verdict is assigned. One case cannot establish general improvement.

Current cost (historical calls excluded):
```text
{
  "llm_calls": 1,
  "prompt_tokens": 879,
  "completion_tokens": 114,
  "total_tokens": 993,
  "execution_time_sec": 18.9106357,
  "retrieval_steps": 0
}
```
