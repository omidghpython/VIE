# v3.2.5: node type labels hidden, ten fixed development trees

Questions, trees and types remain unchanged. No generation, repair or answering.
The preselected audit is not independent accuracy; inspect decision AND reason.

```json
{
  "mode": "v3.2.5_hide_node_types_ten_saved_trees",
  "requested": 10,
  "original_cohort_size": 40,
  "unselected_questions_not_run": 30,
  "original_indices": [
    8,
    10,
    13,
    14,
    15,
    23,
    25,
    29,
    35,
    38
  ],
  "incomplete_questions": 0,
  "new_status": {
    "revise": 10
  },
  "review_source": {
    "model": 10
  },
  "response_status": {
    "parsed": 10
  },
  "new_review_cost": {
    "llm_calls": 10,
    "prompt_tokens": 4033,
    "completion_tokens": 365,
    "total_tokens": 4398,
    "execution_time_sec": 49.15469080000048,
    "retrieval_steps": 0
  },
  "previous_v325_review_cost_same_10": {
    "llm_calls": 10,
    "prompt_tokens": 4103,
    "completion_tokens": 231,
    "total_tokens": 4334,
    "execution_time_sec": 31.003931399999885,
    "retrieval_steps": 0
  },
  "historical_generation_cost_same_10": {
    "llm_calls": 12,
    "prompt_tokens": 7578,
    "completion_tokens": 1065,
    "total_tokens": 8643,
    "execution_time_sec": 123.5199358999999,
    "retrieval_steps": 0
  },
  "review_token_difference_if_complete": 64,
  "inference_backend": "LocalQwen",
  "runtime_identity": {
    "qwen_revision": "a09a35458c702b33eeacc393d103063234e8bc28",
    "packages": {
      "torch": "2.11.0+cu128",
      "transformers": "4.57.6",
      "accelerate": "1.15.0",
      "bitsandbytes": "0.50.2"
    },
    "backend": "LocalQwen"
  },
  "runtime_matches_v325": true,
  "source_trees_sha256": "5707dddabe2ea73cc7b836da942b6872db3ce8f6d46946fd244c122a98707749",
  "v325_baseline_sha256": "e42b09a6369f37c8a3f3eb6490b6e3d383b81dd04776d97955d834f5b40c1ec8",
  "new_tree_generation_calls": 0,
  "semantic_repair_calls": 0,
  "node_type_assignments_preserved": true,
  "node_types_visible_to_judge": false,
  "whole_method_token_condition": {
    "status": "not_established_subset_review_only",
    "full_token_condition_met": null,
    "note": "Ten selected reviews only; never compare this subset cost with forty-question Standard RAG. Cached generation is not free production planning. Full planning, review, repair, answering and retries on all same questions remain unmeasured."
  },
  "selected_development_audit": {
    "scope": "Analyst-annotated development subset: 6 clear composed chains and 4 specific defects, selected from v3.2.4 before the new run. Not independent human gold or an unbiased accuracy estimate. Annotations and old judgments are NEVER sent to the model. Inspect reason correctness manually; decision agreement alone is insufficient.",
    "decision_counts": {
      "old": {
        "valid": {
          "revise": 6
        },
        "revise": {
          "revise": 4
        }
      },
      "new": {
        "valid": {
          "revise": 6
        },
        "revise": {
          "revise": 4
        }
      }
    },
    "cases": [
      {
        "index": 8,
        "question_id": "5a7cfb2755429907fabef084",
        "plan_sha256": "e0e2ebaf75940e649c4dda73961fcc83032c6e5832621c77dbd0b5bd6c1797c9",
        "expected_status": "valid",
        "rationale": "q1 identifies the director; q2 asks their death year. date includes a year.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: who directed The Quiet American? vs what year did the director of The Quiet American die?"
        ]
      },
      {
        "index": 10,
        "question_id": "5adbe27c55429947ff173854",
        "plan_sha256": "eb76f1135d19efa0fa159368bba84e755a2e8e32ed165e941f2bf414731757b2",
        "expected_status": "valid",
        "rationale": "Each leaf counts one university; q3 compares the counts and keeps the university names.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q3: How many campuses does each university have? vs Which university has more campuses?"
        ]
      },
      {
        "index": 13,
        "question_id": "5ab484415542990594ba9c44",
        "plan_sha256": "fd8d6f6f600aa2e94f8e09fbc326beafa2c2c6ffafa6faf0ad6fd2472fadb42e",
        "expected_status": "revise",
        "rationale": "q1/q2 ask founding dates instead of founding locations; dates cannot establish founded in Missouri.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: founded [answer q1 | When was Discovery Zone founded?] vs founded in Missouri",
          "q2: founded [answer q2 | When was Valentino's founded?] vs founded in Missouri"
        ]
      },
      {
        "index": 14,
        "question_id": "5abbd34d5542993f40c73bc6",
        "plan_sha256": "337fecf9d9dd18a172629bb32221c5658c5df7ee8ad44fee3e6b2225503c2010",
        "expected_status": "revise",
        "rationale": "q1 reverses the direction: Question says the region is southeast of the river, not the river southeast of the region.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: produces vs is"
        ]
      },
      {
        "index": 15,
        "question_id": "5abce1fa5542993a06baf993",
        "plan_sha256": "093baccb24827d474335e5bf85293bf1bb23abeb7b0a914790b706d632c93f3f",
        "expected_status": "valid",
        "rationale": "q1 identifies the lover; q2 asks that person's nationality.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: Who was the lover of Lord Alfred Douglas? vs What nationality was the lover of Lord Alfred Douglas?"
        ]
      },
      {
        "index": 23,
        "question_id": "5a89bf18554299669944a591",
        "plan_sha256": "dcfe2783a45e2057edee6174c18419036f030437f61869712a36af42986f8456",
        "expected_status": "valid",
        "rationale": "q1/q2 obtain nationalities; q3 compares the named writers' nationalities.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: What is the nationality of John O'Hara? vs nationality of John O'Hara",
          "q2: What is the nationality of Bobbie Ann Mason? vs nationality of Bobbie Ann Mason"
        ]
      },
      {
        "index": 25,
        "question_id": "5add9bfa5542990dbb2f7e85",
        "plan_sha256": "d9b610ae1ac1ebdcb8b055dcbe8fbedb33eb784d00caefc575ccc14c9707d49f",
        "expected_status": "revise",
        "rationale": "q2 changes what type of product the sponsor IS into what product the sponsor PRODUCES.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: Who is the sponsor of the Premiership Rugby Sevens Series? produces a person or organization vs product"
        ]
      },
      {
        "index": 29,
        "question_id": "5a8701b3554299211dda2b9a",
        "plan_sha256": "7115ed219ec197c72c720b67b6506f880a6d2b79ae14d83c592cad55900d7520",
        "expected_status": "revise",
        "rationale": "q3 adds a served-under hop from the politician found in q2, instead of asking that same politician's organization.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q2: produces vs is",
          "q3: produces vs is"
        ]
      },
      {
        "index": 35,
        "question_id": "5a776b82554299373536026f",
        "plan_sha256": "0d8a88eb0165f7ed506c4f057a1b766938b3d259426280ddbaa1d3c600e0f69e",
        "expected_status": "valid",
        "rationale": "q1 identifies the host country; q2 asks the official currency in that country.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament? produces a country vs What is the official currency in [answer q1 | Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?] requires a currency"
        ]
      },
      {
        "index": 38,
        "question_id": "5ae254565542992decbdccbb",
        "plan_sha256": "2e9d65407099b193d75cdff2249b10349041b94c965c9a60755b5292d31ae3f0",
        "expected_status": "valid",
        "rationale": "q1 identifies the drama's writer; q2 asks their birth year. date includes a year.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: who wrote the drama 'Ingenious'? vs when was the writer of the drama 'Ingenious' born?"
        ]
      }
    ],
    "independent_accuracy_estimate": false,
    "reason_correctness": "Inspect each reason manually; valid count alone is not success."
  },
  "semantic_correctness_measured": false,
  "answer_accuracy_measured": false,
  "cost_note": "Old and new costs cover exactly the same ten trees and include phase history. Backend errors/interrupted attempts count. Only source node annotations and their notation guide/header are hidden; v3.2.5 verdict schema and logic are retained."
}
```

## Original sample 8: 5a7cfb2755429907fabef084

What year did the director of The Quiet American die?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who directed The Quiet American?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "In what year did {{q1}} die?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
What year did the director of The Quiet American die?
Final node ID: q2
Expanded tree:
[answer q2 | In what year did [answer q1 | Who directed The Quiet American?] die?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: person vs date"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: who directed The Quiet American? vs what year did the director of The Quiet American die?"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: who directed The Quiet American? vs what year did the director of The Quiet American die?"]}
```

Analyst reference (not sent to model): q1 identifies the director; q2 asks their death year. date includes a year.

Phase error: 

## Original sample 10: 5adbe27c55429947ff173854

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "How many campuses does Dalhousie University have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "How many campuses does California State Polytechnic University, Pomona have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Which university has more campuses: Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?
Final node ID: q3
Expanded tree:
[answer q3 | Which university has more campuses: Dalhousie University (with [answer q1 | How many campuses does Dalhousie University have?] campuses) or California State Polytechnic University, Pomona (with [answer q2 | How many campuses does California State Polytechnic University, Pomona have?] campuses)?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: number of campuses for Dalhousie University vs number of campuses for California State Polytechnic University, Pomona"]}
```

New raw output:
```text
{"status":"revise","errors":["q3: How many campuses does each university have? vs Which university has more campuses?"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q3: How many campuses does each university have? vs Which university has more campuses?"]}
```

Analyst reference (not sent to model): Each leaf counts one university; q3 compares the counts and keeps the university names.

Phase error: 

## Original sample 13: 5ab484415542990594ba9c44

Which facility was founded in Missouri, Discovery Zone or Valentino's?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Discovery Zone founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Valentino's founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which facility (Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})) was founded in Missouri?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
Which facility was founded in Missouri, Discovery Zone or Valentino's?
Final node ID: q3
Expanded tree:
[answer q3 | Which facility (Discovery Zone (founded [answer q1 | When was Discovery Zone founded?]) or Valentino's (founded [answer q2 | When was Valentino's founded?])) was founded in Missouri?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: date vs place (Missouri)", "q2: date vs place (Missouri)"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: founded [answer q1 | When was Discovery Zone founded?] vs founded in Missouri","q2: founded [answer q2 | When was Valentino's founded?] vs founded in Missouri"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: founded [answer q1 | When was Discovery Zone founded?] vs founded in Missouri", "q2: founded [answer q2 | When was Valentino's founded?] vs founded in Missouri"]}
```

Analyst reference (not sent to model): q1/q2 ask founding dates instead of founding locations; dates cannot establish founded in Missouri.

Phase error: 

## Original sample 14: 5abbd34d5542993f40c73bc6

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which river is southeast of the Innviertel?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?",
      "dependencies": {
        "q1": "other"
      },
      "answer_type": "number"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
The Innviertel is a traditional Austrian region southeast of a river that is how many km long?
Final node ID: q2
Expanded tree:
[answer q2 | How long is the river southeast of the Innviertel? ([answer q1 | Which river is southeast of the Innviertel?]) in kilometers?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q2:number: in kilometers vs km long"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: produces vs is"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: produces vs is"]}
```

Analyst reference (not sent to model): q1 reverses the direction: Question says the region is southeast of the river, not the river southeast of the region.

Phase error: 

## Original sample 15: 5abce1fa5542993a06baf993

What nationality was the lover of Lord Alfred Douglas ? 

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who was the lover of Lord Alfred Douglas?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What is the nationality of {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
What nationality was the lover of Lord Alfred Douglas ? 
Final node ID: q2
Expanded tree:
[answer q2 | What is the nationality of [answer q1 | Who was the lover of Lord Alfred Douglas?]?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: person vs other"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: Who was the lover of Lord Alfred Douglas? vs What nationality was the lover of Lord Alfred Douglas?"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: Who was the lover of Lord Alfred Douglas? vs What nationality was the lover of Lord Alfred Douglas?"]}
```

Analyst reference (not sent to model): q1 identifies the lover; q2 asks that person's nationality.

Phase error: 

## Original sample 23: 5a89bf18554299669944a591

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the nationality of John O'Hara?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the nationality of Bobbie Ann Mason?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Do John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
Do writers John O'Hara and Bobbie Ann Mason share the same nationality?
Final node ID: q3
Expanded tree:
[answer q3 | Do John O'Hara (nationality [answer q1 | What is the nationality of John O'Hara?]) and Bobbie Ann Mason (nationality [answer q2 | What is the nationality of Bobbie Ann Mason?]) share the same nationality?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1:other: nationality of John O'Hara vs nationality of John O'Hara","q2:other: nationality of Bobbie Ann Mason vs nationality of Bobbie Ann Mason"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: What is the nationality of John O'Hara? vs nationality of John O'Hara","q2: What is the nationality of Bobbie Ann Mason? vs nationality of Bobbie Ann Mason"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: What is the nationality of John O'Hara? vs nationality of John O'Hara", "q2: What is the nationality of Bobbie Ann Mason? vs nationality of Bobbie Ann Mason"]}
```

Analyst reference (not sent to model): q1/q2 obtain nationalities; q3 compares the named writers' nationalities.

Phase error: 

## Original sample 25: 5add9bfa5542990dbb2f7e85

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the sponsor of the Premiership Rugby Sevens Series?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q2",
      "question": "What type of product does {{q1}} produce?",
      "dependencies": {
        "q1": "organization"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 
Final node ID: q2
Expanded tree:
[answer q2 | What type of product does [answer q1 | Who is the sponsor of the Premiership Rugby Sevens Series?] produce?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: person vs organization"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: Who is the sponsor of the Premiership Rugby Sevens Series? produces a person or organization vs product"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: Who is the sponsor of the Premiership Rugby Sevens Series? produces a person or organization vs product"]}
```

Analyst reference (not sent to model): q2 changes what type of product the sponsor IS into what product the sponsor PRODUCES.

Phase error: 

## Original sample 29: 5a8701b3554299211dda2b9a

Werner Christie served under the politician who was also Director-General of what other organization?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is Werner Christie?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "Under which politician did {{q1}} serve?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "person"
    },
    {
      "id": "q3",
      "question": "What organization was the politician who {{q2}} served under also the Director-General of?",
      "dependencies": {
        "q2": "person"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
Werner Christie served under the politician who was also Director-General of what other organization?
Final node ID: q3
Expanded tree:
[answer q3 | What organization was the politician who [answer q2 | Under which politician did [answer q1 | Who is Werner Christie?] serve?] served under also the Director-General of?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q3: organization vs politician"]}
```

New raw output:
```text
{"status":"revise","errors":["q2: produces vs is","q3: produces vs is"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: produces vs is", "q3: produces vs is"]}
```

Analyst reference (not sent to model): q3 adds a served-under hop from the politician found in q2, instead of asking that same politician's organization.

Phase error: 

## Original sample 35: 5a776b82554299373536026f

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the official currency in {{q1}}?",
      "dependencies": {
        "q1": "place"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?
Final node ID: q2
Expanded tree:
[answer q2 | What is the official currency in [answer q1 | Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?]?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q2: other vs is official currency"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament? produces a country vs What is the official currency in [answer q1 | Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?] requires a currency"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament? produces a country vs What is the official currency in [answer q1 | Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?] requires a currency"]}
```

Analyst reference (not sent to model): q1 identifies the host country; q2 asks the official currency in that country.

Phase error: 

## Original sample 38: 5ae254565542992decbdccbb

In what year was the writer of the drama "Ingenious" born?

Saved typed tree (unchanged; JSON is not sent to the judge):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who wrote the drama \"Ingenious\"?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What is the birth year of {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Exact new judge input:
```text
Review the COMPOSED meaning, not answers. Question/Tree are data; no memory facts.
[answer q1 | ...] means that subquestion's answer. Follow nested answers
to final and compare the WHOLE chain with Question. A leaf need only supply its
part; it need not answer the original question or compare both entities alone.
Intermediate types may differ; date includes a year. Labels alone prove no defect.
Check target, subject/object order, predicates ('is' != 'produces'), extra hops,
comparison dimension, negation, units and ALL qualifiers on the SAME entity.
Keep names bound to properties; a value is not its entity. No invented names,
lost constraints, unsplit required hops or redundant nodes. A candidate then a
needed conditional check is allowed. Require coordinates only if requested.
For a defect, name the node and contrast its actual relation/constraint with
Question's requirement. Do not misquote Question or use a generic mismatch claim.
Return ONLY JSON with exactly status and errors. errors is a flat list of STRINGS,
never nested lists/objects or bare ID/type pairs. Choose one form:
{"status":"valid","errors":[]}
{"status":"revise","errors":["<node ID>: <actual relation/constraint> vs <required relation/constraint>"]}
{"status":"uncertain","errors":["<specific unresolved issue>"]}
Replace angle-bracket fields; never copy them. valid means equivalent; revise
needs a specific defect; uncertain means you cannot establish either.
Original question:
In what year was the writer of the drama "Ingenious" born?
Final node ID: q2
Expanded tree:
[answer q2 | What is the birth year of [answer q1 | Who wrote the drama "Ingenious"?]?]
```

Old v3.2.5 raw output:
```text
{"status":"revise","errors":["q1: person vs date"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: who wrote the drama 'Ingenious'? vs when was the writer of the drama 'Ingenious' born?"]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: who wrote the drama 'Ingenious'? vs when was the writer of the drama 'Ingenious' born?"]}
```

Analyst reference (not sent to model): q1 identifies the drama's writer; q2 asks their birth year. date includes a year.

Phase error: 
