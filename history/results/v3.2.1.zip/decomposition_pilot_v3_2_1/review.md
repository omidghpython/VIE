# Decomposition pilot

Inspect every tree against its original question. Model judgments are observations, not ground truth.
Check required decomposition, entity/property binding, direction, constraints/negation and final answer type.
Several nodes alone do not establish correct decomposition. Answers and retrieval are not evaluated.

## 1. 5ab3cecd5542992ade7c6eae (bridge)

How do the Peter Laufer books Forbidden Creatures and No Animals Were Harmed differ in their focus on animals?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 2. 5ab42a2b5542996a3a969f5a (bridge)

What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What is the name of the historic figure who participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "person"
    },
    {
      "id": "q3",
      "question": "Who had a premier African American recreation center named after {{q2}}?",
      "dependencies": {
        "q2": "person"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 43 (char 42)"]
Structure error: 

Manual review: pending.

## 3. 5a7d3f895542995f4f402248 (bridge)

Pandora- The World of Avatar includes a ride that allows guest to take flight on what animal?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 4. 5a778b345542992a6e59decf (comparison)

Who was born first, Susan Oliver or W. S. Van Dyke?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Susan Oliver born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was W. S. Van Dyke born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Is {{q1}} before {{q2}}?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["uncertain"]
Structure error: 

Manual review: pending.

## 5. 5a8ceddb554299441c6b9f85 (comparison)

What profession does Nora Roberts and Elizabeth Hardwick have in common?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What profession does Nora Roberts have?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What profession does Elizabeth Hardwick have?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "What profession do {{q1}} and {{q2}} have in common?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["multi-hop question not decomposed into separate nodes"]
Structure error: 

Manual review: pending.

## 6. 5a7e05f75542995f4f402394 (comparison)

Which was released first, Hot Girls Wanted or China Blue?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the release year of Hot Girls Wanted?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "What is the release year of China Blue?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which release year is earlier, {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "date"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 123 (char 122)"]
Structure error: 

Manual review: pending.

## 7. 5ab3306a55429969a97a80fd (comparison)

The movies The Boatniks and The Great Locomotive Chase were both made by which production company?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 8. 5a7cfb2755429907fabef084 (bridge)

What year did the director of The Quiet American die?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who directed The Quiet American?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What year did {{q1}} die?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["The question asks for a year, but the tree asks for a person first"]
Structure error: 

Manual review: pending.

## 9. 5ab201765542993be8fa98a4 (bridge)

Hobart Paving is a single by a band formed in which year ?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Hobart Paving is a single by a band formed in which year?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "What year was the band formed that released {{q1}}?",
      "dependencies": {
        "q1": "date"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["multi-hop question not decomposed into meaningful nodes"]
Structure error: 

Manual review: pending.

## 10. 5adbe27c55429947ff173854 (comparison)

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "How many campuses does Dalhousie University have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "How many campuses does California State Polytechnic University, Pomona have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Is the number of campuses of {{q1}} greater than the number of campuses of {{q2}}?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 43 (char 42)"]
Structure error: 

Manual review: pending.

## 11. 5a8fa4d95542995b4424207b (comparison)

Which airport is busier, Palm Springs International Airport or Trenton–Mercer Airport?

Structure: valid; judge: valid; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the passenger throughput of Palm Springs International Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "What is the passenger throughput of Trenton–Mercer Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Is the passenger throughput of {{q1}} greater than the passenger throughput of {{q2}}?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: []
Structure error: 

Manual review: pending.

## 12. 5ac19ff35542991316484b61 (comparison)

Which was published or broadcast first, The Graveyard Book of Phineas and Ferb?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was The Graveyard Book published?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Phineas and Ferb broadcast?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which was published or broadcast first, {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["mismatch in entity names"]
Structure error: 

Manual review: pending.

## 13. 5ab484415542990594ba9c44 (comparison)

Which facility was founded in Missouri, Discovery Zone or Valentino's?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 14. 5abbd34d5542993f40c73bc6 (bridge)

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which river is southeast of the Innviertel?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "How long is the {{q1}} in kilometers?",
      "dependencies": {
        "q1": "other"
      },
      "answer_type": "number"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["Question asks for length of a river, while Tree asks for name of a river"]
Structure error: 

Manual review: pending.

## 15. 5abce1fa5542993a06baf993 (bridge)

What nationality was the lover of Lord Alfred Douglas ? 

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who was the lover of Lord Alfred Douglas?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What nationality is {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["The second node should directly ask about the nationality of the person identified in the first node, rather than using a placeholder."]
Structure error: 

Manual review: pending.

## 16. 5a77a7db5542995d8318124d (comparison)

Which author was born first, Josephine Tey or Julia Peterkin?

Structure: valid; judge: valid; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Josephine Tey born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Julia Peterkin born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which author was born earlier, {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: []
Structure error: 

Manual review: pending.

## 17. 5abe94fd55429965af743f37 (comparison)

Were both Sinclair Research and the Wave Mate Bullet founded in the 1970s?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Sinclair Research founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was the Wave Mate Bullet founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Was {{q1}} in the 1970s?",
      "dependencies": {
        "q1": "date"
      },
      "answer_type": "boolean"
    },
    {
      "id": "q4",
      "question": "Was {{q2}} in the 1970s?",
      "dependencies": {
        "q2": "date"
      },
      "answer_type": "boolean"
    },
    {
      "id": "q5",
      "question": "Is both {{q3}} and {{q4}} true?",
      "dependencies": {
        "q3": "boolean",
        "q4": "boolean"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q5"
}
```

Judge errors: ["Wave Mate Bullet is not a company, but a product"]
Structure error: 

Manual review: pending.

## 18. 5a7d598d5542995f4f402262 (comparison)

Which director was also a film editor, Burton L. King or Maheen Zia?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the profession of Burton L. King?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the profession of Maheen Zia?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Is {{q1}} 'film editor'?",
      "dependencies": {
        "q1": "other"
      },
      "answer_type": "boolean"
    },
    {
      "id": "q4",
      "question": "Is {{q2}} 'film editor'?",
      "dependencies": {
        "q2": "other"
      },
      "answer_type": "boolean"
    },
    {
      "id": "q5",
      "question": "If {{q3}} and {{q4}}, which director was also a film editor, Burton L. King or Maheen Zia?",
      "dependencies": {
        "q3": "boolean",
        "q4": "boolean"
      },
      "answer_type": "other"
    }
  ],
  "final": "q5"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 43 (char 42)"]
Structure error: 

Manual review: pending.

## 19. 5ae73ddb554299572ea5478d (bridge)

Hoy Es Manana is by what Mexican Actress and singer, who is the current First Lady of Chiapas State, Mexico?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 20. 5ade5a645542997c77adee0d (comparison)

Which city is at coastal county-level, Wenling or Ruili?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Is Wenling a coastal city?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q2",
      "question": "Is Ruili a coastal city?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q3",
      "question": "Which city is coastal, {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "boolean",
        "q2": "boolean"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["different wording for the same concept"]
Structure error: 

Manual review: pending.

## 21. 5a87bc3f5542996432c57275 (comparison)

Which is located farther West, the Cascade Locks and Canal or Lake Worth Lagoon?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the location of Cascade Locks and Canal?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the location of Lake Worth Lagoon?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Is {{q1}} located farther west than {{q2}}?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["different comparison operands"]
Structure error: 

Manual review: pending.

## 22. 5ae38b115542990afbd1e183 (comparison)

Who played a more important role in the church George Albert Smith or Wong Jing?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who played a more important role in the church George Albert Smith?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "Who played a more important role in the church Wong Jing?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q3",
      "question": "{{q1}} compared to {{q2}}",
      "dependencies": {
        "q1": "person",
        "q2": "person"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["mismatch in comparison context"]
Structure error: 

Manual review: pending.

## 23. 5a89bf18554299669944a591 (comparison)

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the nationality of John O'Hara?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the nationality of Bobbie Ann Mason?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Do {{q1}} and {{q2}} share the same nationality?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["different wording"]
Structure error: 

Manual review: pending.

## 24. 5ae0a5825542993d6555ebdf (comparison)

Are George Stevens and Luc Besson American cinematographers?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 25. 5add9bfa5542990dbb2f7e85 (bridge)

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 26. 5a75a0725542992d0ec05fc9 (bridge)

Disorganized Crime included what cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?",
      "dependencies": {},
      "answer_type": "person"
    }
  ],
  "final": "q1"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 88 (char 87)"]
Structure error: 

Manual review: pending.

## 27. 5ac43e0f554299076e296d8e (comparison)

What country are both Dafeng District and Jixi in?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What country is Dafeng District in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What country is Jixi in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Are both {{q1}} and {{q2}} the same country?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["uncertain"]
Structure error: 

Manual review: pending.

## 28. 5a8ea7f25542995085b37468 (comparison)

Are The Limousines and Faith No More from the same state?

Structure: valid; judge: valid; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What state is The Limousines from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What state is Faith No More from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Are {{q1}} and {{q2}} the same?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: []
Structure error: 

Manual review: pending.

## 29. 5a8701b3554299211dda2b9a (bridge)

Werner Christie served under the politician who was also Director-General of what other organization?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is Werner Christie?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What organization was the politician that {{q1}} served under also the Director-General of?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 72 (char 71)"]
Structure error: 

Manual review: pending.

## 30. 5ac3dfee554299204fd21eab (bridge)

The man known as the voice of "Elgar" voices the English character in what Manga inspired by Keitaro Arima?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the voice actor known as the voice of 'Elgar'?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What manga is inspired by Keitaro Arima?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Which English character does {{q1}} voice in {{q2}}?",
      "dependencies": {
        "q1": "person",
        "q2": "other"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["Q1 and Q2 are not directly related to the original question's context and do not capture the necessary information."]
Structure error: 

Manual review: pending.

## 31. 5a7f7b3b5542992097ad2f81 (comparison)

Which restaurant chain's headquarters is further north, Pizza Inn or Papa Gino's?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the headquarters location of Pizza Inn?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the headquarters location of Papa Gino's?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Is {{q1}} further north than {{q2}}?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["different wording"]
Structure error: 

Manual review: pending.

## 32. 5ae3d2715542990afbd1e1e9 (comparison)

Are Control Room and Meeting Resistance both documentary films that involve Iraq?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 33. 5ae077735542993d6555eb6d (bridge)

What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 34. 5adf4b335542993a75d264a5 (bridge)

Paul DeBoy is known for an appearance in the Western action-adventure game developed by which company?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 35. 5a776b82554299373536026f (bridge)

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

Structure: valid; judge: valid; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the official currency in {{q1}}?",
      "dependencies": {
        "q1": "place"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Judge errors: []
Structure error: 

Manual review: pending.

## 36. 5ac0b1835542992a796ded65 (bridge)

Bordan Tkachuk was the former CEO of which company, which provides IT products?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is Bordan Tkachuk?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What company does {{q1}} used to be the CEO of?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "organization"
    },
    {
      "id": "q3",
      "question": "Does {{q2}} provide IT products?",
      "dependencies": {
        "q2": "organization"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Judge errors: ["semantic decomposition missing for 'which company' and 'IT products' constraints"]
Structure error: 

Manual review: pending.

## 37. 5a80afcf554299485f5986b9 (bridge)

Who else beside the  American university administrator and politician from the state of Oklahoma was part of the  Boren-McCurdy proposals?

Structure: valid; judge: revise; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who else beside the American university administrator and politician from the state of Oklahoma was part of the Boren-McCurdy proposals?",
      "dependencies": {},
      "answer_type": "person"
    }
  ],
  "final": "q1"
}
```

Judge errors: ["uncertain"]
Structure error: 

Manual review: pending.

## 38. 5ae254565542992decbdccbb (bridge)

In what year was the writer of the drama "Ingenious" born?

Structure: valid; judge: uncertain; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who wrote the drama \"Ingenious\"?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "In what year was {{q1}} born?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Judge errors: ["Invalid semantic review: Invalid JSON: Extra data: line 1 column 59 (char 58)"]
Structure error: 

Manual review: pending.

## 39. 5ae14b0655429920d52343a6 (bridge)

Bangalore Naatkal starred which actor and photographer?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.

## 40. 5ae409d955429970de88d89d (bridge)

Greetings! We're The Monitors was the debut album by the band who had what soul and R&B singer as their lead?

Structure: invalid; judge: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Judge errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Manual review: pending.
