# Decomposition pilot

Inspect every tree against its original question. Model judgments are observations, not ground truth.
Check required decomposition, entity/property binding, direction, constraints/negation and final answer type.
Several nodes alone do not establish correct decomposition. Answers and retrieval are not evaluated.
invalid_response is a reviewer format failure, not semantic uncertainty or a demonstrated tree defect.

## 1. 5ab3cecd5542992ade7c6eae (bridge)

How do the Peter Laufer books Forbidden Creatures and No Animals Were Harmed differ in their focus on animals?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the focus of Forbidden Creatures on animals?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the focus of No Animals Were Harmed on animals?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "How do the Peter Laufer books Forbidden Creatures (focus on {{q1}}) and No Animals Were Harmed (focus on {{q2}}) differ in their focus on animals?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:other | How do the Peter Laufer books Forbidden Creatures (focus on [answer q1:other | What is the focus of Forbidden Creatures on animals?]) and No Animals Were Harmed (focus on [answer q2:other | What is the focus of No Animals Were Harmed on animals?]) differ in their focus on animals?]

Root errors: []
Review errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the focus of Forbidden Creatures on animals?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the focus of No Animals Were Harmed on animals?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"How do the Peter Laufer books Forbidden Creatures (focus on {{q1}}) and No Animals Were Harmed (focus on {{q2}}) differ in their focus on animals?","dependencies":{"q1":"other","q2":"other"},"answer_type":"other"}],"final":"q3"}
```

Manual review: pending.

## 2. 5ab42a2b5542996a3a969f5a (bridge)

What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?

Structure: invalid; root check: not_checked; review: not_reviewed (not_reviewed); model judgment: not_called.
Response handling: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Expanded typed tree (same representation sent to the judge if called):



Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is {{q1}} associated with a premier African American recreation center named after them?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is there a premier African American recreation center named after {{q1}}?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q2":"boolean","q1":"person"},"answer_type":"person"}],"final":"q3"}
```

Manual review: pending.

## 3. 5a7d3f895542995f4f402248 (bridge)

Pandora- The World of Avatar includes a ride that allows guest to take flight on what animal?

Structure: valid; root check: not_checked; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What animal allows guests to take flight in Pandora- The World of Avatar?",
      "dependencies": {},
      "answer_type": "work"
    }
  ],
  "final": "q1"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q1:work | What animal allows guests to take flight in Pandora- The World of Avatar?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What animal allows guests to take flight in Pandora- The World of Avatar?","dependencies":{},"answer_type":"work"}],"final":"q1"}
```

Manual review: pending.

## 4. 5a778b345542992a6e59decf (comparison)

Who was born first, Susan Oliver or W. S. Van Dyke?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Susan Oliver born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was W. S. Van Dyke born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:person | Who was born first: Susan Oliver (born [answer q1:date | When was Susan Oliver born?]) or W. S. Van Dyke (born [answer q2:date | When was W. S. Van Dyke born?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Susan Oliver born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was W. S. Van Dyke born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

Manual review: pending.

## 5. 5a8ceddb554299441c6b9f85 (comparison)

What profession does Nora Roberts and Elizabeth Hardwick have in common?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the profession of Nora Roberts?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What is the profession of Elizabeth Hardwick?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "What profession do Nora Roberts (profession {{q1}}) and Elizabeth Hardwick (profession {{q2}}) have in common?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:work | What profession do Nora Roberts (profession [answer q1:work | What is the profession of Nora Roberts?]) and Elizabeth Hardwick (profession [answer q2:work | What is the profession of Elizabeth Hardwick?]) have in common?]

Root errors: []
Review errors: ["q3: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q3: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q3: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Nora Roberts?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Elizabeth Hardwick?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"What profession do Nora Roberts (profession {{q1}}) and Elizabeth Hardwick (profession {{q2}}) have in common?","dependencies":{"q1":"work","q2":"work"},"answer_type":"work"}],"final":"q3"}
```

Manual review: pending.

## 6. 5a7e05f75542995f4f402394 (comparison)

Which was released first, Hot Girls Wanted or China Blue?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Hot Girls Wanted released?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was China Blue released?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:work | Which was released first: Hot Girls Wanted (released [answer q1:date | When was Hot Girls Wanted released?]) or China Blue (released [answer q2:date | When was China Blue released?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Hot Girls Wanted released?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was China Blue released?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual review: pending.

## 7. 5ab3306a55429969a97a80fd (comparison)

The movies The Boatniks and The Great Locomotive Chase were both made by which production company?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What production company made The Boatniks?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q2",
      "question": "What production company made The Great Locomotive Chase?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q3",
      "question": "Which production company made both The Boatniks ({{q1}}) and The Great Locomotive Chase ({{q2}})?",
      "dependencies": {
        "q1": "organization",
        "q2": "organization"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:organization | Which production company made both The Boatniks ([answer q1:organization | What production company made The Boatniks?]) and The Great Locomotive Chase ([answer q2:organization | What production company made The Great Locomotive Chase?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What production company made The Boatniks?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What production company made The Great Locomotive Chase?","dependencies":{},"answer_type":"organization"},{"id":"q3","question":"Which production company made both The Boatniks ({{q1}}) and The Great Locomotive Chase ({{q2}})?","dependencies":{"q1":"organization","q2":"organization"},"answer_type":"organization"}],"final":"q3"}
```

Manual review: pending.

## 8. 5a7cfb2755429907fabef084 (bridge)

What year did the director of The Quiet American die?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who directed The Quiet American?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "In what year did {{q1}} die?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:date | In what year did [answer q1:person | Who directed The Quiet American?] die?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who directed The Quiet American?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year did {{q1}} die?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

Manual review: pending.

## 9. 5ab201765542993be8fa98a4 (bridge)

Hobart Paving is a single by a band formed in which year ?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the name of the band that released the single 'Hobart Paving'?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "In which year was {{q1}} formed?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:date | In which year was [answer q1:work | What is the name of the band that released the single 'Hobart Paving'?] formed?]

Root errors: []
Review errors: ["q2:date produces a date instead of a year; q1:work should be a band formation year."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2:date produces a date instead of a year; q1:work should be a band formation year."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
````text
{"status":"revise","errors":["q2:date produces a date instead of a year; q1:work should be a band formation year."]}```
````

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the name of the band that released the single 'Hobart Paving'?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In which year was {{q1}} formed?","dependencies":{"q1":"work"},"answer_type":"date"}],"final":"q2"}
```

Manual review: pending.

## 10. 5adbe27c55429947ff173854 (comparison)

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

Structure: valid; root check: mismatch; review: revise (root_rule); model judgment: not_called.
Response handling: not_called; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "How many campuses does Dalhousie University have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "How many campuses does California State Polytechnic University, Pomona have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Does Dalhousie University (with {{q1}} campuses) have more campuses than California State Polytechnic University, Pomona (with {{q2}} campuses)?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:boolean | Does Dalhousie University (with [answer q1:number | How many campuses does Dalhousie University have?] campuses) have more campuses than California State Polytechnic University, Pomona (with [answer q2:number | How many campuses does California State Polytechnic University, Pomona have?] campuses)?]

Root errors: ["q3: original question requests a name/value, but the final node has a boolean type or asks yes/no. Rewrite its question and type to return the requested name/value, preserving each entity with its property."]
Review errors: ["q3: original question requests a name/value, but the final node has a boolean type or asks yes/no. Rewrite its question and type to return the requested name/value, preserving each entity with its property."]
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: answer_type must be one of ['boolean', 'date', 'number', 'organization', 'other', 'person', 'place', 'work'].
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"How many campuses does Dalhousie University have?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"How many campuses does California State Polytechnic University, Pomona have?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which university has more campuses: Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"university"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"How many campuses does Dalhousie University have?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"How many campuses does California State Polytechnic University, Pomona have?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Does Dalhousie University (with {{q1}} campuses) have more campuses than California State Polytechnic University, Pomona (with {{q2}} campuses)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"boolean"}],"final":"q3"}
```

Manual review: pending.

## 11. 5a8fa4d95542995b4424207b (comparison)

Which airport is busier, Palm Springs International Airport or Trenton–Mercer Airport?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the passenger throughput of Palm Springs International Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "What is the passenger throughput of Trenton–Mercer Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Which airport has higher passenger throughput, Palm Springs International Airport ({{q1}} passengers) or Trenton–Mercer Airport ({{q2}} passengers)?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:place | Which airport has higher passenger throughput, Palm Springs International Airport ([answer q1:number | What is the passenger throughput of Palm Springs International Airport?] passengers) or Trenton–Mercer Airport ([answer q2:number | What is the passenger throughput of Trenton–Mercer Airport?] passengers)?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the passenger throughput of Palm Springs International Airport?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the passenger throughput of Trenton–Mercer Airport?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which airport has higher passenger throughput, Palm Springs International Airport ({{q1}} passengers) or Trenton–Mercer Airport ({{q2}} passengers)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```

Manual review: pending.

## 12. 5ac19ff35542991316484b61 (comparison)

Which was published or broadcast first, The Graveyard Book of Phineas and Ferb?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was The Graveyard Book published?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Phineas and Ferb broadcasted?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:work | Which was published or broadcasted first, The Graveyard Book (published [answer q1:date | When was The Graveyard Book published?]) or Phineas and Ferb (broadcasted [answer q2:date | When was Phineas and Ferb broadcasted?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was The Graveyard Book published?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Phineas and Ferb broadcasted?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual review: pending.

## 13. 5ab484415542990594ba9c44 (comparison)

Which facility was founded in Missouri, Discovery Zone or Valentino's?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Discovery Zone founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Valentino's founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which facility (Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})) was founded in Missouri?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:work | Which facility (Discovery Zone (founded [answer q1:date | When was Discovery Zone founded?]) or Valentino's (founded [answer q2:date | When was Valentino's founded?])) was founded in Missouri?]

Root errors: []
Review errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Discovery Zone founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Valentino's founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which facility (Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})) was founded in Missouri?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual review: pending.

## 14. 5abbd34d5542993f40c73bc6 (bridge)

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the length of the river southeast of which the Innviertel is located?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "The Innviertel is a traditional Austrian region southeast of a river that is {{q1}} km long.",
      "dependencies": {
        "q1": "number"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:other | The Innviertel is a traditional Austrian region southeast of a river that is [answer q1:number | What is the length of the river southeast of which the Innviertel is located?] km long.]

Root errors: []
Review errors: ["q1: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the length of the river southeast of which the Innviertel is located?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The Innviertel is a traditional Austrian region southeast of a river that is {{q1}} km long.","dependencies":{"q1":"number"},"answer_type":"other"}],"final":"q2"}
```

Manual review: pending.

## 15. 5abce1fa5542993a06baf993 (bridge)

What nationality was the lover of Lord Alfred Douglas ? 

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who was the lover of Lord Alfred Douglas?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What nationality was {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "place"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:place | What nationality was [answer q1:person | Who was the lover of Lord Alfred Douglas?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What nationality was Lord Alfred Douglas?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{"q1":"place"},"answer_type":"person"},{"id":"q3","question":"What nationality was {{q2}}?","dependencies":{"q2":"person"},"answer_type":"place"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What nationality was {{q1}}?","dependencies":{"q1":"person"},"answer_type":"place"}],"final":"q2"}
```

Manual review: pending.

## 16. 5a77a7db5542995d8318124d (comparison)

Which author was born first, Josephine Tey or Julia Peterkin?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Josephine Tey born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Julia Peterkin born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:person | Who was born first: Josephine Tey (born [answer q1:date | When was Josephine Tey born?]) or Julia Peterkin (born [answer q2:date | When was Julia Peterkin born?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Josephine Tey born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Julia Peterkin born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

Manual review: pending.

## 17. 5abe94fd55429965af743f37 (comparison)

Were both Sinclair Research and the Wave Mate Bullet founded in the 1970s?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Sinclair Research founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was the Wave Mate Bullet founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:boolean | Were both Sinclair Research (founded [answer q1:date | When was Sinclair Research founded?]) and the Wave Mate Bullet (founded [answer q2:date | When was the Wave Mate Bullet founded?]) founded in the 1970s?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Sinclair Research founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was the Wave Mate Bullet founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?","dependencies":{"q1":"date","q2":"date"},"answer_type":"boolean"}],"final":"q3"}
```

Manual review: pending.

## 18. 5a7d598d5542995f4f402262 (comparison)

Which director was also a film editor, Burton L. King or Maheen Zia?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is Burton L. King's profession?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What is Maheen Zia's profession?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "Which director ({{q1}} or {{q2}}) was also a film editor?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:person | Which director ([answer q1:work | What is Burton L. King's profession?] or [answer q2:work | What is Maheen Zia's profession?]) was also a film editor?]

Root errors: []
Review errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is Burton L. King's profession?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is Maheen Zia's profession?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Which director ({{q1}} or {{q2}}) was also a film editor?","dependencies":{"q1":"work","q2":"work"},"answer_type":"person"}],"final":"q3"}
```

Manual review: pending.

## 19. 5ae73ddb554299572ea5478d (bridge)

Hoy Es Manana is by what Mexican Actress and singer, who is the current First Lady of Chiapas State, Mexico?

Structure: valid; root check: mismatch; review: revise (root_rule); model judgment: not_called.
Response handling: not_called; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the current First Lady of Chiapas State, Mexico and a Mexican actress and singer?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What work is {{q1}} associated with?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:work | What work is [answer q1:person | Who is the current First Lady of Chiapas State, Mexico and a Mexican actress and singer?] associated with?]

Root errors: ["q2: original target 'actress' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]
Review errors: ["q2: original target 'actress' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the current First Lady of Chiapas State, Mexico and a Mexican actress and singer?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What work is {{q1}} associated with?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual review: pending.

## 20. 5ade5a645542997c77adee0d (comparison)

Which city is at coastal county-level, Wenling or Ruili?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Is Wenling at coastal county-level?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q2",
      "question": "Is Ruili at coastal county-level?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q3",
      "question": "Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?",
      "dependencies": {
        "q1": "boolean",
        "q2": "boolean"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:place | Which city is at coastal county-level, Wenling (at [answer q1:boolean | Is Wenling at coastal county-level?]) or Ruili (at [answer q2:boolean | Is Ruili at coastal county-level?])?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: answer_type must be one of ['boolean', 'date', 'number', 'organization', 'other', 'person', 'place', 'work'].
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"city"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"place"}],"final":"q3"}
```

Manual review: pending.

## 21. 5a87bc3f5542996432c57275 (comparison)

Which is located farther West, the Cascade Locks and Canal or Lake Worth Lagoon?

Structure: valid; root check: compatible; review: revise (geography_rule); model judgment: not_called.
Response handling: not_called; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the longitude of Cascade Locks and Canal?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "What is the longitude of Lake Worth Lagoon?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Which location is farther West: Cascade Locks and Canal (longitude {{q1}}) or Lake Worth Lagoon (longitude {{q2}})?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:place | Which location is farther West: Cascade Locks and Canal (longitude [answer q1:number | What is the longitude of Cascade Locks and Canal?]) or Lake Worth Lagoon (longitude [answer q2:number | What is the longitude of Lake Worth Lagoon?])?]

Root errors: []
Review errors: ["q1: requires a numerical longitude absent from the original request. Ask for the location/city/state and compare the named entities; retain any coordinates if present in evidence, but do not require them.", "q2: requires a numerical longitude absent from the original request. Ask for the location/city/state and compare the named entities; retain any coordinates if present in evidence, but do not require them."]
Binding errors: []
Geographic precision errors: ["q1: requires a numerical longitude absent from the original request. Ask for the location/city/state and compare the named entities; retain any coordinates if present in evidence, but do not require them.", "q2: requires a numerical longitude absent from the original request. Ask for the location/city/state and compare the named entities; retain any coordinates if present in evidence, but do not require them."]
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the longitude of Cascade Locks and Canal?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the longitude of Lake Worth Lagoon?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which location is farther West: Cascade Locks and Canal (longitude {{q1}}) or Lake Worth Lagoon (longitude {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```

Manual review: pending.

## 22. 5ae38b115542990afbd1e183 (comparison)

Who played a more important role in the church George Albert Smith or Wong Jing?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What role did George Albert Smith play in the church?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What role did Wong Jing play in the church?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:person | Who played a more important role in the church: George Albert Smith (played [answer q1:work | What role did George Albert Smith play in the church?]) or Wong Jing (played [answer q2:work | What role did Wong Jing play in the church?])?]

Root errors: []
Review errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What role did George Albert Smith play in the church?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What role did Wong Jing play in the church?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?","dependencies":{"q1":"work","q2":"work"},"answer_type":"person"}],"final":"q3"}
```

Manual review: pending.

## 23. 5a89bf18554299669944a591 (comparison)

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the nationality of John O'Hara?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the nationality of Bobbie Ann Mason?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Do John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:boolean | Do John O'Hara (nationality [answer q1:other | What is the nationality of John O'Hara?]) and Bobbie Ann Mason (nationality [answer q2:other | What is the nationality of Bobbie Ann Mason?]) share the same nationality?]

Root errors: []
Review errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the nationality of John O'Hara?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the nationality of Bobbie Ann Mason?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"Do John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?","dependencies":{"q1":"other","q2":"other"},"answer_type":"boolean"}],"final":"q3"}
```

Manual review: pending.

## 24. 5ae0a5825542993d6555ebdf (comparison)

Are George Stevens and Luc Besson American cinematographers?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Is George Stevens an American cinematographer?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q2",
      "question": "Is Luc Besson an American cinematographer?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q3",
      "question": "Are George Stevens and Luc Besson American cinematographers: {{q1}} and {{q2}}?",
      "dependencies": {
        "q1": "boolean",
        "q2": "boolean"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:boolean | Are George Stevens and Luc Besson American cinematographers: [answer q1:boolean | Is George Stevens an American cinematographer?] and [answer q2:boolean | Is Luc Besson an American cinematographer?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is George Stevens an American cinematographer?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Luc Besson an American cinematographer?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Are George Stevens and Luc Besson American cinematographers: {{q1}} and {{q2}}?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"boolean"}],"final":"q3"}
```

Manual review: pending.

## 25. 5add9bfa5542990dbb2f7e85 (bridge)

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the sponsor of the Premiership Rugby Sevens SeriesSeries?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What type of product is {{q1}}?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:work | What type of product is [answer q1:work | What is the sponsor of the Premiership Rugby Sevens SeriesSeries?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the sponsor of the Premiership Rugby Sevens SeriesSeries?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What type of product is {{q1}}?","dependencies":{"q1":"work"},"answer_type":"work"}],"final":"q2"}
```

Manual review: pending.

## 26. 5a75a0725542992d0ec05fc9 (bridge)

Disorganized Crime included what cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?

Structure: valid; root check: not_checked; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What cast member of Disorganized Crime is best known for playing Al Bundy on Married... with Children?",
      "dependencies": {},
      "answer_type": "person"
    }
  ],
  "final": "q1"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q1:person | What cast member of Disorganized Crime is best known for playing Al Bundy on Married... with Children?]

Root errors: []
Review errors: ["q1: changes the subject from Disorganized Crime to a cast member."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q1: changes the subject from Disorganized Crime to a cast member."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q1: changes the subject from Disorganized Crime to a cast member."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What cast member of Disorganized Crime is best known for playing Al Bundy on Married... with Children?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

Manual review: pending.

## 27. 5ac43e0f554299076e296d8e (comparison)

What country are both Dafeng District and Jixi in?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What country is Dafeng District in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What country is Jixi in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:place | What country are both Dafeng District (in [answer q1:place | What country is Dafeng District in?]) and Jixi (in [answer q2:place | What country is Jixi in?]) in?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What country is Dafeng District in?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What country is Jixi in?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?","dependencies":{"q1":"place","q2":"place"},"answer_type":"place"}],"final":"q3"}
```

Manual review: pending.

## 28. 5a8ea7f25542995085b37468 (comparison)

Are The Limousines and Faith No More from the same state?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What state is The Limousines from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What state is Faith No More from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Are The Limousines and Faith No More from the same state: {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:boolean | Are The Limousines and Faith No More from the same state: [answer q1:place | What state is The Limousines from?] or [answer q2:place | What state is Faith No More from?]?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What state is The Limousines from?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What state is Faith No More from?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Are The Limousines and Faith No More from the same state: {{q1}} or {{q2}}?","dependencies":{"q1":"place","q2":"place"},"answer_type":"boolean"}],"final":"q3"}
```

Manual review: pending.

## 29. 5a8701b3554299211dda2b9a (bridge)

Werner Christie served under the politician who was also Director-General of what other organization?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is Werner Christie's superior politician?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What organization was the {{q1}} Director-General of?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:organization | What organization was the [answer q1:person | Who is Werner Christie's superior politician?] Director-General of?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is Werner Christie's superior politician?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What organization was the {{q1}} Director-General of?","dependencies":{"q1":"person"},"answer_type":"organization"}],"final":"q2"}
```

Manual review: pending.

## 30. 5ac3dfee554299204fd21eab (bridge)

The man known as the voice of "Elgar" voices the English character in what Manga inspired by Keitaro Arima?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the voice actor of Elgar?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What manga is inspired by Keitaro Arima and features the English character voiced by {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:work | What manga is inspired by Keitaro Arima and features the English character voiced by [answer q1:person | Who is the voice actor of Elgar?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the voice actor of Elgar?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What manga is inspired by Keitaro Arima and features the English character voiced by {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual review: pending.

## 31. 5a7f7b3b5542992097ad2f81 (comparison)

Which restaurant chain's headquarters is further north, Pizza Inn or Papa Gino's?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Where is Pizza Inn's headquarters located?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "Where is Papa Gino's headquarters located?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at {{q1}}) or Papa Gino's (headquartered at {{q2}})?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q3:work | Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at [answer q1:place | Where is Pizza Inn's headquarters located?]) or Papa Gino's (headquartered at [answer q2:place | Where is Papa Gino's headquarters located?])?]

Root errors: []
Review errors: ["q3: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q3: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q3: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Where is Pizza Inn's headquarters located?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"Where is Papa Gino's headquarters located?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at {{q1}}) or Papa Gino's (headquartered at {{q2}})?","dependencies":{"q1":"place","q2":"place"},"answer_type":"work"}],"final":"q3"}
```

Manual review: pending.

## 32. 5ae3d2715542990afbd1e1e9 (comparison)

Are Control Room and Meeting Resistance both documentary films that involve Iraq?

Structure: invalid; root check: not_checked; review: not_reviewed (not_reviewed); model judgment: not_called.
Response handling: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Expanded typed tree (same representation sent to the judge if called):



Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
Plan must contain 1..4 nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
Plan must contain 1..4 nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

Manual review: pending.

## 33. 5ae077735542993d6555eb6d (bridge)

What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?

Structure: invalid; root check: not_checked; review: not_reviewed (not_reviewed); model judgment: not_called.
Response handling: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Expanded typed tree (same representation sent to the judge if called):



Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What type of sprite did Milada Šubrtová portray?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In which opera did Milada Šubrtová portray a sprite?","dependencies":{"q1":"work"},"answer_type":"other"}],"final":"q2"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In which opera did Milada Šubrtová portray a sprite?","dependencies":{"q1":"work"},"answer_type":"other"}],"final":"q1"}
```

Manual review: pending.

## 34. 5adf4b335542993a75d264a5 (bridge)

Paul DeBoy is known for an appearance in the Western action-adventure game developed by which company?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is Paul DeBoy known for?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "Which company developed the {{q1}}?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:organization | Which company developed the [answer q1:work | What is Paul DeBoy known for?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is Paul DeBoy known for?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"Which company developed the {{q1}}?","dependencies":{"q1":"work"},"answer_type":"organization"}],"final":"q2"}
```

Manual review: pending.

## 35. 5a776b82554299373536026f (bridge)

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the official currency of {{q1}}?",
      "dependencies": {
        "q1": "place"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:other | What is the official currency of [answer q1:place | What country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?]?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: dependency q1 expects place, but returns other.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the official currency of {{q1}}?","dependencies":{"q1":"place"},"answer_type":"other"}],"final":"q2"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the official currency of {{q1}}?","dependencies":{"q1":"place"},"answer_type":"other"}],"final":"q2"}
```

Manual review: pending.

## 36. 5ac0b1835542992a796ded65 (bridge)

Bordan Tkachuk was the former CEO of which company, which provides IT products?

Structure: valid; root check: compatible; review: valid (model); model judgment: valid.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What company did Bordan Tkachuk formerly lead that provides IT products?",
      "dependencies": {},
      "answer_type": "organization"
    }
  ],
  "final": "q1"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q1:organization | What company did Bordan Tkachuk formerly lead that provides IT products?]

Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What company did Bordan Tkachuk formerly lead that provides IT products?","dependencies":{},"answer_type":"organization"}],"final":"q1"}
```

Manual review: pending.

## 37. 5a80afcf554299485f5986b9 (bridge)

Who else beside the  American university administrator and politician from the state of Oklahoma was part of the  Boren-McCurdy proposals?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who were the American university administrators and politicians from Oklahoma involved in the Boren-Mcurdy proposals?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "Who else beside {{q1}} was part of the Boren-Mcurdy proposals?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "person"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:person | Who else beside [answer q1:person | Who were the American university administrators and politicians from Oklahoma involved in the Boren-Mcurdy proposals?] was part of the Boren-Mcurdy proposals?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who were the American university administrators and politicians from Oklahoma involved in the Boren-Mcurdy proposals?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Who else beside {{q1}} was part of the Boren-Mcurdy proposals?","dependencies":{"q1":"person"},"answer_type":"person"}],"final":"q2"}
```

Manual review: pending.

## 38. 5ae254565542992decbdccbb (bridge)

In what year was the writer of the drama "Ingenious" born?

Structure: valid; root check: compatible; review: revise (model); model judgment: revise.
Response handling: parsed; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who wrote the drama \"Ingenious\"?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "In what year was {{q1}} born?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:date | In what year was [answer q1:person | Who wrote the drama "Ingenious"?] born?]

Root errors: []
Review errors: ["q2: adds a relation absent from Question."]
Binding errors: []
Geographic precision errors: []
Original model errors: ["q2: adds a relation absent from Question."]
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who wrote the drama \"Ingenious\"?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year was {{q1}} born?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

Manual review: pending.

## 39. 5ae14b0655429920d52343a6 (bridge)

Bangalore Naatkal starred which actor and photographer?

Structure: invalid; root check: not_checked; review: not_reviewed (not_reviewed); model judgment: not_called.
Response handling: not_reviewed; semantic correctness: not evaluated.

```json
null
```

Expanded typed tree (same representation sent to the judge if called):



Root errors: []
Review errors: []
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: Decomposition remained structurally invalid after two attempts.

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q1: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q2"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

Manual review: pending.

## 40. 5ae409d955429970de88d89d (bridge)

Greetings! We're The Monitors was the debut album by the band who had what soul and R&B singer as their lead?

Structure: valid; root check: mismatch; review: revise (root_rule); model judgment: not_called.
Response handling: not_called; semantic correctness: not evaluated.

```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the lead singer of the band who had 'Greetings! We're The Monitors' as their debut album?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What soul and R&B singer is {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Expanded typed tree (same representation sent to the judge if called):

[answer q2:work | What soul and R&B singer is [answer q1:person | Who is the lead singer of the band who had 'Greetings! We're The Monitors' as their debut album?]?]

Root errors: ["q2: original target 'singer' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]
Review errors: ["q2: original target 'singer' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]
Binding errors: []
Geographic precision errors: []
Original model errors: []
Structure error: 

Reviewer format error kind: (none)

Raw model review (unmodified; no code-rule response is substituted):
```text
(not recorded / model not called)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the lead singer of the band who had 'Greetings! We're The Monitors' as their debut album?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What soul and R&B singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual review: pending.
