# Simple vs operadic decomposition

Compare FIRST outputs on equal calls, then inspect operadic structural repair separately.
No model judge, retrieval or final answering was run. No automatic semantic winner.
Both prompts request at most four items; simple output has no typed/tree validation or repair.
Inspect target, relations, constraints, necessary decomposition and redundant steps.
Formatting, item count and structural validity are not semantic accuracy.

## 1. 5ab3cecd5542992ade7c6eae

How do the Peter Laufer books Forbidden Creatures and No Animals Were Harmed differ in their focus on animals?

### simple: observed

FIRST output (original call):
```text
1. What are the main animal-related themes in "Forbidden Creatures"? 
2. How does "No Animals Were Harmed" explore animal themes compared to "Forbidden Creatures"?
3. Are there any specific animals or animal-related issues that are central to one book but not the other?
4. How do the authors' approaches to animal representation differ between these two works?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the focus of Forbidden Creatures on animals?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the focus of No Animals Were Harmed on animals?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"How do the Peter Laufer books Forbidden Creatures (focus on animals: {{q1}}) and No Animals Were Harmed (focus on animals: {{q2}}) differ in their focus on animals?","dependencies":{"q1":"other","q2":"other"},"answer_type":"other"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the focus of Forbidden Creatures on animals?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the focus of No Animals Were Harmed on animals?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"How do the Peter Laufer books Forbidden Creatures (focus on animals: {{q1}}) and No Animals Were Harmed (focus on animals: {{q2}}) differ in their focus on animals?","dependencies":{"q1":"other","q2":"other"},"answer_type":"other"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 2. 5ab42a2b5542996a3a969f5a

What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?

### simple: observed

FIRST output (original call):
```text
1. Who was the historic figure that participated in surveying the borders of the District of Columbia?
2. What is the name of the premier African American recreation center that was named after this historic figure?
```
First error: 

Manual semantic assessment: pending.

### operadic: invalid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is {{q1}} associated with a premier African American recreation center named after them?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is there a premier African American recreation center named after {{q1}}?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is {{q1}} associated with a premier African American recreation center named after them?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is there a premier African American recreation center named after {{q1}}?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 3. 5a7d3f895542995f4f402248

Pandora- The World of Avatar includes a ride that allows guest to take flight on what animal?

### simple: observed

FIRST output (original call):
```text
1. What animal is featured in the ride at Pandora- The World of Avatar?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What animal does the ride in Pandora- The World of Avatar allow guests to take flight on?","dependencies":{},"answer_type":"work"}],"final":"q1"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What animal does the ride in Pandora- The World of Avatar allow guests to take flight on?","dependencies":{},"answer_type":"work"}],"final":"q1"}
```

Manual semantic assessment: pending.

## 4. 5a778b345542992a6e59decf

Who was born first, Susan Oliver or W. S. Van Dyke?

### simple: observed

FIRST output (original call):
```text
1. When was Susan Oliver born?
2. When was W. S. Van Dyke born?
3. Who was born first between Susan Oliver and W. S. Van Dyke?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"When was Susan Oliver born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was W. S. Van Dyke born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Susan Oliver born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was W. S. Van Dyke born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 5. 5a8ceddb554299441c6b9f85

What profession does Nora Roberts and Elizabeth Hardwick have in common?

### simple: observed

FIRST output (original call):
```text
1. What is Nora Roberts' profession?
2. What is Elizabeth Hardwick's profession?
3. How are Nora Roberts and Elizabeth Hardwick's professions related?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Nora Roberts?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Elizabeth Hardwick?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"What profession do Nora Roberts ({{q1}}) and Elizabeth Hardwick ({{q2}}) have in common?","dependencies":{"q1":"work","q2":"work"},"answer_type":"work"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Nora Roberts?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Elizabeth Hardwick?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"What profession do Nora Roberts ({{q1}}) and Elizabeth Hardwick ({{q2}}) have in common?","dependencies":{"q1":"work","q2":"work"},"answer_type":"work"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 6. 5a7e05f75542995f4f402394

Which was released first, Hot Girls Wanted or China Blue?

### simple: observed

FIRST output (original call):
```text
1. When was the documentary Hot Girls Wanted released?
2. When was the documentary China Blue released?
3. Comparing the release dates of both documentaries, which one came first?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What was the release date of Hot Girls Wanted?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"What was the release date of China Blue?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What was the release date of Hot Girls Wanted?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"What was the release date of China Blue?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 7. 5ab3306a55429969a97a80fd

The movies The Boatniks and The Great Locomotive Chase were both made by which production company?

### simple: observed

FIRST output (original call):
```text
1. Which production company made the movie The Boatniks?
2. Which production company made the movie The Great Locomotive Chase?
3. Are the production companies that made The Boatniks and The Great Locomotive Chase the same?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What production company made The Boatniks?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What production company made The Great Locomotive Chase?","dependencies":{},"answer_type":"organization"},{"id":"q3","question":"The movies The Boatniks and The Great Locomotive Chase were both made by which production company: {{q1}} or {{q2}}?","dependencies":{"q1":"organization","q2":"organization"},"answer_type":"organization"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What production company made The Boatniks?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What production company made The Great Locomotive Chase?","dependencies":{},"answer_type":"organization"},{"id":"q3","question":"The movies The Boatniks and The Great Locomotive Chase were both made by which production company: {{q1}} or {{q2}}?","dependencies":{"q1":"organization","q2":"organization"},"answer_type":"organization"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 8. 5a7cfb2755429907fabef084

What year did the director of The Quiet American die?

### simple: observed

FIRST output (original call):
```text
1. When did the director of The Quiet American pass away?
2. Who directed the movie "The Quiet American"?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who directed The Quiet American?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year did {{q1}} die?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who directed The Quiet American?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year did {{q1}} die?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 9. 5ab201765542993be8fa98a4

Hobart Paving is a single by a band formed in which year ?

### simple: observed

FIRST output (original call):
```text
1. In what year was the band that released "Hobart Paving" formed?
2. What is the name of the band that released "Hobart Paving"?
3. When was "Hobart Paving" released?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the formation year of the band that released Hobart Paving?","dependencies":{},"answer_type":"date"}],"final":"q1"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the formation year of the band that released Hobart Paving?","dependencies":{},"answer_type":"date"}],"final":"q1"}
```

Manual semantic assessment: pending.

## 10. 5adbe27c55429947ff173854

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

### simple: observed

FIRST output (original call):
```text
1. How many campuses does Dalhousie University have?
2. How many campuses does California State Polytechnic University, Pomona have?
3. Which university has more campuses based on the number of campuses from steps 1 and 2?
4. (If necessary) Where are the campuses of each university located?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"How many campuses does Dalhousie University have?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"How many campuses does California State Polytechnic University, Pomona have?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which university has more campuses, Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"organization"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"How many campuses does Dalhousie University have?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"How many campuses does California State Polytechnic University, Pomona have?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which university has more campuses, Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"organization"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 11. 5a8fa4d95542995b4424207b

Which airport is busier, Palm Springs International Airport or Trenton–Mercer Airport?

### simple: observed

FIRST output (original call):
```text
1. How many passengers used Palm Springs International Airport in the latest available year?
2. How many passengers used Trenton–Mercer Airport in the latest available year?
3. Which airport had a higher number of passenger arrivals and departures in the latest available year?
4. Are there any recent changes in passenger numbers that might affect the current ranking of these airports?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the passenger throughput of Palm Springs International Airport?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the passenger throughput of Trenton–Mercer Airport?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which airport is busier, Palm Springs International Airport (with throughput {{q1}}) or Trenton–Mercer Airport (with throughput {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the passenger throughput of Palm Springs International Airport?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the passenger throughput of Trenton–Mercer Airport?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which airport is busier, Palm Springs International Airport (with throughput {{q1}}) or Trenton–Mercer Airport (with throughput {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 12. 5ac19ff35542991316484b61

Which was published or broadcast first, The Graveyard Book of Phineas and Ferb?

### simple: observed

FIRST output (original call):
```text
1. When was The Graveyard Book published?
2. When did the series Phineas and Ferb first air?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"When was The Graveyard Book published?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Phineas and Ferb broadcasted?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was The Graveyard Book published?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Phineas and Ferb broadcasted?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 13. 5ab484415542990594ba9c44

Which facility was founded in Missouri, Discovery Zone or Valentino's?

### simple: observed

FIRST output (original call):
```text
1. Where is Discovery Zone located?
2. Where is Valentino's located?
3. In which year was Discovery Zone founded?
4. In which year was Valentino's founded?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"When was Discovery Zone founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Valentino's founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which facility was founded in Missouri: Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Discovery Zone founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Valentino's founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which facility was founded in Missouri: Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 14. 5abbd34d5542993f40c73bc6

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

### simple: observed

FIRST output (original call):
```text
1. Which river is located southeast of the Innviertel?
2. How many kilometers long is this river?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Which river is southeast of the Innviertel?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?","dependencies":{"q1":"other"},"answer_type":"number"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which river is southeast of the Innviertel?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?","dependencies":{"q1":"other"},"answer_type":"number"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 15. 5abce1fa5542993a06baf993

What nationality was the lover of Lord Alfred Douglas ? 

### simple: observed

FIRST output (original call):
```text
1. Who is Lord Alfred Douglas? 
2. Who was Lord Alfred Douglas's lover?
3. What nationality was this lover?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What nationality was Lord Alfred Douglas?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{"q1":"place"},"answer_type":"person"},{"id":"q3","question":"What nationality was {{q2}}?","dependencies":{"q2":"person"},"answer_type":"place"}],"final":"q3"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What nationality was {{q1}}?","dependencies":{"q1":"person"},"answer_type":"place"}],"final":"q2"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What nationality was Lord Alfred Douglas?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{"q1":"place"},"answer_type":"person"},{"id":"q3","question":"What nationality was {{q2}}?","dependencies":{"q2":"person"},"answer_type":"place"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What nationality was {{q1}}?","dependencies":{"q1":"person"},"answer_type":"place"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 16. 5a77a7db5542995d8318124d

Which author was born first, Josephine Tey or Julia Peterkin?

### simple: observed

FIRST output (original call):
```text
1. When was Josephine Tey born?
2. When was Julia Peterkin born?
3. Who was born first between Josephine Tey and Julia Peterkin?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"When was Josephine Tey born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Julia Peterkin born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Josephine Tey born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Julia Peterkin born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 17. 5abe94fd55429965af743f37

Were both Sinclair Research and the Wave Mate Bullet founded in the 1970s?

### simple: observed

FIRST output (original call):
```text
1. When was Sinclair Research founded?
2. When was the Wave Mate Bullet founded?
3. Did both companies start operations in the 1970s?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"When was Sinclair Research founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was the Wave Mate Bullet founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?","dependencies":{"q1":"date","q2":"date"},"answer_type":"boolean"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Sinclair Research founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was the Wave Mate Bullet founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?","dependencies":{"q1":"date","q2":"date"},"answer_type":"boolean"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 18. 5a7d598d5542995f4f402262

Which director was also a film editor, Burton L. King or Maheen Zia?

### simple: observed

FIRST output (original call):
```text
1. What films did Burton L. King edit?
2. What films did Maheen Zia direct?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What works did Burton L. King direct?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What works did Maheen Zia direct?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Was Burton L. King also a film editor?","dependencies":{"q1":"work"},"answer_type":"boolean"},{"id":"q4","question":"Was Maheen Zia also a film editor?","dependencies":{"q2":"work"},"answer_type":"boolean"},{"id":"q5","question":"Which director was also a film editor, Burton L. King ({{q3}}) or Maheen Zia ({{q4}})?","dependencies":{"q3":"boolean","q4":"boolean"},"answer_type":"person"}],"final":"q5"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Did Burton L. King edit films?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Did Maheen Zia edit films?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which director was also a film editor, Burton L. King ({{q1}}) or Maheen Zia ({{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
Plan must contain 1..4 nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What works did Burton L. King direct?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What works did Maheen Zia direct?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Was Burton L. King also a film editor?","dependencies":{"q1":"work"},"answer_type":"boolean"},{"id":"q4","question":"Was Maheen Zia also a film editor?","dependencies":{"q2":"work"},"answer_type":"boolean"},{"id":"q5","question":"Which director was also a film editor, Burton L. King ({{q3}}) or Maheen Zia ({{q4}})?","dependencies":{"q3":"boolean","q4":"boolean"},"answer_type":"person"}],"final":"q5"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Did Burton L. King edit films?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Did Maheen Zia edit films?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which director was also a film editor, Burton L. King ({{q1}}) or Maheen Zia ({{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 19. 5ae73ddb554299572ea5478d

Hoy Es Manana is by what Mexican Actress and singer, who is the current First Lady of Chiapas State, Mexico?

### simple: observed

FIRST output (original call):
```text
1
Who is the Mexican actress and singer that performs "Hoy Es Manana"?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who is the current First Lady of Chiapas State, Mexico?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What Mexican Actress and singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the current First Lady of Chiapas State, Mexico?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What Mexican Actress and singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 20. 5ade5a645542997c77adee0d

Which city is at coastal county-level, Wenling or Ruili?

### simple: observed

FIRST output (original call):
```text
1. Where is Wenling located?
2. Is Wenling a coastal city?
3. Where is Ruili located?
4. Is Ruili a coastal city?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"city"}],"final":"q3"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"place"}],"final":"q3"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: answer_type must be one of ['boolean', 'date', 'number', 'organization', 'other', 'person', 'place', 'work'].
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"city"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"place"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 21. 5a87bc3f5542996432c57275

Which is located farther West, the Cascade Locks and Canal or Lake Worth Lagoon?

### simple: observed

FIRST output (original call):
```text
1. Where is the Cascade Locks and Canal located?
2. Where is Lake Worth Lagoon located?
3. How do the longitudes of these two locations compare?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the longitude of Cascade Locks and Canal?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the longitude of Lake Worth Lagoon?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which location is farther West: Cascade Locks and Canal (longitude {{q1}}) or Lake Worth Lagoon (longitude {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the longitude of Cascade Locks and Canal?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the longitude of Lake Worth Lagoon?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which location is farther West: Cascade Locks and Canal (longitude {{q1}}) or Lake Worth Lagoon (longitude {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 22. 5ae38b115542990afbd1e183

Who played a more important role in the church George Albert Smith or Wong Jing?

### simple: observed

FIRST output (original call):
```text
1. What was George Albert Smith's role in the church?
2. What was Wong Jing's role in the church?
3. How are these roles compared in terms of importance within the church structure?
4. Are there any historical events or documents that highlight the relative importance of these roles?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What role did George Albert Smith play in the church?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What role did Wong Jing play in the church?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?","dependencies":{"q1":"work","q2":"work"},"answer_type":"person"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What role did George Albert Smith play in the church?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What role did Wong Jing play in the church?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?","dependencies":{"q1":"work","q2":"work"},"answer_type":"person"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 23. 5a89bf18554299669944a591

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

### simple: observed

FIRST output (original call):
```text
1. What is John O'Hara's nationality?
2. What is Bobbie Ann Mason's nationality?
3. Are John O'Hara and Bobbie Ann Mason of the same nationality?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the nationality of John O'Hara?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the nationality of Bobbie Ann Mason?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"Do writers John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?","dependencies":{"q1":"other","q2":"other"},"answer_type":"boolean"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the nationality of John O'Hara?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the nationality of Bobbie Ann Mason?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"Do writers John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?","dependencies":{"q1":"other","q2":"other"},"answer_type":"boolean"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 24. 5ae0a5825542993d6555ebdf

Are George Stevens and Luc Besson American cinematographers?

### simple: observed

FIRST output (original call):
```text
1. What is George Stevens's nationality?
2. What is Luc Besson's nationality?
3. Are cinematographers typically known for their nationality or for their profession?
4. Can someone be considered an American cinematographer if they are not American by nationality?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Is George Stevens American?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Luc Besson American?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Are George Stevens and Luc Besson American cinematographers? ({{q1}} and {{q2}})","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"boolean"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is George Stevens American?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Luc Besson American?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Are George Stevens and Luc Besson American cinematographers? ({{q1}} and {{q2}})","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"boolean"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 25. 5add9bfa5542990dbb2f7e85

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

### simple: observed

FIRST output (original call):
```text
1 What is the name of the sponsor of the Premiership Rugby Sevens Series?
2 What type of product does this sponsor produce?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who is the sponsor of the Premiership Rugby Sevens Series?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What type of product does {{q1}} produce?","dependencies":{"q1":"organization"},"answer_type":"work"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the sponsor of the Premiership Rugby Sevens Series?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What type of product does {{q1}} produce?","dependencies":{"q1":"organization"},"answer_type":"work"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 26. 5a75a0725542992d0ec05fc9

Disorganized Crime included what cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?

### simple: observed

FIRST output (original call):
```text
1
Who is the cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

Manual semantic assessment: pending.

## 27. 5ac43e0f554299076e296d8e

What country are both Dafeng District and Jixi in?

### simple: observed

FIRST output (original call):
```text
1. In which country is Dafeng District located?
2. In which country is Jixi located?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What country is Dafeng District in?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What country is Jixi in?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?","dependencies":{"q1":"place","q2":"place"},"answer_type":"place"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What country is Dafeng District in?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What country is Jixi in?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?","dependencies":{"q1":"place","q2":"place"},"answer_type":"place"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 28. 5a8ea7f25542995085b37468

Are The Limousines and Faith No More from the same state?

### simple: observed

FIRST output (original call):
```text
1. Where is The Limousines from?
2. Where is Faith No More from?
3. Are these two states the same?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What state is The Limousines from?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What state is Faith No More from?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Are The Limousines and Faith No More from the same state: {{q1}} = {{q2}}?","dependencies":{"q1":"place","q2":"place"},"answer_type":"boolean"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What state is The Limousines from?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What state is Faith No More from?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Are The Limousines and Faith No More from the same state: {{q1}} = {{q2}}?","dependencies":{"q1":"place","q2":"place"},"answer_type":"boolean"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 29. 5a8701b3554299211dda2b9a

Werner Christie served under the politician who was also Director-General of what other organization?

### simple: observed

FIRST output (original call):
```text
1. Who is Werner Christie?
2. Under which politician did Werner Christie serve?
3. What organization had a Director-General who Werner Christie's superior also served under?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who was the politician that Werner Christie served under?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What organization was the politician ({{q1}}) also the Director-General of?","dependencies":{"q1":"person"},"answer_type":"organization"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who was the politician that Werner Christie served under?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What organization was the politician ({{q1}}) also the Director-General of?","dependencies":{"q1":"person"},"answer_type":"organization"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 30. 5ac3dfee554299204fd21eab

The man known as the voice of "Elgar" voices the English character in what Manga inspired by Keitaro Arima?

### simple: observed

FIRST output (original call):
```text
1. Who is the man known as the voice of "Elgar"? 
2. In which Manga does this man voice an English character?
3. Who is Keitaro Arima and what is his connection to the mentioned Manga?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who is the voice actor of Elgar?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What manga is inspired by Keitaro Arima and features the English character voiced by {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the voice actor of Elgar?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What manga is inspired by Keitaro Arima and features the English character voiced by {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 31. 5a7f7b3b5542992097ad2f81

Which restaurant chain's headquarters is further north, Pizza Inn or Papa Gino's?

### simple: observed

FIRST output (original call):
```text
1. Where is Pizza Inn's headquarters located?
2. Where is Papa Gino's headquarters located?
3. Which of the two locations is further north?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the headquarters location of Pizza Inn?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the headquarters location of Papa Gino's?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Which restaurant chain's headquarters is further north, Pizza Inn (located at {{q1}}) or Papa Gino's (located at {{q2}})?","dependencies":{"q1":"place","q2":"place"},"answer_type":"work"}],"final":"q3"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the headquarters location of Pizza Inn?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the headquarters location of Papa Gino's?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Which restaurant chain's headquarters is further north, Pizza Inn (located at {{q1}}) or Papa Gino's (located at {{q2}})?","dependencies":{"q1":"place","q2":"place"},"answer_type":"work"}],"final":"q3"}
```

Manual semantic assessment: pending.

## 32. 5ae3d2715542990afbd1e1e9

Are Control Room and Meeting Resistance both documentary films that involve Iraq?

### simple: observed

FIRST output (original call):
```text
1. What is the subject matter of Control Room?
2. Which country is featured prominently in Meeting Resistance?
3. Does Control Room focus on any events or issues related to Iraq?
4. Is Meeting Resistance a documentary film about Iraq?
```
First error: 

Manual semantic assessment: pending.

### operadic: invalid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
Plan must contain 1..4 nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
Plan must contain 1..4 nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are Control Room and Meeting Resistance both documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

Manual semantic assessment: pending.

## 33. 5ae077735542993d6555eb6d

What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?

### simple: observed

FIRST output (original call):
```text
1 What is the name of Antonín Dvořák's renowned opera?
2 Who was Milada Šubrtová in the context of this opera?
3 What specific character did Milada Šubrtová portray that involves a sprite?
4 What type of sprite character was this in the opera?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What type of sprite did Milada Šubrtová portray?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In which opera did {{q1}} appear?","dependencies":{"q1":"work"},"answer_type":"work"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What type of sprite did Milada Šubrtová portray?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In which opera did {{q1}} appear?","dependencies":{"q1":"work"},"answer_type":"work"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 34. 5adf4b335542993a75d264a5

Paul DeBoy is known for an appearance in the Western action-adventure game developed by which company?

### simple: observed

FIRST output (original call):
```text
1. Who is Paul DeBoy?
2. In which Western action-adventure game did Paul DeBoy appear?
3. Which company developed the game where Paul DeBoy appeared?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the name of the Western action-adventure game Paul DeBoy appeared in?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"Which company developed {{q1}}?","dependencies":{"q1":"work"},"answer_type":"organization"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the name of the Western action-adventure game Paul DeBoy appeared in?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"Which company developed {{q1}}?","dependencies":{"q1":"work"},"answer_type":"organization"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 35. 5a776b82554299373536026f

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

### simple: observed

FIRST output (original call):
```text
1. Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?
2. What is the official currency of that country?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"}],"final":"q1"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the official currency in {{q1}}?","dependencies":{"q1":"place"},"answer_type":"other"}],"final":"q2"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"}],"final":"q1"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the official currency in {{q1}}?","dependencies":{"q1":"place"},"answer_type":"other"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 36. 5ac0b1835542992a796ded65

Bordan Tkachuk was the former CEO of which company, which provides IT products?

### simple: observed

FIRST output (original call):
```text
1. Who is Bordan Tkachuk?
2. What company did Bordan Tkachuk formerly lead as CEO?
3. What type of products does this company provide?
4. In what industry is this company active?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"Does {{q1}} provide IT products?","dependencies":{"q1":"organization"},"answer_type":"boolean"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"Does {{q1}} provide IT products?","dependencies":{"q1":"organization"},"answer_type":"boolean"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 37. 5a80afcf554299485f5986b9

Who else beside the  American university administrator and politician from the state of Oklahoma was part of the  Boren-McCurdy proposals?

### simple: observed

FIRST output (original call):
```text
1. Who are the Boren-McCurdy proposals named after?
2. What were the main components of the Boren-McCurdy proposals?
3. Besides the American university administrator and politician from Oklahoma, who else was involved in proposing these measures?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who were the American university administrators and politicians from Oklahoma involved in the Boren-Mcurdy proposals?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Who else besides {{q1}} was part of the Boren-Mcurdy proposals?","dependencies":{"q1":"person"},"answer_type":"person"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who were the American university administrators and politicians from Oklahoma involved in the Boren-Mcurdy proposals?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Who else besides {{q1}} was part of the Boren-Mcurdy proposals?","dependencies":{"q1":"person"},"answer_type":"person"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 38. 5ae254565542992decbdccbb

In what year was the writer of the drama "Ingenious" born?

### simple: observed

FIRST output (original call):
```text
1. When was the author of "Ingenious" born?
2. What is the name of the writer of the drama "Ingenious"?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who wrote the drama \"Ingenious\"?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year was {{q1}} born?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who wrote the drama \"Ingenious\"?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year was {{q1}} born?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

Manual semantic assessment: pending.

## 39. 5ae14b0655429920d52343a6

Bangalore Naatkal starred which actor and photographer?

### simple: observed

FIRST output (original call):
```text
1. Which actor starred in Bangalore Naatkal?
2. Who was the photographer for Bangalore Naatkal?
```
First error: 

Manual semantic assessment: pending.

### operadic: invalid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```
First error: 

Additional call: phase attempt 1, call 2
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```
Error: 

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

Manual semantic assessment: pending.

## 40. 5ae409d955429970de88d89d

Greetings! We're The Monitors was the debut album by the band who had what soul and R&B singer as their lead?

### simple: observed

FIRST output (original call):
```text
1
Who is the lead singer of the band that released "Greetings! We're The Monitors"?
```
First error: 

Manual semantic assessment: pending.

### operadic: valid

FIRST output (original call):
```text
{"nodes":[{"id":"q1","question":"Who is the lead singer of the band that released 'Greetings! We're The Monitors'?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What soul and R&B singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```
First error: 

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the lead singer of the band that released 'Greetings! We're The Monitors'?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What soul and R&B singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

Manual semantic assessment: pending.
