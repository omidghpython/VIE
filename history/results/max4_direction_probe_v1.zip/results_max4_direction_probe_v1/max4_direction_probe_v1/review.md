# Direction probe: paired first outputs

Five development cases; no automatic semantic winner, judge, repair or RAG.
Direction, final target, units and all qualifiers need manual review.

## 1. 5abbd34d5542993f40c73bc6

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Manual reference (not sent to either model call): Innviertel is southeast of the unknown river; preserve km length target.

### baseline

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"Which river is southeast of the Innviertel?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?","dependencies":{"q1":"other"},"answer_type":"number"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:number | How long is the river southeast of the Innviertel? ([answer q1:other | Which river is southeast of the Innviertel?]) in kilometers?]
Manual direction/target/qualifiers/decomposition review: pending.

### direction_template

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"How long is the river southeast of which the Innviertel is located?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The Innviertel is a traditional Austrian region southeast of a river that is {{q1}} km long.","dependencies":{"q1":"number"},"answer_type":"other"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:other | The Innviertel is a traditional Austrian region southeast of a river that is [answer q1:number | How long is the river southeast of which the Innviertel is located?] km long.]
Manual direction/target/qualifiers/decomposition review: pending.

## 2. synthetic_direction_1

The district of Velora lies northeast of a lake that covers how many square kilometers?

Manual reference (not sent to either model call): Velora northeast of unknown lake; target lake area in square kilometers.

### baseline

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"How many square kilometers does the lake cover?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The district of Velora lies northeast of a lake that covers {{q1}} square kilometers.","dependencies":{"q1":"number"},"answer_type":"other"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:other | The district of Velora lies northeast of a lake that covers [answer q1:number | How many square kilometers does the lake cover?] square kilometers.]
Manual direction/target/qualifiers/decomposition review: pending.

### direction_template

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"How many square kilometers does the lake cover?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The district of Velora lies northeast of a lake (which covers {{q1}} square kilometers). Is this true?","dependencies":{"q1":"number"},"answer_type":"boolean"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:boolean | The district of Velora lies northeast of a lake (which covers [answer q1:number | How many square kilometers does the lake cover?] square kilometers). Is this true?]
Manual direction/target/qualifiers/decomposition review: pending.

## 3. synthetic_direction_2

A lake northeast of the district of Velora covers how many square kilometers?

Manual reference (not sent to either model call): Unknown lake northeast of Velora; target lake area in square kilometers.

### baseline

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"What is the size in square kilometers of the lake northeast of Velora's district?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"Which lake is northeast of Velora's district?","dependencies":{},"answer_type":"work"}],"final":"q1"}
```

Structure: invalid
Structure error: q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
Expanded tree: 
Manual direction/target/qualifiers/decomposition review: pending.

### direction_template

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"Which lake is northeast of the district of Velora?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"How many square kilometers does {{q1}} cover?","dependencies":{"q1":"place"},"answer_type":"number"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:number | How many square kilometers does [answer q1:place | Which lake is northeast of the district of Velora?] cover?]
Manual direction/target/qualifiers/decomposition review: pending.

## 4. synthetic_direction_3

The town of Merovin is west of a mountain that is how many meters high?

Manual reference (not sent to either model call): Merovin west of unknown mountain; target mountain height in meters.

### baseline

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"How many meters high is the mountain that Merovin is west of?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The town of Merovin is west of a mountain that is {{q1}} meters high.","dependencies":{"q1":"number"},"answer_type":"other"}],"final":"q1"}
```

Structure: invalid
Structure error: final must be the root and cannot be consumed by another node.
Expanded tree: 
Manual direction/target/qualifiers/decomposition review: pending.

### direction_template

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"How high is the mountain that Merovin is west of?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"The town of Merovin is west of a mountain that is {{q1}} meters high.","dependencies":{"q1":"number"},"answer_type":"other"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:other | The town of Merovin is west of a mountain that is [answer q1:number | How high is the mountain that Merovin is west of?] meters high.]
Manual direction/target/qualifiers/decomposition review: pending.

## 5. synthetic_direction_4

A mountain west of the town of Merovin is how many meters high?

Manual reference (not sent to either model call): Unknown mountain west of Merovin; target mountain height in meters.

### baseline

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"What is the height of a mountain west of the town of Merovin in meters?","dependencies":{},"answer_type":"number"}],"final":"q1"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q1:number | What is the height of a mountain west of the town of Merovin in meters?]
Manual direction/target/qualifiers/decomposition review: pending.

### direction_template

Phase: observed
Runtime error: 
```text
{"nodes":[{"id":"q1","question":"Which mountain is west of the town of Merovin?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"How many meters high is {{q1}}?","dependencies":{"q1":"place"},"answer_type":"number"}],"final":"q2"}
```

Structure: valid
Structure error: 
Expanded tree: [answer q2:number | How many meters high is [answer q1:place | Which mountain is west of the town of Merovin?]?]
Manual direction/target/qualifiers/decomposition review: pending.
