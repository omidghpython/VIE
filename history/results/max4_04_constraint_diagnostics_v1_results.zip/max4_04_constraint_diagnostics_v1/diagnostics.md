# Advisory diagnostics

No automatic rejection, repair, gold answers, or model calls. Unknown patterns abstain.

no_violation_found covers supported checks only; it is not semantic validity.

## 1. 5ab3cecd5542992ade7c6eae: unknown

How do the Peter Laufer books Forbidden Creatures and No Animals Were Harmed differ in their focus on animals?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 2. 5ab42a2b5542996a3a969f5a: unknown

What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?

No structurally valid plan: Plan must contain exactly nodes and final.

## 3. 5a7d3f895542995f4f402248: unknown

Pandora- The World of Avatar includes a ride that allows guest to take flight on what animal?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 4. 5a778b345542992a6e59decf: unknown

Who was born first, Susan Oliver or W. S. Van Dyke?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 5. 5a8ceddb554299441c6b9f85: unknown

What profession does Nora Roberts and Elizabeth Hardwick have in common?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 6. 5a7e05f75542995f4f402394: unknown

Which was released first, Hot Girls Wanted or China Blue?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 7. 5ab3306a55429969a97a80fd: unknown

The movies The Boatniks and The Great Locomotive Chase were both made by which production company?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 8. 5a7cfb2755429907fabef084: unknown

What year did the director of The Quiet American die?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 9. 5ab201765542993be8fa98a4: unknown

Hobart Paving is a single by a band formed in which year ?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 10. 5adbe27c55429947ff173854: unknown

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 11. 5a8fa4d95542995b4424207b: unknown

Which airport is busier, Palm Springs International Airport or Trenton–Mercer Airport?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 12. 5ac19ff35542991316484b61: unknown

Which was published or broadcast first, The Graveyard Book of Phineas and Ferb?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 13. 5ab484415542990594ba9c44: unknown

Which facility was founded in Missouri, Discovery Zone or Valentino's?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 14. 5abbd34d5542993f40c73bc6: unknown

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 15. 5abce1fa5542993a06baf993: unknown

What nationality was the lover of Lord Alfred Douglas ? 

Advisory pattern checks only; no assertion of complete semantic correctness.

## 16. 5a77a7db5542995d8318124d: unknown

Which author was born first, Josephine Tey or Julia Peterkin?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 17. 5abe94fd55429965af743f37: unknown

Were both Sinclair Research and the Wave Mate Bullet founded in the 1970s?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 18. 5a7d598d5542995f4f402262: unknown

Which director was also a film editor, Burton L. King or Maheen Zia?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 19. 5ae73ddb554299572ea5478d: suspicious

Hoy Es Manana is by what Mexican Actress and singer, who is the current First Lady of Chiapas State, Mexico?

- title_not_found_literally (): The source title has no literal normalized occurrence in any node; aliases need manual review. Evidence: {'title': 'Hoy Es Manana'}

## 20. 5ade5a645542997c77adee0d: unknown

Which city is at coastal county-level, Wenling or Ruili?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 21. 5a87bc3f5542996432c57275: unknown

Which is located farther West, the Cascade Locks and Canal or Lake Worth Lagoon?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 22. 5ae38b115542990afbd1e183: unknown

Who played a more important role in the church George Albert Smith or Wong Jing?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 23. 5a89bf18554299669944a591: unknown

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 24. 5ae0a5825542993d6555ebdf: suspicious

Are George Stevens and Luc Besson American cinematographers?

- entity_qualifier_not_established (q1): This subject-specific branch omits part of the joint property. A negative conjunct may still suffice for no; inspect evidence. Evidence: {'entity': 'George Stevens', 'required': ['American', 'cinematographer'], 'missing': ['cinematographer']}
- entity_qualifier_not_established (q2): This subject-specific branch omits part of the joint property. A negative conjunct may still suffice for no; inspect evidence. Evidence: {'entity': 'Luc Besson', 'required': ['American', 'cinematographer'], 'missing': ['cinematographer']}

## 25. 5add9bfa5542990dbb2f7e85: unknown

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

Advisory pattern checks only; no assertion of complete semantic correctness.

## 26. 5a75a0725542992d0ec05fc9: no_violation_found

Disorganized Crime included what cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 27. 5ac43e0f554299076e296d8e: unknown

What country are both Dafeng District and Jixi in?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 28. 5a8ea7f25542995085b37468: unknown

Are The Limousines and Faith No More from the same state?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 29. 5a8701b3554299211dda2b9a: unknown

Werner Christie served under the politician who was also Director-General of what other organization?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 30. 5ac3dfee554299204fd21eab: no_violation_found

The man known as the voice of "Elgar" voices the English character in what Manga inspired by Keitaro Arima?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 31. 5a7f7b3b5542992097ad2f81: unknown

Which restaurant chain's headquarters is further north, Pizza Inn or Papa Gino's?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 32. 5ae3d2715542990afbd1e1e9: unknown

Are Control Room and Meeting Resistance both documentary films that involve Iraq?

No structurally valid plan: Plan must contain exactly nodes and final.

## 33. 5ae077735542993d6555eb6d: unknown

What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 34. 5adf4b335542993a75d264a5: unknown

Paul DeBoy is known for an appearance in the Western action-adventure game developed by which company?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 35. 5a776b82554299373536026f: unknown

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 36. 5ac0b1835542992a796ded65: unknown

Bordan Tkachuk was the former CEO of which company, which provides IT products?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 37. 5a80afcf554299485f5986b9: suspicious

Who else beside the  American university administrator and politician from the state of Oklahoma was part of the  Boren-McCurdy proposals?

- excluded_single_person_became_group (q1): A singular excluded-person description became a plural lookup. Evidence: {'descriptor': 'american university administrator and politician from the state of oklahoma'}

## 38. 5ae254565542992decbdccbb: no_violation_found

In what year was the writer of the drama "Ingenious" born?

Advisory pattern checks only; no assertion of complete semantic correctness.

## 39. 5ae14b0655429920d52343a6: unknown

Bangalore Naatkal starred which actor and photographer?

No structurally valid plan: Plan must contain exactly nodes and final.

## 40. 5ae409d955429970de88d89d: unknown

Greetings! We're The Monitors was the debut album by the band who had what soul and R&B singer as their lead?

Advisory pattern checks only; no assertion of complete semantic correctness.
