# Saved-tree reviewer comparison v3.2.5

Old trees and old verdicts are preserved. Only Question and the expanded tree reach the new judge.
Status changes are not proof of correctness; a specific reason may still be wrong.
Audit annotations describe a selected development subset, not independent test accuracy.

```json
{
  "mode": "review_saved_trees_only",
  "source_sha256": "5707dddabe2ea73cc7b836da942b6872db3ce8f6d46946fd244c122a98707749",
  "source_version": "v3.2.4",
  "requested": 40,
  "eligible_saved_trees": 35,
  "source_structurally_invalid": 5,
  "incomplete_questions": 0,
  "new_status": {
    "revise": 32,
    "source_structure_invalid": 5,
    "valid": 3
  },
  "response_status": {
    "parsed": 32,
    "not_called": 3
  },
  "review_source": {
    "model": 32,
    "root_rule": 3
  },
  "old_to_new_status": {
    "revise -> revise": 24,
    "not_reviewed -> source_structure_invalid": 5,
    "valid -> valid": 3,
    "valid -> revise": 8
  },
  "new_experiment_cost": {
    "llm_calls": 32,
    "prompt_tokens": 13425,
    "completion_tokens": 981,
    "total_tokens": 14406,
    "execution_time_sec": 136.26579419999996,
    "retrieval_steps": 0
  },
  "historical_generation_cost": {
    "llm_calls": 49,
    "prompt_tokens": 31171,
    "completion_tokens": 4964,
    "total_tokens": 36135,
    "execution_time_sec": 565.9271314999997,
    "retrieval_steps": 0
  },
  "historical_review_cost": {
    "llm_calls": 32,
    "prompt_tokens": 12753,
    "completion_tokens": 621,
    "total_tokens": 13374,
    "execution_time_sec": 73.82741800000014,
    "retrieval_steps": 0
  },
  "generation_plus_replacement_review_estimate": {
    "llm_calls": 81,
    "prompt_tokens": 44596,
    "completion_tokens": 5945,
    "total_tokens": 50541,
    "execution_time_sec": 702.1929256999997,
    "retrieval_steps": 0
  },
  "all_experiments_including_old_review_cost": {
    "llm_calls": 113,
    "prompt_tokens": 57349,
    "completion_tokens": 6566,
    "total_tokens": 63915,
    "execution_time_sec": 776.0203436999998,
    "retrieval_steps": 0
  },
  "review_tokens_difference_if_complete": 1032,
  "cost_note": "All failed/interrupted/retried calls included. Cached generation is historical cost, not free production planning. Replacement estimate excludes superseded old review; all-experiment total includes it. Compare review costs only when all 35 eligible trees are processed. The 5 invalid source trees remain in the cohort and cost.",
  "runtime_matches_source": true,
  "runtime_identity": {
    "qwen_revision": "a09a35458c702b33eeacc393d103063234e8bc28",
    "packages": {
      "torch": "2.11.0+cu128",
      "transformers": "4.57.6",
      "accelerate": "1.15.0",
      "bitsandbytes": "0.50.2"
    },
    "backend": "LocalQwen"
  },
  "inference_backend": "LocalQwen",
  "new_tree_generation_calls": 0,
  "semantic_repair_calls": 0,
  "whole_method_token_condition": {
    "criterion": "Whole decomposed RAG must use strictly fewer input + output tokens than Standard RAG",
    "pilot_tokens": 50541,
    "full_decomposed_tokens": null,
    "full_token_condition_met": null,
    "status": "pilot_below_reference_full_savings_not_established",
    "note": "Historical A reference only. Pilot omits retrieval/answering and semantic repair. Being below A here is necessary, not sufficient; use a full paired run to decide. No questions, evidence or failed attempts are removed to reduce reported cost.",
    "standard_reference_tokens": 54222,
    "standard_reference_status": {
      "completed": 39,
      "failed": 1
    },
    "reference_source": "Observed Standard RAG v3.2; historical reference, not a new paired run.",
    "remaining_tokens_below_historical_standard": 3680,
    "scope": "Historical generation plus new review only; not a new full decomposed RAG run."
  },
  "semantic_correctness_measured": false,
  "answer_accuracy_measured": false,
  "selected_development_audit": {
    "scope": "Analyst-annotated development subset: 6 clear composed chains and 4 specific defects, selected from v3.2.4 before the new run. Not independent human gold or an unbiased accuracy estimate. Annotations and old judgments are NEVER sent to the model. Inspect reason correctness manually; decision agreement alone is insufficient.",
    "decision_counts": {
      "old": {
        "valid": {
          "revise": 6
        },
        "revise": {
          "revise": 4
        }
      },
      "new": {
        "valid": {
          "revise": 6
        },
        "revise": {
          "revise": 4
        }
      }
    },
    "cases": [
      {
        "index": 8,
        "question_id": "5a7cfb2755429907fabef084",
        "plan_sha256": "e0e2ebaf75940e649c4dda73961fcc83032c6e5832621c77dbd0b5bd6c1797c9",
        "expected_status": "valid",
        "rationale": "q1 identifies the director; q2 asks their death year. date includes a year.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: person vs date"
        ]
      },
      {
        "index": 10,
        "question_id": "5adbe27c55429947ff173854",
        "plan_sha256": "eb76f1135d19efa0fa159368bba84e755a2e8e32ed165e941f2bf414731757b2",
        "expected_status": "valid",
        "rationale": "Each leaf counts one university; q3 compares the counts and keeps the university names.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: number of campuses for Dalhousie University vs number of campuses for California State Polytechnic University, Pomona"
        ]
      },
      {
        "index": 13,
        "question_id": "5ab484415542990594ba9c44",
        "plan_sha256": "fd8d6f6f600aa2e94f8e09fbc326beafa2c2c6ffafa6faf0ad6fd2472fadb42e",
        "expected_status": "revise",
        "rationale": "q1/q2 ask founding dates instead of founding locations; dates cannot establish founded in Missouri.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: date vs place (Missouri)",
          "q2: date vs place (Missouri)"
        ]
      },
      {
        "index": 14,
        "question_id": "5abbd34d5542993f40c73bc6",
        "plan_sha256": "337fecf9d9dd18a172629bb32221c5658c5df7ee8ad44fee3e6b2225503c2010",
        "expected_status": "revise",
        "rationale": "q1 reverses the direction: Question says the region is southeast of the river, not the river southeast of the region.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q2:number: in kilometers vs km long"
        ]
      },
      {
        "index": 15,
        "question_id": "5abce1fa5542993a06baf993",
        "plan_sha256": "093baccb24827d474335e5bf85293bf1bb23abeb7b0a914790b706d632c93f3f",
        "expected_status": "valid",
        "rationale": "q1 identifies the lover; q2 asks that person's nationality.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: person vs other"
        ]
      },
      {
        "index": 23,
        "question_id": "5a89bf18554299669944a591",
        "plan_sha256": "dcfe2783a45e2057edee6174c18419036f030437f61869712a36af42986f8456",
        "expected_status": "valid",
        "rationale": "q1/q2 obtain nationalities; q3 compares the named writers' nationalities.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1:other: nationality of John O'Hara vs nationality of John O'Hara",
          "q2:other: nationality of Bobbie Ann Mason vs nationality of Bobbie Ann Mason"
        ]
      },
      {
        "index": 25,
        "question_id": "5add9bfa5542990dbb2f7e85",
        "plan_sha256": "d9b610ae1ac1ebdcb8b055dcbe8fbedb33eb784d00caefc575ccc14c9707d49f",
        "expected_status": "revise",
        "rationale": "q2 changes what type of product the sponsor IS into what product the sponsor PRODUCES.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: person vs organization"
        ]
      },
      {
        "index": 29,
        "question_id": "5a8701b3554299211dda2b9a",
        "plan_sha256": "7115ed219ec197c72c720b67b6506f880a6d2b79ae14d83c592cad55900d7520",
        "expected_status": "revise",
        "rationale": "q3 adds a served-under hop from the politician found in q2, instead of asking that same politician's organization.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q3: organization vs politician"
        ]
      },
      {
        "index": 35,
        "question_id": "5a776b82554299373536026f",
        "plan_sha256": "0d8a88eb0165f7ed506c4f057a1b766938b3d259426280ddbaa1d3c600e0f69e",
        "expected_status": "valid",
        "rationale": "q1 identifies the host country; q2 asks the official currency in that country.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q2: other vs is official currency"
        ]
      },
      {
        "index": 38,
        "question_id": "5ae254565542992decbdccbb",
        "plan_sha256": "2e9d65407099b193d75cdff2249b10349041b94c965c9a60755b5292d31ae3f0",
        "expected_status": "valid",
        "rationale": "q1 identifies the drama's writer; q2 asks their birth year. date includes a year.",
        "old_status": "revise",
        "new_status": "revise",
        "new_errors": [
          "q1: person vs date"
        ]
      }
    ],
    "reason_correctness": "Read each reason against the recorded defect; not scored by string matching.",
    "independent_accuracy_estimate": false
  }
}
```

## 1. 5ab3cecd5542992ade7c6eae

How do the Peter Laufer books Forbidden Creatures and No Animals Were Harmed differ in their focus on animals?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the focus of Forbidden Creatures on animals?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the focus of No Animals Were Harmed on animals?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "How do the Peter Laufer books Forbidden Creatures (focus on animals: {{q1}}) and No Animals Were Harmed (focus on animals: {{q2}}) differ in their focus on animals?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:other | How do the Peter Laufer books Forbidden Creatures (focus on animals: [answer q1:other | What is the focus of Forbidden Creatures on animals?]) and No Animals Were Harmed (focus on animals: [answer q2:other | What is the focus of No Animals Were Harmed on animals?]) differ in their focus on animals?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q3: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q3: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: other vs person, q2: other vs person"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: other vs person, q2: other vs person"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the focus of Forbidden Creatures on animals?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the focus of No Animals Were Harmed on animals?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"How do the Peter Laufer books Forbidden Creatures (focus on animals: {{q1}}) and No Animals Were Harmed (focus on animals: {{q2}}) differ in their focus on animals?","dependencies":{"q1":"other","q2":"other"},"answer_type":"other"}],"final":"q3"}
```

## 2. 5ab42a2b5542996a3a969f5a

What is the name of the historic figure whom participated in surveying the borders of the District of Columbia and had a premier African American recreation center named after him?

Source structure: invalid; old: not_reviewed; new: source_structure_invalid.
New model status: None; source: None; response status: None.

Saved tree (unchanged):
```json
null
```

Old effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is {{q1}} associated with a premier African American recreation center named after them?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who participated in surveying the borders of the District of Columbia?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Is there a premier African American recreation center named after {{q1}}?","dependencies":{"q1":"person"},"answer_type":"boolean"},{"id":"q3","question":"What is the name of this historic figure?","dependencies":{"q1":"person","q2":"boolean"},"answer_type":"person"}],"final":"q3"}
```

## 3. 5a7d3f895542995f4f402248

Pandora- The World of Avatar includes a ride that allows guest to take flight on what animal?

Source structure: valid; old: valid; new: valid.
New model status: valid; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What animal does the ride in Pandora- The World of Avatar allow guests to take flight on?",
      "dependencies": {},
      "answer_type": "work"
    }
  ],
  "final": "q1"
}
```

Composed tree:
```text
[answer q1:work | What animal does the ride in Pandora- The World of Avatar allow guests to take flight on?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "valid", "errors": []}
```

New raw output:
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What animal does the ride in Pandora- The World of Avatar allow guests to take flight on?","dependencies":{},"answer_type":"work"}],"final":"q1"}
```

## 4. 5a778b345542992a6e59decf

Who was born first, Susan Oliver or W. S. Van Dyke?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Susan Oliver born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was W. S. Van Dyke born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:person | Who was born first: Susan Oliver (born [answer q1:date | When was Susan Oliver born?]) or W. S. Van Dyke (born [answer q2:date | When was W. S. Van Dyke born?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:date: when was Susan Oliver born? vs when was the person in question born?", "q2:date: when was W. S. Van Dyke born? vs when was the person in question born?"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:date: when was Susan Oliver born? vs when was the person in question born?","q2:date: when was W. S. Van Dyke born? vs when was the person in question born?"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Susan Oliver born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was W. S. Van Dyke born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Susan Oliver (born {{q1}}) or W. S. Van Dyke (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

## 5. 5a8ceddb554299441c6b9f85

What profession does Nora Roberts and Elizabeth Hardwick have in common?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the profession of Nora Roberts?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What is the profession of Elizabeth Hardwick?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "What profession do Nora Roberts ({{q1}}) and Elizabeth Hardwick ({{q2}}) have in common?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:work | What profession do Nora Roberts ([answer q1:work | What is the profession of Nora Roberts?]) and Elizabeth Hardwick ([answer q2:work | What is the profession of Elizabeth Hardwick?]) have in common?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: What is the profession of Nora Roberts? vs What profession does Nora Roberts and Elizabeth Hardwick have in common?", "q2: What is the profession of Elizabeth Hardwick? vs What profession does Nora Roberts and Elizabeth Hardwick have in common?"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: What is the profession of Nora Roberts? vs What profession does Nora Roberts and Elizabeth Hardwick have in common?","q2: What is the profession of Elizabeth Hardwick? vs What profession does Nora Roberts and Elizabeth Hardwick have in common?"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Nora Roberts?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Elizabeth Hardwick?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"What profession do Nora Roberts ({{q1}}) and Elizabeth Hardwick ({{q2}}) have in common?","dependencies":{"q1":"work","q2":"work"},"answer_type":"work"}],"final":"q3"}
```

## 6. 5a7e05f75542995f4f402394

Which was released first, Hot Girls Wanted or China Blue?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What was the release date of Hot Girls Wanted?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "What was the release date of China Blue?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:work | Which was released first: Hot Girls Wanted (released [answer q1:date | What was the release date of Hot Girls Wanted?]) or China Blue (released [answer q2:date | What was the release date of China Blue?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:date: what was the release date of Hot Girls Wanted? vs when was Hot Girls Wanted released?", "q2:date: what was the release date of China Blue? vs when was China Blue released?"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:date: what was the release date of Hot Girls Wanted? vs when was Hot Girls Wanted released?","q2:date: what was the release date of China Blue? vs when was China Blue released?"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What was the release date of Hot Girls Wanted?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"What was the release date of China Blue?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was released first: Hot Girls Wanted (released {{q1}}) or China Blue (released {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

## 7. 5ab3306a55429969a97a80fd

The movies The Boatniks and The Great Locomotive Chase were both made by which production company?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What production company made The Boatniks?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q2",
      "question": "What production company made The Great Locomotive Chase?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q3",
      "question": "The movies The Boatniks and The Great Locomotive Chase were both made by which production company: {{q1}} or {{q2}}?",
      "dependencies": {
        "q1": "organization",
        "q2": "organization"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:organization | The movies The Boatniks and The Great Locomotive Chase were both made by which production company: [answer q1:organization | What production company made The Boatniks?] or [answer q2:organization | What production company made The Great Locomotive Chase?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:organization: or q2:organization: produces vs made by"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:organization: or q2:organization: produces vs made by"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What production company made The Boatniks?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What production company made The Great Locomotive Chase?","dependencies":{},"answer_type":"organization"},{"id":"q3","question":"The movies The Boatniks and The Great Locomotive Chase were both made by which production company: {{q1}} or {{q2}}?","dependencies":{"q1":"organization","q2":"organization"},"answer_type":"organization"}],"final":"q3"}
```

## 8. 5a7cfb2755429907fabef084

What year did the director of The Quiet American die?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who directed The Quiet American?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "In what year did {{q1}} die?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:date | In what year did [answer q1:person | Who directed The Quiet American?] die?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs date"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs date"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who directed The Quiet American?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"In what year did {{q1}} die?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

## 9. 5ab201765542993be8fa98a4

Hobart Paving is a single by a band formed in which year ?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the name of the band that released the single 'Hobart Paving'?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "In what year was {{q1}} formed?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:date | In what year was [answer q1:work | What is the name of the band that released the single 'Hobart Paving'?] formed?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2:date produces a date rather than a year; the question asks for the year of formation."]}
```

Old raw output:
````text
{"status":"revise","errors":["q2:date produces a date rather than a year; the question asks for the year of formation."]}```
````

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs work"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs work"]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: dependency q1 expects date, but returns work.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the name of the band that released the single 'Hobart Paving'?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In what year was {{q1}} formed?","dependencies":{"q1":"date"},"answer_type":"date"}],"final":"q2"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the name of the band that released the single 'Hobart Paving'?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In what year was {{q1}} formed?","dependencies":{"q1":"work"},"answer_type":"date"}],"final":"q2"}
```

## 10. 5adbe27c55429947ff173854

Which university has more campuses, Dalhousie University or California State Polytechnic University, Pomona?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "How many campuses does Dalhousie University have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "How many campuses does California State Polytechnic University, Pomona have?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Which university has more campuses: Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:organization | Which university has more campuses: Dalhousie University (with [answer q1:number | How many campuses does Dalhousie University have?] campuses) or California State Polytechnic University, Pomona (with [answer q2:number | How many campuses does California State Polytechnic University, Pomona have?] campuses)?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q1: asks about the number of campuses for Dalhousie University instead of comparing both universities.", "q2: asks about the number of campuses for California State Polytechnic University, Pomona instead of comparing both universities."]}
```

Old raw output:
````text
{"status":"revise","errors":["q1: asks about the number of campuses for Dalhousie University instead of comparing both universities.","q2: asks about the number of campuses for California State Polytechnic University, Pomona instead of comparing both universities."]}```
````

New effective verdict:
```json
{"status": "revise", "errors": ["q1: number of campuses for Dalhousie University vs number of campuses for California State Polytechnic University, Pomona"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: number of campuses for Dalhousie University vs number of campuses for California State Polytechnic University, Pomona"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"How many campuses does Dalhousie University have?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"How many campuses does California State Polytechnic University, Pomona have?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which university has more campuses: Dalhousie University (with {{q1}} campuses) or California State Polytechnic University, Pomona (with {{q2}} campuses)?","dependencies":{"q1":"number","q2":"number"},"answer_type":"organization"}],"final":"q3"}
```

## 11. 5a8fa4d95542995b4424207b

Which airport is busier, Palm Springs International Airport or Trenton–Mercer Airport?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the passenger throughput of Palm Springs International Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q2",
      "question": "What is the passenger throughput of Trenton–Mercer Airport?",
      "dependencies": {},
      "answer_type": "number"
    },
    {
      "id": "q3",
      "question": "Which airport is busier, Palm Springs International Airport (with throughput {{q1}}) or Trenton–Mercer Airport (with throughput {{q2}})?",
      "dependencies": {
        "q1": "number",
        "q2": "number"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:place | Which airport is busier, Palm Springs International Airport (with throughput [answer q1:number | What is the passenger throughput of Palm Springs International Airport?]) or Trenton–Mercer Airport (with throughput [answer q2:number | What is the passenger throughput of Trenton–Mercer Airport?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: number vs throughput (passenger throughput)", "q2: number vs throughput (passenger throughput)"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: number vs throughput (passenger throughput)","q2: number vs throughput (passenger throughput)"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the passenger throughput of Palm Springs International Airport?","dependencies":{},"answer_type":"number"},{"id":"q2","question":"What is the passenger throughput of Trenton–Mercer Airport?","dependencies":{},"answer_type":"number"},{"id":"q3","question":"Which airport is busier, Palm Springs International Airport (with throughput {{q1}}) or Trenton–Mercer Airport (with throughput {{q2}})?","dependencies":{"q1":"number","q2":"number"},"answer_type":"place"}],"final":"q3"}
```

## 12. 5ac19ff35542991316484b61

Which was published or broadcast first, The Graveyard Book of Phineas and Ferb?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was The Graveyard Book published?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Phineas and Ferb broadcasted?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:work | Which was published or broadcasted first, The Graveyard Book (published [answer q1:date | When was The Graveyard Book published?]) or Phineas and Ferb (broadcasted [answer q2:date | When was Phineas and Ferb broadcasted?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:date: when published vs when broadcasted", "q2:date: when broadcasted vs when published"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:date: when published vs when broadcasted","q2:date: when broadcasted vs when published"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was The Graveyard Book published?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Phineas and Ferb broadcasted?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which was published or broadcasted first, The Graveyard Book (published {{q1}}) or Phineas and Ferb (broadcasted {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

## 13. 5ab484415542990594ba9c44

Which facility was founded in Missouri, Discovery Zone or Valentino's?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Discovery Zone founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Valentino's founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Which facility (Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})) was founded in Missouri?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "work"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:work | Which facility (Discovery Zone (founded [answer q1:date | When was Discovery Zone founded?]) or Valentino's (founded [answer q2:date | When was Valentino's founded?])) was founded in Missouri?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: date vs place (Missouri)", "q2: date vs place (Missouri)"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: date vs place (Missouri)", "q2: date vs place (Missouri)"]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Discovery Zone founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Valentino's founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which facility (Discovery Zone or Valentino's) was founded in Missouri?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Discovery Zone founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Valentino's founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Which facility (Discovery Zone (founded {{q1}}) or Valentino's (founded {{q2}})) was founded in Missouri?","dependencies":{"q1":"date","q2":"date"},"answer_type":"work"}],"final":"q3"}
```

## 14. 5abbd34d5542993f40c73bc6

The Innviertel is a traditional Austrian region southeast of a river that is how many km long?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which river is southeast of the Innviertel?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?",
      "dependencies": {
        "q1": "other"
      },
      "answer_type": "number"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:number | How long is the river southeast of the Innviertel? ([answer q1:other | Which river is southeast of the Innviertel?]) in kilometers?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: changes the measurement unit from unspecified to kilometers."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: changes the measurement unit from unspecified to kilometers."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2:number: in kilometers vs km long"]}
```

New raw output:
```text
{"status":"revise","errors":["q2:number: in kilometers vs km long"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which river is southeast of the Innviertel?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"How long is the river southeast of the Innviertel? ({{q1}}) in kilometers?","dependencies":{"q1":"other"},"answer_type":"number"}],"final":"q2"}
```

## 15. 5abce1fa5542993a06baf993

What nationality was the lover of Lord Alfred Douglas ? 

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who was the lover of Lord Alfred Douglas?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What is the nationality of {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:other | What is the nationality of [answer q1:person | Who was the lover of Lord Alfred Douglas?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs other"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs other"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who was the lover of Lord Alfred Douglas?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What is the nationality of {{q1}}?","dependencies":{"q1":"person"},"answer_type":"other"}],"final":"q2"}
```

## 16. 5a77a7db5542995d8318124d

Which author was born first, Josephine Tey or Julia Peterkin?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Josephine Tey born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was Julia Peterkin born?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:person | Who was born first: Josephine Tey (born [answer q1:date | When was Josephine Tey born?]) or Julia Peterkin (born [answer q2:date | When was Julia Peterkin born?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:answer: born [answer q1:date | When was Josephine Tey born?] vs born first", "q2:answer: born [answer q2:date | When was Julia Peterkin born?] vs born first"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:answer: born [answer q1:date | When was Josephine Tey born?] vs born first","q2:answer: born [answer q2:date | When was Julia Peterkin born?] vs born first"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Josephine Tey born?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was Julia Peterkin born?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Who was born first: Josephine Tey (born {{q1}}) or Julia Peterkin (born {{q2}})?","dependencies":{"q1":"date","q2":"date"},"answer_type":"person"}],"final":"q3"}
```

## 17. 5abe94fd55429965af743f37

Were both Sinclair Research and the Wave Mate Bullet founded in the 1970s?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "When was Sinclair Research founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q2",
      "question": "When was the Wave Mate Bullet founded?",
      "dependencies": {},
      "answer_type": "date"
    },
    {
      "id": "q3",
      "question": "Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?",
      "dependencies": {
        "q1": "date",
        "q2": "date"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:boolean | Were both Sinclair Research (founded [answer q1:date | When was Sinclair Research founded?]) and the Wave Mate Bullet (founded [answer q2:date | When was the Wave Mate Bullet founded?]) founded in the 1970s?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:date: founded in the 1970s vs founded in the 1970s; q2:date: founded in the 1970s vs founded in the 1970s"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:date: founded in the 1970s vs founded in the 1970s; q2:date: founded in the 1970s vs founded in the 1970s"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"When was Sinclair Research founded?","dependencies":{},"answer_type":"date"},{"id":"q2","question":"When was the Wave Mate Bullet founded?","dependencies":{},"answer_type":"date"},{"id":"q3","question":"Were both Sinclair Research (founded {{q1}}) and the Wave Mate Bullet (founded {{q2}}) founded in the 1970s?","dependencies":{"q1":"date","q2":"date"},"answer_type":"boolean"}],"final":"q3"}
```

## 18. 5a7d598d5542995f4f402262

Which director was also a film editor, Burton L. King or Maheen Zia?

Source structure: invalid; old: not_reviewed; new: source_structure_invalid.
New model status: None; source: None; response status: None.

Saved tree (unchanged):
```json
null
```

Old effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Burton L. King?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Maheen Zia?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Is Burton L. King a film editor?","dependencies":{"q1":"work"},"answer_type":"boolean"},{"id":"q4","question":"Is Maheen Zia a film editor?","dependencies":{"q2":"work"},"answer_type":"boolean"},{"id":"q5","question":"Which director was also a film editor, Burton L. King ({{q3}}) or Maheen Zia ({{q4}})?","dependencies":{"q3":"boolean","q4":"boolean"},"answer_type":"person"}],"final":"q5"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the profession of Burton L. King?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What is the profession of Maheen Zia?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Is Burton L. King a film editor?","dependencies":{"q1":"work"},"answer_type":"boolean"},{"id":"q4","question":"Is Maheen Zia a film editor?","dependencies":{"q2":"work"},"answer_type":"boolean"},{"id":"q5","question":"Which director was also a film editor, Burton L. King ({{q3}}) or Maheen Zia ({{q4}})?","dependencies":{"q3":"boolean","q4":"boolean"},"answer_type":"person"}],"final":"q5"}
```

## 19. 5ae73ddb554299572ea5478d

Hoy Es Manana is by what Mexican Actress and singer, who is the current First Lady of Chiapas State, Mexico?

Source structure: valid; old: revise; new: revise.
New model status: None; source: root_rule; response status: not_called.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the current First Lady of Chiapas State, Mexico?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What Mexican Actress and singer is {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:work | What Mexican Actress and singer is [answer q1:person | Who is the current First Lady of Chiapas State, Mexico?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: original target 'actress' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: original target 'actress' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the current First Lady of Chiapas State, Mexico?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What Mexican Actress and singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

## 20. 5ade5a645542997c77adee0d

Which city is at coastal county-level, Wenling or Ruili?

Source structure: valid; old: valid; new: valid.
New model status: valid; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Is Wenling at coastal county-level?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q2",
      "question": "Is Ruili at coastal county-level?",
      "dependencies": {},
      "answer_type": "boolean"
    },
    {
      "id": "q3",
      "question": "Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?",
      "dependencies": {
        "q1": "boolean",
        "q2": "boolean"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:place | Which city is at coastal county-level, Wenling (at [answer q1:boolean | Is Wenling at coastal county-level?]) or Ruili (at [answer q2:boolean | Is Ruili at coastal county-level?])?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "valid", "errors": []}
```

New raw output:
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: answer_type must be one of ['boolean', 'date', 'number', 'organization', 'other', 'person', 'place', 'work'].
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"city"}],"final":"q3"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Wenling at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Ruili at coastal county-level?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Which city is at coastal county-level, Wenling (at {{q1}}) or Ruili (at {{q2}})?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"place"}],"final":"q3"}
```

## 21. 5a87bc3f5542996432c57275

Which is located farther West, the Cascade Locks and Canal or Lake Worth Lagoon?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What are the coordinates of Cascade Locks and Canal?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What are the coordinates of Lake Worth Lagoon?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Which location is farther West, Cascade Locks and Canal (coordinates {{q1}}) or Lake Worth Lagoon (coordinates {{q2}})?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:place | Which location is farther West, Cascade Locks and Canal (coordinates [answer q1:other | What are the coordinates of Cascade Locks and Canal?]) or Lake Worth Lagoon (coordinates [answer q2:other | What are the coordinates of Lake Worth Lagoon?])?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q3: does not compare the correct locations; should compare Cascade Locks and Canal with Lake Worth Lagoon directly."]}
```

Old raw output:
````text
{"status":"revise","errors":["q3: does not compare the correct locations; should compare Cascade Locks and Canal with Lake Worth Lagoon directly."]}```
````

New effective verdict:
```json
{"status": "revise", "errors": ["q1:other: coordinates vs location", "q2:other: coordinates vs location"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:other: coordinates vs location","q2:other: coordinates vs location"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What are the coordinates of Cascade Locks and Canal?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What are the coordinates of Lake Worth Lagoon?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"Which location is farther West, Cascade Locks and Canal (coordinates {{q1}}) or Lake Worth Lagoon (coordinates {{q2}})?","dependencies":{"q1":"other","q2":"other"},"answer_type":"place"}],"final":"q3"}
```

## 22. 5ae38b115542990afbd1e183

Who played a more important role in the church George Albert Smith or Wong Jing?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What role did George Albert Smith play in the church?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "What role did Wong Jing play in the church?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?",
      "dependencies": {
        "q1": "work",
        "q2": "work"
      },
      "answer_type": "person"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:person | Who played a more important role in the church: George Albert Smith (played [answer q1:work | What role did George Albert Smith play in the church?]) or Wong Jing (played [answer q2:work | What role did Wong Jing play in the church?])?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: played [answer q1:work | What role did George Albert Smith play in the church?] vs played a more important role in the church", "q2: played [answer q2:work | What role did Wong Jing play in the church?] vs played a more important role in the church"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: played [answer q1:work | What role did George Albert Smith play in the church?] vs played a more important role in the church","q2: played [answer q2:work | What role did Wong Jing play in the church?] vs played a more important role in the church"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What role did George Albert Smith play in the church?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"What role did Wong Jing play in the church?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Who played a more important role in the church: George Albert Smith (played {{q1}}) or Wong Jing (played {{q2}})?","dependencies":{"q1":"work","q2":"work"},"answer_type":"person"}],"final":"q3"}
```

## 23. 5a89bf18554299669944a591

Do writers John O'Hara and Bobbie Ann Mason share the same nationality?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the nationality of John O'Hara?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What is the nationality of Bobbie Ann Mason?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q3",
      "question": "Do John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?",
      "dependencies": {
        "q1": "other",
        "q2": "other"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:boolean | Do John O'Hara (nationality [answer q1:other | What is the nationality of John O'Hara?]) and Bobbie Ann Mason (nationality [answer q2:other | What is the nationality of Bobbie Ann Mason?]) share the same nationality?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q1: adds a relation absent from Question.", "q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q1: adds a relation absent from Question.","q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:other: nationality of John O'Hara vs nationality of John O'Hara", "q2:other: nationality of Bobbie Ann Mason vs nationality of Bobbie Ann Mason"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:other: nationality of John O'Hara vs nationality of John O'Hara","q2:other: nationality of Bobbie Ann Mason vs nationality of Bobbie Ann Mason"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the nationality of John O'Hara?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What is the nationality of Bobbie Ann Mason?","dependencies":{},"answer_type":"other"},{"id":"q3","question":"Do John O'Hara (nationality {{q1}}) and Bobbie Ann Mason (nationality {{q2}}) share the same nationality?","dependencies":{"q1":"other","q2":"other"},"answer_type":"boolean"}],"final":"q3"}
```

## 24. 5ae0a5825542993d6555ebdf

Are George Stevens and Luc Besson American cinematographers?

Source structure: invalid; old: not_reviewed; new: source_structure_invalid.
New model status: None; source: None; response status: None.

Saved tree (unchanged):
```json
null
```

Old effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is George Stevens American?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Luc Besson American?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Are George Stevens and Luc Besson American cinematographers?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"boolean"}],"final":"q3"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q3: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is George Stevens American?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Is Luc Besson American?","dependencies":{},"answer_type":"boolean"},{"id":"q3","question":"Are George Stevens and Luc Besson American cinematographers?","dependencies":{"q1":"boolean","q2":"boolean"},"answer_type":"boolean"}],"final":"q3"}
```

## 25. 5add9bfa5542990dbb2f7e85

What type of product is the sponsor of the Premiership Rugby Sevens SeriesSeries ? 

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the sponsor of the Premiership Rugby Sevens Series?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q2",
      "question": "What type of product does {{q1}} produce?",
      "dependencies": {
        "q1": "organization"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:work | What type of product does [answer q1:organization | Who is the sponsor of the Premiership Rugby Sevens Series?] produce?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs organization"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs organization"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the sponsor of the Premiership Rugby Sevens Series?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"What type of product does {{q1}} produce?","dependencies":{"q1":"organization"},"answer_type":"work"}],"final":"q2"}
```

## 26. 5a75a0725542992d0ec05fc9

Disorganized Crime included what cast member best known for playing Al Bundy on the Fox Network sitcom "Married... with Children"?

Source structure: valid; old: valid; new: valid.
New model status: valid; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?",
      "dependencies": {},
      "answer_type": "person"
    }
  ],
  "final": "q1"
}
```

Composed tree:
```text
[answer q1:person | What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "valid", "errors": []}
```

New raw output:
```text
{"status":"valid","errors":[]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What cast member of Disorganized Crime is best known for playing Al Bundy on the Fox Network sitcom 'Married... with Children'?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

## 27. 5ac43e0f554299076e296d8e

What country are both Dafeng District and Jixi in?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What country is Dafeng District in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What country is Jixi in?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "place"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:place | What country are both Dafeng District (in [answer q1:place | What country is Dafeng District in?]) and Jixi (in [answer q2:place | What country is Jixi in?]) in?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: place vs country", "q2: place vs country"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: place vs country","q2: place vs country"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What country is Dafeng District in?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What country is Jixi in?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"What country are both Dafeng District (in {{q1}}) and Jixi (in {{q2}}) in?","dependencies":{"q1":"place","q2":"place"},"answer_type":"place"}],"final":"q3"}
```

## 28. 5a8ea7f25542995085b37468

Are The Limousines and Faith No More from the same state?

Source structure: valid; old: valid; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What state is The Limousines from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What state is Faith No More from?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Are The Limousines and Faith No More from the same state: {{q1}} equals {{q2}}?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:boolean | Are The Limousines and Faith No More from the same state: [answer q1:place | What state is The Limousines from?] equals [answer q2:place | What state is Faith No More from?]?]
```

Old effective verdict:
```json
{"status": "valid", "errors": []}
```

Old raw output:
```text
{"status":"valid","errors":[]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1:place: what state is The Limousines from? vs are The Limousines and Faith No More from the same state?", "q2:place: what state is Faith No More from? vs are The Limousines and Faith No More from the same state?"]}
```

New raw output:
```text
{"status":"revise","errors":["q1:place: what state is The Limousines from? vs are The Limousines and Faith No More from the same state?","q2:place: what state is Faith No More from? vs are The Limousines and Faith No More from the same state?"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What state is The Limousines from?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What state is Faith No More from?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Are The Limousines and Faith No More from the same state: {{q1}} equals {{q2}}?","dependencies":{"q1":"place","q2":"place"},"answer_type":"boolean"}],"final":"q3"}
```

## 29. 5a8701b3554299211dda2b9a

Werner Christie served under the politician who was also Director-General of what other organization?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is Werner Christie?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "Under which politician did {{q1}} serve?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "person"
    },
    {
      "id": "q3",
      "question": "What organization was the politician who {{q2}} served under also the Director-General of?",
      "dependencies": {
        "q2": "person"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:organization | What organization was the politician who [answer q2:person | Under which politician did [answer q1:person | Who is Werner Christie?] serve?] served under also the Director-General of?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q3: organization vs politician"]}
```

New raw output:
```text
{"status":"revise","errors":["q3: organization vs politician"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is Werner Christie?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Under which politician did {{q1}} serve?","dependencies":{"q1":"person"},"answer_type":"person"},{"id":"q3","question":"What organization was the politician who {{q2}} served under also the Director-General of?","dependencies":{"q2":"person"},"answer_type":"organization"}],"final":"q3"}
```

## 30. 5ac3dfee554299204fd21eab

The man known as the voice of "Elgar" voices the English character in what Manga inspired by Keitaro Arima?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the voice actor of Elgar?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What manga is inspired by Keitaro Arima and features an English character voiced by {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:work | What manga is inspired by Keitaro Arima and features an English character voiced by [answer q1:person | Who is the voice actor of Elgar?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs work"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs work"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the voice actor of Elgar?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What manga is inspired by Keitaro Arima and features an English character voiced by {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```

## 31. 5a7f7b3b5542992097ad2f81

Which restaurant chain's headquarters is further north, Pizza Inn or Papa Gino's?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the headquarters location of Pizza Inn?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the headquarters location of Papa Gino's?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q3",
      "question": "Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at {{q1}}) or Papa Gino's (headquartered at {{q2}})?",
      "dependencies": {
        "q1": "place",
        "q2": "place"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:other | Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at [answer q1:place | What is the headquarters location of Pizza Inn?]) or Papa Gino's (headquartered at [answer q2:place | What is the headquarters location of Papa Gino's?])?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q3: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q3: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: place vs coordinates (latitude)", "q2: place vs coordinates (latitude)"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: place vs coordinates (latitude)", "q2: place vs coordinates (latitude)"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the headquarters location of Pizza Inn?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the headquarters location of Papa Gino's?","dependencies":{},"answer_type":"place"},{"id":"q3","question":"Which restaurant chain's headquarters is further north, Pizza Inn (headquartered at {{q1}}) or Papa Gino's (headquartered at {{q2}})?","dependencies":{"q1":"place","q2":"place"},"answer_type":"other"}],"final":"q3"}
```

## 32. 5ae3d2715542990afbd1e1e9

Are Control Room and Meeting Resistance both documentary films that involve Iraq?

Source structure: invalid; old: not_reviewed; new: source_structure_invalid.
New model status: None; source: None; response status: None.

Saved tree (unchanged):
```json
null
```

Old effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are both Control Room and Meeting Resistance documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q2: placeholders and declared dependencies must match exactly.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Is Control Room a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q2","question":"Does Control Room involve Iraq?","dependencies":{"q1":"boolean"},"answer_type":"boolean"},{"id":"q3","question":"Is Meeting Resistance a documentary film?","dependencies":{},"answer_type":"boolean"},{"id":"q4","question":"Does Meeting Resistance involve Iraq?","dependencies":{"q3":"boolean"},"answer_type":"boolean"},{"id":"q5","question":"Are both Control Room and Meeting Resistance documentary films that involve Iraq?","dependencies":{"q2":"boolean","q4":"boolean"},"answer_type":"boolean"}],"final":"q5"}
```

## 33. 5ae077735542993d6555eb6d

What type of sprite did Milada Šubrtová portray in Antonín Dvořák's reknowned opera?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is the name of Antonín Dvořák's renowned opera?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "In {{q1}}, who played the character portrayed by Milada Šubrtová?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "person"
    },
    {
      "id": "q3",
      "question": "What type of sprite did {{q2}} portray?",
      "dependencies": {
        "q2": "person"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:other | What type of sprite did [answer q2:person | In [answer q1:work | What is the name of Antonín Dvořák's renowned opera?], who played the character portrayed by Milada Šubrtová?] portray?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2:person: who played the character portrayed by Milada Šubrtová? vs what type of sprite did Milada Šubrtová portray?"]}
```

New raw output:
```text
{"status":"revise","errors":["q2:person: who played the character portrayed by Milada Šubrtová? vs what type of sprite did Milada Šubrtová portray?"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the name of Antonín Dvořák's renowned opera?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"In {{q1}}, who played the character portrayed by Milada Šubrtová?","dependencies":{"q1":"work"},"answer_type":"person"},{"id":"q3","question":"What type of sprite did {{q2}} portray?","dependencies":{"q2":"person"},"answer_type":"other"}],"final":"q3"}
```

## 34. 5adf4b335542993a75d264a5

Paul DeBoy is known for an appearance in the Western action-adventure game developed by which company?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What is Paul DeBoy known for?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q2",
      "question": "Which company developed the game {{q1}}?",
      "dependencies": {
        "q1": "work"
      },
      "answer_type": "organization"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:organization | Which company developed the game [answer q1:work | What is Paul DeBoy known for?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: organization vs work"]}
```

New raw output:
```text
{"status":"revise","errors":["q2: organization vs work"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is Paul DeBoy known for?","dependencies":{},"answer_type":"work"},{"id":"q2","question":"Which company developed the game {{q1}}?","dependencies":{"q1":"work"},"answer_type":"organization"}],"final":"q2"}
```

## 35. 5a776b82554299373536026f

What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?",
      "dependencies": {},
      "answer_type": "place"
    },
    {
      "id": "q2",
      "question": "What is the official currency in {{q1}}?",
      "dependencies": {
        "q1": "place"
      },
      "answer_type": "other"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:other | What is the official currency in [answer q1:place | Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: other vs is official currency"]}
```

New raw output:
```text
{"status":"revise","errors":["q2: other vs is official currency"]}
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What is the official currency in the country that hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"}],"final":"q1"}
```

#### Attempt 2 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which country hosts the Asahi-Ryokuken Yomiuri Memorial tournament?","dependencies":{},"answer_type":"place"},{"id":"q2","question":"What is the official currency in {{q1}}?","dependencies":{"q1":"place"},"answer_type":"other"}],"final":"q2"}
```

## 36. 5ac0b1835542992a796ded65

Bordan Tkachuk was the former CEO of which company, which provides IT products?

Source structure: valid; old: revise; new: revise.
New model status: None; source: root_rule; response status: not_called.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "What company was Bordan Tkachuk the former CEO of?",
      "dependencies": {},
      "answer_type": "organization"
    },
    {
      "id": "q2",
      "question": "Does {{q1}} provide IT products?",
      "dependencies": {
        "q1": "organization"
      },
      "answer_type": "boolean"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:boolean | Does [answer q1:organization | What company was Bordan Tkachuk the former CEO of?] provide IT products?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: original question requests a name/value, but the final node has a boolean type or asks yes/no. Rewrite its question and type to return the requested name/value, preserving each entity with its property."]}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: original question requests a name/value, but the final node has a boolean type or asks yes/no. Rewrite its question and type to return the requested name/value, preserving each entity with its property."]}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"What company was Bordan Tkachuk the former CEO of?","dependencies":{},"answer_type":"organization"},{"id":"q2","question":"Does {{q1}} provide IT products?","dependencies":{"q1":"organization"},"answer_type":"boolean"}],"final":"q2"}
```

## 37. 5a80afcf554299485f5986b9

Who else beside the  American university administrator and politician from the state of Oklahoma was part of the  Boren-McCurdy proposals?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who were the American university administrators and politicians from Oklahoma?",
      "dependencies": {},
      "answer_type": "other"
    },
    {
      "id": "q2",
      "question": "What are the Boren-McCurdy proposals?",
      "dependencies": {},
      "answer_type": "work"
    },
    {
      "id": "q3",
      "question": "Who else besides {{q1}} was part of the Boren-McCurdy proposals ({{q2}})?",
      "dependencies": {
        "q1": "other",
        "q2": "work"
      },
      "answer_type": "other"
    }
  ],
  "final": "q3"
}
```

Composed tree:
```text
[answer q3:other | Who else besides [answer q1:other | Who were the American university administrators and politicians from Oklahoma?] was part of the Boren-McCurdy proposals ([answer q2:work | What are the Boren-McCurdy proposals?])?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: adds a relation absent from Question."]}
```

Old raw output:
```text
{"status":"revise","errors":["q2: adds a relation absent from Question."]}
```

New effective verdict:
```json
{"status": "revise", "errors": ["q1: other vs person"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: other vs person"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who were the American university administrators and politicians from Oklahoma?","dependencies":{},"answer_type":"other"},{"id":"q2","question":"What are the Boren-McCurdy proposals?","dependencies":{},"answer_type":"work"},{"id":"q3","question":"Who else besides {{q1}} was part of the Boren-McCurdy proposals ({{q2}})?","dependencies":{"q1":"other","q2":"work"},"answer_type":"other"}],"final":"q3"}
```

## 38. 5ae254565542992decbdccbb

In what year was the writer of the drama "Ingenious" born?

Source structure: valid; old: revise; new: revise.
New model status: revise; source: model; response status: parsed.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who wrote the drama \"Ingenious\"?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What is the birth year of {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "date"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:date | What is the birth year of [answer q1:person | Who wrote the drama "Ingenious"?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: changes the question from asking about the birth year to the date."]}
```

Old raw output:
````text
{"status":"revise","errors":["q2: changes the question from asking about the birth year to the date."]}```
````

New effective verdict:
```json
{"status": "revise", "errors": ["q1: person vs date"]}
```

New raw output:
```text
{"status":"revise","errors":["q1: person vs date"]}
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who wrote the drama \"Ingenious\"?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What is the birth year of {{q1}}?","dependencies":{"q1":"person"},"answer_type":"date"}],"final":"q2"}
```

## 39. 5ae14b0655429920d52343a6

Bangalore Naatkal starred which actor and photographer?

Source structure: invalid; old: not_reviewed; new: source_structure_invalid.
New model status: None; source: None; response status: None.

Saved tree (unchanged):
```json
null
```

Old effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "not_reviewed", "errors": []}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

#### Attempt 2 (invalid)

Exact validation error:
```text
q2: each non-root node needs exactly one consumer; no shared or orphan nodes.
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Which actor starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"Which photographer starred in Bangalore Naatkal?","dependencies":{},"answer_type":"person"}],"final":"q1"}
```

## 40. 5ae409d955429970de88d89d

Greetings! We're The Monitors was the debut album by the band who had what soul and R&B singer as their lead?

Source structure: valid; old: revise; new: revise.
New model status: None; source: root_rule; response status: not_called.

Saved tree (unchanged):
```json
{
  "nodes": [
    {
      "id": "q1",
      "question": "Who is the lead singer of the band that released 'Greetings! We're The Monitors'?",
      "dependencies": {},
      "answer_type": "person"
    },
    {
      "id": "q2",
      "question": "What soul and R&B singer is {{q1}}?",
      "dependencies": {
        "q1": "person"
      },
      "answer_type": "work"
    }
  ],
  "final": "q2"
}
```

Composed tree:
```text
[answer q2:work | What soul and R&B singer is [answer q1:person | Who is the lead singer of the band that released 'Greetings! We're The Monitors'?]?]
```

Old effective verdict:
```json
{"status": "revise", "errors": ["q2: original target 'singer' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]}
```

Old raw output:
```text
(no model output)
```

New effective verdict:
```json
{"status": "revise", "errors": ["q2: original target 'singer' requires person, but final answer_type=work. Rewrite its question and type together; retain all original constraints and entity-property links."]}
```

New raw output:
```text
(no model output)
```

### Structure attempts

#### Attempt 1 (valid)

Exact validation error:
```text
(none)
```

Raw model output (unmodified):
```text
{"nodes":[{"id":"q1","question":"Who is the lead singer of the band that released 'Greetings! We're The Monitors'?","dependencies":{},"answer_type":"person"},{"id":"q2","question":"What soul and R&B singer is {{q1}}?","dependencies":{"q1":"person"},"answer_type":"work"}],"final":"q2"}
```
