@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=%~dp0.venv\Scripts\python.exe"
if not exist "%PYTHON%" (
  echo ERROR: .venv not found. Run install_windows.bat first.
  pause
  exit /b 1
)
if not exist logs mkdir logs
if not exist results mkdir results
"%PYTHON%" preload_models.py --verify-only --qwen-only
if errorlevel 1 (
  echo Qwen model is not cached. Run download_models.bat first.
  pause
  exit /b 1
)
"%PYTHON%" main.py --n-samples 40 --use-4bit --max-input-tokens 8500 --max-new-tokens 150 --output-csv results\hotpotqa_qwen25_operadic_rag_results_v3.csv
if errorlevel 1 (
  echo.
  echo Experiment exited with an error. See logs/console output and CSV checkpoint.
  pause
  exit /b 1
)
echo.
echo Experiment completed.
pause
