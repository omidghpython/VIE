@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=%~dp0.venv\Scripts\python.exe"
if not exist "%PYTHON%" (
  echo ERROR: Project virtual environment was not found.
  echo Create it with: py -3.13 -m venv .venv
  pause
  exit /b 1
)
"%PYTHON%" preload_models.py %*
if errorlevel 1 (
  echo.
  echo Model download or verification failed. Read the error above.
  pause
  exit /b 1
)
echo.
echo Model preparation completed.
pause
