"""Modular Standard RAG vs Operadic-Guided RAG experiment."""
__version__ = "1.0.0"
