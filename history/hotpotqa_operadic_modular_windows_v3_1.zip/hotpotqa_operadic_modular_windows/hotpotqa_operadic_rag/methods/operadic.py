"""Typed-tree RAG with one shared second retrieval for all unresolved needs."""
from ..contracts import SLOT_PATTERN, expand_plan
from ..decomposition import decompose_question
from ..retriever import retrieve_round, merge_evidence
from .common import assess_node


def evaluate_tree(llm, plan, evidence):
    answers, expanded, states = {}, {}, []
    for node in plan['nodes']:
        nid = node['id']
        expanded[nid] = SLOT_PATTERN.sub(lambda m: '[' + expanded[m.group(1)] + ']', node['question'])
        missing = [dep for dep in node['dependencies'] if dep not in answers]
        if missing:
            # The downstream need is retained even when its prerequisite is unknown.
            states.append({'id': nid, 'status': 'blocked', 'answer': '', 'missing_dependencies': missing,
                           'question': node['question'], 'missing_query': expanded[nid]})
            continue
        instantiated = SLOT_PATTERN.sub(lambda m: answers[m.group(1)], node['question'])
        result = assess_node(llm, instantiated, node['answer_type'], evidence)
        if result['sufficient']:
            answers[nid] = result['answer']
        states.append({'id': nid, 'status': 'answered' if result['sufficient'] else 'insufficient',
                       'question': instantiated, 'answer': result['answer'],
                       'missing_query': '' if result['sufficient'] else result['missing_query']})
    return {'nodes': states, 'answers': answers, 'sufficient': plan['final'] in answers}


def joint_query(question, needs):
    # One text query -> exactly one retriever.search call. No hidden per-node searches.
    unique = list(dict.fromkeys(text.strip() for text in needs if text.strip()))
    return question + '\nInformation needed:\n' + '\n'.join(unique)


def run_operadic_rag(question, retriever, llm, tracker):
    """Core Method B only. Direct-answer/OC is a separately checkpointed phase."""
    plan, decomposition_trace = decompose_question(llm, question)
    leaves = [node['question'] for node in plan['nodes'] if not node['dependencies']]
    first, retrieval1 = retrieve_round(retriever, joint_query(question, leaves), tracker)
    round1 = evaluate_tree(llm, plan, first)
    evidence, retrieval_trace = list(first), [retrieval1]
    rounds = [round1]
    second_query = ''
    if not round1['sufficient']:
        needs = [node['missing_query'] for node in round1['nodes'] if node['status'] != 'answered']
        second_query = joint_query(question, needs)
        second, retrieval2 = retrieve_round(retriever, second_query, tracker, previous=first)
        evidence = merge_evidence(first, second)
        retrieval_trace.append(retrieval2)
        # Reassess with all six passages, including every independent comparison branch.
        rounds.append(evaluate_tree(llm, plan, evidence))
    final_round = rounds[-1]
    answer = ''
    if final_round['sufficient']:
        answer = llm.answer(question, evidence, trace={'plan': plan, 'node_answers': final_round['answers']})
    return {'answer_decomposed': answer, 'plan': plan, 'expanded_plan': expand_plan(plan),
            'decomposition_trace': decomposition_trace, 'structural_status': 'valid',
            'semantic_status': 'unreviewed', 'node_rounds': rounds,
            'final_evidence_sufficient': final_round['sufficient'],
            'answer_status': 'answered' if answer else 'abstained',
            'stopped_after_first': round1['sufficient'], 'second_query': second_query,
            'evidence_first': first, 'evidence_final': evidence, 'retrieval_trace': retrieval_trace}
