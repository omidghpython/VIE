"""Strict evidence-sufficiency checks. No gold answer or supporting facts enter prompts."""
from ..retriever import format_evidence


def standard_sufficiency_check(llm, question, evidence):
    data = llm.ask_json(
        'Decide whether the evidence contains all facts needed to answer the question. '
        'Use no outside knowledge. If facts are missing, propose a focused follow-up query. '
        'Return JSON: {"is_sufficient": true, "follow_up_query": "..."}\n'
        f'Question:\n{question}\nEvidence:\n{format_evidence(evidence)}')
    if set(data) != {'is_sufficient', 'follow_up_query'} or type(data['is_sufficient']) is not bool or not isinstance(data['follow_up_query'], str):
        raise ValueError('Invalid sufficiency response; no defaults substituted.')
    data['follow_up_query'] = data['follow_up_query'].strip() or question
    return data


def assess_node(llm, question, answer_type, evidence):
    data = llm.ask_json(
        'Using ONLY these passages, decide whether this subquestion is answerable. '
        'If supported, give its short answer; otherwise leave answer empty and describe '
        'the missing information as a search query. Do not guess. '
        'Return JSON: {"sufficient": true, "answer": "...", "missing_query": "..."}\n'
        f'Expected answer type: {answer_type}\nQuestion:\n{question}\nEvidence:\n{format_evidence(evidence)}')
    if set(data) != {'sufficient', 'answer', 'missing_query'} or type(data['sufficient']) is not bool or not all(isinstance(data[k], str) for k in ('answer','missing_query')):
        raise ValueError('Invalid node assessment; no defaults substituted.')
    if data['sufficient'] and not data['answer'].strip():
        raise ValueError('A sufficient node assessment must include a nonempty answer.')
    return {'sufficient': data['sufficient'], 'answer': data['answer'].strip() if data['sufficient'] else '',
            'missing_query': data['missing_query'].strip() or question}
