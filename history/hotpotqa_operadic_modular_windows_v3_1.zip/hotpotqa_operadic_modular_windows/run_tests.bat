@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m unittest discover -s tests -v
) else (
  python -m unittest discover -s tests -v
)
set "TEST_EXIT=%errorlevel%"
pause
exit /b %TEST_EXIT%
