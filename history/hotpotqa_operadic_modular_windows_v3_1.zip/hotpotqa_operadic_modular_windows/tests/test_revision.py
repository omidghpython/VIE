"""Offline behavioral checks; no weights, network, CUDA, or measured QA quality."""
import copy
from contextlib import nullcontext, redirect_stdout, redirect_stderr
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np

from hotpotqa_operadic_rag import telemetry, experiment
from hotpotqa_operadic_rag import cli
from hotpotqa_operadic_rag.checkpoint import RunStore
from hotpotqa_operadic_rag.data import select_balanced, make_passage_corpus
from hotpotqa_operadic_rag.decomposition import decompose_question, DecompositionError
from hotpotqa_operadic_rag.llm import LocalQwen, InputBudgetError, OutputBudgetError, require_short_answer
from hotpotqa_operadic_rag.metrics import evidence_metrics
from hotpotqa_operadic_rag.methods.standard import run_standard_rag
from hotpotqa_operadic_rag.methods.operadic import run_operadic_rag
from hotpotqa_operadic_rag.retriever import retrieve_round, HybridRetriever

PLAN = {'nodes':[
    {'id':'q1','question':'What is the property of Ada?','dependencies':{},'answer_type':'number'},
    {'id':'q2','question':'What is the property of Ben?','dependencies':{},'answer_type':'number'},
    {'id':'q3','question':'Given Ada value {{q1}} and Ben value {{q2}}, which is larger?',
     'dependencies':{'q1':'number','q2':'number'},'answer_type':'person'}], 'final':'q3'}


def sample(qid='bridge_0', kind='bridge'):
    return {'id':qid,'question_id':qid,'type':kind,'question':f'Question {qid}?',
            'answer':'GOLD_NOT_SENT','level':'hard',
            'context':{'title':[f'{qid}_D{i}' for i in range(10)],
                       'sentences':[[f'Paragraph {i} sentence one.',f'Paragraph {i} sentence two.'] for i in range(10)]},
            'supporting_facts':{'title':[f'{qid}_D0',f'{qid}_D4'],'sent_id':[0,1]}}


def dataset(n=30):
    return [sample(f'{kind}_{i}',kind) for kind in ('bridge','comparison') for i in range(n//2)]


class FakeRetriever:
    def __init__(self, s):
        self.passages=make_passage_corpus(s)
        self.encoder=None
        self.calls=[]
    def search(self, query, top_k=3, exclude_indices=()):
        self.calls.append((query,top_k,tuple(exclude_indices)))
        eligible=[p for p in self.passages if p['index'] not in exclude_indices]
        return copy.deepcopy(eligible[:top_k])


class FakeLLM:
    plan_tokens=3072
    def __init__(self, need_second=False, outputs=None, **kwargs):
        self.need_second=need_second
        self.outputs=outputs
        self.prompts=[]
        self.final_evidence=[]
    def count(self):
        tracker=telemetry._ACTIVE_TRACKER
        if tracker:
            tracker.add_generate_invocation(10)
            tracker.add_completion(5)
    def generate(self,messages,max_new_tokens=None):
        self.count();self.prompts.append((copy.deepcopy(messages),max_new_tokens))
        if self.outputs is not None:
            value=self.outputs.pop(0)
            if isinstance(value,Exception):raise value
            return value
        return json.dumps(PLAN)
    def ask_json(self,prompt):
        self.count();self.prompts.append(prompt)
        enough=not self.need_second or prompt.count('[Evidence ') == 6
        if '"is_sufficient"' in prompt:
            return {'is_sufficient':enough,'follow_up_query':'missing facts'}
        target='Ada' if 'property of Ada' in prompt else 'Ben' if 'property of Ben' in prompt else 'comparison'
        return {'sufficient':enough,'answer':'Ada' if enough else '', 'missing_query':'need '+target}
    def answer(self,question,evidence,trace=None):
        self.count();self.final_evidence.append(copy.deepcopy(evidence))
        self.prompts.append({'question':question,'evidence':copy.deepcopy(evidence),'trace':trace})
        return 'Ada'


class DataRetrievalTests(unittest.TestCase):
    def test_balanced_original_ids_stable_order_and_local_ten(self):
        rows=dataset(50)
        selected=select_balanced(rows,40)
        self.assertEqual([r['id'] for r in selected], [r['id'] for r in select_balanced(list(reversed(rows)),40)])
        self.assertEqual(sum(r['type']=='bridge' for r in selected),20)
        self.assertEqual(len({r['question_id'] for r in selected}),40)
        for row in selected:
            corpus=make_passage_corpus(row)
            self.assertEqual(len(corpus),10)
            self.assertTrue(all(p['title'].startswith(row['id']+'_') for p in corpus))
            self.assertNotIn('GOLD_NOT_SENT',json.dumps(corpus))
            self.assertNotIn('supporting_facts',json.dumps(corpus))
    def test_invalid_scope_and_counts_fail(self):
        s=sample();s['context']['title'].pop();s['context']['sentences'].pop()
        with self.assertRaises(ValueError):make_passage_corpus(s)
        for count in (29,31,51):
            with self.assertRaises(ValueError):select_balanced(dataset(60),count)
    def test_first_ranks_ten_second_ranks_seven_and_retains_first_three(self):
        r=FakeRetriever(sample());t=telemetry.TelemetryTracker('test')
        first,a=retrieve_round(r,'first',t)
        second,b=retrieve_round(r,'second',t,first)
        self.assertEqual(a['candidate_indices'],list(range(10)))
        self.assertEqual(b['candidate_indices'],list(range(3,10)))
        self.assertEqual(b['ranked_indices'],list(range(3,10)))
        self.assertEqual(b['excluded_indices'],[0,1,2])
        self.assertEqual(b['retained_indices'],[0,1,2])
        self.assertEqual(b['new_indices'],[3,4,5])
        self.assertEqual(len(first+second),6)
        self.assertEqual(r.calls,[('first',10,()),('second',7,(0,1,2))])
        self.assertEqual(t.retrieval_steps,2)
        with self.assertRaises(RuntimeError):retrieve_round(r,'third',t,first+second)
    def test_first_round_hybrid_scores_all_ten_passages(self):
        r=HybridRetriever.__new__(HybridRetriever)
        r.passages=make_passage_corpus(sample());r.alpha=.6
        r.embeddings=np.asarray([[float(10-i)] for i in range(10)],dtype=np.float32)
        class Encoder:
            def encode(self,*args,**kwargs):return np.asarray([[1]],dtype=np.float32)
        class BM25:
            def get_scores(self,words):return np.arange(10,0,-1)
        r.encoder=Encoder();r.bm25=BM25()
        ranked=r.search('query',10)
        self.assertEqual([p['index'] for p in ranked],list(range(10)))
        self.assertEqual(ranked[0]['hybrid_score'],1.)
        self.assertEqual(ranked[-1]['hybrid_score'],0.)

    def test_second_round_normalizes_only_remaining_seven_before_top_three(self):
        r=HybridRetriever.__new__(HybridRetriever)
        r.passages=make_passage_corpus(sample());r.alpha=.6
        r.embeddings=np.asarray([[1],[1],[1],[.02],[0],[.018],[.016],[.014],[.012],[.010]],dtype=np.float32)
        class Encoder:
            def encode(self,*args,**kwargs):return np.asarray([[1]],dtype=np.float32)
        class BM25:
            def get_scores(self,words):return np.asarray([0,0,0,0,10,9,8,7,6,5])
        r.encoder=Encoder();r.bm25=BM25()
        t=telemetry.TelemetryTracker('test')
        first,_=retrieve_round(r,'first',t)
        self.assertEqual([p['index'] for p in first],[0,1,2])
        # Merely filtering the old all-ten ranking would incorrectly select 4,5,6.
        old_style=[p['index'] for p in r.search('second',10) if p['index'] not in (0,1,2)][:3]
        self.assertEqual(old_style,[4,5,6])
        second,trace=retrieve_round(r,'second',t,first)
        self.assertEqual([p['index'] for p in second],[5,6,7])
        self.assertEqual(len(trace['ranked_indices']),7)
        self.assertEqual({p['index'] for p in first+second},{0,1,2,5,6,7})


class MethodTests(unittest.TestCase):
    def test_standard_uses_three_then_all_six_without_gold(self):
        s=sample();r=FakeRetriever(s);llm=FakeLLM(need_second=True)
        t=telemetry.TelemetryTracker('a')
        with telemetry.activate_tracker(t):result=run_standard_rag(s['question'],r,llm,t)
        self.assertEqual(len(result['evidence_first']),3)
        self.assertEqual(len(llm.final_evidence[0]),6)
        self.assertFalse(result['stopped_after_first'])
        self.assertNotIn('GOLD_NOT_SENT',json.dumps(llm.prompts))
    def test_standard_sufficient_stops_after_first(self):
        r=FakeRetriever(sample());llm=FakeLLM();t=telemetry.TelemetryTracker('a')
        result=run_standard_rag('Q?',r,llm,t)
        self.assertTrue(result['stopped_after_first'])
        self.assertEqual(t.retrieval_steps,1)
        self.assertEqual(len(llm.final_evidence[0]),3)
    def test_shared_second_query_covers_both_branches_and_blocked_root(self):
        r=FakeRetriever(sample());llm=FakeLLM(need_second=True);t=telemetry.TelemetryTracker('b')
        with telemetry.activate_tracker(t):result=run_operadic_rag('Which person?',r,llm,t)
        self.assertEqual(t.retrieval_steps,2)
        self.assertIn('need Ada',r.calls[1][0]);self.assertIn('need Ben',r.calls[1][0])
        self.assertIn('which is larger',r.calls[1][0])
        self.assertEqual(result['node_rounds'][0]['nodes'][2]['status'],'blocked')
        self.assertTrue(result['node_rounds'][1]['sufficient'])
        self.assertEqual(len(result['evidence_final']),6)
        self.assertEqual(len(llm.final_evidence[0]),6)
        self.assertEqual(result['semantic_status'],'unreviewed')
    def test_unresolved_after_second_abstains_without_unknown_substitution(self):
        llm=FakeLLM(need_second=True)
        llm.ask_json=lambda prompt: {'sufficient':False,'answer':'','missing_query':'missing fact'}
        r=FakeRetriever(sample());t=telemetry.TelemetryTracker('b')
        result=run_operadic_rag('Q?',r,llm,t)
        self.assertEqual(result['answer_decomposed'],'')
        self.assertEqual(result['answer_status'],'abstained')
        self.assertEqual(t.retrieval_steps,2)
        self.assertFalse(llm.final_evidence)
    def test_decomposition_repaired_once_and_no_fallback(self):
        llm=FakeLLM(outputs=['{}',json.dumps(PLAN)])
        plan,trace=decompose_question(llm,'Q?')
        self.assertEqual(plan,PLAN);self.assertEqual(len(trace),2)
        self.assertEqual(llm.prompts[0][1],3072)
        self.assertIn('Repair',llm.prompts[1][0][-1]['content'])
        with self.assertRaises(DecompositionError) as cm:decompose_question(FakeLLM(outputs=['{}','not json']),'Q?')
        self.assertEqual(len(cm.exception.details['decomposition_trace']),2)
    def test_backend_error_is_not_structural_retry(self):
        llm=FakeLLM(outputs=[RuntimeError('offline')])
        with self.assertRaises(RuntimeError):decompose_question(llm,'Q?')
        self.assertEqual(len(llm.prompts),1)
    def test_coverage_and_early_stop_sentence_ids(self):
        s=sample();passages=make_passage_corpus(s)
        result={'evidence_first':passages[:3],'evidence_final':passages[:6],'stopped_after_first':False}
        m=evidence_metrics(result,s['supporting_facts'])
        self.assertEqual(m['supporting_fact_coverage_first'],.5)
        self.assertEqual(m['supporting_fact_coverage_final'],1)
        self.assertFalse(m['premature_stopping'])
        result.update(stopped_after_first=True,evidence_final=passages[:3])
        self.assertTrue(evidence_metrics(result,s['supporting_facts'])['premature_stopping'])
        result['evidence_first']=[dict(passages[4],sentence_ids=[0])]
        self.assertEqual(evidence_metrics(result,s['supporting_facts'])['supporting_fact_coverage_first'],0)


class TelemetryTests(unittest.TestCase):
    def tearDown(self):telemetry._ACTIVE_TRACKER=None
    def test_context_and_cleanup_on_error(self):
        t=telemetry.TelemetryTracker('test')
        with self.assertRaisesRegex(RuntimeError,'boom'):
            with telemetry.activate_tracker(t):
                self.assertIs(telemetry._ACTIVE_TRACKER,t)
                raise RuntimeError('boom')
        self.assertIsNone(telemetry._ACTIVE_TRACKER)
        with telemetry.activate_tracker(t):pass
    def test_cleanup_when_stop_raises_and_nested_rejection(self):
        t=telemetry.TelemetryTracker('test')
        with telemetry.activate_tracker(t):
            with self.assertRaisesRegex(RuntimeError,'nested'):
                with telemetry.activate_tracker(telemetry.TelemetryTracker('other')):pass
            self.assertIs(telemetry._ACTIVE_TRACKER,t)
        with patch.object(t,'stop',side_effect=RuntimeError('sync failed')):
            with self.assertRaises(RuntimeError):
                with telemetry.activate_tracker(t):pass
        self.assertIsNone(telemetry._ACTIVE_TRACKER)
    def test_generate_counts_success_and_failure(self):
        model=types.SimpleNamespace(generate=lambda **kw:np.zeros((1,5),dtype=int))
        telemetry.install_generate_wrapper(model)
        tracker=telemetry.TelemetryTracker('test')
        with telemetry.activate_tracker(tracker):model.generate(input_ids=np.zeros((1,3)))
        self.assertEqual(tracker.llm_calls,1);self.assertEqual(tracker.completion_tokens,2)
        def fail(**kw):raise RuntimeError('generation failed')
        model=types.SimpleNamespace(generate=fail);telemetry.install_generate_wrapper(model)
        with self.assertRaises(RuntimeError):
            with telemetry.activate_tracker(tracker):model.generate(input_ids=np.zeros((1,3)))
        self.assertEqual(tracker.llm_calls,1);self.assertEqual(tracker.prompt_tokens,3)
        self.assertEqual(tracker.completion_tokens,0)


class BudgetTests(unittest.TestCase):
    def make_llm(self,n_input=10,truncate=False):
        obj=LocalQwen.__new__(LocalQwen)
        obj.max_input_tokens=8500;obj.max_new_tokens=150;obj.intermediate_tokens=512;obj.plan_tokens=3072
        class Tensor:
            shape=(1,n_input)
            def to(self,device):return self
        class Tokenizer:
            eos_token_id=2;pad_token_id=2
            def apply_chat_template(self,*args,**kwargs):return 'prompt'
            def __call__(self,*args,**kwargs):
                self.kwargs=kwargs
                return {'input_ids':Tensor()}
            def decode(self,*args,**kwargs):return '{"value":true}'
        obj.tokenizer=Tokenizer();obj.calls=[]
        def generate(**kw):
            obj.calls.append(kw)
            new=[1]*kw['max_new_tokens'] if truncate else [1,2]
            return np.asarray([[0]*n_input+new])
        obj.model=types.SimpleNamespace(config=types.SimpleNamespace(max_position_embeddings=32768),
            get_input_embeddings=lambda:types.SimpleNamespace(weight=types.SimpleNamespace(device='cpu')),generate=generate)
        return obj
    def test_separate_budgets_and_no_input_truncation(self):
        obj=self.make_llm()
        with patch.dict(sys.modules,{'torch':types.SimpleNamespace(inference_mode=nullcontext)}):
            obj.generate([]);obj.ask_json('question');obj.generate([],max_new_tokens=obj.plan_tokens)
        self.assertEqual([c['max_new_tokens'] for c in obj.calls],[150,512,3072])
        self.assertFalse(obj.tokenizer.kwargs['truncation'])
    def test_oversized_input_fails_before_generate(self):
        obj=self.make_llm(n_input=8501)
        with patch.dict(sys.modules,{'torch':types.SimpleNamespace(inference_mode=nullcontext)}), self.assertRaises(InputBudgetError):obj.generate([])
        self.assertEqual(obj.calls,[])
    def test_truncated_output_and_overlong_answer_rejected(self):
        obj=self.make_llm(truncate=True)
        with patch.dict(sys.modules,{'torch':types.SimpleNamespace(inference_mode=nullcontext)}), self.assertRaises(OutputBudgetError):obj.generate([])
        with self.assertRaises(ValueError):require_short_answer('one two three four five six')
        self.assertEqual(require_short_answer('one two three four five'),'one two three four five')


class ResumeTests(unittest.TestCase):
    def run_fake(self,path,**changes):
        kwargs=dict(n_samples=30,output_csv=str(path))
        kwargs.update(changes)
        with patch.object(experiment,'load_hotpotqa',return_value=dataset()), \
             patch.object(experiment,'check_runtime'),patch.object(experiment,'set_seed'), \
             patch.object(experiment,'LocalQwen',side_effect=lambda **kw:FakeLLM(**kw)), \
             patch.object(experiment,'build_question_retrievers',side_effect=lambda rows:{s['question_id']:FakeRetriever(s) for s in rows}), \
             redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
            return experiment.run_experiment(**kwargs)
    def test_finished_run_skips_dataset_and_models_and_recovers_csv(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'results.csv'
            df=self.run_fake(path)
            self.assertTrue(df.attrs['run_complete']);self.assertEqual(len(df),30)
            self.assertTrue((df['std_supporting_fact_coverage_first']==.5).all())
            self.assertTrue(df['std_premature_stopping'].all())
            path.unlink()
            with patch.object(experiment,'load_hotpotqa',side_effect=AssertionError('dataset reload')), \
                 patch.object(experiment,'LocalQwen',side_effect=AssertionError('model reload')),redirect_stdout(io.StringIO()):
                again=experiment.run_experiment(n_samples=30,output_csv=str(path))
            self.assertTrue(again.attrs['run_complete']);self.assertTrue(path.exists())
    def test_interrupt_after_a_does_not_repeat_a_on_resume(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'results.csv'
            with patch.object(experiment,'run_operadic_rag',side_effect=KeyboardInterrupt), self.assertRaises(KeyboardInterrupt):self.run_fake(path)
            recordpath=path.with_name(path.name+'.state')/'questions'/'bridge_0.json'
            before=json.loads(recordpath.read_text())
            self.assertEqual(before['phases']['standard']['status'],'completed')
            self.assertEqual(before['phases']['operadic']['status'],'interrupted')
            df=self.run_fake(path)
            after=json.loads(recordpath.read_text())
            self.assertEqual(before['phases']['standard'],after['phases']['standard'])
            self.assertEqual(len(after['phases']['operadic']['history']),2)
            self.assertTrue(df.attrs['run_complete'])
    def test_oc_only_resume_preserves_both_core_phases(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'results.csv'
            with patch.object(experiment,'_oc_result',side_effect=RuntimeError('OC failure')):df=self.run_fake(path)
            self.assertFalse(df.attrs['run_complete'])
            state=path.with_name(path.name+'.state')/'questions'/'bridge_0.json'
            before=json.loads(state.read_text())
            with patch.object(experiment,'run_standard_rag',side_effect=AssertionError('A repeated')), \
                 patch.object(experiment,'run_operadic_rag',side_effect=AssertionError('B repeated')):
                resumed=self.run_fake(path)
            after=json.loads(state.read_text())
            self.assertTrue(resumed.attrs['run_complete'])
            for phase in ('standard','operadic'):self.assertEqual(before['phases'][phase],after['phases'][phase])
            self.assertEqual(len(after['phases']['oc']['history']),2)
    def test_settings_mismatch_and_unowned_csv_preserved(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'results.csv';self.run_fake(path);before=path.read_bytes()
            with self.assertRaisesRegex(ValueError,'settings/code'):self.run_fake(path,max_new_tokens=151)
            self.assertEqual(path.read_bytes(),before)
            legacy=Path(root)/'legacy.csv';legacy.write_text('keep me')
            with self.assertRaisesRegex(ValueError,'not be overwritten'):self.run_fake(legacy)
            self.assertEqual(legacy.read_text(),'keep me')
    def test_both_fail_are_not_reported_as_success_or_premature(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(experiment,'run_standard_rag',side_effect=RuntimeError('A failed')), \
                 patch.object(experiment,'run_operadic_rag',side_effect=RuntimeError('B failed')):
                df=self.run_fake(Path(root)/'failed.csv')
            self.assertFalse(df.attrs['run_complete'])
            self.assertTrue((df['std_status']=='failed').all())
            self.assertTrue((df['operadic_status']=='failed').all())
            self.assertTrue(df['std_premature_stopping'].isna().all())
            self.assertTrue(df['operadic_premature_stopping'].isna().all())
    def test_invalid_decomposition_trace_survives_failure(self):
        with tempfile.TemporaryDirectory() as root:
            error=DecompositionError('invalid',[{'attempt':1,'status':'invalid'},{'attempt':2,'status':'invalid'}])
            with patch.object(experiment,'run_operadic_rag',side_effect=error):
                df=self.run_fake(Path(root)/'badplan.csv')
            self.assertEqual(len(json.loads(df.iloc[0]['decomposition_trace'])),2)
            self.assertFalse(df.attrs['run_complete'])


class CLITests(unittest.TestCase):
    def test_defaults_and_windows_launcher_match_requested_budgets(self):
        args=cli.build_arg_parser().parse_args([])
        self.assertEqual((args.n_samples,args.max_input_tokens,args.max_new_tokens),(40,8500,150))
        self.assertEqual((args.intermediate_tokens,args.plan_tokens),(512,3072))
        launcher=(Path(__file__).resolve().parents[1]/'run_windows.bat').read_text()
        self.assertIn('--max-input-tokens 8500 --max-new-tokens 150',launcher)
    def test_failed_run_returns_nonzero_exit(self):
        for complete,code in ((True,0),(False,2)):
            result=types.SimpleNamespace(attrs={'run_complete':complete})
            with patch.object(sys,'argv',['main.py']),patch.object(cli,'run_experiment',return_value=result),self.assertRaises(SystemExit) as cm:
                cli.main()
            self.assertEqual(cm.exception.code,code)


if __name__=='__main__':unittest.main()
