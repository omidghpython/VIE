import copy
import json
import unittest
from hotpotqa_operadic_rag.contracts import validate_plan
from hotpotqa_operadic_rag.decomposition import generate_plan, DecompositionError


class Model:
    def __init__(self, replies): self.replies, self.messages = list(replies), []
    def generate(self, messages, **kwargs):
        self.messages.append(copy.deepcopy(messages)); return json.dumps(self.replies.pop(0))


class StructureMessagesTests(unittest.TestCase):
    def tree(self, text, deps):
        return dict(nodes=[dict(id='q1', question='Who wrote Alpha?', answer_type='person', dependencies={}),
                           dict(id='q2', question=text, answer_type='place', dependencies=deps)], final='q2')

    def test_missing_declaration_names_slot(self):
        tree = self.tree('Where was {{q1}} born?', {})
        before = copy.deepcopy(tree)
        with self.assertRaisesRegex(ValueError, "Slots without dependency declarations: \\['q1'\\]"):
            validate_plan(tree)
        self.assertEqual(tree, before)

    def test_missing_slot_names_dependency(self):
        with self.assertRaisesRegex(ValueError, "declared dependencies without question slots: \\['q1'\\]"):
            validate_plan(self.tree('Where was the author born?', {'q1':'person'}))

    def test_both_sides_are_distinguished(self):
        with self.assertRaises(ValueError) as c:
            validate_plan(self.tree('Where was {{q3}} born?', {'q1':'person'}))
        self.assertIn("Slots without dependency declarations: ['q3']", str(c.exception))
        self.assertIn("declared dependencies without question slots: ['q1']", str(c.exception))

    def test_cap_guidance_preserves_constraints(self):
        with self.assertRaises(ValueError) as c:
            validate_plan({'nodes':[{}]*5,'final':'q5'})
        for phrase in ['same entity', 'ALL qualifiers', 'different entities']:
            self.assertIn(phrase, str(c.exception))

    def test_empty_plan_does_not_get_merge_advice(self):
        with self.assertRaises(ValueError) as c: validate_plan({'nodes':[],'final':'q1'})
        self.assertEqual(str(c.exception), 'Plan must contain 1..4 nodes.')

    def test_error_enters_second_prompt_without_silent_repair(self):
        bad = self.tree('Where was {{q1}} born?', {})
        good = self.tree('Where was {{q1}} born?', {'q1':'person'})
        model = Model([bad, good])
        result, trace = generate_plan(model, 'Where was the writer of Alpha born?')
        self.assertEqual(result, good)
        self.assertIn("Slots without dependency declarations: ['q1']", model.messages[1][1]['content'])
        self.assertEqual(json.loads(trace[0]['raw_output']), bad)
        self.assertEqual(len(model.messages), 2)

    def test_two_attempt_budget_unchanged(self):
        model = Model([self.tree('Where was {{q1}} born?', {})] * 2)
        with self.assertRaises(DecompositionError): generate_plan(model, 'Where was the writer born?')
        self.assertEqual(len(model.messages), 2)
