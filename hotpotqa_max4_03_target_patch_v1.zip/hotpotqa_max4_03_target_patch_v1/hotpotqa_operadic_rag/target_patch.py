"""Experimental final-node patch, within the original two-generation budget.

This is a pilot-only intervention. It never changes graph topology or silently
repairs dependencies. Lexical retention is conservative, not a semantic proof.
"""
from copy import deepcopy
import json
import re
from .contracts import parse_json_object, validate_plan
from .config import MAX_PLAN_NODES, PLAN_ATTEMPTS, DEFAULT_PLAN_TOKENS
from .decomposition import root_answer_check


PATCH_SYSTEM = '''Repair only the final question and its answer_type in the supplied tree.
Return exactly one JSON object: {"question":"...", "answer_type":"..."}.
Allowed types: person, organization, place, date, number, work, boolean, other.
Return the original question's requested entity/value, not a yes/no test.
Preserve every qualifier, relation, named entity and literal {{qX}} slot already in the final question.
Keep each slot exactly once. You cannot change IDs, dependencies, other nodes or the final node ID.
Use the supplied target error. If the fixed graph cannot support a correct answer, do not invent facts.
No explanation or additional JSON keys.'''

STOP = set('what which who whom is are was were be been being do does did has have had '
           'a an the name yes no whether'.split())


def content_words(text):
    text = re.sub(r'\{\{q\d+\}\}', '', text.casefold())
    # Permit simple inflection changes such as provide/provides without deleting content.
    return {w[:-1] if len(w) > 4 and w.endswith('s') else w
            for w in re.findall(r"[a-z0-9]+", text) if w not in STOP}


def maybe_patch(llm, question, plan, trace, *, enabled):
    before = root_answer_check(question, plan)
    meta = dict(enabled=enabled, attempted=False, status='disabled' if not enabled else 'not_needed',
                root_before=before, root_after=before, changed=False,
                scope='final question/type only; lexical retention is not semantic certification')
    if not enabled or before['status'] != 'mismatch':
        return plan, trace, meta
    if len(trace) >= PLAN_ATTEMPTS:
        meta['status'] = 'budget_exhausted'
        return plan, trace, meta
    root = next(n for n in plan['nodes'] if n['id'] == plan['final'])
    messages = [{'role': 'system', 'content': PATCH_SYSTEM}, {'role': 'user', 'content':
        json.dumps(dict(original_question=question, tree=plan, target_error=before), ensure_ascii=False)}]
    raw = llm.generate(messages, max_new_tokens=getattr(llm, 'plan_tokens', DEFAULT_PLAN_TOKENS))
    event = dict(stage='target_root_patch', attempt=len(trace) + 1, raw_output=raw,
                 messages=messages, root_before=before)
    meta['attempted'] = True
    try:
        patch = parse_json_object(raw)
        if set(patch) != {'question', 'answer_type'}:
            raise ValueError('Patch must contain exactly question and answer_type; graph changes are forbidden.')
        candidate = deepcopy(plan)
        candidate_root = next(n for n in candidate['nodes'] if n['id'] == candidate['final'])
        candidate_root.update(patch)
        candidate = validate_plan(candidate, max_nodes=MAX_PLAN_NODES)
        missing = sorted(content_words(root['question']) - content_words(patch['question']))
        if missing:
            raise ValueError('Conservative retention guard: removed original root content words: ' + ', '.join(missing))
        after = root_answer_check(question, candidate)
        event['candidate_root_contract'] = after
        if after['status'] == 'mismatch':
            raise ValueError('Target mismatch remains: ' + '; '.join(after['errors']))
        expected = (before.get('expected_target') or {}).get('type')
        if expected and expected != 'other':
            if patch['answer_type'] != expected or (after.get('root_question_target') or {}).get('type') != expected:
                raise ValueError('Patch must explicitly identify the expected target in both question and answer_type; an unspecified other target is not enough.')
    except (ValueError, TypeError) as exc:
        event.update(status='rejected', error=str(exc))
        meta.update(status='rejected', reason=str(exc))
        # Preserve the valid original plan; preserve the rejected proposal in trace.
    else:
        plan = candidate
        event.update(status='accepted', error='', root_contract=after)
        meta.update(status='accepted', changed=True, root_after=after)
    return plan, [*trace, event], meta
