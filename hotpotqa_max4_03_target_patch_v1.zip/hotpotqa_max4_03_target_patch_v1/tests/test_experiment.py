import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout
from hotpotqa_operadic_rag.semantic_checks import answer_target
from hotpotqa_operadic_rag.decomposition import plan_instructions, PLAN_SYSTEM
from hotpotqa_operadic_rag.target_patch import maybe_patch
from hotpotqa_operadic_rag import telemetry
from hotpotqa_operadic_rag.contracts import parse_json_object
import decomposition_pilot as pilot

Q = 'Ari was the former CEO of which company, which provides IT products?'
TREE = dict(nodes=[dict(id='q1', question='What company was Ari the former CEO of?', answer_type='organization', dependencies={}),
                  dict(id='q2', question='Does {{q1}} provide IT products?', answer_type='boolean', dependencies={'q1':'organization'})], final='q2')
GOOD = dict(question='Which company is {{q1}} that provides IT products?', answer_type='organization')


class Model:
    plan_tokens = 3072
    last_raw_output = None
    def __init__(self, replies): self.replies, self.messages = list(replies), []
    def generate(self, messages, **kwargs):
        self.messages.append(copy.deepcopy(messages))
        if telemetry._ACTIVE_TRACKER:
            telemetry._ACTIVE_TRACKER.add_generate_invocation(10)
            telemetry._ACTIVE_TRACKER.add_completion(5)
        reply = self.replies.pop(0)
        self.last_raw_output = reply if isinstance(reply, str) else json.dumps(reply)
        return self.last_raw_output
    def ask_json(self, prompt): return parse_json_object(self.generate([{'role':'user','content':prompt}]))


class TargetExperimentTests(unittest.TestCase):
    def test_category_extraction(self):
        for text, head in [('What type of sprite did Ari portray?', 'type of sprite'),
                           ('Which kind of product is the sponsor?', 'kind of product'),
                           ('What sort of material is this?', 'sort of material')]:
            with self.subTest(text=text): self.assertEqual(answer_target(text), {'type':'other','head':head})

    def test_category_hint(self):
        self.assertEqual(plan_instructions('What type of sprite did Ari portray?'), PLAN_SYSTEM + '\nFinal target: type of sprite (other).')

    def test_existing_mid_sentence_targets(self):
        for text, kind in [('Album is by what Mexican actress?', 'person'), (Q, 'organization'),
                           ('The band had what soul singer as their lead?', 'person')]:
            with self.subTest(text=text): self.assertEqual(answer_target(text)['type'], kind)

    def test_possessive_multiword_unsupported_and_other_typed_targets_unchanged(self):
        for question in ["What type of sprite's costume is red?", 'What type of rare sprite is that?', 'What type of company is this?']:
            with self.subTest(question=question): self.assertEqual(answer_target(question), {'type':'other','head':'type'})

    def test_quoted_category_not_target(self):
        self.assertEqual(answer_target('"What type of sprite" is by what actor?'), {'type':'person','head':'actor'})

    def test_patch_accepts_only_final_text_and_type(self):
        model = Model([TREE, GOOD]); before = copy.deepcopy(TREE)
        result = pilot.generate_result(model, Q, target_repair=True)
        self.assertEqual(result['target_patch']['status'], 'accepted')
        self.assertEqual(len(model.messages), 2)
        self.assertEqual(TREE, before)
        candidate = copy.deepcopy(result['plan']); candidate['nodes'][-1].update({k:TREE['nodes'][-1][k] for k in GOOD})
        self.assertEqual(candidate, TREE)
        event = result['decomposition_trace'][1]
        self.assertEqual(event['messages'], model.messages[1])
        self.assertEqual(json.loads(event['raw_output']), GOOD)

    def test_rejected_patch_keeps_original_and_trace(self):
        for patch in ['not JSON', {'nodes':[]}, dict(question='Which company is {{q1}}?', answer_type='organization'),
                      dict(question='Which company provides IT products?', answer_type='organization'),
                      dict(question='Does {{q1}} provide IT products?', answer_type='boolean'),
                      dict(question=42, answer_type='organization')]:
            with self.subTest(patch=patch):
                result = pilot.generate_result(Model([TREE,patch]), Q, target_repair=True)
                self.assertEqual(result['plan'], TREE)
                self.assertEqual(result['target_patch']['status'], 'rejected')
                self.assertTrue(result['decomposition_trace'][1]['error'])

    def test_second_structural_attempt_exhausts_budget(self):
        model = Model([{'nodes':[],'final':'q1'}, TREE])
        result = pilot.generate_result(model, Q, target_repair=True)
        self.assertEqual(len(model.messages), 2)
        self.assertEqual(result['target_patch']['status'], 'budget_exhausted')
        self.assertEqual(result['plan'], TREE)

    def test_patch_cannot_hide_target_in_other_type(self):
        bad = dict(GOOD, answer_type='other')
        result = pilot.generate_result(Model([TREE, bad]), Q, target_repair=True)
        self.assertEqual(result['plan'], TREE)
        self.assertEqual(result['target_patch']['status'], 'rejected')

    def test_patch_must_explicitly_request_target_in_question(self):
        bad = dict(question='What is {{q1}} that provides IT products?', answer_type='organization')
        result = pilot.generate_result(Model([TREE, bad]), Q, target_repair=True)
        self.assertEqual(result['plan'], TREE)
        self.assertEqual(result['target_patch']['status'], 'rejected')

    def test_disabled_no_extra_call(self):
        model = Model([TREE]); result = pilot.generate_result(model, Q)
        self.assertEqual(len(model.messages), 1); self.assertNotIn('target_patch', result)

    def test_compatible_root_no_extra_call(self):
        tree = copy.deepcopy(TREE); tree['nodes'][-1].update(GOOD)
        model = Model([tree]); result = pilot.generate_result(model, Q, target_repair=True)
        self.assertEqual(len(model.messages), 1); self.assertEqual(result['target_patch']['status'], 'not_needed')

    def test_failed_patch_is_not_success(self):
        result = pilot.generate_result(Model([TREE, dict(question='Which company is {{q1}}?',answer_type='organization')]), Q, target_repair=True)
        self.assertEqual(result['target_patch']['root_after']['status'], 'mismatch')
        self.assertFalse(result['target_patch']['changed'])

    def test_end_to_end_telemetry_bundle_resume_and_mode_isolation(self):
        samples=[dict(question_id='synthetic', question=Q, type='bridge', answer='DO_NOT_USE_GOLD')]
        model=Model([TREE,GOOD,dict(status='valid',errors=[])])
        with tempfile.TemporaryDirectory() as tmp, redirect_stdout(io.StringIO()):
            output=Path(tmp)/'repair'
            factory=lambda settings:(model,dict(backend='synthetic'))
            summary=pilot.run_pilot(samples,{},output,model_factory=factory,target_repair=True)
            self.assertEqual(summary['target_patch_status'], {'accepted':1})
            self.assertEqual(summary['total_cost']['llm_calls'],3) # two generation + one judge
            self.assertNotIn('DO_NOT_USE_GOLD',json.dumps(model.messages))
            self.assertTrue((Path(tmp)/'repair_results.zip').is_file())
            pilot.run_pilot(samples,{},output,model_factory=factory,target_repair=True)
            self.assertEqual(len(model.messages),3)
            with self.assertRaises(ValueError):
                pilot.run_pilot(samples,{},output,model_factory=factory,target_repair=False)
